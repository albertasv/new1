ALTER TABLE "AO_D46467_USER_INFO"
    ADD COLUMN "CALENDAR_SYNC" boolean;
ALTER TABLE "AO_D46467_USER_INFO"
    ADD COLUMN "PLANNING_ISSUE" varchar(255);

CREATE TABLE "AO_D46467_TEMPO_APPOINTMENT"
(
    "ID"          serial not null
        constraint "AO_D46467_TEMPO_APPOINTMENT_pkey" primary key,
    "EXCHANGE_ID" varchar(255),
    "TEMPO_ID"    varchar(255),
    "LAST_UPDATED_BY" varchar(255) not null,
    "LAST_UPDATE_DATE" timestamp not null
);