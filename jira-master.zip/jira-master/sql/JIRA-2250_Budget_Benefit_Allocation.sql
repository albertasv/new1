ALTER TABLE "AO_2E196D_INTERNAL_BUDGET" ADD "INITIAL" boolean;
ALTER TABLE "AO_2E196D_EXTERNAL_BUDGET" ADD "INITIAL" boolean;

create table "AO_2E196D_BENEFIT"
(
    "ID" serial not null constraint "AO_2E196D_BENEFIT_pkey" primary key,
    "CATEGORY" varchar(255),
    "BENEFIT_DATE" timestamp,
    "BENEFIT_VALUE" double precision default 0.0,
    "ISSUE" varchar(255) not null,
    "LAST_UPDATED_BY" varchar(255) not null,
    "LAST_UPDATE_DATE" timestamp not null,
    "INITIAL" boolean
);
alter table "AO_2E196D_BENEFIT" owner to jirauser;

create table "AO_2E196D_ALLOCATION"
(
    "ID" serial not null constraint "AO_2E196D_ALLOCATION_pkey" primary key,
    "DOMAIN" varchar(255),
    "ALLOCATION_TYPE" varchar(255),
    "ALLOCATION_VALUE" double precision default 0.0,
    "ISSUE" varchar(255) not null,
    "LAST_UPDATED_BY" varchar(255) not null,
    "LAST_UPDATE_DATE" timestamp not null,
    "INITIAL" boolean
);

alter table "AO_2E196D_ALLOCATION" owner to jirauser;