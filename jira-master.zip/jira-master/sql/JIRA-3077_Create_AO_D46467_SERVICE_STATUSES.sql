CREATE TABLE "AO_D46467_SERVICE_STATUSES"
(
	"ID" serial not null constraint "AO_D46467_SERVICE_STATUSES_pkey" primary key,
    "SERVICE_NAME" varchar(255),
    "MESSAGE" text,
    "STATUS" varchar(255),
    "LAST_UPDATE_DATE" timestamp not null
);