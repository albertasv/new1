SELECT CONCAT(p.pkey, '-', i.issuenum) "Issue Key",
       it.pname "Issue Type",
       ist.pname "Current Status",
       cfv_sprint.STRINGVALUE Sprint,
       convert(varchar, plan_status.plan_start_date, 120) "Planning Start Date",
       convert(varchar, release_status.release_start_date, 120) "Release Start Date",
       DATEDIFF(DAY, plan_status.plan_start_date, release_status.release_start_date) TTM
FROM jiraissue i
  INNER JOIN project p ON p.ID = i.PROJECT
  INNER JOIN issuetype it ON i.issuetype = it.ID
  INNER JOIN issuestatus ist ON ist.ID = i.issuestatus
  LEFT JOIN customfieldvalue cfv_sprint ON cfv_sprint.ISSUE = I.ID AND cfv_sprint.CUSTOMFIELD = 11004
--  Статус: Открыто[12911] -> Планирование[10110]
  LEFT JOIN (
    SELECT cg.issueid, MIN(cg.created) plan_start_date
    FROM changeitem ci
      LEFT JOIN changegroup cg ON ci.groupid = cg.id
WHERE ci.field = 'status' AND CONVERT(nvarchar(max), ci.OLDVALUE) = '12911'
  AND CONVERT(nvarchar(max), ci.NEWVALUE) = '10110'
    GROUP BY cg.issueid) plan_status ON plan_status.issueid = i.ID
--  Статус: UAT пройден[10304] - > Подготовка релиза[10006]
  LEFT JOIN (
    SELECT cg.issueid, MIN(cg.created) release_start_date
    FROM changeitem ci
      LEFT JOIN changegroup cg ON ci.groupid = cg.id
    WHERE ci.field = 'status' AND CONVERT(nvarchar(max), ci.OLDVALUE) = '10304'
      AND CONVERT(nvarchar(max), ci.NEWVALUE) = '10006'
    GROUP BY cg.issueid) release_status ON release_status.issueid = i.ID
WHERE p.pkey = 'AGP'
  -- Issue Type: 'Задача на разработку';
  AND it.ID = 10112
ORDER BY i.issuenum;