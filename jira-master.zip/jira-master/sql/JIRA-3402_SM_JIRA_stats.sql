-- By project stats
select p.pname || ' (' || p.pkey || ')' project, count(i.id)
from jiraissue i
         join project p on p.id = i.project
         join customfieldvalue cfv_source on cfv_source.issue = i.id
    and cfv_source.customfield = (select id from customfield where cfname = 'Issue Source')
    and cfv_source.stringvalue = 'SM'
group by p.pname, p.pkey
order by p.pname;

-- By project and status stats
select p.pname || ' (' || p.pkey || ')' project, ist.pname status, count(i.id)
from jiraissue i
         join project p on p.id = i.project
         join issuestatus ist on ist.id = i.issuestatus
         join customfieldvalue cfv_source on cfv_source.issue = i.id
    and cfv_source.customfield = (select id from customfield where cfname = 'Issue Source')
    and cfv_source.stringvalue = 'SM'
group by p.pname, p.pkey, ist.pname
order by p.pname, ist.pname;

-- By project and status stats current year
select p.pname || ' (' || p.pkey || ')' project, ist.pname status, count(i.id)
from jiraissue i
         join project p on p.id = i.project
         join issuestatus ist on ist.id = i.issuestatus
         join customfieldvalue cfv_source on cfv_source.issue = i.id
    and cfv_source.customfield = (select id from customfield where cfname = 'Issue Source')
    and cfv_source.stringvalue = 'SM'
where i.created >= date_trunc('YEAR', i.created)
group by p.pname, p.pkey, ist.pname
order by p.pname, ist.pname;