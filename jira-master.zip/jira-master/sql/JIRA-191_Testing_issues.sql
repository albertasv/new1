-- Testing Issues stats
SELECT it.ID, it.pstyle, it.pname, count(i.ID)
FROM issuetype it
       LEFT JOIN jiraissue i ON it.ID = i.issuetype
WHERE it.id IN (10103, 10105, 10415, 11003, 11006, 12103, 11711, 11712)
GROUP BY it.ID, it.pstyle, it.pname
ORDER BY it.pstyle, it.pname;

