create table "AO_D46467_CLICK_LOG"
(
    "ID" serial not null constraint "AO_D46467_CLICK_LOG_pkey" primary key,
    "USERNAME" varchar(255) not null,
    "TOPIC" varchar(255) not null,
    "CLICK" integer default 0,
    "LAST_UPDATE_DATE" timestamp not null
);
alter table "AO_D46467_CLICK_LOG" owner to jirauser;

-- Reporting
SELECT cl."ID",
       cl."USERNAME",
       cu.display_name,
       cl."TOPIC",
       cl."CLICK",
       cl."LAST_UPDATE_DATE"
FROM "AO_D46467_CLICK_LOG" cl
         LEFT JOIN cwd_user cu on cu.user_name = cl."USERNAME";

SELECT "TOPIC",
       SUM(CASE WHEN "LAST_UPDATE_DATE" >= date_trunc('YEAR', now()) THEN "CLICK" ELSE 0 END)  current_year,
       SUM(CASE WHEN "LAST_UPDATE_DATE" >= date_trunc('MONTH', now()) THEN "CLICK" ELSE 0 END) current_month,
       SUM(CASE WHEN "LAST_UPDATE_DATE" >= date_trunc('WEEK', now()) THEN "CLICK" ELSE 0 END)  current_week
FROM "AO_D46467_CLICK_LOG"
WHERE "LAST_UPDATE_DATE" >= date_trunc('YEAR', now())
GROUP BY "TOPIC"
ORDER BY "TOPIC";