-- Declare current month period
DECLARE @p_start datetime = DATEADD(month, DATEDIFF(month, 0, getdate()), 0), @p_finish datetime = getdate();

WITH core AS
       (
         SELECT i.ID         ikey,
                ci.oldstring step,
                cg.CREATED   executed,
                s.pname      curr_step
         FROM changeitem ci
                LEFT JOIN changegroup cg ON cg.id = ci.groupid
                LEFT JOIN jiraissue i ON i.ID = cg.issueid
                LEFT JOIN issuestatus s ON s.ID = i.issuestatus
         WHERE ci.field = 'status'
       ),
     events as
       (SELECT tab.*,
               row_number() over (PARTITION BY ikey ORDER BY executed) myrank
        FROM
          (
            SELECT ikey, step, executed
            FROM core
            UNION ALL
              -- Issue Created
            SELECT jiraissue.ID, 'PASS', jiraissue.created
            FROM jiraissue
            WHERE jiraissue.ID IN (SELECT ikey FROM core)
            UNION ALL
            SELECT DISTINCT ikey, curr_step, getdate()
            FROM core
          ) tab
       )
SELECT data.id                       "Issue ID",
       data.SUMMARY                  "Issue Summary",
       data.ikey                     "Issue Key",
       data.status                   "Status",
       SUM(data.transition_time_sec) "Time In Status(sec)"
FROM (
       SELECT
         i.ID,
         i.summary,
         CONVERT(nvarchar(max), CONCAT(p.pkey, '-', i.issuenum)) ikey,
         CONVERT(nvarchar(max), e1.step)                         status,
         e2.executed                                             start_date,
         e1.executed                                             finish_date,
         CASE
           -- period includes status phase
           WHEN (@p_start <= e2.executed AND @p_start <= e1.executed) AND
                (@p_finish >= e2.executed AND @p_finish >= e1.executed)
             THEN DATEDIFF(SECOND, e2.executed, e1.executed)
           -- period is included into status phase
           WHEN (@p_start >= e2.executed AND @p_start <= e1.executed) AND
                (@p_finish >= e2.executed AND @p_finish <= e1.executed)
             THEN DATEDIFF(SECOND, @p_start, @p_finish)
           -- period start is included into status phase, but period finish
           WHEN (@p_start >= e2.executed AND @p_start <= e1.executed) AND @p_finish >= e1.executed
             THEN DATEDIFF(SECOND, @p_start, e1.executed)
           -- period finish is included into status phase, but period start
           WHEN @p_start <= e2.executed AND (@p_finish >= e2.executed AND @p_finish <= e1.executed)
             THEN DATEDIFF(SECOND, e2.executed, @p_finish)
           ELSE 0 END                                            transition_time_sec
       FROM events e1
              LEFT JOIN events e2 ON e1.ikey = e2.ikey AND e1.myrank = e2.myrank + 1
              LEFT JOIN jiraissue i ON i.ID = e2.ikey
              LEFT JOIN issuetype it ON it.ID = i.issuetype
              LEFT JOIN project p ON p.id = i.PROJECT
       WHERE it.pname = 'Service Status'
     ) data
GROUP BY data.id, data.ikey, data.status, data.summary
ORDER BY data.ikey, data.status;