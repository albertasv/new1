-- (UPP) Управление поддержки приложений - https://kb.rosbank.rus.socgen/pages/viewpage.action?pageId=397101063
-- (GA) Гильдия Админов / Administrators Guild - https://kb.rosbank.rus.socgen/pages/viewpage.action?pageId=413311044
-- (1stLineIT) ServiceDesk | RB - https://kb.rosbank.rus.socgen/display/1stLineIT/ServiceDesk+%7C+RB
-- (FAQ) База знаний - решения, инструкции пользователям - https://kb.rosbank.rus.socgen/pages/viewpage.action?pageId=21397870
-- (IUS) ИТ-команда - https://kb.rosbank.rus.socgen/pages/viewpage.action?pageId=344588367
-- (1) ServiceDesk | Extended Support - https://kb.rosbank.rus.socgen/display/1/ServiceDesk+%7C+Extended+Support
CREATE OR REPLACE VIEW rb_sd_stats_v AS
SELECT um.username,
       c.title,
       c.version,
       c.lastmoddate,
       c.versioncomment,
       c.contentid,
       s.spacename,
       cu.display_name
FROM content c
    JOIN spaces s on s.spaceid = c.spaceid
    JOIN user_mapping um ON c.lastmodifier = um.user_key
    JOIN cwd_user cu ON cu.lower_user_name = um.lower_username
WHERE (c.prevver IN (SELECT contentid
                     FROM content
                     WHERE prevver IS NULL
                       AND contenttype IN ('PAGE', 'BLOGPOST')
                       AND content_status = 'current'
                       AND spaceid IN (SELECT spaceid
                                       FROM spaces
                                       WHERE spacekey IN ('UPP', 'GA', '1stLineIT', 'FAQ', 'IUS', '1')))
    AND c.content_status = 'current'
    AND c.contenttype IN ('PAGE', 'BLOGPOST'))
   OR (c.prevver IS NULL
    AND c.contenttype IN ('PAGE', 'BLOGPOST')
    AND c.content_status = 'current'
    AND c.spaceid IN ((SELECT spaceid
                       FROM spaces
                       WHERE spacekey IN ('UPP', 'GA', '1stLineIT', 'FAQ', 'IUS', '1'))))
ORDER BY c.title, c.version DESC;