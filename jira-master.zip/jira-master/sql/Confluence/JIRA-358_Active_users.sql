-- JIRA-358 Power BI: Распределение лицензий Confluence
SELECT cu.lower_user_name,
       cu.display_name,
       d.directory_name,
       MAX(li.successdate) successdate
FROM cwd_user cu
         INNER JOIN cwd_directory d on cu.directory_id = d.id
         LEFT JOIN cwd_membership m ON cu.id = child_user_id
         LEFT JOIN cwd_group g ON m.parent_id = g.id
         LEFT JOIN cwd_membership cm ON cu.ID = cm.child_user_id
         LEFT JOIN cwd_group gr ON gr.id = cm.parent_id
         LEFT JOIN user_mapping um ON um.username = cu.user_name
         LEFT JOIN logininfo li ON um.user_key = li.username
WHERE cu.active = 'T'
  AND d.active = 'T'
  AND gr.group_name IN (
                        'confluence-users',
                        'rsb-sl-ct-MOS_Confluence_Administrators',
                        'rsb-sl-ct-MOS_Confluence_Users',
                        'rsb-sl-ct-MOS_Confluence_Users_RO',
                        'itbot'
    )
  AND cu.id NOT IN (
    SELECT cu.ID
    FROM cwd_user cu
             INNER JOIN cwd_directory cd on cu.directory_id = cd.id
    WHERE cd.directory_name = 'Confluence Internal Directory'
      AND cu.lower_user_name IN (
        SELECT cu.lower_user_name
        FROM cwd_user cu
                 INNER JOIN cwd_directory cd on cu.directory_id = cd.id
        WHERE cd.directory_name <> 'Confluence Internal Directory'
    )
)
GROUP BY cu.lower_user_name,
         cu.display_name,
         d.directory_name;