CREATE OR REPLACE VIEW rb_sm_issue_v AS
SELECT i.id,
       p.pkey || '-' || i.issuenum issue_key,
       assignee.lower_user_name    assignee,
       labels.labels
FROM jiraissue i
         join project p on p.id = i.project
         join app_user assignee on assignee.user_key = i.assignee
         join customfieldvalue cf_issue_source on cf_issue_source.issue = i.id AND cf_issue_source.stringvalue = 'SM'
    AND cf_issue_source.customfield = (SELECT id FROM customfield WHERE cfname = 'Issue Source')
         left join (select string_agg(label.label, ';') labels, issue
                    from label
                    group by issue) labels on labels.issue = i.id
WHERE i.created >= '2022-04-01'
ORDER BY p.pkey, i.id;

GRANT SELECT ON TABLE rb_sm_issue_v  TO odppuser;