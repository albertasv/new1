-- SELECT priorities: 'Major', 'Minor', 'Trivial'
SELECT i.ID             "Issue ID",
       pr.id            "Priority ID",
       pr.pname         "Priority name",
       CASE
         WHEN pr.pname = 'Major' THEN 10001
         WHEN pr.pname = 'Minor' THEN 10002
         ELSE 10003 END "n_priority"
FROM jiraissue i
       INNER JOIN project p ON p.ID = i.PROJECT
       INNER JOIN priority pr ON pr.ID = i.PRIORITY
WHERE pr.pname IN ('Major', 'Minor', 'Trivial');

-- UPDATE priorities: 'Major' -> 'High', 'Minor' -> 'Medium', 'Trivial' -> 'Low'
UPDATE i
SET i.PRIORITY = CASE
                   WHEN pr.pname = 'Major' THEN 10001
                   WHEN pr.pname = 'Minor' THEN 10002
                   ELSE 10003 END
FROM jiraissue i
       INNER JOIN project p ON p.ID = i.PROJECT
       INNER JOIN priority pr ON pr.ID = i.PRIORITY
WHERE pr.pname IN ('Major', 'Minor', 'Trivial');


-- Field Configs Priority
SELECT fl.NAME,
       fli.FIELDIDENTIFIER,
       fli.ISHIDDEN,
       fli.ISREQUIRED,
       fli.RENDERERTYPE
FROM fieldlayout fl
       INNER JOIN fieldlayoutitem fli ON fli.FIELDLAYOUT = fl.ID
WHERE fli.FIELDIDENTIFIER = 'priority'
--  AND ISHIDDEN = 'true'
;

-- Field Configs Приоритет
SELECT fl.NAME,
       fli.FIELDIDENTIFIER,
       fli.ISHIDDEN,
       fli.ISREQUIRED,
       fli.RENDERERTYPE
FROM fieldlayout fl
       INNER JOIN fieldlayoutitem fli ON fli.FIELDLAYOUT = fl.ID
WHERE fli.FIELDIDENTIFIER = 'customfield_10411'
--  AND ISHIDDEN = 'true'
;

-- Priority Schemes
SELECT p.ID,
       p.pkey,
       p.pname,
       cat.cname    category,
       f.configname "PriorityScheme"
FROM project p
       LEFT JOIN configurationcontext c ON c.PROJECT = p.ID
       LEFT JOIN fieldconfigscheme f ON f.ID = c.FIELDCONFIGSCHEME AND f.FIELDID = 'priority'
       LEFT JOIN nodeassociation na_cat ON na_cat.source_node_id = p.id AND na_cat.sink_node_entity = 'ProjectCategory'
       LEFT JOIN projectcategory cat ON cat.id = na_cat.sink_node_id
     --   LEFT JOIN nodeassociation na_wf ON na_wf.source_node_id = p.id AND na_wf.sink_node_entity = 'PriorityScheme'
     --   LEFT JOIN workflowscheme wf ON wf.id = na_wf.sink_node_id
WHERE p.pkey IN
      ('AGP', 'BIS', 'BPMAO', 'CCFUL', 'CORPFL', 'CRM', 'CRSAHDNBU', 'DS', 'FILS', 'GLQ', 'HKM', 'HTOH', 'IBN', 'ICB',
       'NEWFRONT', 'NLT', 'PAYR', 'PAYR3', 'PCC', 'PCCRM', 'PHUB', 'RUF', 'SFEC', 'SPT', 'USC')
  AND f.configname IS NOT NULL
ORDER BY f.configname, p.pkey;