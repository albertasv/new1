create table "AO_D46467_NEWS"
(
    "ID" serial not null
        constraint "AO_D46467_NEWS_pkey"
            primary key,
    "NEWS" text not null,
    "LAST_UPDATE_DATE" timestamp not null
);

alter table "AO_D46467_NEWS" owner to jirauser;

ALTER TABLE "AO_D46467_USER_INFO" ADD COLUMN "NEWS_ID" integer default 0;