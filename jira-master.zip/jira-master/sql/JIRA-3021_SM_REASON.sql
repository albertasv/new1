create table "AO_BEF1AE_SM_REASON"
(
    "ID" serial not null constraint "AO_BEF1AE_SM_REASON_pkey" primary key,
    "CODE" varchar(255) not null constraint u_ao_bef1ae_reason476248010 unique,
    "NAME" varchar(255) not null,
    "GROUP_REASON" varchar(255) not null,
    "LAST_UPDATE_DATE" timestamp,
    "LAST_SYNC_DATE" timestamp
);

alter table "AO_BEF1AE_SM_REASON" owner to jirauser;