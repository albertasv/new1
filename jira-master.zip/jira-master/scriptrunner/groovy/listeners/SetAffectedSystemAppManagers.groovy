//JIRA-8194
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.index.IssueIndexingService
import com.atlassian.jira.util.ImportUtils
import groovy.sql.Sql
import java.sql.Connection
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import com.atlassian.jira.issue.label.*
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.ModifiedValue
    
def issueToUpdate = (MutableIssue) event.getIssue()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def labelManager = ComponentAccessor.getComponent(LabelManager); 
def affectedSystemCodes = labelManager.getLabels(issueToUpdate.id, 18401)
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def issueManager = ComponentAccessor.getIssueManager()
def indexingService = ComponentAccessor.getComponent(IssueIndexingService.class)
def appManagersField = customFieldManager.getCustomFieldObjectByName("Affected System AMs")
def currentAppManagers = issueToUpdate.getCustomFieldValue(appManagersField)
boolean wasIndexing = ImportUtils.isIndexIssues()



if (affectedSystemCodes != null && appManagersField != null) {
    Set<ApplicationUser> usersToAdd = []
    for (Label affectedSystemCode in affectedSystemCodes) {
        // Data base connection
		DelegatorInterface delegator = ComponentAccessor.getComponent(DelegatorInterface)
		String helperName = delegator.getGroupHelperName("default")
		Connection conn = ConnectionFactory.getConnection(helperName)
        Sql sql = new Sql(conn)
        StringBuilder appManagerNameBuilder = new StringBuilder()
        try {
            String itSystemsQuery = String.format("SELECT * FROM \"AO_BEF1AE_CONFIGURATION_ITEM\" where \"CODE\"= \'%s\'", affectedSystemCode.toString())
			sql.eachRow(itSystemsQuery) {
                row ->
                	if (row.manager != null)
                		appManagerNameBuilder.append(row.manager)
            }            
            if (appManagerNameBuilder.length() > 0) {
                def appManagerName = appManagerNameBuilder.toString().trim()
                def appManagerUserObject = ComponentAccessor.getUserManager().getUserByName(appManagerName)
                usersToAdd.add(appManagerUserObject)                       
            }
        } catch (Exception e) {
            log.error("Unexpected error in Affected system AMs listener {}", e)        
        } finally {
            sql.close()
        }
    }
    // Update and save issue
    if (usersToAdd?.size() > 0) {
        issueToUpdate.setCustomFieldValue(appManagersField, usersToAdd)
        def changeHolder = new DefaultIssueChangeHolder()
		appManagersField.updateValue(null, issueToUpdate, new ModifiedValue(currentAppManagers, usersToAdd), changeHolder)
    }
} else {
    log.info("Nothing to update in Affected system AMs field")
}
ImportUtils.setIndexIssues(true)
indexingService.reIndex(issueToUpdate)
ImportUtils.setIndexIssues(wasIndexing)