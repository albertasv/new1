import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.index.IssueIndexingService
import com.atlassian.jira.util.ImportUtils
import groovy.sql.Sql
import java.sql.Connection
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface

//domain - Бизнес домен
//JIRA-6813
def issueToUpdate = (MutableIssue) event.getIssue()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def itSystemCode = issueToUpdate.getCustomFieldValue(ComponentAccessor.customFieldManager.getCustomFieldObjectByName("IT System"))
def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
def businessDomainField = customFieldManager.getCustomFieldObjectByName("Business Domain (Text)") 
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def issueManager = ComponentAccessor.getIssueManager()
def indexingService = ComponentAccessor.getComponent(IssueIndexingService.class)
boolean wasIndexing = ImportUtils.isIndexIssues()

String helperName = delegator.getGroupHelperName("default")
Connection conn = ConnectionFactory.getConnection(helperName)
StringBuffer itSystemName = new StringBuffer()
StringBuffer domain = new StringBuffer() 
Sql sql = new Sql(conn)

if(itSystemCode != null) {
    try {
        String itSystemsQuery = String.format("SELECT * FROM \"AO_BEF1AE_CONFIGURATION_ITEM\" where \"CODE\"= \'%s\'", itSystemCode)
        sql.eachRow(itSystemsQuery) {
            row ->
            	itSystemName.append(row.name)
                domain.append(row.domain)
        }
        if(itSystemName.length() > 0) {
            def businessDomain = domain.toString().trim()       
            if (domain != 0 && businessDomainField != null) {
                issueToUpdate.setCustomFieldValue(businessDomainField, businessDomain)
            }           
        }
    } catch (Exception e) {
        log.error("Unexpected error in IT System Business Domain listener {}", e)        
    } finally {
        sql.close()
    }
} else {
    issueToUpdate.setCustomFieldValue(businessDomainField, null)
}
issueManager.updateIssue(currentUser, issueToUpdate, EventDispatchOption.DO_NOT_DISPATCH, false)
ImportUtils.setIndexIssues(true)
indexingService.reIndex(issueToUpdate)
ImportUtils.setIndexIssues(wasIndexing)