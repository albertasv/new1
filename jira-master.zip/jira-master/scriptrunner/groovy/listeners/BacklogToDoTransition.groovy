import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ofbiz.FieldMap
import com.atlassian.jira.workflow.TransitionOptions
import com.opensymphony.workflow.loader.ActionDescriptor
import com.opensymphony.workflow.spi.WorkflowEntry

def issueEvent = event as IssueEvent
def issue = event.issue as MutableIssue

if (issueEvent.eventTypeId == EventType.ISSUE_CREATED_ID) {
    backlogToDoTransition(issue, true)

} else if (issueEvent.eventTypeId == EventType.ISSUE_UPDATED_ID) {
    // Sprint was changed
    def sprintChange = event?.changeLog?.getRelated("ChildChangeItem")?.find { it.field == "Sprint" }
    if (sprintChange) {
        backlogToDoTransition(issue, false)
    }
}

def backlogToDoTransition(Issue issue, boolean created) {
    final def BACKLOG_STATUS = "Backlog"
    final def TODO_STATUS = "To Do"
    final def SPRINT_FIELD_ID = 11004

    def sprintField = ComponentAccessor.customFieldManager.getCustomFieldObject(SPRINT_FIELD_ID)
    def sprints = issue.getCustomFieldValue(sprintField)
    def currStatus = issue.status.name
    def nextStatus
    if (sprints && currStatus == BACKLOG_STATUS) {
        nextStatus = TODO_STATUS
    } else if (!sprints && currStatus == TODO_STATUS) {
        nextStatus = BACKLOG_STATUS
    }

    if (nextStatus) {
        // Activate workflow if created
        if (created) {
            def workflowEntries = ComponentAccessor.ofBizDelegator.findByAnd("OSWorkflowEntry", FieldMap.build("id", issue.workflowId))
            workflowEntries.each() {
                workflowEntry ->
                    if (workflowEntry.getInteger("state") == null || workflowEntry.getInteger("state") == 0) {
                        workflowEntry.set("state", new Integer(WorkflowEntry.ACTIVATED))
                        workflowEntry.store()
                    }
            }
        }

        // Transition
        def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
        def workflow = ComponentAccessor.workflowManager.getWorkflow(issue)
        ActionDescriptor action = workflow.getLinkedStep(issue.status).actions.find { action -> ((ActionDescriptor) action).name == nextStatus }
        if (action) {
            def issueService = ComponentAccessor.issueService
            def transitionOptions = new TransitionOptions.Builder().skipConditions().build()
            def transitionValidationResult = issueService.validateTransition(currentUser, issue.id,
                    action.id, issueService.newIssueInputParameters(), transitionOptions)
            if (transitionValidationResult.valid) {
                issueService.transition(currentUser, transitionValidationResult)
            }
        }
    }
}