import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.issue.search.SearchResults
import com.atlassian.jira.jql.builder.JqlQueryBuilder
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.query.Query

// is part of release
final def IS_PART_OF_RELEASE_LINK_TYPE = 10201
final def RELEASE_CYCLE_TYPE = "Release Cycle"

def issueEvent = event as IssueEvent
def issue = event.issue as MutableIssue
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def issueManager = ComponentAccessor.issueManager

def isCrossProjectRelease = true
def projectIds = [issue.projectId] as Long[]

def oldFixVersions, newFixVersions
if (issueEvent.eventTypeId == EventType.ISSUE_CREATED_ID) {
    if (issue.issueType.name == RELEASE_CYCLE_TYPE) {
        /*
        Здесь создается новый Fix version пока отключено
        if (!issue.fixVersions) {
            def versionManager = ComponentAccessor.versionManager
            if (!issue.fixVersions) {
                def version = versionManager.getAllVersionsForProjects([issue.projectObject], true)?.find { version -> version.name == issue.summary }
                if (!version) {
                    version = versionManager.createVersion(issue.summary,
                            getReleaseStartDate(issue) as Date, getReleaseEndDate(issue) as Date,
                            null, issue.projectId, null, false)
                }
                issue.setFixVersions([version])
                issueManager.updateIssue(event.user, ((MutableIssue) issue), EventDispatchOption.ISSUE_UPDATED, false)
            }
        }
        */
    }
    if (issue.fixVersions) {
        newFixVersions = issue.fixVersions.collect { fixVersion -> fixVersion.name }
    }

} else if (issueEvent.eventTypeId == EventType.ISSUE_UPDATED_ID) {
    // Fix Version Changed
    def fixVersionChanges = event?.changeLog?.getRelated("ChildChangeItem")?.findAll { it.field == "Fix Version" }
    oldFixVersions = fixVersionChanges.findAll { fixVersionChange -> fixVersionChange && fixVersionChange.oldstring }
            .collect { fixVersionChange -> fixVersionChange.oldstring }
    newFixVersions = fixVersionChanges.findAll { fixVersionChange -> fixVersionChange && fixVersionChange.newstring }
            .collect { fixVersionChange -> fixVersionChange.newstring }
}

def issueLinkManager = ComponentAccessor.issueLinkManager
// Remove links for old fix version
if (oldFixVersions) {
    def jql = JqlQueryBuilder.newBuilder().where()
    if (!isCrossProjectRelease) {
        jql = jql.project(projectIds).and()
    }
    def resultOldIssues = searchJQL(jql.fixVersion(oldFixVersions as String[]).buildQuery()) as SearchResults
    if (resultOldIssues.total > 0) {
        resultOldIssues.results.each() {
            docIssueToUnlink ->
                if (issue.id != docIssueToUnlink.id) {
                    def issueToUnlink = issueManager.getIssueObject(docIssueToUnlink.id)
                    def linkToRemove = issue.issueType.name == RELEASE_CYCLE_TYPE ?
                            issueLinkManager.getIssueLink(issueToUnlink.id, issue.id, IS_PART_OF_RELEASE_LINK_TYPE) :
                            issueLinkManager.getIssueLink(issue.id, issueToUnlink.id, IS_PART_OF_RELEASE_LINK_TYPE)
                    if (linkToRemove) {
                        issueLinkManager.removeIssueLink(linkToRemove, currentUser)
                    }
                }

        }
    }
}
// Link issues by fix version
if (newFixVersions) {
    def jql = JqlQueryBuilder.newBuilder().where()
    if (!isCrossProjectRelease) {
        jql = jql.project(projectIds).and()
    }
    def resultNewIssues = searchJQL(jql.fixVersion(newFixVersions as String[]).buildQuery()) as SearchResults
    if (resultNewIssues.total > 0) {
        resultNewIssues.results.each() {
            docIssueToLink ->
                def issueToLink = issueManager.getIssueObject(docIssueToLink.id)
                if (issue.issueType.name == RELEASE_CYCLE_TYPE && issueToLink.issueType.name != RELEASE_CYCLE_TYPE) {
                    issueLinkManager.createIssueLink(issueToLink.id, issue.id, IS_PART_OF_RELEASE_LINK_TYPE, 1, currentUser)
                } else if (issue.issueType.name != RELEASE_CYCLE_TYPE && issueToLink.issueType.name == RELEASE_CYCLE_TYPE) {
                    issueLinkManager.createIssueLink(issue.id, issueToLink.id, IS_PART_OF_RELEASE_LINK_TYPE, 1, currentUser)
                }
        }
    }
}

// Release Cycle resolved
if (issue.issueType.name == RELEASE_CYCLE_TYPE) {
    def resolutionChange = event?.changeLog?.getRelated("ChildChangeItem")?.find { it.field == "resolution" }
    if (resolutionChange) {
        def versionManager = ComponentAccessor.versionManager
        boolean released = false
        if (resolutionChange.newvalue) {
            released = true
        }
        issue.fixVersions.each() {
            version ->
                version = versionManager.editVersionStartDate(version, (Date) getReleaseStartDate(issue))
                version = versionManager.editVersionReleaseDate(version, (Date) getReleaseEndDate(issue))
                version = versionManager.releaseVersion(version, released)
                versionManager.update(version)
        }
    }
}

/**
 * Get issues by JQL
 * @param jql
 * @return
 */
def searchJQL(Query jql) {
    def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
    def searchService = ComponentAccessor.getComponent(SearchService)
    return searchService.search(currentUser, jql, PagerFilter.getUnlimitedFilter())
}

/**
 * Get Release Start Date
 * @param issue
 * @return
 */
def getReleaseStartDate(MutableIssue issue) {
    def customFieldManager = ComponentAccessor.customFieldManager
    def releaseStartDateField = customFieldManager.getCustomFieldObject(13806)
    return issue.getCustomFieldValue(releaseStartDateField) as Date
}

/**
 * Get Actual Go-Live Date
 * @param issue
 * @return
 */
def getReleaseEndDate(MutableIssue issue) {
    def customFieldManager = ComponentAccessor.customFieldManager
    // Actual Go-Live Date
    def actualGoLiveField = customFieldManager.getCustomFieldObject(11103)
    def actualGoLive = issue.getCustomFieldValue(actualGoLiveField) as Date
    if (actualGoLive) {
        return actualGoLive
    }
    // Planned Go-Live Date
    def plannedGoLiveDateField = customFieldManager.getCustomFieldObject(11102)
    def plannedGoLiveDate = issue.getCustomFieldValue(plannedGoLiveDateField) as Date
    if (plannedGoLiveDate) {
        return plannedGoLiveDate
    }
    // Proposed Go-Live Date
    def proposedGoLiveDateField = customFieldManager.getCustomFieldObject(11401)
    def proposedGoLiveDate = issue.getCustomFieldValue(proposedGoLiveDateField) as Date
    if (proposedGoLiveDate) {
        return proposedGoLiveDate
    }
    return null
}