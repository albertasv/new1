import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueWatcherAddedEvent
import com.atlassian.jira.event.issue.IssueWatcherDeletedEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.MutableIssue

def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def viewersField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14201")

if (event instanceof IssueWatcherAddedEvent) {
    def watcherAddedEvent = event as IssueWatcherAddedEvent
    def issue = watcherAddedEvent.issue as MutableIssue
    def viewers = issue.getCustomFieldValue(viewersField) as List
    issue.setCustomFieldValue(viewersField, (viewers ?: []) + watcherAddedEvent.applicationUser)
    ComponentAccessor.issueManager.updateIssue(user, issue, EventDispatchOption.ISSUE_UPDATED, false)
} else if (event instanceof IssueWatcherDeletedEvent) {
    def watcherDeletedEvent = event as IssueWatcherDeletedEvent
    def issue = watcherDeletedEvent.issue as MutableIssue
    def viewers = issue.getCustomFieldValue(viewersField) as List
    issue.setCustomFieldValue(viewersField, (viewers ?: []) - watcherDeletedEvent.applicationUser)
    ComponentAccessor.issueManager.updateIssue(user, issue, EventDispatchOption.ISSUE_UPDATED, false)
}