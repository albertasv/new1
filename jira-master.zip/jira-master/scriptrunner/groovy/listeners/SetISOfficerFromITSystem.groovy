import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.index.IssueIndexingService
import com.atlassian.jira.util.ImportUtils
import groovy.sql.Sql
import java.sql.Connection
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface


//JIRA-6500 
//isOfficer - Information Security Officer
def issueToUpdate = (MutableIssue) event.getIssue()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def itSystemCode = issueToUpdate.getCustomFieldValue(ComponentAccessor.customFieldManager.getCustomFieldObjectByName("IT System"))
def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
def isOfficerField = customFieldManager.getCustomFieldObjectByName("IS Officer")
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def issueManager = ComponentAccessor.getIssueManager()
def indexingService = ComponentAccessor.getComponent(IssueIndexingService.class)
boolean wasIndexing = ImportUtils.isIndexIssues()

String helperName = delegator.getGroupHelperName("default")
Connection conn = ConnectionFactory.getConnection(helperName)
StringBuffer itSystemName = new StringBuffer()
StringBuffer isOfficerUserName = new StringBuffer() 
Sql sql = new Sql(conn)

if(itSystemCode != null) {
    try {
        String itSystemsQuery = String.format("SELECT * FROM \"AO_BEF1AE_CONFIGURATION_ITEM\" where \"CODE\"= \'%s\'", itSystemCode)
        sql.eachRow(itSystemsQuery) {
            row ->
            	itSystemName.append(row.name)
            	isOfficerUserName.append(row.is_officer)
        }
        if(itSystemName.length() > 0) {
            def isOfficerName = isOfficerUserName.toString().trim()
            def isOfficerUser = ComponentAccessor.getUserManager().getUserByName(isOfficerName)
            if (isOfficerUserName.length() != 0 && isOfficerField != null) {               
                issueToUpdate.setCustomFieldValue(isOfficerField, isOfficerUser)        
            }                        
        }
    } catch (Exception e) {
        log.error("Unexpected error in IT System IS Officer listener {}", e)        
    } finally {
        sql.close()
    }
} else {
    issueToUpdate.setCustomFieldValue(isOfficerField, null) 
}
issueManager.updateIssue(currentUser, issueToUpdate, EventDispatchOption.DO_NOT_DISPATCH, false)
ImportUtils.setIndexIssues(true)
indexingService.reIndex(issueToUpdate)
ImportUtils.setIndexIssues(wasIndexing)