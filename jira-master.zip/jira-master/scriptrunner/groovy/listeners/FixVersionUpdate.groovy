import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue

def issueEvent = event as IssueEvent
def issue = event.issue as MutableIssue
def issueManager = ComponentAccessor.issueManager

if(issueEvent.eventTypeId == EventType.ISSUE_CREATED_ID){
    // Set Fix Version(s) for new Subtask    
	def parent = issue.parentObject
    if(parent) {
        issue.setFixVersions(parent.fixVersions)
		issueManager.updateIssue(event.user, issue, EventDispatchOption.ISSUE_UPDATED, false)
    }	
} else if(issueEvent.eventTypeId == EventType.ISSUE_UPDATED_ID){
	//Update Fix version(s) for subtasks from parent
    def fixVersionChange = event?.changeLog?.getRelated("ChildChangeItem")?.find {it.field == "Fix Version"}
    if (fixVersionChange) {
        def subtasks = issue.subTaskObjects
        if (subtasks){
            subtasks.each {it ->
                ((MutableIssue) it).setFixVersions(issue.fixVersions)
                issueManager.updateIssue(event.user, ((MutableIssue) it), EventDispatchOption.ISSUE_UPDATED, false)
            }
        }
    }
    // Clear Fix version (s) if move
    def moveChange = event?.changeLog?.getRelated("ChildChangeItem")?.find {it.field == "Parent"}
    // 1. Sub-task (task with parent) -> Task (Task without parent)
    if(moveChange && moveChange.oldstring != null && moveChange.newstring == null){
        issue.setAffectedVersions(issue.fixVersions)
        issue.setFixVersions([])
        issueManager.updateIssue(event.user, issue, EventDispatchOption.ISSUE_UPDATED, false)
    }
    // 2. Sub-task (task with parent) -> Task (Task without parent)
    if(moveChange && moveChange.oldstring == null && moveChange.newstring != null){
        def parent = issue.parentObject
        if(parent) {
            issue.setFixVersions(parent.fixVersions)
            issueManager.updateIssue(event.user, issue, EventDispatchOption.ISSUE_UPDATED, false)
        }
    }
}