import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.link.RemoteIssueLinkManager

def linkManager = ComponentAccessor.getComponentOfType(RemoteIssueLinkManager.class)

def links = []
links.addAll(linkManager.getRemoteIssueLinksForIssue(issue)*.url)

def confPageField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_10702") // Confluence Page
def confPageValue = issue.getCustomFieldValue(confPageField)?.value
if (confPageValue) {
    links.add(confPageValue)
}

return links.join("; ")