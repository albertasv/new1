import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import ru.rosbank.jira.sm.api.ConfigurationItemService

@WithPlugin("ru.rosbank.jira.jira-rb-sm")

@PluginModule
ConfigurationItemService configurationItemService

def itSystemCode = issue.getCustomFieldValue(ComponentAccessor.customFieldManager.getCustomFieldObject(16904))
if(itSystemCode) {
   def itSystem = configurationItemService.getByCode(String.valueOf(itSystemCode))
    if(itSystem && itSystem.owner){
        return ComponentAccessor.userManager.getUserByName(itSystem.manager)
    }
}

return null