import java.sql.Connection
import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import ru.rosbank.jira.sm.api.ConfigurationItemService
import groovy.sql.Sql
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface


try {
    def itSystemCode = issue.getCustomFieldValue(ComponentAccessor.customFieldManager.getCustomFieldObjectByName("IT System"))
    def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
    String helperName = delegator.getGroupHelperName("default")
    Connection conn = ConnectionFactory.getConnection(helperName)
    Sql sql = new Sql(conn)
    StringBuffer sb = new StringBuffer()
    if(itSystemCode != null || !itSystemCode.equals("")) {
        try {
          sql = new Sql(conn);
            String query = String.format("select * from \"AO_BEF1AE_CONFIGURATION_ITEM\" where \"CODE\"= \'%s\'", itSystemCode)
            sql.eachRow(query) {
                switch(it.status) {
                    case '05': sb << "Исследование"; break
                    case '10': sb << "Новый/В разработке"; break
                    case '30': sb << "Опытная эксплуатация"; break
                    case '40': sb << "В эксплуатации"; break
                    case '80': sb << "Снят с эксплуатации"; break
                    case '90': sb << "Архив"; break
                    case '91': sb << "Декомиссия"; break                    
                }
            }
            return sb
        } finally {
          sql.close()
        }
    }
    return ""
} catch (Exception ex) {
    return ""
}