import com.atlassian.jira.component.ComponentAccessor

def spFieldId = 11002
def option1FieldId = 15014
def option2FieldId = 15015
def option3FieldId = 15016 
def option4FieldId = 15017
def option5FieldId = 15018
def option6FieldId = 17213
def option7FieldId = 18410 
def option8FieldId = 18411
def option9FieldId = 17200
def option10FieldId = 17205
def option11FieldId = 17201
def option12FieldId = 17213
def option13FieldId = 19803
def option14FieldId = 20000
def option15FieldId = 20001
def option16FieldId = 20002
def option17FieldId = 20003
def option18FieldId = 20800
def option19FieldId = 20205


// Повышает доходы
def option1 = getOptionValue(option1FieldId)
// Снижает расходы
def option2 = getOptionValue(option2FieldId)
// Увеличивает СХ
def option3 = getOptionValue(option3FieldId)
// Коэффициент частоты использования клиентом
def option4 = getOptionValue(option4FieldId)
// Закон/Охват
def option5 = getOptionValue(option5FieldId)
// Кол-во сегментов
def option6 = getOptionValue(option6FieldId)
// Повышает TTY/TTM 
def option7 = getOptionValue(option7FieldId)
// Повышает data quality 
def option8 = getOptionValue(option8FieldId)
// Кол-во затронутых пользователей
def option9 = getOptionValue(option9FieldId)
// Комплаенс/Аудит/Риски
def option10 = getOptionValue(option10FieldId)
// Кол-во затронутых сервисов/систем
def option11 = getOptionValue(option11FieldId)
// Кол-во сегментов
def option12 = getOptionValue(option12FieldId)
// Сегмент
def option13 = getOptionValue(option13FieldId)
// Тип канала
def option14 = getOptionValue(option14FieldId)
// Трудоемкость
def option15 = getOptionValue(option15FieldId)
// Важность канала
def option16 = getOptionValue(option16FieldId)
// Кол-во потребителей
def option17 = getOptionValue(option17FieldId)
// Reach
def option18 = getOptionValue(option18FieldId)
// Impact
def option19 = getOptionValue(option19FieldId)


def spField = ComponentAccessor.customFieldManager.getCustomFieldObject(spFieldId)
def sp = 1 as Double

def project = issue.projectObject.key

switch (project) {
    case 'AID':
    	// (Повышает доходы * 5) + (Снижает расходы * 5) + (Увеличивает CX * 5) + ((Reach * Impact) * 5) + (Закон/Охват * 10) + (Комплаенс / Аудит / Риски * 10)
    	return (option1 * 5) + (option2 * 5) + (option3 * 5) + (option18 * option19 * 5) + (option5 * 10) + (option10 * 10)
    case 'PRODBO':
        // (Повышает доходы * 5 * Снижает расходы * 3 * Увеличивает СХ * 7 * Коэффициент частоты использования клиентом * 10 * Закон) / Story Points
        return (sp && option1 && option2 && option3 && option4 && option5) ? (option1 * 5 * option2 * 3 * option3 * 7 * option4 * 10 * option5 / sp) : 0
    case 'PROPS':
        // (Повышает доходы * 30% + Увеличивает СХ  * Коэффициент частоты использования клиентом * 70% * Закон/Охват) / Story Point
        return sp ? (((option1 ?: 1) * 0.3 + (option3 ?: 1) * (option4 ?: 1) * 0.7 * (option5 ?: 1)) / sp) : 0
    case 'DBOP':
        // (Повышает доходы * 4 + Снижает расходы * 2 + Увеличивает СХ * 8 + Коэффициент частоты использования клиентом * 6 + Закон * 10
        // + Кол-во сегментов
        return (option1 * 4 + option2 * 2 + option3 * 8 + option4 * 6 + option5 * 10 + option6)
    case 'DEMO':
        return (option1 * 4 + option2 * 2)
    case 'CCFUL':
    	/* (Коэффициент частоты использования клиентом + 
    	 Повышает TTY/TTM +
    	 Повышает data quality) 
         */
    	return (option3 + option7 + option8)
    case 'RDBO':
    	/* (Повышает доходы * 5 + Увеличивает СХ * 5 + 
    	 Коэффициент частоты использования клиентом * 5 +  
         Кол-во затронутых пользователей * 5 + 
    	 Закон / Охват * 10 +
    	 Группа SG / Аудит * 10) 
         */
    	return (option1 * 5 + option3 * 5 + option4 * 5 + option9 * 5 + option5 * 10 + option10 * 10)
    case 'RFT':
    	/* (Повышает доходы * 5 + Увеличивает СХ * 5 + 
    	 Коэффициент частоты использования клиентом * 5 +  
         Кол-во затронутых пользователей * 5 + 
    	 Закон / Охват * 10 +
    	 Группа SG / Аудит * 10 +
         Сегмент * 10) 
         */
    	return (option1 * 5 + option3 * 5 + option4 * 5 + option9 * 5 + option5 * 10 + option10 * 10 + option13 * 10)
    case 'RFP': 
    	/* (Повышает доходы * 5 + Увеличивает СХ * 5 + 
    	 Коэффициент частоты использования клиентом * 5 +  
         Кол-во затронутых пользователей * 5 + 
         Закон / Охват * 10 +
    	 Группа SG / Аудит * 10) 
         */
    	return (option1 * 5 + option3 * 5 + option4 * 5 + option9 * 5 + option5 * 10 + option10 * 10)
    case 'CRM':
    	/* (Повышает доходы * 5 + Увеличивает СХ * 5 + 
    	 Коэффициент частоты использования клиентом * 5 +  
         Кол-во затронутых пользователей * 5 + 
    	 Закон / Охват * 10 +
    	 Группа SG / Аудит * 10 +
         Сегмент * 10) 
         */
    	return (option1 * 5 + option3 * 5 + option4 * 5 + option9 * 5 + option5 * 10 + option10 * 10 + option13 * 10)   
    case 'TRN':
    	/* (Повышает доходы * 5 + 
    	 Снижает расходы * 5 + 
    	 Кол-во затронутых сервисов/систем * 5 +  
         Закон/Охват * 5 + 
    	 Группа SG/Аудит * 10 +
    	 Кол-во сегментов * 5 
         */  	
    	return (option1 * 5) + (option2 * 5) + (option11 * 5) + (option5 * 10) + (option10 * 10) + (option12 * 5)
     case 'OPT':
       /* Повышает доходы * 5 + 
        Снижает расходы * 5 + 
        Увеличивает СХ * 5 + 
        Коэффициент частоты использования клиентом * 5 + 
        Закон / Охват * 10 + 
        Группа SG / Аудит * 10) 
        */
       return (option1 * 5) + (option2 * 5) + (option3 * 5) + (option4 * 5) + (option5 * 10) + (option10 * 10)
    case 'IN': 
    	/* (Повышает доходы * 5 + Увеличивает СХ * 5 + 
    	 Коэффициент частоты использования клиентом * 5 +  
         Кол-во затронутых пользователей * 5 + 
    	 Закон / Охват * 10 +
    	 Группа SG / Аудит * 10) 
         */
    	return (option1 * 5 + option3 * 5 + option4 * 5 + option9 * 5 + option5 * 10 + option10 * 10)
    case 'RBSP':
        /* Повышает доходы + Тип запроса + Трудоемкость +
         Важность канала + Кол-во потребителей 
         */
       return (option1 + option14 + option15 + option16 + option17)
    case 'REC':
    	/* Повышает доходы *
        Снижает расходы * 
        Коэффициент частоты использования клиентом *
        Reach
        */
    	return (option1 * option2 * option4 * option18)
    
    default:
        return null
}

Double getOptionValue(Integer fieldId) {
    try {
        def optionField = ComponentAccessor.customFieldManager.getCustomFieldObject(fieldId)
        return Double.parseDouble(issue.getCustomFieldValue(optionField)?.data)
    } catch (Exception ex) {
        //log.error("Score calculating exception" ,ex)
    }
    return 0
}