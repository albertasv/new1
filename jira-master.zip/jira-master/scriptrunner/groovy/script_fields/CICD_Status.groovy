import com.atlassian.jira.component.ComponentAccessor

def statusField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('CI/CD Status')
def status = String.valueOf(issue.getCustomFieldValue(statusField))
def color
if (status == "Success") {
    color = 'green'
} else if (status == 'Failure') {
    color = 'red'
} else if (status == 'Progress') {
    color = 'yellow'
}

if (color) {
    return "<div style='background:${color};width:10px;height:10px;margin:5px'></div>"
}