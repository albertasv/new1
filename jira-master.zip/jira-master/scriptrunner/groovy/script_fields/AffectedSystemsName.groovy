import java.util.Calendar
import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import ru.rosbank.jira.sm.api.ConfigurationItemService

@WithPlugin("ru.rosbank.jira.jira-rb-sm")

@PluginModule
ConfigurationItemService configurationItemService

def itSystemCodes = issue.getCustomFieldValue(ComponentAccessor.customFieldManager.getCustomFieldObject(18505))
if (itSystemCodes) {
    def result = []
    for (def itSystemCode : itSystemCodes) {
        def itSystem = configurationItemService.getByCode(String.valueOf(itSystemCode))
        if (itSystem && itSystem.name) {
            result.add(itSystem.name)
        }
    }
    return result.join(", ")
}

return null