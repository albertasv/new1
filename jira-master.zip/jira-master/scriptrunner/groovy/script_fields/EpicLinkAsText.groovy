import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.Issue

CustomFieldManager customFieldManager = ComponentAccessor.customFieldManager
CustomField epicLinkCF = customFieldManager.getCustomFieldObjectByName("Epic Link")
if (epicLinkCF) {
    def story = issue.subTask ? issue.parentObject : issue
    def epic = story.getCustomFieldValue(epicLinkCF) as Issue
    if (epic) {
        def epicNameCF = customFieldManager.getCustomFieldObjectByName("Epic Name")
        if (epicNameCF) {
            return epic.getCustomFieldValue(epicNameCF)
        }
    }
}

return null