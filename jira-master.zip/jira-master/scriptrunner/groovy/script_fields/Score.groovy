﻿import com.atlassian.jira.component.ComponentAccessor


def spFieldId = 11002
def option1FieldId = 15014
def option2FieldId = 15015
def option3FieldId = 15016
def option4FieldId = 15017
def option5FieldId = 15018
def option6FieldId = 17213
def option7FieldId = 15020 
def option8FieldId = 18204
def option9FieldId = 18410 
def option10FieldId = 18411
def option11FieldId = 15019
def option12FieldId = 17200
def option13FieldId = 17205

def option14FieldId = 17201
def option15FieldId = 17202
def option16FieldId = 17203
def option17FieldId = 17204
def option18FieldId = 17206
def option19FieldId = 17207
def option20FieldId = 19803

def option21FieldId = 20000
def option22FieldId = 20001
def option23FieldId = 20002
def option24FieldId = 20003

def option25FieldId = 20207
def option26FieldId = 20205
def option27FieldId = 20206
def option28FieldId = 20204

def option29FieldId = 20602
def option30FieldId = 20603
def option31FieldId = 20604
def option32FieldId = 20605
def option33FieldId = 20606
def option34FieldId = 20607
def option35FieldId = 20608
def option36FieldId = 20702
def option37FieldId = 20703

def option38FieldId = 10410

def option39FieldId = 20800
def option40FieldId = 20801
def option41FieldId = 20802



// Повышает доходы
def option1 = getOptionValue(option1FieldId)
// Снижает расходы
def option2 = getOptionValue(option2FieldId)
// Увеличивает СХ
def option3 = getOptionValue(option3FieldId)
// Коэффициент частоты использования клиентом
def option4 = getOptionValue(option4FieldId)
// Закон / Охват
def option5 = getOptionValue(option5FieldId)
// Кол-во сегментов
def option6 = getOptionValue(option6FieldId)
// Classification
def option8 = getOptionValue(option8FieldId)
// Повышает TTY/TTM 
def option9 = getOptionValue(option9FieldId)
// Повышает data quality 
def option10 = getOptionValue(option10FieldId)
// Количество затронутых пользователей
def option12 = getOptionValue(option12FieldId)
// Комплаенс / Аудит / Риски
def option13 = getOptionValue(option13FieldId)
// Кол-во затронутых сервисов/систем
def option14 = getOptionValue(option14FieldId)
// Кол-во затронутых процессов/отчетов
def option15 = getOptionValue(option15FieldId)
// Репутационный ущерб
def option16 = getOptionValue(option16FieldId)
// Регулятор / Гос. Органы
def option17 = getOptionValue(option17FieldId)
// Время возникновения проблемы
def option18 = getOptionValue(option18FieldId)
// Повторяемость проблемы
def option19 = getOptionValue(option19FieldId)
// Сегмент
def option20 = getOptionValue(option20FieldId)
// Тип запроса
def option21 = getOptionValue(option21FieldId)
// Трудоемкость
def option22 = getOptionValue(option22FieldId)
// Важность канала
def option23 = getOptionValue(option23FieldId)
// Кол-во потребителей
def option24 = getOptionValue(option24FieldId)
//Reach,FTE
def option25 = getOptionValue(option25FieldId)
//Impact
def option26 = getOptionValue(option26FieldId) 
//Confidence
def option27 = getOptionValue(option27FieldId)
//Effort
def option28 = getOptionValue(option28FieldId)

//КЦ (звонки+чаты)
def option29 = getOptionValue(option29FieldId)
//Претензии/Техпроблемы
def option30 = getOptionValue(option30FieldId)
//Фин/реп риски
def option31 = getOptionValue(option31FieldId)
//CSI
def option32 = getOptionValue(option32FieldId)
//NPS
def option33 = getOptionValue(option33FieldId)
//Доп.фактор
def option34 = getOptionValue(option34FieldId)
//Приоритет
def option35 = getOptionValue(option35FieldId)
//Повышает качество сервиса
def option36 = getOptionValue(option36FieldId)
//Увеличивает AX
def option37 = getOptionValue(option37FieldId)

//Severity
def option38 = getOptionValueSeverity(option38FieldId)

//Reach
def option39 = getOptionValue(option39FieldId)
//Frequency
def option40 = getOptionValue(option40FieldId)
//Effort
def option41 = getOptionValue(option41FieldId)



def spField = ComponentAccessor.customFieldManager.getCustomFieldObject(spFieldId)
def sp = issue.getCustomFieldValue(spField) as Double //Story points field value

def project = issue.projectObject.key

//import org.apache.log4j.Level
//import org.apache.log4j.Logger

switch (project) {
    case 'PRODBO':
    	def pstField = ComponentAccessor.customFieldManager.getCustomFieldObject(14308)
		def pst = issue.getCustomFieldValue(pstField) as String  

    	/* def log1 = Logger.getLogger("in.ravisagar.sr4j") //Not needed when binding variable is available
		
    	log.info("pst:"+pst)
    	if (pst == "[PRO Partners Services]")
    		return 2
    	else
        	 (Повышает доходы * 5 * Снижает расходы * 3 * Увеличивает СХ * 7 * Коэффициент частоты использования клиентом * 10 * Закон) / Story Points
         */
        return  (sp && option1 && option2 && option3 && option4 && option5) ? (Double)(option1 * 5 * option2 * 3 * option3 * 7 * option4 * 10 * option5 / sp) : 0
    case 'PROPS':
        // Повышает доходы * 30% + Увеличивает СХ  * Коэффициент частоты использования клиентом * 70% * Закон/Охват) / Story Point
        return sp ? (Double)(((option1 ?: 1) * 0.3 + (option3 ?: 1) * (option4 ?: 1) * 0.7 * (option5 ?: 1)) / sp) : 0
    case 'DBOP':
        /* (Повышает доходы * 4 + Снижает расходы * 2 + Увеличивает СХ * 8 + Коэффициент частоты использования клиентом * 6 + Закон * 10
         + Кол-во сегментов
        */
        return (option1 * 4 + option2 * 2 + option3 * 8 + option4 * 6 + option5 * 10 + option6)
    	// Повышает доходы + Снижает расходы
   	case 'DEMO':
        return sp ? (Double)((option1 * 4 + option2 * 2) / sp) : 0
    case 'CCFUL':
    	// Бизнес-ценность
		def businessValue = option3 + option9 + option10
    	//Score
    	return (businessValue && option8) ? (businessValue/(Math.log(option8 + 1))) : 0
    
    case 'RDBO':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5)  + (option3 * 5) + (option4 * 5) + (option12 * 5) + (option5 * 10) + (option13 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)   
    case 'DQM':
        /* (Кол-во затронутых пользователей * 4 + Кол-во затронутых сервисов/систем *4 + Кол-во затронутых процессов/отчетов * 4 + Репутационный ущерб * 5 + Регулятор / Гос. Органы * 4 + Группа SG / Аудит * 3 + Повышает доходы * 3 + Снижает расходы * 3 + 
          Время возникновения проблемы * 2 + Повторяемость проблемы * 4)/44
          return sp ? (Double)((option12 * 4 + option14 * 4 + option15 * 4 + option16 * 5 + option17 * 4 + option13 * 3 + option1 * 3 + option2 * 3 + option18 * 2 + option19 * 4) /1) : 0
        */
		return (Double)((option12 * 4 + option14 * 4 + option15 * 4 + option16 * 5 + option17 * 4 + option13 * 3 + option1 * 3 + option2 * 3 + option18 * 2 + option19 * 4) / 44)
     case 'TRN':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5) + (option14 * 5) + (option6 * 5) + (option5 * 10) + (option13 * 10)
    	// Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)
    case 'AID':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5) + (option3 * 5) + (option39 * option26 * 5) + (option5 * 10) + (option13 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)
    case 'OPT':
       //Бизнес-ценность = (Повышает доходы * 5 + Снижает расходы * 5 + Увеличивает СХ * 5 + Коэффициент частоты использования клиентом * 5 + Закон / Охват * 10 + Группа SG / Аудит * 10)
       def businessValue = (option1 * 5) + (option2 * 5) + (option3 * 5) + (option4 * 5) + (option5 * 10) + (option13 * 10)
       // Score
       return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1) 
    case 'RFT':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5)  + (option3 * 5) + (option4 * 5) +  (option5 * 10) + (option13 * 10) + (option20 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)   
    case 'CRM':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5)  + (option3 * 5) + (option4 * 5) + (option5 * 10) + (option13 * 10) + (option20 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)   
    case 'RFP':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5)  + (option3 * 5) + (option4 * 5) + (option5 * 10) + (option13 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)   
    case 'IN':
    	// Бизнес-ценность
    	def businessValue = (option1 * 5) + (option2 * 5)  + (option3 * 5) + (option4 * 5) + (option5 * 10) + (option13 * 10) + (option20 * 10)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)   
    case 'RBSP':
     	// Бизнес-ценность
    	def businessValue = option1 + option21 + option22 + option23 + option24
    	//Score
    	return (Double)(businessValue / 1)      
    case 'SFP':
    	// Бизнес-ценность
    	def businessValue = (option3 * 7.25) + (option36 * 7)  + (option37 * 4.5) + (option12 * 6.25) + (option14 * 4) + (option5 * 8.75)
    	//Score
    	return sp ? (Double)(businessValue / sp) : (Double)(businessValue / 1)       
    case 'OSTR':
    	//Score
    	if (option25 == null) {
            option25 = 0
        }
        if (option28 == null || option28 == 0) {
            return 0
        }
    	def res = (Double)(option25 * option26 * option27 / option28)   
        return res.round(2)
    case 'TOPP':
        //Score
        return (Double)(option29 + option30 + option31 + option32 + option33 + option34 + option35)
	case 'JIRA':
        //Score = Impact*Reach*Confidence/Effort
		return option41 ? ((Double)(option26 * option39 * option27 / option41)).round(2) : 0
    case 'DAY':
        //Score
        return option41 ? (Double)((option26 ?: 1) * (option39 ?: 1) * (option27 ?: 1) * (option38 ?: 1) * (option40 ?: 1) / option41) : null
    case 'REC':
		//Score
    	return option41 ? (Double) (option1 * option2 * option4 * option39) / option41 : 0
    default:
        return null
}

Double getOptionValue(Integer fieldId) {
    try {
        def optionField = ComponentAccessor.customFieldManager.getCustomFieldObject(fieldId)
        return Double.parseDouble(issue.getCustomFieldValue(optionField)?.data)
    } catch (Exception ex) {
        //log.error("Score calculating exception" ,ex)
    }
    return 0
}


Double getOptionValueSeverity(Integer fieldId) {
    try {
        def optionField = ComponentAccessor.customFieldManager.getCustomFieldObject(fieldId)
		def severity = issue.getCustomFieldValue(optionField)
        switch (severity) {
           case 'Blocker':
       			return (Double) 2.5
           case 'Critical':
       			return (Double) 2
           case 'Major':
       			return (Double) 1.5
           case 'Minor':
            	return (Double) 1
           case 'Trivial':
            	return (Double) 0.5 
           default:
             return 1    
        }
    } catch (Exception ex) {
        //log.error("Score calculating exception" ,ex)
    }
    return 0
}


