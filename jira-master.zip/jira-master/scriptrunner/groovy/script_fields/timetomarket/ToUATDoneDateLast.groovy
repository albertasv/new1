import com.atlassian.jira.component.ComponentAccessor

def statusChanges = ComponentAccessor.changeHistoryManager.getChangeItemsForField(issue, "status")
return statusChanges.reverse().find { it.toString == "UAT Done" }?.created