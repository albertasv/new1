import com.atlassian.greenhopper.service.sprint.Sprint
import com.atlassian.greenhopper.service.sprint.SprintManager
import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.JiraAgileBean
import com.onresolve.scriptrunner.runner.customisers.WithPlugin

@WithPlugin("com.pyxis.greenhopper.jira")

@JiraAgileBean
SprintManager sprintManager

def sprintFields = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName("Sprint")

def sprintChanges = ComponentAccessor.changeHistoryManager.getChangeItemsForField(issue, "Sprint")
def changeDate = sprintChanges.find { change ->
    try {
        def sprint = sprintManager.getSprint(Long.valueOf(change.to))?.value
        return sprint != null && sprint?.state != Sprint.State.FUTURE
    } catch (Exception ex) {
    }
}?.created

if (!changeDate) {
    def sprints = issue.getCustomFieldValue(sprintFields?.first()) as List<Sprint>
    if (sprints) {
        def sprint = sprints?.first()
        if (sprint && sprint?.state != Sprint.State.FUTURE) {
            changeDate = issue?.created
        }
    }
}
return changeDate
