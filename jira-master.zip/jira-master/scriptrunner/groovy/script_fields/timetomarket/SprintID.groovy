import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.greenhopper.service.sprint.Sprint

def sprintFields = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName("Sprint")
def sprints = issue.getCustomFieldValue(sprintFields?.first()) as List<Sprint>
return sprints?.first()?.id