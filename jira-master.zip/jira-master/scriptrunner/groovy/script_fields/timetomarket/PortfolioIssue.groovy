import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue

try {
    def portfolioIssueField = ComponentAccessor.customFieldManager.getCustomFieldObject(16905)
    def portfolioIssue = issue.getCustomFieldValue(portfolioIssueField) as Issue
    if (portfolioIssue) {
        // Portfolio Issue CR / Project ID
        //def ppmCodeField = ComponentAccessor.customFieldManager.getCustomFieldObject(14000)
        //return portfolioIssue.getCustomFieldValue(ppmCodeField)
        // Portfolio Issue Business Domain
        def domainField = ComponentAccessor.customFieldManager.getCustomFieldObject(14101)
        return portfolioIssue.getCustomFieldValue(domainField)?.value
    }
} catch (Exception e) {
}
return null