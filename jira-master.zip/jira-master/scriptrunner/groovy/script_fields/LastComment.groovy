import com.atlassian.jira.component.ComponentAccessor

def commentManager = ComponentAccessor.commentManager
def userManager = ComponentAccessor.userManager
def comment = commentManager.getLastComment(issue)
def commentBody = comment.body
def userName
def displayName
String[] splittedBySpaceComment

if (comment != null) {
    splittedBySpaceComment = commentBody.split(" ")
    for (word in splittedBySpaceComment) {
         if (word.contains("[~")){             
             userName = word.subSequence(word.indexOf("~") + 1,                   
                        word.indexOf("]"))
             try {
                 displayName = userManager.getUser(userName.toString()).displayName
             } catch (Exception ex) {
                 continue
             }                             
			 commentBody = commentBody.replace("[~" + userName + "]", displayName)          
         }
    }
    return commentBody = "[" + comment.authorFullName + "]" + ": " + commentBody
}

return null