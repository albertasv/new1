import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.service.util.handler.MessageUserProcessor
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.mail.MailUtils
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import ru.rosbank.jira.misc.api.WorkflowService

@WithPlugin("ru.rosbank.jira.misc")

@PluginModule
WorkflowService workflowService

def messageUserProcessor = ComponentAccessor.getComponent(MessageUserProcessor)


def subjectPrefix = "transition"
def subject = message.subject as String

if (subject.toLowerCase().startsWith(subjectPrefix)) {
    ApplicationUser appUser = messageUserProcessor.getAuthorFromSender(message)
    if (appUser) {
        appUser = workflowService.getActiveUser(appUser.emailAddress)
    }


    if (appUser) {
        try {
            def subjectSplit = subject.split(":") as List<String>
            if (subjectSplit.size() == 3) {
                def issueKey = subjectSplit[1].trim()
                def newStatus = subjectSplit[2].trim()
                def comment = MailUtils.getBody(message)
                def result = workflowService.transition(appUser, issueKey, newStatus, comment)
                log.info(result)
            }
        } catch (Exception ex) {
            log.error("Exception ", ex)
        }
    }
}