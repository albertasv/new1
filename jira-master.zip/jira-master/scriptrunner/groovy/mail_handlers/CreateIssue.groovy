import com.atlassian.jira.application.ApplicationAuthorizationService
import com.atlassian.jira.application.ApplicationKeys
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.config.util.JiraHome
import com.atlassian.jira.issue.label.LabelManager
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.permission.ProjectPermissions
import com.atlassian.jira.service.services.file.FileService
import com.atlassian.jira.service.util.handler.MessageUserProcessor
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.UserUtils
import com.atlassian.mail.Email
import com.atlassian.mail.MailUtils
import com.atlassian.jira.security.roles.ProjectRoleManager
import com.atlassian.jira.security.roles.ProjectRole
import com.opensymphony.util.TextUtils
import org.apache.commons.io.FileUtils
import com.atlassian.jira.service.util.ServiceUtils
import com.atlassian.jira.util.json.JSONObject

import java.sql.Timestamp
import java.text.SimpleDateFormat
import javax.mail.Address
import javax.mail.Message
import javax.mail.internet.InternetAddress

import com.atlassian.jira.util.ImportUtils
import com.atlassian.jira.issue.index.IssueIndexingService

try {
    
    def messageSizeInBytes = message.getSize()
	def maxMessageSizeInBytes = 10485760
    def messageUserProcessor = ComponentAccessor.getComponent(MessageUserProcessor)
	ApplicationUser reporter = messageUserProcessor.getAuthorFromSender(message)

    if (messageSizeInBytes > maxMessageSizeInBytes) {
        def outOfSizeEmailSubject = "Превышен допустимый размер письма"
        def outOfSizeEmailBody = "Задача по Вашему письму не была создана, так как размер Вашего письма превысил допустимое ограничение, равное 10 МБ."
        sendEmail(reporter.emailAddress, outOfSizeEmailSubject, outOfSizeEmailBody)
        return
    }

    def projectManager = ComponentAccessor.projectManager
    def issueFactory = ComponentAccessor.issueFactory
    JiraHome jiraHome = ComponentAccessor.getComponent(JiraHome)

    def backlogUser = "backlog"
    String kbLink = "https://kb.rosbank.rus.socgen/x/6oEdEg"
    String errorMsg = "Вы можете ознакомится с правилами создания новой задачи на основании входящего письма на странице базы знаний: ${kbLink}.\n" +
            "Либо обратитесь к администратору JIRA."

    def subjectPrefix = "new"
    def subject = message.subject as String
    def filename =""

    log.info("Starting create issue by e-mail...")
    def writer = new StringWriter()
    //def jiraHome = ComponentAccessor.getComponent(JiraHome)
    def fileName ='new_mail.txt'
    def issueFile = new File(jiraHome.getCachesDirectory(), fileName)
    def outputString = subject
    issueFile.write outputString.toString()

    if (subject.toLowerCase().startsWith(subjectPrefix)) {
        

        if (reporter) {
            reporter = getActiveReporterByEmail(reporter.emailAddress)
        }

        if (!reporter) {
            reporter = ComponentAccessor.userManager.getUserByName(backlogUser)
        }

        def attachmentsError = false;
        try {
            def subjectSplit = subject.split(":") as List<String>

            if (subjectSplit.size() < 2) {
                // Incorrect email subject send message
                def errorSubject = "Ошибка формирования задачи - ${subject}"
                def errorBody = "Некорректная тема письма.\n${errorMsg}"
                sendEmail(reporter.emailAddress, errorSubject, errorBody)
                log.error("Split subject exception")
            }      

            def projectKey = subjectSplit[1].trim()


            if (projectKey == "Grade"){
                def grade = subjectSplit[2].trim() 
                def issueKey = subjectSplit[3].trim() 
                def comment = MailUtils.getBody(message)
                def commentSplit = comment.split(":") as List<String>

                comment = "Оценка: " + grade
                if (commentSplit.size() > 1) {comment = comment +"\n" + commentSplit[1]}
                def issue = ServiceUtils.findIssueObjectInString(issueKey )		

                def commentManager = ComponentAccessor.getCommentManager()
                final SD_PUBLIC_COMMENT = "sd.public.comment"
                def properties = [(SD_PUBLIC_COMMENT): new JSONObject(["internal": false] as Map)]
                def commentNew = commentManager.create(issue, reporter, comment, null, null, new Date(), 		properties, true)           

                def customField = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).findByName('Rating')

                def availableOptions = ComponentAccessor.optionsManager.getOptions(customField.getRelevantConfig(issue))
                def optionToSet = availableOptions.find { it.value == grade }
                customField.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(customField), optionToSet), new DefaultIssueChangeHolder())

                boolean wasIndexing = ImportUtils.isIndexIssues()
                ImportUtils.setIndexIssues(true)
                ComponentAccessor.getComponent(IssueIndexingService.class).reIndex(issue)
                ImportUtils.setIndexIssues(wasIndexing)          

                return
            }
            def project = projectManager.getProjectObjByKey(projectKey)
            def issueType = project.issueTypes.find { it.name == subjectSplit[2].trim() }
            def summary

            // Проверка прав на создание задачи в проекте
            if (!ComponentAccessor.permissionManager.hasPermission(ProjectPermissions.CREATE_ISSUES, project, reporter)) {
                def errorSubject = "Ошибка создания задачи - ${subject}"
                def errorBody = "Необходимы права на создание задачи в проекте ${projectKey} - обратитесь к администратору проекта.\n${errorMsg}"
                sendEmail(reporter.emailAddress, errorSubject, errorBody)
                return
            }

            // Issue type processing
            if (issueType) {
                summary = subjectSplit[3]
            } else {
                if (subjectSplit.size() > 2) {
                    summary = subjectSplit[2..subjectSplit.size() - 1].join(":")
                }
                issueType = project.issueTypes.find { it.name == "Task" }
            }

            def newIssue;
            if (project && issueType && reporter) {
                def issueObject = issueFactory.getIssue()
                issueObject.setProjectObject(project)
                issueObject.setIssueTypeId(issueType.id)
                issueObject.setLabels(["mailHandler"].toSet())

                // Low priority
                issueObject.setPriorityId("10003")
                issueObject.setSummary(summary ?: "Автоматически созданная из письма задача")

                def body = MailUtils.getBody(message)
                def stopWord = "****"
                def bodyForProcess = body.lastIndexOf(stopWord) > 0 ? body.substring(0, body.lastIndexOf(stopWord)) : body
                // TODO Replaced with processed body
                // issueObject.setDescription(bodyForProcess)

                issueObject.setReporter(reporter)
                issueObject.setAssignee(projectManager.getDefaultAssignee(project, []))

                try {
                    // Set Issue Source
                    def issueSourceFields = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName('Issue Source')
                    if (issueSourceFields && issueSourceFields.size() > 0) {
                        issueObject.setCustomFieldValue(issueSourceFields[0], "email")
                    }

                    // Set Reporter email
                    def reporterFields = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName('Contact Person from Business')
                    if (reporterFields && reporterFields.size() > 0) {
                        Address[] froms = message.getFrom();
                        String reporterEmail = froms == null ? null : ((InternetAddress) froms[0]).getAddress();
                        issueObject.setCustomFieldValue(reporterFields[0], reporterEmail)
                    }
                } catch (Exception srcEx) {
                    log.info("Filling issue source exception", srcEx)
                }

                if (!issueType.subTask) {
                    newIssue = messageHandlerContext.createIssue(reporter, issueObject)

                    // Add attachments
                    try {
                        log.info("Starting attachments loading...")
                        log.info("Reporter: " + reporter.displayName)
                        def attachments = MailUtils.getAttachments(message)
                        def attachCount = 0
                        log.info("attachments loaded.")
                        attachments.each { MailUtils.Attachment attachment ->
                            try {
                                def destination = new File(jiraHome.home, FileService.MAIL_DIR + "/attach").getCanonicalFile()
                                filename = attachment.filename
                                log.info("Attachment filename is " + filename)
                                /**Если вложение - это письмо, то в имени может быть двоеточие,
                                   что запрещено в windows, и система не даёт сохранять вложения
                                */
                                if (filename.contains("windows_1251")) {
                                   filename = "attachment_" + attachCount + filename.substring(filename.lastIndexOf("."))
                                }
                                if (filename.contains("utf_8")) {
                                   filename = "attachment_" + attachCount + filename.substring(filename.lastIndexOf("."))
                                }
                                def file = FileUtils.getFile(destination, filename) as File
                                FileUtils.writeByteArrayToFile(file, attachment.contents)
                                def contentType = attachment.contentType
                                if (contentType.size() > 255) {
                                    contentType = contentType.split(';')[0]
                                }
                                messageHandlerContext.createAttachment(file, filename, contentType, reporter, newIssue)
                                attachCount++;
                            } catch (Exception aEx) {
                                // Ignore this attachment exception
                                log.error("Add attachment exception1", aEx);
                                attachmentsError = true
                            }
                        }
                    } catch (Exception aaEx) {
                        log.error("Add attachments exception2", aaEx);
                        attachmentsError = true
                    }

                    // Add watchers from cc
                    def userSearchService = ComponentAccessor.userSearchService
                    def watcherManager = ComponentAccessor.watcherManager
                    def addressesCC = message.getRecipients(Message.RecipientType.CC) as List<Address>
                    addressesCC.each {
                        InternetAddress internetAddress = it as InternetAddress
                        def email = internetAddress.address
                        if (TextUtils.verifyEmail(email)) {
                            def users = userSearchService.findUsersByEmail(email)
                            if (users.size() > 0)
                                watcherManager.startWatching(users[0], newIssue)
                        }
                    }

                    // Fill issue fields
                    def labels = [:]
                    def epic
                    def description = new StringBuilder()
                    def assignee
                    def projectRoleManager
                    def role
                    bodyForProcess.split("\n").each {
                        line ->
                            line = line.trim()
                            def appendLine = false
                            try {
                                if (line.startsWith("#") && line.contains("=")) {
                                    def fieldName = line.substring(1, line.indexOf("=")).trim()
                                    def fieldValue = line.substring(line.indexOf("=") + 1, line.size()).trim()
                                    switch (fieldName) {
                                        case "Priority":
                                            def priority = ComponentAccessor.constantsManager.priorities.find { priority -> priority.name == fieldValue }
                                            if (priority) {
                                                newIssue.setPriority(priority)
                                            }
                                            break;
                                        case "Due":
                                            def dueDate = new SimpleDateFormat("dd.MM.yyyy").parse(fieldValue)
                                            newIssue.setDueDate(new Timestamp(dueDate.time))
                                            break;
                                        case "Labels":
                                            fieldValue.split(',').each {
                                                label ->
                                                    ComponentAccessor.getComponent(LabelManager).addLabel(reporter, newIssue.id, label, false)
                                            }
                                            break;
                                        case "Epic":
                                            epic = ComponentAccessor.issueManager.getIssueObject(fieldValue)
                                            break;
                                        case "Reporter":
                                            def reporter_2 = ComponentAccessor.userManager.getUserByName(fieldValue)
                                            if (reporter_2)	newIssue.setReporter(reporter_2)
                                            break;
                                        case "Assignee":
                                            assignee = ComponentAccessor.userManager.getUserByName(fieldValue)
                                            projectRoleManager = ComponentAccessor.getComponent(ProjectRoleManager.class)
                                            role = projectRoleManager.getProjectRole("Project Members")

                                            if (assignee != null && role != null && projectRoleManager
                                                .isUserInProjectRole(assignee, role, newIssue.getProjectObject()) ) {

                                                try {
                                                    newIssue.setAssignee(assignee)
                                                } catch (Exception ex) {
                                                    newIssue.setAssignee(projectManager.getDefaultAssignee(project, []))
                                                }
                                            } else {
                                                newIssue.setAssignee(projectManager.getDefaultAssignee(project, []))
                                            }
                                            break;
                                       case "Component/s":
                                            def components = []
                                            fieldValue.split(',').each { 
                                                label ->
                                                 log.info("The Component/s field value is: " + label)
                                                    def theComponent = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(),label.trim())
                                                    if (theComponent == null) {
                                                        theComponent = ComponentAccessor.getProjectComponentManager().create(label.trim(),"","",0,project.getId())
                                                        components.add(theComponent)
                                                    }
                                                    components.add(theComponent)												                                        
                                            }
                                            newIssue.setComponent(components)
                                        default:
                                            def fields = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName(fieldName)
                                            def field = fields[0]
                                            if (field) {
                                                switch (field.customFieldType.name) {
                                                    case "Text Field (single line)":
                                                    case "Text Field (multi-line)":
                                                    case "URL Field":
                                                        newIssue.setCustomFieldValue(field, fieldValue)
                                                        break;
                                                    case "Labels":
                                                        labels.put(field.idAsLong, fieldValue)
                                                        break;
                                                    case "Select List (single choice)":
                                                    case "Select List (multiple choices)":
                                                        def option = ComponentAccessor.optionsManager.getOptions(field.getRelevantConfig(newIssue)).getOptionForValue(fieldValue, null)
                                                        if (option) {
                                                            newIssue.setCustomFieldValue(field, option)
                                                        }
                                                        break;
                                                    case "Number Field":
                                                        if (fieldValue.integer) {
                                                            newIssue.setCustomFieldValue(field, fieldValue.toDouble())
                                                        }
                                                        break
                                                    case "Date Picker":
                                                    case "Date Time Picker":
                                                        def dateTime = new SimpleDateFormat("dd.MM.yyyy").parse(fieldValue)
                                                        newIssue.setCustomFieldValue(field, new Timestamp(dateTime.time))
                                                        break
                                                    case "RB IT System Field":
                                                        newIssue.setCustomFieldValue(field, fieldValue)
                                                        break
                                                }
                                            }
                                            break;
                                    }
                                } else {
                                    appendLine = true
                                }
                            } catch (Exception ex) {
                                log.info("Parse line exception", ex)
                                appendLine = true
                            }

                            if (appendLine) {
                                description.append(line)
                                description.append("\n")
                            }
                    }

                    newIssue.setDescription(description.toString())

                    newIssue = ComponentAccessor.issueManager.updateIssue(reporter, newIssue, EventDispatchOption.ISSUE_UPDATED, false)
                    labels.each {
                        fieldId, label ->
                            ComponentAccessor.getComponent(LabelManager).addLabel(reporter, newIssue.id, fieldId, label, false)
                    }

                    if (epic) {
                        // TODO Проставление эпика не работает
    //                    def epicLinkField = ComponentAccessor.customFieldManager.getCustomFieldObjectsByName('Epic Link')[0]
    //                    def epicLinkIssue = ComponentAccessor.issueManager.getIssueObject(newIssue.id)
    //                    epicLinkIssue.setCustomFieldValue(epicLinkField, epic)
    //                    epicLinkField.updateValue(null, epicLinkIssue, new ModifiedValue(null, epic), new DefaultIssueChangeHolder())
    //                    ComponentAccessor.issueManager.updateIssue(reporter, epicLinkIssue, EventDispatchOption.ISSUE_UPDATED, false)
                    }
                }
            }

            if (newIssue) {
                def successSubject = "Сформирована задача по входящему письму - ${newIssue.key} | ${newIssue.summary}"
                def successBody = "Issue: https://jirahq.rosbank.rus.socgen:8443/browse/${newIssue.key}\n" +
                        "Summary: ${newIssue.summary}\n" +
                        "Project: ${newIssue.projectObject.name}\n" +
                        "Assignee: ${newIssue.assigneeUser.displayName}\n"

                if (attachmentsError) {
                    def attachmentsErrorMsg = "\nПри загрузке вложений ${filename} произошла ошибка - просьба добавить вложения в задачу в ручном режиме"
                    successBody += attachmentsErrorMsg
                    ComponentAccessor.commentManager.create(newIssue, reporter, attachmentsErrorMsg, false);
                }
                sendEmail(reporter.emailAddress, successSubject, successBody)
            } else {
                sendEmail(reporter.emailAddress, "Ошибка формирования задачи - ${subject}", errorMsg)
                log.error("No issue exception")
            }
        } catch (Exception ex) {
            def errorSubject = "Ошибка формирования задачи - ${subject}"
            def errorBody = "${errorMsg}\nException: ${ex.message}."
            sendEmail(reporter.emailAddress, errorSubject, errorBody)
            log.error("Unrecognized exception ", ex)
        }
    }
} catch (Exception ex) {
    log.error("MailHandler unrecognized exception: ", ex)
}

def sendEmail(String emailAddr, String subject, String body) {
    def mailServer = ComponentAccessor.mailServerManager.defaultSMTPMailServer
    if (mailServer) {
        Email email = new Email(emailAddr)
        email.setSubject(subject)
        email.setBody(body)
        mailServer.send(email)
    }
}

ApplicationUser getActiveReporterByEmail(String email) {
    UserUtils.getUsersByEmail(email).find { user ->
        if (ComponentAccessor.getComponent(ApplicationAuthorizationService).canUseApplication(user, ApplicationKeys.SOFTWARE)) {
            return user
        }
    }
}