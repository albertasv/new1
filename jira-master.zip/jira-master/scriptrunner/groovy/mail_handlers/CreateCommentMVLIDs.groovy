import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.comments.CommentManager
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.mail.MailUtils

def subjectPrefix = "MVLIDs:"
def subject = message.getSubject() as String
// Trim
subject = subject.replaceAll( '(?:\\[?(?:[Ff][Ww][Dd]?|[Rr][Ee])(?:\\s*[:;-]+\\s*\\]?))+' , '')

if (subject.startsWith(subjectPrefix)) {
    def mvlIds = subject.replaceAll(subjectPrefix, "")
    def body = MailUtils.getBody(message)
    def senders = MailUtils.getSenders(message)

    def stopWord = "****"
    def comment = body.lastIndexOf(stopWord) > 0 ? body.substring(0, body.lastIndexOf(stopWord)) : body

    senders.each() {
        sender ->
            def senderAppUsers = ComponentAccessor.getUserSearchService().findUsersByEmail(sender)
            senderAppUsers.iterator().each() {
                senderAppUser ->
                    def issueManager = ComponentAccessor.getIssueManager()
                    //def customFieldManager = ComponentAccessor.getCustomFieldManager()

                    def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
                    def searchProvider = ComponentAccessor.getComponent(SearchProvider)
                    def searchQuery = jqlQueryParser.parseQuery("cf[10430] IN (" + mvlIds + ")")
                    def resultIssues = searchProvider.search(searchQuery, senderAppUser, PagerFilter.getUnlimitedFilter())

                    if (resultIssues.total > 0) {
                        CommentManager commentMgr = ComponentAccessor.getCommentManager()
                        resultIssues.getIssues().each() {
                            documentIssue ->
                                def issue = issueManager.getIssueObject(documentIssue.id)
                                commentMgr.create(issue, senderAppUser, comment, true)
                        }
                    }
            }
    }
}