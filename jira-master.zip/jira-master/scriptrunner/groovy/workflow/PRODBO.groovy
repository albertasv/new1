import com.atlassian.jira.component.ComponentAccessor

// def issue = ComponentAccessor.issueManager.getIssueObject("PRODBO-3600")
def microservicesField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_15307")
def microservices = issue.getCustomFieldValue(microservicesField)

if ((issue.components*.name?.contains("Front-End") || issue.components*.name?.contains("Back-End"))
        && !microservices) {
    return false
}