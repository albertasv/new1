import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
 
def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
// Check issue result, then uncomment issue.store() to save values
def searchQuery = jqlQueryParser.parseQuery("(project IN (PRJ, CRS, PRE) AND created >= '2021-09-01') OR assignee IS EMPTY")
 
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)
def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())
 
def sb = new StringBuilder()
if (resultIssues.total > 0) {
    resultIssues.results.each() {
        documentIssue ->
            def issue = issueManager.getIssueObject(documentIssue.id)           
            try {
                // Update assignee
                if(!issue.assignee){
                    issue.setAssignee(issue.projectObject.lead)
                    //issue.store()
                    sb.append("Updated ${issue.key} with assignee ${issue.assignee}\n<br/>")
                }
                // Update reporter
                if(!issue.reporter){
                    issue.setReporter(issue.projectObject.lead)
                    //issue.store()
                    sb.append("Updated ${issue.key} with reporter ${issue.reporter}\n<br/>")
                }
            } catch (Exception ex) {
                sb.append("Error while update ${issue.key}\n")
            }
    }
}
return sb.toString()