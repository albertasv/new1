import com.atlassian.jira.component.ComponentAccessor

def wfManager = ComponentAccessor.workflowManager
def projects = ComponentAccessor.projectManager.projectObjects

def result = new StringBuilder()
result.append("Category;PKey;PName;IssueType;Workflow;Statuses<br/>")
projects.each { project ->
    def category = project.projectCategory?.name ?: 'None'
    def pkey = project.key
    def pname = project.name
    project.issueTypes.each { issueType ->
        def wf = wfManager.getWorkflow(project.id, issueType.id)
        def statuses = wf.linkedStatusObjects.iterator().collect{status -> status.name}.join(",")
        result.append("${category};${pkey};${pname};")
        result.append("${issueType.name};")
        result.append("${wf.name};")
        result.append("${statuses}")
        result.append("<br/>")
    }
}

return result