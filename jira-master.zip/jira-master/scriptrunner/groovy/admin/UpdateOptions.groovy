import com.atlassian.jira.component.ComponentAccessor

def issueManager = ComponentAccessor.issueManager
def optionsManager = ComponentAccessor.optionsManager

def envField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('Environment Found')
def issue = issueManager.getIssueObject("NEWFRONT-1000")
def opts = optionsManager.getOptions(envField.getRelevantConfig(issue))

opts.each {
    opt ->
        if (!(opt.value in ['DEV', 'TEST', 'CERT', 'PROD'])){
            log.error("${opt.value} ${opt.disabled}")
            //opt.setDisabled(true)
            //optionsManager.updateOptions([opt])
        }
}