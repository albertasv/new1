import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchQuery = jqlQueryParser.parseQuery("key = JIT-1")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)

def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())

def sb = new StringBuilder()

if (resultIssues.total > 0) {
    resultIssues.results.each() {
        documentIssue ->
            def issue = issueManager.getIssueObject(documentIssue.id)
            sb.append(issue)
    }
}

return sb.toString()