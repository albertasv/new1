import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.event.type.EventDispatchOption

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def searchQuery = jqlQueryParser.parseQuery("issueFunction in issuesInEpics('type = Epic AND \"Portfolio Issue\" is not empty') and \"Portfolio Issue\" is EMPTY")
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)

def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())

if (resultIssues.total > 0) {
	resultIssues.results.each() {
        documentIssue ->      
            def issue = issueManager.getIssueObject(documentIssue.id)
        	def value = issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(16905))
        	if(value == null) {
                //Получаем значение поля Epic Link
                def epicName
                def portfolioIssueFieldValue
                epicName = issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(11006)).toString()
                //Получаем Epic по имени Epic'а, которое было указано в текущей Issue
                def epic = issueManager.getIssueObject(epicName)
                //Из полученного Epic'a получаем значение поля Portfolio Issue
                try{
                    portfolioIssueFieldValue = epic.getCustomFieldValue(customFieldManager.getCustomFieldObject(16905))
                    //Устанавливаем значение поля Portfolio Issue в Issue из того, что получили из Epic'а
                    issue.setCustomFieldValue(customFieldManager.getCustomFieldObject(16905), portfolioIssueFieldValue)
                    //Сохраняем изменения
                    issueManager.updateIssue(currentUser, issue, EventDispatchOption.DO_NOT_DISPATCH, false)
                }catch (NullPointerException ex) {
                    log.error(issue.key)
                }
            } else {
                
            }
    }
}
