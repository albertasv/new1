import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import com.tempoplugin.jira.plan.core.api.AssigneeType
import com.tempoplugin.planning.PlanningService
import com.tempoplugin.planning.TimePlanDao
import org.apache.commons.lang3.tuple.Pair
import org.joda.time.LocalDate

@WithPlugin("is.origo.jira.tempo-plugin")

@PluginModule
PlanningService planningService

def user = ComponentAccessor.userManager.getUserByName("rb076022")
Calendar from = Calendar.getInstance();
//Period from current monday
from.set(Calendar.DAY_OF_WEEK, 2);
from.set(Calendar.HOUR_OF_DAY, 0);
from.set(Calendar.MINUTE, 0);
from.set(Calendar.SECOND, 0);
from.set(Calendar.MILLISECOND, 0);

//Period to current moday + 7 days
Calendar to = (Calendar) from.clone();
to.add(Calendar.DAY_OF_YEAR, 7);

def dates = Pair.of(new LocalDate(from.getTime()), new LocalDate(to.getTime()).plusDays(1))
def res = new StringBuilder()
res.append("Delete plans for period: $from.time - $to.time. Ids:").append("<br/>")
def plans = planningService.getAllocationsForAssignees(List.of(user.key), AssigneeType.USER, dates);
for (def plan : plans) {
    def planId = ((TimePlanDao) plan).id
    res.append("$planId").append("<br/>")
    planningService.delete(planId)
}
return res