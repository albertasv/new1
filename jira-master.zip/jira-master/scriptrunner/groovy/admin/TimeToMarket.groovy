import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.greenhopper.service.sprint.Sprint

List.metaClass.safeFirst = { -> delegate?.empty ? null : delegate.first() }
List.metaClass.safeLast = { -> delegate?.empty ? null : delegate.last() }

def issueManager = ComponentAccessor.issueManager
def chm = ComponentAccessor.changeHistoryManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)
def searchQuery = jqlQueryParser.parseQuery("project = AGP")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def resultIssues = searchProvider.search(searchQuery, currentUser, PagerFilter.getUnlimitedFilter())

def dateFormat = 'yyyy-MM-dd'

def sb = new StringBuilder()
sb.append("KEY;Status;Summary;Issue Type;Issue Created;Sprint ID;Sprint;Sprint Start;Added to Sprint (FIRST);Added to Sprint (LAST);To Closed (LAST);To Ready to Release (LAST)<br/>")
resultIssues.issues.each() {
    documentIssue ->
        def issue = issueManager.getIssueObject(documentIssue.id)
        def SPRINT_FIELD_ID = 11004
        def sprintField = ComponentAccessor.customFieldManager.getCustomFieldObject(SPRINT_FIELD_ID)
        def sprint = issue.getCustomFieldValue(sprintField)?.find { true } as Sprint

        def changes = ComponentAccessor.changeHistoryManager.getAllChangeItems(issue)
        def sprintFirstChange = changes.findAll { change -> change.field == "Sprint" }?.safeFirst()
        def sprintChange = changes.findAll { change -> change.field == "Sprint" }?.safeLast()
        def statusChange1 = changes.findAll { change ->
            change.field == "status" && change.tos?.find {
                true
            }?.value == 'Closed'
        }?.safeLast()
        def statusChange2 = changes.findAll { change ->
            change.field == "status" && change.tos?.find {
                true
            }?.value == 'Ready To Release'
        }?.safeLast()
        sb.append("${issue.key};${issue.status.name};${issue.summary};${issue.issueType.name};${issue.created.format(dateFormat)};")
        sb.append("${sprint ? sprint?.id : ''};${sprint ? sprint.name : ''};${sprint && sprint.startDate ? sprint.startDate.toString(dateFormat) : ''};")
        sb.append("${sprintFirstChange ? sprintFirstChange?.created?.format(dateFormat) : ''};")
        sb.append("${sprint && sprintChange ? sprintChange?.created?.format(dateFormat) : ''};")
        sb.append("${statusChange1 ? statusChange1.created?.format(dateFormat) : ''};")
        sb.append("${statusChange2 ? statusChange2?.created?.format(dateFormat) : ''};")
        sb.append("<br/>")
}

return sb.toString()