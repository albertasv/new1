import com.atlassian.jira.component.ComponentAccessor

/**
 * Удаление неактивных ЖЦ
 */

def workflowManager = ComponentAccessor.workflowManager
def schemeManager = ComponentAccessor.workflowSchemeManager

def sb = new StringBuffer()

workflowManager.workflows.each {
    if (!it.systemWorkflow) {
        def schemes = schemeManager.getSchemesForWorkflow(it)
        if (schemes.size() == 0 && it.name != "PPMC Approval workflow") {
            sb.append("Workflow To Delete: ${it.name} - ${it.updatedDate}\n <br/>")
            //Uncomment to delete
            //workflowManager.deleteWorkflow(it)
        }
    }
}

return sb.toString()