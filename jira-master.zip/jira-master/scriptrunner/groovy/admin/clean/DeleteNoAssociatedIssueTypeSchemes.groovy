import com.atlassian.jira.component.ComponentAccessor

/**
 * Удаление неактивных Issue type schemes
 */
def itsManager = ComponentAccessor.issueTypeSchemeManager
def defaultScheme = itsManager.defaultIssueTypeScheme

def sb = new StringBuffer()
def count = 0

itsManager.allSchemes.each { it ->
    if (it == defaultScheme) {
        //do not delete the default scheme
        return
    }

    if (it.associatedProjectIds.size() == 0) {
        sb.append("IssueTypeScheme ${count++} to delete: ${it.name}\n <br/>")
        //Uncomment to delete
        //itsManager.deleteScheme(it)
    }
}
return sb.toString()