import com.atlassian.jira.component.ComponentAccessor

/**
 * Удаление неактивных статусов
 */

def constantsManager = ComponentAccessor.constantsManager
def workflowManager = ComponentAccessor.workflowManager

def sb = new StringBuilder()
def count = 0
constantsManager.statuses.each { status ->
    def associated = false
    workflowManager.workflows.find { workflow ->
        workflow.linkedStatusIds.find { linkedStatusId ->
            if (linkedStatusId == status.id) {
                associated = true
            }
            return associated
        }
        return associated
    }

    if (associated == false) {
        sb.append("To delete ${status.name} \n<br>")
        //Uncomment to delete
        //statusManager.removeStatus(status.id)
    }
}

return sb.toString()