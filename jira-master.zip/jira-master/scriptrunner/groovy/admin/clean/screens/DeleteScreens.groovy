import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.fields.screen.FieldScreenFactory
import com.atlassian.jira.issue.fields.screen.FieldScreenManager
import com.atlassian.jira.issue.fields.screen.FieldScreenSchemeManager
import com.atlassian.jira.web.action.admin.issuefields.screens.ViewFieldScreens
import com.atlassian.jira.workflow.WorkflowManager

/**
 * Удаление неактивных Screens
 */
FieldScreenManager fieldScreenManager = ComponentAccessor.getFieldScreenManager()
FieldScreenFactory fieldScreenFactory = ComponentAccessor.getComponent(FieldScreenFactory.class)
FieldScreenSchemeManager fieldScreenSchemeManager = ComponentAccessor.getComponent(FieldScreenSchemeManager.class)
WorkflowManager workflowManager = ComponentAccessor.getWorkflowManager()
ViewFieldScreens viewFieldScreens = new ViewFieldScreens(fieldScreenManager, fieldScreenFactory, fieldScreenSchemeManager, workflowManager)

// use StringBuffer to spit out log to screen for ScriptRunner Console
def sb = new StringBuffer()
def count = 0

sb.append('Screens that were deleted:<br/>\n')

fieldScreenManager.getFieldScreens().each { fieldScreen ->
    //find all screens with no (or only null/previously deleted) screen schemes (1) or workflows (2)
    def allEmptyOrNull = true
    //screen schemes (1)
    viewFieldScreens.getFieldScreenSchemes(fieldScreen).each { fieldScreenScheme ->
        if (fieldScreenScheme != null) {
            allEmptyOrNull = false
            return
        }
    }
    if (!allEmptyOrNull) {
        return
    }
    //workflows (2)
    viewFieldScreens.getWorkflows(fieldScreen).each { workflow ->
        if (workflow != null) {
            allEmptyOrNull = false
            return
        }
    }

    if (allEmptyOrNull) {
        sb.append("Screen ${count++} to delete: ${fieldScreen.name}\n <br/>")
        //fieldScreenManager.removeFieldScreen(fieldScreen.getId())
    }
}
return sb.toString()