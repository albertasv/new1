import com.atlassian.jira.component.ComponentAccessor

/**
 * Удаление неактивных Issue type screen schemes
 */
def itssManager = ComponentAccessor.issueTypeScreenSchemeManager
def defaultScheme = itssManager.defaultScheme

def sb = new StringBuffer()
def count = 0

itssManager.issueTypeScreenSchemes.each {
    if (it == defaultScheme) {
        //do not delete the default scheme
        return
    }
    if (it.getProjects().size() == 0) {
        sb.append("IssueTypeScreenScheme ${count++} to delete: ${it.name}\n <br/>")
        //remove any associations with screen schemes
        itssManager.removeIssueTypeSchemeEntities(it)
        //remove the issue type screen scheme
        itssManager.removeIssueTypeScreenScheme(it)
    }
}
return sb.toString()