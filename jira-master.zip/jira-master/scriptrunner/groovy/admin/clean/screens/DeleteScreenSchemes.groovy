import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.fields.screen.FieldScreenSchemeManager

/**
 * Удаление неактивных Screen schemes
 */

def fssManager = ComponentAccessor.getComponent(FieldScreenSchemeManager.class)
def itssManager = ComponentAccessor.issueTypeScreenSchemeManager

def sb = new StringBuffer()
def count = 0

fssManager.fieldScreenSchemes.each { fss ->

    def itssCollection = itssManager.getIssueTypeScreenSchemes(fss)

    // find field screen schemes that are still associated with deleted issues type screen schemes
    def allDeleted = true
    itssCollection.each { itss ->
        if (itss != null) {
            allDeleted = false
            return
        }
    }

    //remove field screen schemes with no (valid) associated issue type screen schemes
    if (itssCollection.size() == 0 || allDeleted == true) {
        sb.append("ScreenScheme ${count++} to delete: ${fss.name}\n <br/>")
        //remove association to any screens
        fssManager.removeFieldSchemeItems(fss)
        //remove field screen scheme
        fssManager.removeFieldScreenScheme(fss)
    }
}
return sb.toString()