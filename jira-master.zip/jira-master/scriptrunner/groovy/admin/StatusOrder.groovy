import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.config.StatusManager

def statusManager = ComponentAccessor.getComponent(StatusManager.class)

//Backlog Up x20
20.times {
    sm.moveStatusUp("10905")
}