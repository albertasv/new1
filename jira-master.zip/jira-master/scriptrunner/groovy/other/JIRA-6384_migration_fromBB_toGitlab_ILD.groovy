import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.link.RemoteIssueLinkManager
import com.atlassian.jira.issue.link.RemoteIssueLinkBuilder
import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService
import com.atlassian.jira.issue.link.RemoteIssueLink
import com.atlassian.jira.issue.Issue

import com.atlassian.jira.issue.MutableIssue;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.onresolve.scriptrunner.runner.customisers.WithPlugin;
import com.atlassian.jira.util.ErrorCollection;
import io.atlassian.fugue.Either;
import org.codehaus.jackson.JsonNode;
import java.util.Collection;

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser 

IssueManager im = ComponentAccessor.getIssueManager();
//def project = ComponentAccessor.projectManager.getProjectObjByKey("ILD")
def project = ComponentAccessor.projectManager.getProjectObjByKey("ILAT")

def issues = im.getIssueObjects(im.getIssueIdsForProject(project.id))
def ii = 1 as int

for( issue in issues) {
   
    RemoteIssueLinkManager remoteIssueLinkManager = ComponentAccessor.getComponent(RemoteIssueLinkManager)

    def rilm = ComponentAccessor.getComponentOfType(RemoteIssueLinkManager);
    def remoteLink =    rilm.getRemoteIssueLinksForIssue(issue);

        Set<String> newUrls = []

    for( l in remoteLink) {
        def title = l.getTitle()
        def url = l.getUrl()
        if (url.indexOf("https://bitbucket.gts.rus.socgen") > -1){
            def newURL = "https://gitlab.rosbank.rus.socgen/il/ib/rb-iib10/-/"
            
            if (url.indexOf("pull-requests") > -1){
                def subjectSplit = url.split("pull-requests/") as List<String>  
                def subjectSplitNumber = subjectSplit[1].split("/") as List<String>
                newURL = newURL + "merge_requests/" + subjectSplitNumber[0]
            }    
            else if (url.indexOf("commits") > -1){           
                def subjectSplitNumber = url.split("commits/") as List<String>
                newURL = newURL + "commit/" + subjectSplitNumber[1]
            }
            else if(url.indexOf("https://bitbucket.gts.rus.socgen/projects/IB/repos/rb-iib10/browse?at=refs%2Fheads%2Ffeature%2FMetricsCollectionManagement") > -1){
                        
                newURL = "https://gitlab.rosbank.rus.socgen/il/ib/rb-iib10/-/tree/feature/MetricsCollectionManagement"            
            }
            else if(url.indexOf("https://bitbucket.gts.rus.socgen/projects/IB/repos/rb-iib10/browse") > -1){
                
                newURL = newURL + "tree/master" 
                if (url.length() > 66) {
                    newURL = newURL + url.substring(66)      
                }
            }
            else if(url.indexOf("https://bitbucket.gts.rus.socgen/projects/IB/repos/rb-iib10/diff") > -1){
                        
                newURL = newURL + "tree/master" + url.substring(64)            
            }       
            else{                    
                newURL = "###"
                
            }
            if (title.indexOf("https://bitbucket.gts.rus.socgen") > -1){
                title = newURL            
            }
        
            newUrls.add(newURL)
        
        //build link
            def linkBuilder = new RemoteIssueLinkBuilder()
            linkBuilder.issueId(issue.id)
            linkBuilder.applicationName("Gitlab")
            linkBuilder.applicationType("https://gitlab.rosbank.rus.socgen./")
            linkBuilder.relationship("Gitlab")
            linkBuilder.title(newURL)
            linkBuilder.url(newURL)     
            
            remoteIssueLinkManager.createRemoteIssueLink( linkBuilder.build(), currentUser);
            //remoteIssueLinkManager.removeRemoteIssueLink(l.getId(), currentUser);             
        
        }
    }    
}  



