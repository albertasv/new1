import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchQuery = jqlQueryParser.parseQuery("project in (ARP, DMS, VCT) AND issuetype = Epic")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)

def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())

def sb = new StringBuilder()
def epicNameField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('Epic Name')

if (resultIssues.total > 0) {
    resultIssues.results.each() {
        documentIssue ->
            def issue = issueManager.getIssueObject(documentIssue.id) as MutableIssue
            sb.append("Epic ${issue.key} was renamed: ${issue.summary} -> ${issue.getCustomFieldValue(epicNameField)}<br/>")
            issue.setSummary(issue.getCustomFieldValue(epicNameField) as String)
            issueManager.updateIssue(currentUser, issue, EventDispatchOption.ISSUE_UPDATED, false)
    }
}

return sb.toString()