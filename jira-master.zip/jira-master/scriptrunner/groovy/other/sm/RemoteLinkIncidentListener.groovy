import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.link.RemoteIssueLink
import com.atlassian.jira.issue.link.RemoteIssueLinkBuilder
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue

def issueEvent = event as IssueEvent
def issue = event.issue as MutableIssue

if (issueEvent.eventTypeId == EventType.ISSUE_CREATED_ID || issueEvent.eventTypeId == EventType.ISSUE_UPDATED_ID) {
    def smIncidentField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14909");
    def smIncidentValue = issue.getCustomFieldValue(smIncidentField) as String

    if (smIncidentValue) {
        def smIncidentChange = event?.changeLog?.getRelated("ChildChangeItem")?.find { it.field == "Номер инцидента в SM" }
        if (smIncidentChange) {
            def remoteIssueLinkService = ComponentAccessor.getComponent(RemoteIssueLinkService.class)
            def links = remoteIssueLinkService.getRemoteIssueLinksForIssue(event.user, issue).remoteIssueLinks
            def linkExist = links.find {
                link -> ((RemoteIssueLink) link).url.contains(smIncidentValue)
            }
            if (!linkExist) {
                def linkBuilder = new RemoteIssueLinkBuilder()
                linkBuilder.issueId(issue.id)
                linkBuilder.title("Инцидент в SM ${smIncidentValue}")
                def smUrl = "https://sm/sm/index.do?ctx=docEngine&file=probsummary&query=number%3D%22${smIncidentValue}%22"
                linkBuilder.url(smUrl)
                def validateCreate = remoteIssueLinkService.validateCreate(event.user, linkBuilder.build())
                if (validateCreate.isValid()) {
                    remoteIssueLinkService.create(event.user, validateCreate)
                }
            }
        }
    }
}
