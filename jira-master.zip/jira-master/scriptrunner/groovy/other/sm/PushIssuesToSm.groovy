import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.event.Event
import com.atlassian.event.api.EventPublisher
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import groovyx.net.http.HTTPBuilder
import static groovyx.net.http.ContentType.*
import groovyx.net.http.ContentType
import static groovyx.net.http.Method.*
import com.atlassian.event.issue.*
import com.atlassian.jira.issue.MutableIssue

def issueManager = ComponentAccessor.issueManager
def issueKeysList = ["PHUB-1689"] // Здесь нужно подставлять номера тасков (через запятую), которые нужно повторно синхронизировать с SM
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
ArrayList<MutableIssue> resultIssues = []
def issueEventPublisher = ComponentAccessor.getComponent(EventPublisher.class)
def issueEvenTypeId = ComponentAccessor.eventTypeManager.getEventType(4L).getId()
def resultMessage = new StringBuilder()
def params = [:] as HashMap
issueKeysList.each() { issueKey ->  
	resultIssues.add(issueManager.getIssueByCurrentKey(issueKey))
}

if (resultIssues.size() > 0) {
    resultIssues.each() {
        issue ->
        if (issue) {
            try {
                def issueEvent = new IssueEvent(issue, params, currentUser, issueEvenTypeId, false)
                issueEventPublisher.publish(issueEvent)
            } catch (Exception ex) {
                resultMessage.append(ex.getMessage())
            } 
        }           
    }
}
return resultMessage.toString()