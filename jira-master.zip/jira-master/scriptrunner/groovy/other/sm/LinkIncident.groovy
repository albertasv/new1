import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.link.RemoteIssueLinkBuilder
import com.atlassian.sal.api.ApplicationProperties
import com.atlassian.sal.api.UrlMode
import com.atlassian.jira.issue.link.RemoteIssueLink
import com.atlassian.sal.api.user.UserManager
import com.onresolve.scriptrunner.runner.ScriptRunnerImpl
import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import groovy.transform.BaseScript

import javax.servlet.http.HttpServletRequest
import javax.ws.rs.core.MediaType
import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response

@BaseScript CustomEndpointDelegate delegate

def applicationProperties = ScriptRunnerImpl.getOsgiService(ApplicationProperties)
def issueManager = ComponentAccessor.issueManager
def smIncidentField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14909");

/**
 * Show confirmation dialog
 */
linkSMDialog(
        httpMethod: "GET", groups: ["jira_users"]
) { MultivaluedMap queryParams ->

    def issueId = queryParams.getFirst("issueId") as Long
    def issue = issueManager.getIssueObject(issueId)
    def smIncidentValue = issue.getCustomFieldValue(smIncidentField)
    def smSDValue = ''
    def dialog =
            """<section role="dialog" id="sr-dialog" class="aui-layer aui-dialog2 aui-dialog2-medium" aria-hidden="true" data-aui-remove-on-hide="true">
            <header class="aui-dialog2-header">
                <h2 class="aui-dialog2-header-main">Link SM</h2>
                <a class="aui-dialog2-header-close">
                    <span class="aui-icon aui-icon-small aui-iconfont-close-dialog">Close</span>
                </a>
            </header>
            <script>
                function submitLink() {
                    var inputIM = document.getElementById("sm-im-input");
                    var inputSD = document.getElementById("sm-sd-input");
                    window.location.href = "/rest/scriptrunner/latest/custom/linkSM?issueId=${issue.id}&smIM=" + inputIM.value + "&smSD=" + inputSD.value;
                }
                var btnEl = document.getElementById("sm-incident-btn");
                if (btnEl.addEventListener){
                    btnEl.addEventListener("click", submitLink, false);
                } else if (btnEl.attachEvent){
                    btnEl.addAttachEvent("onclick", submitLink);
                }
            </script>
            <div class="aui-dialog2-content">
                <form class="aui">
                    <div class="field-group">
                        <label>Номер инцидента в SM</label>
                        <input class="textfield text" id="sm-im-input" value="${smIncidentValue ?: ''}">
                        <div class="description">Перед переходом по ссылке через «связи запроса» авторизуйтесь в SM как «ИТ-специалист». Пример номера инцидента SM: IM1234567</div>
                    </div>
                    <div class="field-group">
                        <label>Номер обращения в SM</label>
                        <input class="textfield text" id="sm-sd-input" value="${smSDValue ?: ''}">
                        <div class="description">Пример номера обращения SM: SD1234567</div>
                    </div>
                 </form>
            </div>
            <footer class="aui-dialog2-footer">
                <div class="aui-dialog2-footer-actions">
                    <a class="aui-button aui-button-primary" id="sm-incident-btn">Link</a>                
                    <button id="dialog-close-button" class="aui-button aui-button-link">Cancel</button>
                </div>                
            </footer>
        </section>
        """
    Response.ok().type(MediaType.TEXT_HTML).entity(dialog.toString()).build()
}

/**
 *
 */
linkSM(
        httpMethod: "GET", groups: ["jira_users"]
) { MultivaluedMap queryParams, String body, HttpServletRequest request ->

    def userManager = ComponentAccessor.getOSGiComponentInstanceOfType(UserManager)
    def userProfile = userManager.getRemoteUser(request)
    def currentUser = ComponentAccessor.userManager.getUserByName(userProfile.username)

    def baseUrl = applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
    def issueId = queryParams.getFirst("issueId") as Long
    def issue = issueManager.getIssueObject(issueId)

    // Link Incident
    def smIncidentValue = queryParams.getFirst("smIM") as String
    def remoteIssueLinkService = ComponentAccessor.getComponent(RemoteIssueLinkService.class)
    def links = remoteIssueLinkService.getRemoteIssueLinksForIssue(currentUser, issue).remoteIssueLinks

    // Fill Incident Field
    issue.setCustomFieldValue(smIncidentField, smIncidentValue ?: null)
    // Create Incident Link, moved to listener (!)
    /*if (smIncidentValue) {
        def linkExist = links.find {
            link -> ((RemoteIssueLink) link).url.contains(smIncidentValue)
        }
        if (!linkExist) {
            def linkBuilder = new RemoteIssueLinkBuilder()
            linkBuilder.issueId(issue.id)
            linkBuilder.title("Инцидент в SM ${smIncidentValue}")
            def smUrl = "https://sm/sm/index.do?ctx=docEngine&file=probsummary&query=number%3D%22${smIncidentValue}%22"
            linkBuilder.url(smUrl)
            def validateCreate = remoteIssueLinkService.validateCreate(currentUser, linkBuilder.build())
            if (validateCreate.isValid()) {
                remoteIssueLinkService.create(currentUser, validateCreate)
            }
        }
    }*/
    // Link SD
    def smSDValue = queryParams.getFirst("smSD") as String
    // Create SD Link
    if (smSDValue) {
        def linkExist = links.find {
            link -> ((RemoteIssueLink) link).url.contains(smSDValue)
        }
        if (!linkExist) {
            def linkBuilder = new RemoteIssueLinkBuilder()
            linkBuilder.issueId(issue.id)
            linkBuilder.title("Обращение в SM ${smSDValue}")
            def smUrl = "https://sm/sm/index.do?ctx=docEngine&file=incidents&query=incident.id%3D%22${smSDValue}%22"
            linkBuilder.url(smUrl)
            def validateCreate = remoteIssueLinkService.validateCreate(currentUser, linkBuilder.build())
            if (validateCreate.isValid()) {
                remoteIssueLinkService.create(currentUser, validateCreate)
            }
        }
    }

    // Update Issue
    issueManager.updateIssue(currentUser, issue, EventDispatchOption.ISSUE_UPDATED, false)

    Response.temporaryRedirect(URI.create("${baseUrl}/browse/${issue.key}")).build()
}