import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.label.LabelManager
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter

def issueManager = ComponentAccessor.issueManager
def customFieldManager = ComponentAccessor.customFieldManager
def labelMgr = ComponentAccessor.getComponent(LabelManager)

def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)
def searchQuery = jqlQueryParser.parseQuery("\"Business Domain (Text)\" is not EMPTY AND project in (ARP)")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def resultIssues = searchProvider.search(searchQuery, currentUser, PagerFilter.getUnlimitedFilter())

def sb = new StringBuilder()
resultIssues.issues.each() {
    documentIssue ->
        def issue = issueManager.getIssueObject(documentIssue.id)
        def fromFieldValue = issue.getCustomFieldValue(customFieldManager.getCustomFieldObjectByName("Business Domain (Text)")) as String
        fromFieldValue = fromFieldValue.replaceAll(" ", "_")
        def toFieldId = customFieldManager.getCustomFieldObjectByName("Customer/s").getIdAsLong()
        sb.append("Copy ${issue.key}: ${fromFieldValue} <br/>")
        //labelMgr.addLabel(currentUser, issue.getId(), toFieldId, fromFieldValue, false)
}

return sb.toString()