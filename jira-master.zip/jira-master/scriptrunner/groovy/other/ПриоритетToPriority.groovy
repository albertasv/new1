// JIRA-141 Объединение полей Приоритет и штатного Priority
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.event.type.EventDispatchOption

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)
def searchQuery = jqlQueryParser.parseQuery("project = NEWFRONT and Приоритет is not EMPTY")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def resultIssues = searchProvider.search(searchQuery, currentUser, PagerFilter.getUnlimitedFilter())

def customFieldManager = ComponentAccessor.customFieldManager
def prField = customFieldManager.getCustomFieldObject("customfield_10411") // Приоритет field

def constantsManager = ComponentAccessor.constantsManager
def priorities = constantsManager.priorities

def sb = new StringBuilder()
resultIssues.issues.each() {
    documentIssue ->
        def issue = issueManager.getIssueObject(documentIssue.id)
        def prFieldValue = issue.getCustomFieldValue(prField)?.value

        priorities.each {
            priority ->
                if (priority.name == prFieldValue) {
                    // TODO Uncomment to update priority
                    sb.append("Update ${issue.key}: from ${issue.priority?.name} to ${prFieldValue} \n")
                    //issue.setPriorityObject(priority)
                    //issueManager.updateIssue(currentUser, issue, EventDispatchOption.ISSUE_UPDATED, false)
                    sb.append(" - OK<br>")
                }
        }
}

return sb.toString()