import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.query.Query
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.customfields.option.Options
import com.atlassian.jira.issue.customfields.manager.OptionsManager
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.customfields.option.Option


def issueManager = ComponentAccessor.issueManager
def customFieldMgr = ComponentAccessor.customFieldManager
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)
def release_TypeField = customFieldMgr.getCustomFieldObjectByName("Release Type")
def releaseTypeField = customFieldMgr.getCustomFieldObjectByName("ReleaseType")
def result = [:] as HashMap
def oldValueToOptionMapping = [:] as HashMap
oldValueToOptionMapping.put("{null=Срочный релиз, 1=Регуляторные доработки}", "Внеплановый релиз - Регуляторные требования")
oldValueToOptionMapping.put("{null=Плановый Релиз, 1=Major}", "Плановый релиз - Major")
oldValueToOptionMapping.put("{null=Плановый Релиз, 1=Minor}", "Плановый релиз - Minor")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=Откат}", "Внеплановый релиз - Откат")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=Высокоприоритетная задача}", "Внеплановый релиз - Высокоприоритетная задача")
oldValueToOptionMapping.put("{null=Не применимо}", "Неприменимо")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=Обоснование: Высокоприоритетная задача}", "Внеплановый релиз: Высокоприоритетная задача")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=Обоснование: Экономическое/Конкурентное преимущество}", "Внеплановый релиз - Высокоприоритетная задача")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=Обоснование: Исправление дефектов}", "Внеплановый релиз - Исправление багов/инцидентов")
oldValueToOptionMapping.put("{null=Внеплановый релиз, 1=HotFix}", "Внеплановый релиз - Исправление багов/инцидентов")
oldValueToOptionMapping.put("{null=Hotfix}", "Внеплановый релиз - Исправление багов/инцидентов")
def searchResult
def issues
def release_TypeFieldValue
def jqlQuery = "\"Release Type\" is not empty"
def jqlParseResult = searchService.parseQuery(currentUser, jqlQuery)

if (jqlParseResult.isValid()) {
	searchResult = searchService.search(currentUser, jqlParseResult.getQuery(), PagerFilter.getUnlimitedFilter())
	issues = searchResult.results.collect {issueManager.getIssueObject(it.id)}
} else {
  	return "Invalid JQL: " + jqlQuery
}

for(issue in issues) {
    try {        
     	release_TypeFieldValue = (String) issue.getCustomFieldValue(release_TypeField)
     	def availableOptions = ComponentAccessor.optionsManager.getOptions(releaseTypeField.getRelevantConfig(issue))
        for (String key in oldValueToOptionMapping.keySet()) {
            if (key.toLowerCase().equals(release_TypeFieldValue.toLowerCase())) {
                def newValue = oldValueToOptionMapping.getAt(key)
                Option optionToSet = availableOptions.find { it.value == newValue }
                releaseTypeField.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(releaseTypeField), optionToSet), new DefaultIssueChangeHolder())
     			issueManager.updateIssue(currentUser, issue, EventDispatchOption.ISSUE_UPDATED, false)
                result.put("[" + issue.getKey(), " " + release_TypeFieldValue + "]")
                //return issue.getKey()
            }
        }
    } catch (Exception ex) {
        return ex.getStackTrace()
    }    	
}

return result
