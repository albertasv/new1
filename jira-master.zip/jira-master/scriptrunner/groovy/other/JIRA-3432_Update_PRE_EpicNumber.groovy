import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.event.type.EventDispatchOption

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchQuery = jqlQueryParser.parseQuery("project = PRE ORDER BY key")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)

def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())

def sb = new StringBuilder()

def op = ComponentAccessor.customFieldManager.getCustomFieldObjectByName("Ordinal priority")

if (resultIssues.total > 0) {
    resultIssues.results.each() {
        documentIssue ->
            def issue = (MutableIssue) issueManager.getIssueObject(documentIssue.id)
            def opv = issue.getCustomFieldValue(op)
            def opv_new = Double.valueOf(issue.summary.substring(issue.summary.length()- 1, issue.summary.length()))
            sb.append("$issue.key $issue.summary $opv_new<br/>")
            issue.setCustomFieldValue(op, opv_new)
            // Обновляем порядковый номер проектного эпика
            issueManager.updateIssue(currentUser, issue, EventDispatchOption.ISSUE_UPDATED, false)
    }
}

return sb.toString()