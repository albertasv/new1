import com.atlassian.jira.bc.project.ProjectCreationData
import com.atlassian.jira.bc.project.ProjectService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.project.AssigneeTypes
import com.atlassian.jira.project.type.ProjectTypeKey

import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.bc.user.UserService;
import com.atlassian.jira.user.ApplicationUser

import com.atlassian.jira.util.json.JSONObject

import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.comments.CommentManager
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.util.thread.OffRequestThreadExecutor
import com.atlassian.crowd.exception.embedded.InvalidGroupException
import com.atlassian.jira.bc.JiraServiceContext
import com.atlassian.jira.bc.JiraServiceContextImpl
import com.atlassian.jira.bc.user.search.UserSearchService
import com.atlassian.jira.issue.ModifiedValue

import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.event.type.EventDispatchOption

import com.atlassian.jira.util.DateFieldFormat

import com.atlassian.jira.issue.IssueInputParametersImpl
import com.atlassian.jira.bc.issue.IssueService
import com.atlassian.jira.workflow.JiraWorkflow
import com.atlassian.jira.workflow.WorkflowManager

import com.atlassian.jira.util.ImportUtils
import com.atlassian.jira.issue.index.IssueIndexingService


def projectKey = "TESTHR"
def projectName = "Test Business Core HR"
def projectDescription = "Проект для проведеня нагрузочного тестирования"
def projectManager = ComponentAccessor.getProjectManager()

def projectService = ComponentAccessor.getComponent(ProjectService)
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def projectTypeKey = new ProjectTypeKey("software")

def project = ComponentAccessor.projectManager.getProjectObjByKey("LT")

def offRequestThreadExecutor = ComponentAccessor.getComponent(OffRequestThreadExecutor.class)
def threading = Thread.start { offRequestThreadExecutor.execute({ 
    createUser("t1")           
}) }

delay(2500)

def offRequestThreadExecutor2 = ComponentAccessor.getComponent(OffRequestThreadExecutor.class)
def threading2 = Thread.start { offRequestThreadExecutor2.execute({ 
    createUser("t2") 
}) }
delay(18000)

def offRequestThreadExecutor3 = ComponentAccessor.getComponent(OffRequestThreadExecutor.class)
    def threading3 = Thread.start { offRequestThreadExecutor3.execute({ 
        createUser("t3") 
    })}

delay(28000)
createUser("t4") 

def offRequestThreadExecutor5 = ComponentAccessor.getComponent(OffRequestThreadExecutor.class)
def threading5 = Thread.start {offRequestThreadExecutor5.execute({ 
    createUser("t5") }) 
 }
delay(650)



private createUser(String username) {    
    def commentManager = ComponentAccessor.getCommentManager()        
    def password = "password"
    def emailAddress = "${username}@example.com"
    
    def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
     
    def userToTest = ComponentAccessor.userManager.getUserByName(username)
   
    log.debug(userToTest)
    if (userToTest != null) { 
        String TASK_JQL = '''project in (TESTHR) '''
        def arrayTasks = runJQL(TASK_JQL, currentUser) as List<MutableIssue>
            
            log.debug("********arrayTasks.size()"+arrayTasks.size())

        for (MutableIssue issue in arrayTasks) {
            commentManager.getComments(issue)
            .findAll{it.getAuthorApplicationUser().equals(userToTest)}
            .collect{commentManager.delete(it)}            
        }
        
        arrayTasks = runJQL(TASK_JQL, currentUser) as List<MutableIssue>
        IssueManager im = ComponentAccessor.getIssueManager()
        log.debug("********arrayTasks.size()"+arrayTasks.size())
        
        for (MutableIssue issue in arrayTasks) {     
            
            //log.debug("********issue"+issue)
            
            if (issue != null) {
        		//ComponentAccessor.issueManager.deleteIssue(currentUser, issue, EventDispatchOption.ISSUE_DELETED, false)
            }
    	}
        
        
        activateDeactivateUser(username,true, log)                
        
        
        def projectManager = ComponentAccessor.getProjectManager()

        projectManager.getProjects().each { it ->

            log.debug(it.key)
            log.debug(it.getIssueTypes()*.name)
            log.debug(it.getComponents()*.name)
            log.debug(it.getProjectLead()*.username)
            log.debug(it.getVersions()*.name)
            log.debug(it.getProjectCategoryObject()?.name)
        }             
              
        //ComponentAccessor.userUtil.removeUser(currentUser, userToTest)
    }
    else{
        UserService userService = ComponentAccessor.getComponent(UserService);
        UserService.CreateUserRequest  createUserRequest = UserService.CreateUserRequest.withUserDetails(currentUser, username, password, emailAddress, username)
        def validationResult = userService.validateCreateUser(createUserRequest)
        assert !validationResult.errorCollection.hasAnyErrors()
 
        userService.createUser(validationResult)     
    }
    
    def groupNametoAdd = "TestAdmin"
    
    def groupName = ComponentAccessor.getGroupManager().getGroup(groupNametoAdd)
    if (groupName == null){

    try {
            ComponentAccessor.groupManager.createGroup(groupNametoAdd)
            log.error("Group added")
        }
        catch (InvalidGroupException invalidGroupException) {

            log.error("Error creating group: " + invalidGroupException.message)
        }
    
    }      
	
    ComponentAccessor.groupManager.addUserToGroup(userToTest, groupName)
    
    def n
    def countIssue = 1000

    for (n=1; n<countIssue; n++) { 

        def creator = ComponentAccessor.userManager.getUserByName(username)
        def project = ComponentAccessor.projectManager.getProjectObjByKey("LT")

        MutableIssue issue = ComponentAccessor.issueFactory.issue
        issue.projectObject = project
        issue.summary = (countIssue-n-1)+".  тикетов осталось создать по скрипту пользователем: " + creator
        issue.issueTypeId = 14501
        issue.assignee = currentUser
        ComponentAccessor.issueManager.createIssueObject(userToTest, issue)
        delay(1000)         
        
              

        def j
        def countComments = 2
		for (j=1; j<=countComments; j++) {
            final SD_PUBLIC_COMMENT = "sd.public.comment"
            def properties = [(SD_PUBLIC_COMMENT): new JSONObject(["internal": false] as Map)]
            def commentNew = commentManager.create(issue, creator, (countComments-j) +" комментариев осталось оставить по скрипту пользователю: " + username + " в тикете:"+issue, null, null, new Date(), 		properties, true)   
            def t
            for (t=1; t<=2; t++){   
                String strJQL = "select * from \"AO_A96CEE_DAILY_DAU\" d\n" +
                    "join app_user u on d.\"USER_ID\" = u.id\n" +
                    "join \"AO_589059_AUDIT_ITEM\" ai on ai.\"AUTHOR_KEY\" = u.user_key\n" +
                    "and d.\"DATE\" between ai.\"START_TIME\" and ai.\"END_TIME\" \n" 
        
        		runJQL(strJQL, currentUser)
                
                delay(100)
                issue.summary += " "
        	    ComponentAccessor.getIssueManager().updateIssue(creator, issue, EventDispatchOption.ISSUE_UPDATED, false)
                
                boolean wasIndexing = ImportUtils.isIndexIssues()
                ImportUtils.setIndexIssues(true)
                ComponentAccessor.getComponent(IssueIndexingService.class).reIndex(issue)
                ImportUtils.setIndexIssues(wasIndexing)
                
                delay(100)                
                def stopUser = ComponentAccessor.userManager.getUserByName("stopUser")
                if (stopUser!=null) {
                    if (stopUser.isActive()) return
                }
            }            
        }       
        
    }

}

def runJQL(String jql, ApplicationUser user) {
    def issuesSearch
    def searchService = ComponentAccessor.getComponent(SearchService.class)
    def issueManager = ComponentAccessor.getIssueManager()

    def parseJQLResult = searchService.parseQuery(user, jql)

    if (parseJQLResult.isValid()) {
        def result = searchService.search(user, parseJQLResult.getQuery(), PagerFilter.getUnlimitedFilter())
        def documentIssues = result.results

        return documentIssues.collect { issueManager.getIssueObject(it.id) }
    } else {
        log.error("Invalid JQL: " + jql);
        log.debug("SendRFCReportToConfluenceSRV out")
    }
    return issuesSearch
}

static def delay(long m){    
    sleep(m)
    return
}

static def activateDeactivateUser(String userName, Boolean activate, log) {
    def userToUpdate = ComponentAccessor.getUserManager().getUserByName(userName)
    if (userToUpdate) {
        def userService = ComponentAccessor.getComponent(UserService)
        def updateUser = userService.newUserBuilder(userToUpdate).active(activate).build()
        def updateUserValidationResult = userService.validateUpdateUser(updateUser)
        if (!updateUserValidationResult.valid) {          
            return
        }

        switch (activate){
            case true:              
                userService.updateUser(updateUserValidationResult)              
                break
            case false:              
                userService.updateUser(updateUserValidationResult)             
                break
            default: break
        }
    }

}