import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import com.tempoplugin.common.TempoDateTimeFormatter
import com.tempoplugin.core.datetime.api.TempoDate
import com.tempoplugin.worklog.v4.rest.InputWorklogsFactory
import com.tempoplugin.worklog.v4.rest.TimesheetWorklogBean
import com.tempoplugin.worklog.v4.services.WorklogService

import java.sql.Timestamp
import java.time.DayOfWeek
import java.time.LocalDateTime

@WithPlugin("is.origo.jira.tempo-plugin")

@PluginModule
WorklogService worklogService

@PluginModule
InputWorklogsFactory inputWorklogsFactory

////
def issueManager = ComponentAccessor.issueManager
Issue issue = issueManager.getIssueObject("JIRA-462")
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
////

def daysToLog = calcWorkingDays(issue)
if (daysToLog) {
    def timeToLog = daysToLog * 8 * 60 * 60
    def remaining = issue.estimate && issue.estimate > timeToLog ? (issue.estimate - timeToLog) : 0

    def startDate = TempoDateTimeFormatter.formatTempoDate(TempoDate.now())
// Add all fields needed to create a new worklog
    def timesheetWorklogBean = new TimesheetWorklogBean.Builder()
            .issueIdOrKey(issue.key)
            .comment('Auto-created worklog')
            .startDate(startDate)
            .workerKey(currentUser.key)
            .timeSpentSeconds(timeToLog)
            .remainingEstimate(remaining)
            .build()

    def inputWorklogs = inputWorklogsFactory.buildForCreate(timesheetWorklogBean)
    worklogService.createTempoWorklogs(inputWorklogs)
}

Integer calcWorkingDays(Issue issue) {
    final String startDateFieldName = "Planned Start Date"
    def startDateField = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).findByName(startDateFieldName)

    if (!startDateField || !issue.getCustomFieldValue(startDateField)) {
        log.error "Could not find custom field with name ${startDateFieldName} or field os empty"
        return null
    }

    def startDate = (issue.getCustomFieldValue(startDateField) as Timestamp).toLocalDateTime().toLocalDate()
    def finishDate = LocalDateTime.now().toLocalDate()

    if (!startDate.isBefore(finishDate)) {
        log.error "Value of custom field ${startDateFieldName} more than now ${finishDate} ${finishDate.isBefore(startDate)}"
        return null
    }

    def weekend = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
    def workingDays = 0
    while (startDate.isBefore(finishDate)) {
        if (!(startDate.dayOfWeek in weekend)) {
            workingDays += 1
        }
        startDate = startDate.plusDays(1)
    }
    return workingDays
}