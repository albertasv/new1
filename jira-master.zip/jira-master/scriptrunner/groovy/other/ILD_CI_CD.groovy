import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.issue.search.SearchResults
import com.atlassian.jira.jql.builder.JqlQueryBuilder
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.query.Query

def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def issueManager = ComponentAccessor.issueManager
def historyManager = ComponentAccessor.changeHistoryManager
def optionsManager = ComponentAccessor.optionsManager

def jql = JqlQueryBuilder.newBuilder().where()

def statusField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('CI/CD Status')
def successField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('CI/CD Success')
def failureField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('CI/CD Failure')
def dateField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName('CI/CD Date')

def issuesSearch = searchJQL(jql.project('ILD').and().issueType('Service status')
        .and().issue('ILD-4594')
        .buildQuery()) as SearchResults
if (issuesSearch.total > 0) {
    issuesSearch.issues.each {
        docIssue ->
            def issue = issueManager.getIssueObject(docIssue.id)
            def statusOptions = optionsManager.getOptions(statusField.getRelevantConfig(issue))
            def status = null;
            if (docIssue.status.name == 'PASS') {
                status = statusOptions.getOptionForValue('SUCCESS', null)
            } else {
                status = statusOptions.getOptionForValue('FAILURE', null)
            }
            def updated = null
            double successCount = 0
            double failedCount = 0
            def changes = historyManager.getAllChangeItems(docIssue)
            changes.each {
                change ->
                    if (change.field == 'status') {
                        updated = change.created
                        if (change.to == 'PASS') {
                            successCount++
                        }
                        if (change.to == 'FAIL') {
                            failedCount++
                        }
                    }
            }
            log.error("Update: ${docIssue.key} ${status} ${updated} ${successCount} ${failedCount}")
            if (status) {
                issue.setCustomFieldValue(statusField, status)
            }
            issue.setCustomFieldValue(successField, successCount)
            issue.setCustomFieldValue(failureField, failedCount)
            issue.setCustomFieldValue(dateField, updated)
            issueManager.updateIssue(user, issue, EventDispatchOption.ISSUE_UPDATED, false)
    }
}

/**
 * Get issues by JQL
 * @param jql
 * @return
 */
def searchJQL(Query jql) {
    def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
    def searchProvider = ComponentAccessor.getComponent(SearchProvider)
    return searchProvider.search(jql, currentUser, PagerFilter.getUnlimitedFilter())
}