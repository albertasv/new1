import com.atlassian.jira.bc.issue.IssueService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueFactory
import com.atlassian.jira.issue.issuetype.IssueType
import com.atlassian.jira.workflow.TransitionOptions
import com.atlassian.sal.api.ApplicationProperties
import com.atlassian.sal.api.UrlMode
import com.onresolve.scriptrunner.runner.ScriptRunnerImpl
import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import groovy.transform.BaseScript

import javax.ws.rs.core.MediaType
import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response

@BaseScript CustomEndpointDelegate delegate

def applicationProperties = ScriptRunnerImpl.getOsgiService(ApplicationProperties)
def issueManager = ComponentAccessor.issueManager
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser

/**
 * Show confirmation dialog
 */
defectToBugConfirm(
        httpMethod: "GET", groups: ["jira_users"]
) { MultivaluedMap queryParams ->

    def issueId = queryParams.getFirst("issueId") as Long
    def issue = issueManager.getIssueObject(issueId)
    def dialog =
            """<section role="dialog" id="sr-dialog" class="aui-layer aui-dialog2 aui-dialog2-medium" aria-hidden="true" data-aui-remove-on-hide="true">
            <header class="aui-dialog2-header">
                <h2 class="aui-dialog2-header-main">Confirmation</h2>
                <a class="aui-dialog2-header-close">
                    <span class="aui-icon aui-icon-small aui-iconfont-close-dialog">Close</span>
                </a>
            </header>
            <div class="aui-dialog2-content">
                <p>Do you actually want to close defect <b>${issue.key}</b> and open Bug?</p>
            </div>
            <footer class="aui-dialog2-footer">
                <div class="aui-dialog2-footer-actions">
                    <a class="aui-button aui-button-primary" 
                    href="/rest/scriptrunner/latest/custom/defectToBug?issueId=${issue.id}">Confirm</a>                
                    <button id="dialog-close-button" class="aui-button aui-button-link">Cancel</button>
                </div>                
            </footer>
        </section>
        """
    Response.ok().type(MediaType.TEXT_HTML).entity(dialog.toString()).build()
}

/**
 *
 */
defectToBug(
        httpMethod: "GET", groups: ["jira_users"]
) { MultivaluedMap queryParams ->
    def issueId = queryParams.getFirst("issueId") as Long
    def issue = issueManager.getIssueObject(issueId)
    IssueService issueService = ComponentAccessor.issueService
    // Transition ID
    def actionId = 321

    def transitionOptions = new TransitionOptions.Builder().skipConditions().build()
    def transitionValidationResult = issueService.validateTransition(currentUser, issue.id, actionId, issueService.newIssueInputParameters(), transitionOptions)

    if (transitionValidationResult.isValid()) {
        def transitionResult = issueService.transition(currentUser, transitionValidationResult)
        if (transitionResult.isValid()) {
            def clonedIssue = ComponentAccessor.getComponent(IssueFactory).cloneIssueWithAllFields(issue)

            // Set issue type to Bug
            def allIssueTypes = ComponentAccessor.constantsManager.allIssueTypeObjects
            def bugIssueType = allIssueTypes.find { issueType -> (issueType as IssueType).name == 'Bug' }
            clonedIssue.setIssueType(bugIssueType)
            // Set Affected Version (s)
            clonedIssue.setAffectedVersions(issue.fixVersions)
            // Clear Fix Version (s)
            clonedIssue.setParentObject(null)
            clonedIssue.setFixVersions([])
            // Clear Defect ALM ID
            def almIdField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName("ALM Defect ID")
            clonedIssue.setCustomFieldValue(almIdField, null)

            def newIssue = issueManager.createIssueObject(currentUser, clonedIssue)
            def baseUrl = applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)

            // Set Link
            ComponentAccessor.issueLinkManager.createIssueLink(issueId, newIssue.id, 10003, 1, currentUser)

            //Copy attachments
            ComponentAccessor.attachmentManager.copyAttachments(issue, currentUser, newIssue.key)

            Response.temporaryRedirect(URI.create("${baseUrl}/browse/${newIssue.key}")).build()
        } else {
            Response.ok().type(MediaType.TEXT_HTML).entity("Transition result is not valid. Please try again and contact to Jira Administrator.").build()
        }
    } else {
        Response.ok().type(MediaType.TEXT_HTML).entity("Transition validation is not valid. Please try again and contact to Jira Administrator.").build()
    }
}