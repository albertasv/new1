import com.atlassian.jira.bc.project.component.ProjectComponent

def components = getFieldById(getFieldChanged())

def isRCA = components.value?.any {
    ProjectComponent component -> component.name in ['_Incident'] // если инциндент то будем дальше делать поля обязательными
}

if (getActionName() in ["Разработка завершена", "Development Done"]) {
    components.setHidden(true)
    //скрываем поле. если его совсем не показывать то значение не вытаскивается скрипт не работает
    def fieldRCA = getFieldByName("RCA")
    if (isRCA) {
        fieldRCA.setRequired(true)
        fieldRCA.setHelpText("На данном этапе поле RCA является обязательным для заполнения в случае Дефекта ПРОД(поле Component/s=_Incident) ")
    } else {
        fieldRCA.setRequired(false)
        fieldRCA.setHidden(true)
    }
}