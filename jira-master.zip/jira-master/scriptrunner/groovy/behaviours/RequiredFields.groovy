import com.atlassian.jira.component.ComponentAccessor

import java.sql.Connection
import groovy.sql.Sql
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import com.atlassian.jira.config.util.JiraHome

import java.time.LocalDateTime


def KEY = issueContext.projectObject.id
def strType = issueContext.issueType.name.toLowerCase()

def writer = new StringWriter()
def jiraHome = ComponentAccessor.getComponent(JiraHome)
def strDate = LocalDateTime.now().toString()
def subjectSplit = strDate.split(":") as List<String>
strDate = ""
subjectSplit.each {
    def strValue = it as String
    if (strValue.indexOf(".") > -1){        
         strDate = strDate + "-" + strValue.substring(0, strValue.indexOf(".")) 
    }
    else{
    	strDate = strDate + "-" + strValue      
    }
}


def outputString = ""

    
def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
String helperName = delegator.getGroupHelperName("default")    
    
def sqlStmt = "select \"VALUE\" from \"AO_D46467_PROJECT_PROPERTY\" pp where \"PROJECT\" = '"+KEY+"' and \"KEY\" = '"+strType+".required';"


Connection conn = ConnectionFactory.getConnection(helperName)
Sql sql = new Sql(conn)
StringBuffer sb = new StringBuffer()
try {   sql.eachRow(sqlStmt) { it ->        
        sb.append( it.getAt("VALUE") ) 
    }    
}
finally { sql.close() }
    
    
def strValues = sb.toString()
subjectSplit = strValues.split(";") as List<String>
subjectSplit.each {
    def strValue = it as String
    def fieldChange = getFieldByName(strValue.trim())
    fieldChange.setRequired(true)                    
}

outputString = outputString + "KEY: "+KEY+" Name:"+issueContext.getProjectObject().getName()+"  strType: "+strType+"  strValues: "+ strValues + " action: " + getActionName() + "\n"

def fileName = ComponentAccessor.jiraAuthenticationContext.loggedInUser.displayName+"_"+issueContext.projectObject.name+'_fields_required'+strDate
if (strValues != ""){
    fileName += "_#"
    fileName += '.txt'

def issueFile = new File(jiraHome.getCachesDirectory(), fileName)

issueFile.write outputString.toString()
}


 
