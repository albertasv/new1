import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter

def portfolioProjectField =  getFieldByName("Portfolio Project");
if (getActionName() == "Create") {
    portfolioProjectField.setRequired(true)
    def summaryField =  getFieldByName("Summary");
    if(!summaryField.getValue()) {
        def portfolioProjectKey = portfolioProjectField.getValue();
        if (portfolioProjectKey != null) {
            def portfolioProjectIssue = ComponentAccessor.issueManager.getIssueObject((String) portfolioProjectKey);
            def searchQuery = ComponentAccessor.getComponent(JqlQueryParser).parseQuery("'Portfolio Project' = " + portfolioProjectKey);
            def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser;
            def resultIssues = ComponentAccessor.getComponent(SearchService).search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter());
            def epicNum = resultIssues.total + 1;
            summaryField.setFormValue(portfolioProjectIssue.summary + " Epic#" + (epicNum < 10 ?"0":"") + epicNum);

            def ordinalPriorityField =  getFieldByName("Ordinal priority");
            ordinalPriorityField.setFormValue(epicNum);
        }
    }
} else {
    portfolioProjectField.setReadOnly(true);
}