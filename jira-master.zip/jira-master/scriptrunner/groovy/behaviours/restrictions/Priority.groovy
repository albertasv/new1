import com.atlassian.jira.component.ComponentAccessor

import static com.atlassian.jira.issue.IssueFieldConstants.PRIORITY

def constantsManager = ComponentAccessor.getConstantsManager()

def userUtil = ComponentAccessor.getUserUtil()

def currentUser = ComponentAccessor.getJiraAuthenticationContext().getUser()
if (!userUtil.getGroupNamesForUser(currentUser.name).contains("jira-developers")) {

    def allowedPriorities = constantsManager.getPriorityObjects().findAll {
        it.id.toInteger() > 2
    }.collectEntries {
        [(it.id): it.name]
    }

    getFieldById(PRIORITY).setFieldOptions(allowedPriorities)
}