import com.atlassian.jira.component.ComponentAccessor
import static com.atlassian.jira.issue.IssueFieldConstants.RESOLUTION

def constantsManager = ComponentAccessor.constantsManager
def allowedResolutions = []

getFieldById(RESOLUTION).setFieldOptions(allowedResolutions)
if (getActionName() in ["Cancelled", "Rejected"]) {
    allowedResolutions = constantsManager.resolutions.findAll {
        it.name in ["Cancelled", "Cannot Reproduce", "Duplicate", "Incomplete", "Won't Do"]
    }
} else {
    allowedResolutions = constantsManager.resolutions.findAll {
        it.name in ["Done", "Cancelled", "Cannot Reproduce", "Duplicate", "Incomplete", "Won't Do"]
    }
}
getFieldById(RESOLUTION).setFieldOptions(allowedResolutions)