import com.atlassian.jira.component.ComponentAccessor
import static com.atlassian.jira.issue.IssueFieldConstants.ISSUE_TYPE
import com.atlassian.jira.project.Project
import com.atlassian.jira.security.roles.*

def allIssueTypes = ComponentAccessor.constantsManager.allIssueTypeObjects
def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser

if (getActionName() == "Create") {    
    def availableIssueTypes = []
    switch(issueContext.projectObject.key){
        case "CICD":
        	def groupManager = ComponentAccessor.groupManager
        	def cicdAdmin = groupManager.getGroup("rsb-sl-ct-MOS_cicd-sfp-team")
            if(!groupManager.getUsersInGroup(cicdAdmin).contains(currentUser)){
                availableIssueTypes.addAll(allIssueTypes.findAll {
                    it.name in  ["Ticket", "Story"]
                })
                getFieldById(ISSUE_TYPE).setFieldOptions(availableIssueTypes)
            }
        	break;
        case "NEWFRONT":
        	availableIssueTypes.addAll(allIssueTypes.findAll {
                it.name in  ["Off-release","Load Testing","Задача на разработку","Epic","Task","Release Cycle", "Дефект", "Improvement/Улучшение", "Разработка", "Testing", "Регрессионное тестирование","Bug","Story"]
            })
        	getFieldById(ISSUE_TYPE).setFieldOptions(availableIssueTypes)
        	break;
        case "KMB":
        	Project project = ComponentAccessor.getProjectManager().getProjectByCurrentKey("KMB")
        	ProjectRoleManager prjrolemgr = ComponentAccessor.getComponent(ProjectRoleManager)
			Collection<ProjectRole> prjroles = prjrolemgr.getProjectRoles(currentUser, project)
        	if(prjroles.size() == 1 && prjroles.getAt(0).getName() == "Project Members") {
                availableIssueTypes.addAll(allIssueTypes.findAll {
                    it.name in  ["Task"]
                })
                getFieldById(ISSUE_TYPE).setFieldOptions(availableIssueTypes)
            }
        	break;
    }
}