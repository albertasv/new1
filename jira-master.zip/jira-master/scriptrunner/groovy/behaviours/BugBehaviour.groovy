import com.atlassian.jira.component.ComponentAccessor

if (getActionName() == "Create") {
    // заполняем значением по умолчанию поле Enviroment
    def envFieldId = "customfield_10434"
    def envFormField = getFieldById(envFieldId)
    if (envFormField) {
        def envField = ComponentAccessor.customFieldManager.getCustomFieldObject(envFieldId)
        def options = ComponentAccessor.optionsManager.getOptions(envField.getRelevantConfig(getIssueContext()))
        def prodOption = options.find { it.value.equalsIgnoreCase("PROD") }
        if (prodOption) {
            envFormField.setFormValue(prodOption.optionId)
        }
    }
}