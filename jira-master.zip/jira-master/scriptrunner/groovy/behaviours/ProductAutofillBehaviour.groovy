import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.jira.groovy.user.FormField

if (getActionName() == "Create") {
    // заполняем значением по умолчанию поле Product
    def productFieldId = "customfield_13421"
    def productMap = [
            "AGP"     : "BIS payments documents",
            "BIS"     : "BIS",
            "CORPFL"  : "New Loan Deposit Engine (NLDE)",
            "CRCONV"  : "Loan Factory for Legal Entities",
            "CRM"     : "Oracle Siebel CRM",
            "FILS"    : "FILS",
            "IBN"     : "Retail remote banking  platform ROSBANK-Online",
            "HKM"     : "NKM",
            "NEWFRONT": "New Front Office",
            "PAYR"    : "Payroll",
            "PAYR3"   : "Payroll Services",
            "PHUB"    : "Payment Hub",
            "PRODBO"  : "Digital PRO",
            "SFEC"    : "SafeCells",
            "FC"      : "ProPortal",
            "MBRB"    : "ICB",
            "USC"     : "Settlement center"
    ]
    productMap.find {
        projectKey, productValue ->
            if (issueContext.projectObject.key == projectKey) {
                def customField = ComponentAccessor.customFieldManager.getCustomFieldObject(productFieldId)
                def options = ComponentAccessor.optionsManager.getOptions(customField.getRelevantConfig(getIssueContext()))
                def optionToSelect = options.find { it.value == productValue }
                def productField = getFieldById(productFieldId)
                productField.setFormValue(optionToSelect.optionId)
                return true
            }
        return false
    }
}

// For Sub-tasks
import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.jira.groovy.user.FormField

def productFieldId = "customfield_13421"
def productField = getFieldById(productFieldId)
FormField parent = getFieldById("parentIssueId")
Long parentIssueId = parent.getFormValue() as Long
if (parentIssueId) {
    def parentIssue = ComponentAccessor.issueManager.getIssueObject(parentIssueId)
    def parentProduct = ComponentAccessor.customFieldManager.getCustomFieldObject(productFieldId).getValue(parentIssue)
    if (parentProduct) {
        productField.setFormValue(parentProduct.optionId)
    }
}