def releaseStartDateField = getFieldByName("Release StartDate")
def fctStartDateField = getFieldByName("FCT Start Date")

if ((Date) fctStartDateField.value < (Date) releaseStartDateField.value) {
    fctStartDateField.setError("Должна быть больше или равна Release Start Date")
} else {
    fctStartDateField.clearError()
}