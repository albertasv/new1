def fctStartDateField = getFieldByName("FCT Start Date")
def uatStartDateField = getFieldByName("UAT Start Date")

if ((Date) uatStartDateField.value < (Date) fctStartDateField.value) {
    uatStartDateField.setError("Должна быть больше или равна FCT Start Date")
} else {
    uatStartDateField.clearError()
}