def uatStartDateField = getFieldByName("UAT Start Date")
def plannedGLDateField = getFieldByName("Planned Go-Live Date")

if ((Date) plannedGLDateField.value < (Date) uatStartDateField.value) {
    plannedGLDateField.setError("Должна быть больше или равна UAT Start Date")
} else {
    plannedGLDateField.clearError()
}