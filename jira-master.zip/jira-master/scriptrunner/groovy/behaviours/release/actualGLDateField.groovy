def uatStartDateField = getFieldByName("UAT Start Date")
def actualGLDateField = getFieldByName("Actual Go-Live Date")

if((Date)actualGLDateField.value < (Date)uatStartDateField.value){
    actualGLDateField.setError("Должна быть больше или равна UAT Start Date")
} else {
    actualGLDateField.clearError()
}