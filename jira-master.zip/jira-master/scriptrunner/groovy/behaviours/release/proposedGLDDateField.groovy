def uatStartDateField = getFieldByName("UAT Start Date")
def proposedGLDateField = getFieldByName("Proposed Go-Live Date")

if ((Date) proposedGLDateField.value < (Date) uatStartDateField.value) {
    proposedGLDateField.setError("Должна быть больше или равна UAT Start Date")
} else {
    proposedGLDateField.clearError()
}