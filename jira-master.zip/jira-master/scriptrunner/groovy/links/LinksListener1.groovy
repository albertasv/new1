import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.MutableIssue

import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.exception.CreateException;

import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;

import com.atlassian.jira.issue.link.IssueLinkTypeManager;

import java.sql.Connection
import groovy.sql.Sql
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import org.ofbiz.core.entity.jdbc.SQLProcessor;


def strKR = "13002"
def strObjective = "13001"
def strEpic = "10601"

def issue = event.getIssue()

// Получаем кастомное поле "Связи целеполагания"
def CF = ComponentAccessor.customFieldManager.getCustomFieldObject(21301)

def keys = issue.getCustomFieldValue(CF)

IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();

def typeFrom = issue.getIssueType().getId();
def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(10500l).getId();

if (event.eventTypeId == 2){

    def LinksOut = issueLinkManager.getOutwardLinks(issue.getId())
    def keysOut = []
        
    for( l in LinksOut) {
        def From = l.getSourceObject()
        def To = l.getDestinationObject()
      
         if ((strKR.equals(From.getIssueType().getId())&&strEpic.equals(To.getIssueType().getId())) ||
             (strObjective.equals(From.getIssueType().getId())&&strKR.equals(To.getIssueType().getId()))) {
        keysOut.add(To.getKey())
        
         }
         }
    def LinksIn = issueLinkManager.getInwardLinks(issue.getId())
       
    
    for( l in LinksIn) {    
        def From = l.getSourceObject()
        def To = l.getDestinationObject()
     
        if ((strKR.equals(From.getIssueType().getId())&&strEpic.equals(To.getIssueType().getId())) ||
             (strObjective.equals(From.getIssueType().getId())&&strKR.equals(To.getIssueType().getId()))) {
        
        	keysOut.add(From.getKey())
      
         }
       }

       for( key in keys) {
       
           MutableIssue issueTo = ComponentAccessor.getIssueManager().getIssueObject(key as String);
           def typeTo = issueTo.getIssueType().getId();
         
           if (issueTo.getKey() in keysOut){           
               keysOut.remove(issueTo.getKey())
           }
           else{
               try {
                   if ((strKR.equals(typeFrom)&&strEpic.equals(typeTo)) ||
                       (strObjective.equals(typeFrom)&&strK.equals(typeTo))) {
                       issueLinkManager.createIssueLink(
                           issue.getId(),
                           issueTo.getId(),
                           splitLinkType,
                           0l,
                           user
                       );
                       addClickLog(user.getName(),"ADD_LINK")
						write = true

                   }
                   if ((strKR.equals(typeFrom)&&strEpic.equals(typeTo)) ||
                       (strEpic.equals(typeFrom)&&strK.equals(typeTo))) {
                       issueLinkManager.createIssueLink(
                           issueTo.getId(),
                           issue.getId() ,
                           splitLinkType,
                           0l,
                           user
                       );
                       addClickLog(user.getName(),"ADD_LINK")
						write = true
                   }
                 

               } catch (CreateException cex) {
                   log.error("Issue link error - {}", cex);
               }
            }

        }
    for( l in LinksOut) {
        def title = l.getSourceObject()
        def url = l.getDestinationObject()
        if (url.getKey() in keysOut){
             issueLinkManager.removeIssueLink(l,user)
       
       
         	addClickLog(user.getName(),"REMOVE_LINK")
            
           
        }
    }
    for( l in LinksIn) {    
        def title = l.getSourceObject()
        if (title.getKey() in keysOut){
             def url = l.getDestinationObject()
             issueLinkManager.removeIssueLink(l,user)
           
            addClickLog(user.getName(),"REMOVE_LINK")           
           
        }
    }
   
 
}

 public void addClickLog(String username, String topic) {       
     
     SQLProcessor sqlProcessor = null;
     try {
         String strSQL = "INSERT INTO \"AO_D46467_CLICK_LOG\" (";
         strSQL += "\"USERNAME\", \"TOPIC\", \"CLICK\" , \"LAST_UPDATE_DATE\")" ;
         strSQL += "VALUES ('" +username + "'";
         strSQL +=",'" + topic + "'";
         strSQL +=",'" + 1 + "'";
         strSQL += ",'" + LocalDateTime.now() + "'";                               
         strSQL +=  ");";

         sqlProcessor = new SQLProcessor("defaultDS");
         sqlProcessor.prepareStatement(strSQL);
         sqlProcessor.executeUpdate();
         sqlProcessor.close();

     } catch( Exception ex){
         log.error("Update: data error: {}" + ex);
     } finally{
         if (sqlProcessor != null) {
             try {
                 sqlProcessor.close();
             } catch (Exception e) {
                 log.error("Close: error: {}" + e);
             }
         }
     }  
 }

