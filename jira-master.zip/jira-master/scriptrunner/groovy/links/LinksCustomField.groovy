import com.atlassian.jira.issue.Issue
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.ModifiedValue
import com.onresolve.jira.groovy.user.FormField
import com.atlassian.jira.issue.MutableIssue

import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.web.bean.PagerFilter

import com.atlassian.jira.issue.index.IssueIndexingService
import com.atlassian.jira.util.ImportUtils
import com.atlassian.jira.event.type.EventDispatchOption

// Получаем кастомное поле "Связи целеполагания" 
String customfield = "customfield_21301"

def strKR = "13002"
def strObjective = "13001"
def strEpic = "10601"

getJql = { Issue issue, String configuredJql ->   
    
    def    issueToUpdate = (MutableIssue) issue
    
    def filter 
    def newValue = []    
    def issueManager = ComponentAccessor.getIssueManager()
    def CFO =    ComponentAccessor.getCustomFieldManager().getCustomFieldObject(customfield)
    def value = issue.getCustomFieldValue(CFO)   
    def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
   
    def ret = ""   

    if (issue.issueType.id == strKR )  {  
        filter = "issuetype in (strObjective) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split from'))  OR issuetype in (Epic)      AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split to')) ORDER BY key"    
        
   	ret = " issuetype in (strObjective, strEpic)    ORDER BY key"
    }
    else if (issue.issueType.id == strObjective )  {  
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split to')) ORDER BY key"    
    	ret = "issuetype in (strKR) ORDER BY key"       
    }
    else if (issue.issueType.id == strEpic )    {
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split from')) ORDER BY key"   
    	ret = "issuetype in (strKR)  ORDER BY key"
    }         
    
    if (!issue){
        def select = runJQL(filter)
        for( l in select) {    
      	  newValue.add(issueManager.getIssueObject(l as String))   
        }
        def customFieldManager = ComponentAccessor.customFieldManager
    	customFieldManager.refresh()
        boolean wasIndexing = ImportUtils.isIndexIssues()
                ImportUtils.setIndexIssues(true)
               ComponentAccessor.getComponent(IssueIndexingService.class).reIndex(issue)
                ImportUtils.setIndexIssues(wasIndexing)
        CFO.updateValue(null, issueToUpdate, new ModifiedValue(value, newValue ), new DefaultIssueChangeHolder())   
            
        issueManager.updateIssue(currentUser, issueToUpdate, EventDispatchOption.ISSUE_UPDATED, false)  
        ComponentAccessor.getComponent(IssueIndexingService.class).reIndex(issue)
    } 
    
    return ret
}


def runJQL(String jql) {
    def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser    
    def searchService = ComponentAccessor.getComponent(SearchService.class)
    def issueManager = ComponentAccessor.getIssueManager()

    def parseJQLResult = searchService.parseQuery(user, jql)

    if (parseJQLResult.isValid()) {
        def result = searchService.search(user, parseJQLResult.getQuery(), PagerFilter.getUnlimitedFilter())
        def issues = result.results
        
        def resultKey = []                                                    
issues.each { it ->

    resultKey.add(it.key)  
}
        return resultKey 
    } else {
        log.error("Invalid JQL: " + jql);
        
    }
    return null
}


   



