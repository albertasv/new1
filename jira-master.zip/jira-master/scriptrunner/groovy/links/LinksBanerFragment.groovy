import com.atlassian.jira.issue.Issue

def issue = context.issue as Issue
def strKR = "13002"
def strObjective = "13001"
def strEpic = "10601"

def filter
if (issue.issueType.id == strKR ) {
      
    	filter = "<div style=\"background-color:#FFC8D1;\" class='rb-alert rb-alert-warning'> Добавить/удалить цель или эпик, связанные с данным ключевым результатом можно при помощи поля \"Связи целеполагания\" на экране редактирования</div>"
    }  
    if (issue.issueType.id == strObjective ) {  
        filter = "<div style=\"background-color:#FFC8D1;\" class='rb-alert rb-alert-warning'> Добавить/удалить ключевой результат(ы) (KR), связанные с данной целью можно при помощи поля \"Связи целеполагания\" на экране редактирования</div>"
       
    }
    if (issue.issueType.id == strEpic ) {  
        filter = "<div style=\"background-color:#FFC8D1;\" class='rb-alert rb-alert-warning'> Добавить/удалить ключевой результат(ы) (KR), связанные с данным эпиком можно при помощи поля \"Связи целеполагания\" на экране редактирования</div>"      
    }
writer.write(filter)
