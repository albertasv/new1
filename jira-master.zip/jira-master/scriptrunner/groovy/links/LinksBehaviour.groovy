import com.atlassian.jira.config.util.JiraHome
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.issue.fields.CustomField

import com.atlassian.jira.service.util.ServiceUtils
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.index.IssueIndexingService
import com.atlassian.jira.util.ImportUtils
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.RendererManager
import com.atlassian.jira.issue.ModifiedValue;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder

def customFieldManager = ComponentAccessor.customFieldManager

customFieldManager.clear()

def strKR = "13002"
def strObjective = "13001"
def strEpic = "10601"

// Получаем кастомное поле "Связи целеполагания"
String customfield = "customfield_21301"  
def CF = getFieldById(customfield)


if (CF){
   
    def filter 
    if (getIssueContext().issueType.id == strKR ) {
        CF.setDescription('Добавьте цель или эпик, связанные с данным ключевым результатом')
        filter = "issuetype in (strObjective) AND (issueFunction in linkedIssuesOf('key="+underlyingIssue.key +"', 'split from'))  OR issuetype in (Epic)      AND (issueFunction in linkedIssuesOf('key="+underlyingIssue.key +"', 'split to')) ORDER BY key"
    	
    }  
    else if (getIssueContext().issueType.id == strObjective  )  {           
        CF.setDescription('Добавьте ключевой результат(ы) (KR), связанный с данной целью')         
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+underlyingIssue.key +"', 'split to')) ORDER BY key"                                           
      
    }
    else if (getIssueContext().issueType.id == strEpic  )    {  
        CF.setDescription('Добавьте ключевой результат(ы) (KR), связанный с данным эпиком')  
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+underlyingIssue.key +"', 'split from')) ORDER BY key"                        
    }
    else {
        CF.setHidden(true) 
        return
    }
    def select = runJQL(filter)     
    def issue = ServiceUtils.findIssueObjectInString(underlyingIssue.key )
    
    def CFO =    ComponentAccessor.getCustomFieldManager().getCustomFieldObject(customfield)
    def value = issue.getCustomFieldValue(CFO)
    def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
    def issueToUpdate = (MutableIssue) issue

    def issueManager = ComponentAccessor.getIssueManager()
    def userManager = ComponentAccessor.getUserManager()
    def newvalue = []    

    for( l in select) {    
    	newvalue.add(issueManager.getIssueObject(l as String))   
    }
     boolean wasIndexing = ImportUtils.isIndexIssues()
                ImportUtils.setIndexIssues(true)
               ComponentAccessor.getComponent(IssueIndexingService.class).reIndex(issue)
                ImportUtils.setIndexIssues(wasIndexing)
    
    CFO.updateValue(null, issueToUpdate, new ModifiedValue(value, newvalue ), new DefaultIssueChangeHolder())    
    issueManager.updateIssue(user, issueToUpdate, EventDispatchOption.DO_NOT_DISPATCH, false)      
        
    customFieldManager.refresh()                 
    
}

def runJQL(String jql) {
    def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
    
    def searchService = ComponentAccessor.getComponent(SearchService.class)
    def issueManager = ComponentAccessor.getIssueManager()

    def parseJQLResult = searchService.parseQuery(user, jql)

    if (parseJQLResult.isValid()) {
        def result = searchService.search(user, parseJQLResult.getQuery(), PagerFilter.getUnlimitedFilter())
        def issues = result.results
        
        def resultKey = []                                                    
	issues.each { it ->
 
    		resultKey.add(it.key)

	}

        return resultKey 
    } else {
        log.error("Invalid JQL: " + jql);        
    }
    return null
}