import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventType
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.event.issue.link.IssueLinkCreatedEvent
import com.atlassian.jira.event.issue.link.IssueLinkDeletedEvent
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.ModifiedValue;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.event.type.EventDispatchOption


// Получаем кастомное поле "Связи целеполагания"
def CF = ComponentAccessor.customFieldManager.getCustomFieldObject(21301)

def user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()

def eventValue = event.class.toString()
def sourceIssue
def destinationIssue 
boolean write = false

if (eventValue == "class com.atlassian.jira.event.issue.link.IssueLinkCreatedEvent") {
    def issueLinkCreated = event as IssueLinkCreatedEvent
    sourceIssue = issueLinkCreated.issueLink.sourceObject
    destinationIssue = issueLinkCreated.issueLink.destinationObject
   
	write = true
} else if (eventValue == "class com.atlassian.jira.event.issue.link.IssueLinkDeletedEvent") {
    def issueLinkDeletedEvent = event as IssueLinkDeletedEvent
    sourceIssue = issueLinkDeletedEvent.issueLink.sourceObject
    destinationIssue = issueLinkDeletedEvent.issueLink.destinationObject
    
	write = true
} 

updateCF(sourceIssue)
updateCF(destinationIssue)

String updateCF(Issue issue){
def strKR = "13002"
def strObjective = "13001"
def strEpic = "10601"

    def filter 
    if (issue.issueType.id == strKR ) {
       
        filter = "issuetype in (strObjective) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split from'))  OR issuetype in (Epic)      AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split to')) ORDER BY key"
    	
    }  
    else if (issue.issueType.id == strObjective )  {           
               
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split to')) ORDER BY key"                                           
      
    }
    else if (issue.issueType.id == strEpic )    {  
        
        filter = "issuetype in (strKR) AND (issueFunction in linkedIssuesOf('key="+issue.key +"', 'split from')) ORDER BY key"                        
    }
    
    def select = runJQL(filter)
    // Получаем кастомное поле "Связи целеполагания"
	String customfield = "customfield_21301"
	def CFO =    ComponentAccessor.getCustomFieldManager().getCustomFieldObject(customfield)
	def value = issue.getCustomFieldValue(CFO)
	
	def issueToUpdate = (MutableIssue) issue
	def issueManager = ComponentAccessor.getIssueManager()
	def newValue = []    
    
	for( l in select) {    
		newvalue.add(issueManager.getIssueObject(l as String))   
	}
	CFO.updateValue(null, issueToUpdate, new ModifiedValue(value, newValue ), new DefaultIssueChangeHolder()) 
	def user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
	issueManager.updateIssue(user, issueToUpdate, EventDispatchOption.DO_NOT_DISPATCH, false)  
}

def runJQL(String jql) {
    if (!jql) return
    def user = ComponentAccessor.jiraAuthenticationContext.loggedInUser
    
    def searchService = ComponentAccessor.getComponent(SearchService.class)
    def issueManager = ComponentAccessor.getIssueManager()

    def parseJQLResult = searchService.parseQuery(user, jql)

    if (parseJQLResult.isValid()) {
        def result = searchService.search(user, parseJQLResult.getQuery(), PagerFilter.getUnlimitedFilter())
        def issues = result.results
        
        def resultKey = []                                                    
		issues.each { it ->   resultKey.add(it.key) }
        return resultKey 
    } else {
        log.error("Invalid JQL: " + jql);      
    }
    return null
}
