import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.label.LabelManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.sal.api.user.UserManager
import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import groovy.transform.BaseScript

import java.sql.Timestamp
import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response
import javax.servlet.http.HttpServletRequest

@BaseScript CustomEndpointDelegate delegate

cicd(
        httpMethod: "GET", groups: ["jira_users"]
) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    def issueManager = ComponentAccessor.issueManager
    def cfm = ComponentAccessor.customFieldManager
    def optsManager = ComponentAccessor.optionsManager

    def issueKey = queryParams.getFirst("issue") as String

    if (!issueKey) {
        return Response.status(Response.Status.BAD_REQUEST).entity("Issue key is required parameter").build()
    }

    def status = queryParams.getFirst("status") as String

    def env = queryParams.getFirst("env") as String

    def userManager = ComponentAccessor.getOSGiComponentInstanceOfType(UserManager)
    def userProfile = userManager.getRemoteUser(request)
    def user = ComponentAccessor.userManager.getUserByName(userProfile.username)

    def issue
    try {
        issue = issueManager.getIssueObject(issueKey) as MutableIssue
    } catch (Exception ex) {
        return Response.status(Response.Status.NOT_FOUND).entity("Issue ${issueKey} NOT FOUND").build()
    }

    def statusField = cfm.getCustomFieldObjectByName('CI/CD Status')
    def statusOptions = optsManager.getOptions(statusField.getRelevantConfig(issue))
    if ("progress".equalsIgnoreCase(status)) {
        issue.setCustomFieldValue(statusField, statusOptions.getOptionForValue('Progress', null))
    } else if ("failure".equalsIgnoreCase(status)) {
        def failureField = cfm.getCustomFieldObjectByName('CI/CD Failure')
        def failCount = (issue.getCustomFieldValue(failureField) as Double ?: 0) + 1;
        issue.setCustomFieldValue(failureField, failCount)
        status = statusOptions.getOptionForValue('Failure', null)
        issue.setCustomFieldValue(statusField, statusOptions.getOptionForValue('Failure', null))
    } else {
        def successField = cfm.getCustomFieldObjectByName('CI/CD Success')
        def succesCount = (issue.getCustomFieldValue(successField) as Double ?: 0) + 1;
        issue.setCustomFieldValue(successField, succesCount)
        issue.setCustomFieldValue(statusField, statusOptions.getOptionForValue('Success', null))
    }

    if (env) {
        switch (env.toLowerCase()) {
            case "dev":
                setDateFieldNow(issue, "Installation Date DEV")
                break
            case "test":
                setDateFieldNow(issue, "Installation Date TEST")
                break
            case "cert":
                setDateFieldNow(issue, "Installation Date CERT")
                break
            case "prod":
                setDateFieldNow(issue, "CI/CD Date")
                break
        }
    }

    setDateFieldNow(issue, "CI/CD Date")

    def tag = queryParams.getFirst("tag") as String
    if (tag) {
        def tagsField = cfm.getCustomFieldObjectByName('CI/CD Tags')
        def labelMgr = ComponentAccessor.getComponent(LabelManager)
        labelMgr.addLabel(user, issue.id, tagsField.idAsLong, tag, true)

    }

    issueManager.updateIssue(user, issue, EventDispatchOption.ISSUE_UPDATED, false)
    return Response.ok("ok").build()
}

def setDateFieldNow(MutableIssue issue, String field) {
    try {
        def now = new Timestamp(new Date().time)
        def dateField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName(field)
        issue.setCustomFieldValue(dateField, now)
    } catch (Exception ex) {
        log.error("Error set date for ${field}", ex)
    }
}