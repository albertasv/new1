# Проект по разработке Rosbank Jira

* plugins
    * atlassian - изменения в системных плагинах и в плагинах из Atlassian Marketplace
    * jira-rb - плагин, реализующий дополнительный общий функционал
    * jira-rb-portfolio - плагин предназначен для работы с сущностями портфеля - CR и проекты
    * jira-rb-sm - плагин предназначен для работы с сущностями, связанными с Service Manager'ом
    * jira-templates - плагин создания проектов по шаблону
* scriptrunner - скрипты, используемые плагином Scriptrunner
* sql - скрипты SQL, отчеты, выгрузки и т.д.
* env.bat - скрипт настройки окружения разработки плагинов

### Полезные ссылки
* [Стенды и перенос доработок](https://kb.rosbank.rus.socgen/x/pQBrBg)
* [Схема интеграций Jira](https://kb.rosbank.rus.socgen/x/4QJSGQ)
