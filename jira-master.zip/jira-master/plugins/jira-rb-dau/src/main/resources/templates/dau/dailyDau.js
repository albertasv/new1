AJS.$(document).ready(function () {
    AJS.$("title").text("Daily DAU");
});