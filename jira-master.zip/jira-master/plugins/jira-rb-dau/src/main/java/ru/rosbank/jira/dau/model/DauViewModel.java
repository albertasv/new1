package ru.rosbank.jira.dau.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

//@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DauViewModel  {

    private String date;
    private Long UserId;
    private String UserName;

    private String joinedDate;
    private Boolean isDay;
    private Boolean isWeek;
    private Boolean isMonth;
    private Boolean enabled;
    private int weekday;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String id) {
        this.UserName = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long id) {
        this.UserId = id;
    }

    public String getJoinedDate() {
        return joinedDate;
    }

    public void setJoinedDate(String joinedDate) {
        this.joinedDate = joinedDate;
    }

    public Boolean getIsDay() {
        return isDay;
    }

    public void setIsDay(Boolean isDay) {  this.isDay = isDay;   }

    public Boolean getIsWeek() {
        return isWeek;
    }

    public void setIsWeek(Boolean isWeek) {
        this.isWeek = isWeek;
    }

    public Boolean getIsMonth() {
        return isMonth;
    }

    public void setIsMonth(Boolean isMonth) {
        this.isMonth = isMonth;
    }

    public int getWeekday() {
        return weekday;
    }

    public void setWeekday(int weekday) { this.weekday = weekday;  }

    public Boolean getEnabled() { return enabled; }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public DauViewModel(String date, Long UserId, String joinedDate, Boolean isDay, Boolean isWeek, Boolean isMonth, Boolean enabled, String UserName, int weekday) {
        this.date = date;
        this.UserId = UserId;
        this.joinedDate = joinedDate;
        this.isDay = isDay;
        this.isWeek = isWeek;
        this.isMonth = isMonth;
        this.enabled = enabled;
        this.UserName = UserName;
        this.weekday = weekday;
    }
}
