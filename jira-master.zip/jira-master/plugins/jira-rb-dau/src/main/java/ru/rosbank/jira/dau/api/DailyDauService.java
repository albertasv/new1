package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.dau.ao.DailyDau;

import java.util.List;

@Transactional
public interface DailyDauService {

    DailyDau addDailyDau(Long id, Long eventID);

    List<DailyDau> getAllDailyActivities();

    void deleteAllDailyActivities();
}
