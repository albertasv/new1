package ru.rosbank.jira.dau.ao;

import net.java.ao.Entity;
import net.java.ao.schema.NotNull;

import java.util.Date;

public interface Dau extends Entity{
    @NotNull
    Date getDate();

    @NotNull
    void setDate(Date date);

    @NotNull
    Long getUserId();

    @NotNull
    void setUserId(Long userId);

    @NotNull
    Date getJoinedDate();

    @NotNull
    void setJoinedDate(Date joinedDate);

    @NotNull
    Boolean getIs1dayActive();

    @NotNull
    void setIs1dayActive(Boolean is1dayActive);

    @NotNull
    Boolean getIs7dayActive();

    @NotNull
    void setIs7dayActive(Boolean is7dayActive);

    @NotNull
    Boolean getIs28dayActive();

    @NotNull
    void setIs28dayActive(Boolean is28dayActive);

    @NotNull
    Boolean getEnabled();

    @NotNull
    void setEnabled(Boolean enabled);

}
