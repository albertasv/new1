package ru.rosbank.jira.dau.action;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import ru.rosbank.jira.dau.api.DailyDauViewService;
import ru.rosbank.jira.dau.model.DailyDauViewModel;
import java.util.List;

public class DailyDauServiceAction extends JiraWebActionSupport {

    DailyDauViewService dailyDauViewService;

    public DailyDauServiceAction( DailyDauViewService dailyDauViewService) {
        this.dailyDauViewService = dailyDauViewService;
    }

    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public List<DailyDauViewModel> getAlldailydau() { return dailyDauViewService.getAlldailydau();  }
    public String getImage() {return dailyDauViewService.getImage( );  }
}