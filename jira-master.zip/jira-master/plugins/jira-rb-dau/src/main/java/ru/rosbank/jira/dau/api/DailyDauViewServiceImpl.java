package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.dau.ao.DailyDau;
import ru.rosbank.jira.dau.model.DailyDauViewModel;
import ru.rosbank.jira.dau.DauUtil;

import javax.inject.Inject;
import javax.inject.Named;
import java.awt.*;
import java.awt.image.BufferedImage;

import java.util.*;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;
import static java.awt.image.BufferedImage.TYPE_INT_RGB;

@Named("dailyDauViewServiceImpl")
public class DailyDauViewServiceImpl implements DailyDauViewService{

    private final ActiveObjects ao;
    private static final Logger LOG = LoggerFactory.getLogger(DailyDauViewServiceImpl.class);

    @Inject
    public DailyDauViewServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public String getImage() {

            Color bgColor = new Color(255,255,255);
            Color axisColor = new Color(100,100,100);
            int dxLeft = 10;
            int wHour = 50;
            int width = 24*wHour + 2*dxLeft;
            int height = 200;

            BufferedImage bi = new BufferedImage(width, height, TYPE_INT_RGB);
            Graphics2D g2 = bi.createGraphics();
            g2.setColor(bgColor);
            g2.fillRect(0, 0, width, height);
            g2.setColor(axisColor);

            for (int i = 0; i < 25; i++){
                g2.drawLine(dxLeft + i*wHour, height - 50, dxLeft + (i+1)*wHour, height - 50);
                g2.drawLine(dxLeft + i*wHour, height - 50, dxLeft + i*wHour, height - 45);
                g2.drawString(""+ i, dxLeft - 5 + i*wHour, height - 20 );
            }

            DailyDau[] dailydauDB = ao.find(DailyDau.class,
                    Query.select()
                            .order("\"DATE\"  DESC")
            );

            for (int i = 0; i < dailydauDB.length; i++) {
               Date date = dailydauDB[i].getDate();
                Color eventColor = new Color((int)(dailydauDB[i].getUserId()%255), 255 - (int)(dailydauDB[i].getUserId() % 255), (int)(dailydauDB[i].getUserId() % 255));
                g2.setColor(eventColor);
                int delta = dxLeft+(int)((date.getHours()*3600+ date.getMinutes()*60.+ date.getSeconds())*24*wHour/(24*3600));
                g2.drawLine(delta, height - 150, delta, height - 50);
            }
        g2.dispose();
        return DauUtil.renderBase64(bi, "DAU");
    }



    @Override
    public List<DailyDauViewModel> getAlldailydau() {

        HashMap<Date, String> ListAuto = DauUtil.getListAuto();

        DailyDau[] dailydauDB = ao.find(DailyDau.class,
                Query.select()
                        .order("\"DATE\"  DESC")

        );

        DailyDauViewModel[] view = new DailyDauViewModel[dailydauDB.length];

        for (int i= 0; i < dailydauDB.length; i++) {

            String str_color = "color:rgb("+(int)(dailydauDB[i].getUserId() % 255)+","+(255 - (int)(dailydauDB[i].getUserId() % 255))+","+(int)(dailydauDB[i].getUserId() % 255)+")";
            Date date = dailydauDB[i].getDate();
            boolean isAuto = false;
            String summary = ListAuto.get(date);

            if ( summary != null) isAuto = true;
            else summary = "";

            view[i] = new DailyDauViewModel(date,
                    dailydauDB[i].getUserId(),
                    dailydauDB[i].getEventId(),
                    ComponentAccessor.getEventTypeManager().getEventType(dailydauDB[i].getEventId()).getName(),
                    ComponentAccessor.getUserManager().getUserById(dailydauDB[i].getUserId()).get().getDisplayName(),
                    str_color, isAuto, summary);
        }

        return newArrayList(view);
    }
}
