package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.dau.ao.Dau;
import ru.rosbank.jira.dau.model.DauModel;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@Transactional
public interface DauService {

    Dau addDau( DauModel dauModel, int id);

    void newDay();

    List<Dau> getAllLinesFromDB();

    void delete();
    Dau[] findActiveDays(Long userID);
    void clearTmpDirectory();
}
