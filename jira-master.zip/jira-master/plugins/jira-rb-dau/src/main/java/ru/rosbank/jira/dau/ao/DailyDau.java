package ru.rosbank.jira.dau.ao;

import net.java.ao.Entity;
import net.java.ao.schema.Default;
import net.java.ao.schema.NotNull;
import java.util.Date;

public interface DailyDau extends Entity{
    @NotNull
    Long getUserId();

    @NotNull
    void setUserId(Long userId);

    @NotNull
    Long getEventId();

    @NotNull
    void setEventId(Long eventId);

    @NotNull
    Date getDate();

    @NotNull
    void setDate(Date date);

    @NotNull
    @Default("false")
    Boolean getIsAuto();

    @NotNull
    @Default("false")
    void setIsAuto(Boolean isAuto);
}
