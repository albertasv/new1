package ru.rosbank.jira.dau.listener;

import ru.rosbank.jira.dau.api.DailyDauService;

import javax.inject.Inject;

public class DauEvent {

    @Inject
    public DauEvent(Long userID, Long eventID, DailyDauService dailyDauService)
    {
        if (dailyDauService != null)
            dailyDauService.addDailyDau(userID, eventID);
    }
}

