package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.UserUtils;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.mail.config.ConfigLoader;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.transaction.TransactionCallback;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import net.java.ao.Query;
import org.ofbiz.core.entity.GenericEntityException;

import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.dau.DauUtil;
import ru.rosbank.jira.dau.ao.DailyDau;
import ru.rosbank.jira.dau.ao.Dau;
import ru.rosbank.jira.dau.model.DauModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("dauService")
public class DauServiceImpl  implements DauService{
    private final UserManager userManager;
    private final DailyDauService dailyDauService;
    private static final Logger LOG = LoggerFactory.getLogger(DauServiceImpl.class);

    private final ActiveObjects ao;
    //private final ConfigLoader config;

    JiraHome jiraHome;

    @Inject
    public DauServiceImpl(@ComponentImport JiraHome jiraHome, @ComponentImport ActiveObjects ao,
                          DailyDauService dailyDauService) {

        this.ao = checkNotNull(ao);
        this.dailyDauService = checkNotNull(dailyDauService);
        this.userManager = ComponentAccessor.getUserManager();
        this.jiraHome = jiraHome;
    }

    public void newDay(){

        Date dateSaveToDB = new Date();
        //  dateSaveToDB = new Date(dateSaveToDB.getTime());

        List<Dau> DBListTotal = getAllLinesFromDB();
        int id_DB = getMaxIDTable()+1;


        dateSaveToDB = new Date(dateSaveToDB.getYear(),dateSaveToDB.getMonth(),dateSaveToDB.getDate());

        List<DailyDau> DailyDBList = dailyDauService.getAllDailyActivities();

        HashMap<Date, String> ListAuto = DauUtil.getListAuto();

        boolean is1dayActive;
        boolean is7dayActive;
        boolean is28dayActive;

        Set<Long> fullListId = new HashSet<>();

        Date joinedDate;

        for (DailyDau dailyStoredDau : DailyDBList){   ////// ****** today is active

            Long id = dailyStoredDau.getUserId();

            if (fullListId.contains(id)) continue;   /// already today added

            if (ListAuto.get(dailyStoredDau.getDate()) != null) continue;  // skip auto event

            fullListId.add(id);

            is1dayActive = true;
            is7dayActive = true;
            is28dayActive = true;

            Dau[] ActiveDays = findActiveDays(id);

            if (ActiveDays.length > 0)
                joinedDate = ActiveDays[0].getJoinedDate();   // already in past
            else
                joinedDate = dailyStoredDau.getDate();                 // 1-st time active

            ApplicationUser applicationUser = ComponentAccessor.getUserManager().getUserById(id).orElse(null);

            if (applicationUser == null) continue;
            dateSaveToDB =  new Date(dailyStoredDau.getDate().getYear(),dailyStoredDau.getDate().getMonth(), dailyStoredDau.getDate().getDate());

            DauModel dauModel = new DauModel(dateSaveToDB,
                    id,
                    joinedDate,
                    is1dayActive,
                    is7dayActive,
                    is28dayActive,
                    applicationUser.isActive());
            Dau dau = addDau (dauModel, id_DB);
            id_DB ++;
        }

        for (Dau storedDau : DBListTotal){   // ******  Today isn't active
            Long id = storedDau.getUserId();

            if (fullListId.contains(id)) continue;  // **** already added in 1-st for
            fullListId.add(id);             // a new user
            is1dayActive = false;
            is7dayActive = false;
            is28dayActive = false;

            Dau[] ActiveDays = findActiveDays(id);

            if (ActiveDays.length > 0) {
                joinedDate = ActiveDays[0].getJoinedDate();
                Date lastActiveDate = ActiveDays[0].getDate();

                int intLastActive = DauUtil.diffDays2(lastActiveDate, dateSaveToDB);
                if (intLastActive < 8){
                    is7dayActive = true;
                    is28dayActive = true;
                }
                else if (intLastActive < 29){
                    is28dayActive = true;
                }
            }
            else {
                joinedDate = new Date(0, Calendar.JANUARY, 1);
            }
            ApplicationUser applicationUser = ComponentAccessor.getUserManager().getUserById(id).orElse(null);


            if( applicationUser == null)   continue;


            DauModel dauModel = new DauModel(dateSaveToDB,
                    id,
                    joinedDate,
                    is1dayActive,
                    is7dayActive,
                    is28dayActive,
                    applicationUser.isActive());
            Dau dau = addDau (dauModel, id_DB);
            id_DB ++;
        }

        dailyDauService.deleteAllDailyActivities();
        clearTmpDirectory();
    }

    @Override
    public void clearTmpDirectory() {
        File tempDirectory = new File(jiraHome.getSharedCachesDirectory(), "dau");
        if (tempDirectory.exists()) {
            File[] files = tempDirectory.listFiles();
            for (File file : files) {
                file.delete();
            }
        }
    }


    public int getMaxIDTable(){
       int maxID = 100000;

            SQLProcessor sqlProcessor = null;

            HashMap<Date, String> ListAuto = new HashMap<>();
            try {

                sqlProcessor = new SQLProcessor("defaultDS");
                ResultSet rs = sqlProcessor.executeQuery("SELECT max(\"ID\") FROM \"AO_A96CEE_DAU\" \n" );

                while (rs.next()) {
                    maxID = rs.getInt(1);
                }
            } catch ( GenericEntityException | SQLException ex) {
                LOG.error("Get audit data error: {}" + ex);
            } finally {
                if (sqlProcessor != null) {
                    try {
                        sqlProcessor.close();
                    } catch (GenericEntityException e) {
                        LOG.error("Get audit data error: {}" + e);
                    }
                }
            }
            return maxID;
    }


    @Override
    public Dau addDau(DauModel dauModel, int id) {

                        SQLProcessor sqlProcessor = null;
                        try {
                            String strSQL = "INSERT INTO \"AO_A96CEE_DAU\" (";
                                strSQL += "\"DATE\", \"ENABLED\", \"ID\" , \"IS1DAY_ACTIVE\", \"IS7DAY_ACTIVE\", \"IS28DAY_ACTIVE\", \"JOINED_DATE\", \"USER_ID\")" ;
                                strSQL += "VALUES ('" +dauModel.getDate() + "'";
                                strSQL +=",'" + dauModel.getEnabled() + "'";
                                strSQL +=",'" + id + "'";
                                strSQL += ",'" + dauModel.getIs1dayActive() + "'";
                                strSQL += ",'" + dauModel.getIs7dayActive() + "'";
                                strSQL += ",'" + dauModel.getIs28dayActive() + "'";
                                strSQL += ",'" + dauModel.getJoinedDate() + "'";
                                strSQL += ",'" + dauModel.getUserId() + "'";
                                strSQL +=  ");";

                            sqlProcessor = new SQLProcessor("defaultDS");
                            sqlProcessor.prepareStatement(strSQL);

                            sqlProcessor.executeUpdate();

                            sqlProcessor.close();

                    } catch( Exception ex){
                        LOG.error("Update: data error: {}" + ex);
                    } finally{
                        if (sqlProcessor != null) {
                            try {
                                sqlProcessor.close();
                            } catch (Exception e) {
                                LOG.error("Close: error: {}" + e);
                            }
                        }
                    }
        return null;
    }

    @Override
    public Dau[] findActiveDays(Long userID) {
        return ao.find(Dau.class,
                Query.select()
                        .where("USER_ID = ? AND IS1DAY_ACTIVE = ?", userID, true)
                        .order("\"DATE\"  DESC"));
    }


    @Override
    public List<Dau> getAllLinesFromDB()
    {
        return newArrayList(ao.find(Dau.class,
                Query.select()
                        .order("\"DATE\"  DESC")));
    }

    public List<Dau> getAllLinesFromDBByDate(Date date)
    {
        return newArrayList(ao.find(Dau.class,
            Query.select()
            .where("DATE = ? ", date)
        ));
    }

    @Override
    public void delete(){

        Dau[] old = ao.find(Dau.class,
                Query.select()
                        //.where("DATE <  ?",  false)
                        .order("\"DATE\"  DESC")
                        );

        for (Dau dau : old) {
            ao.delete(dau);
        }
    }
}
