package ru.rosbank.jira.dau.api;

import ru.rosbank.jira.dau.model.DauViewModel;
import java.io.IOException;
import java.util.List;

public interface DauViewService {

    List<DauViewModel> getAllDauView();

    String getImage() throws IOException;

    void setSortView(String strSort);

    }