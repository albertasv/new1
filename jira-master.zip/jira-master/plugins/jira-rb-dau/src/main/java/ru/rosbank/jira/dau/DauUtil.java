package ru.rosbank.jira.dau;

import com.atlassian.jira.util.Base64InputStreamConsumer;
import org.jfree.chart.encoders.EncoderUtil;
import org.jfree.chart.encoders.ImageFormat;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class DauUtil {

    private static final Logger log = LoggerFactory.getLogger(DauUtil.class);

    public static String renderBase64(BufferedImage image, String Name) {
        try {
            InputStream inputStream = new ByteArrayInputStream(EncoderUtil.encode(image, ImageFormat.PNG));
            Base64InputStreamConsumer base64Consumer = new Base64InputStreamConsumer(false);
            base64Consumer.consume(inputStream);
            return "data:image/png;base64," + base64Consumer.getEncoded();
        } catch (Exception e) {
            throw new RuntimeException("Failed to base 64 image with name " + Name, e);
        }
    }

    public static int getWeekDay(Date date){                
        int year = date.getYear()+1900;
        int month = date.getMonth()+1;
        int day = date.getDate();
        String strDate = year+"."+month+"."+day;
        int dayweek = date.getDay();

        switch (strDate) {            
            case "2023.5.1":
                dayweek = 6;
                break;
            case "2023.5.8":
                dayweek = 6;
                break;
            case "2023.5.9":
                dayweek = 0;
                break;
            case "2023.6.12":
                dayweek = 6;
                break;
            case "2023.11.6":
                dayweek = 6;
                break;
            case "2024.1.1":
                dayweek = 6;
                break;
            case "2024.1.2":
                dayweek = 0;
                break;
            case "2024.1.3":
                dayweek = 6;
                break;
            case "2024.1.4":
                dayweek = 0;
                break;
            case "2024.1.5":
                dayweek = 6;
                break;
            case "2024.2.23":
                dayweek = 6;
                break;
            case "2024.3.8":
                dayweek = 6;
                break;
            case "2024.4.29":
                dayweek = 6;
                break;
            case "2024.4.30":
                dayweek = 0;
                break;
            case "2024.5.1":
                dayweek = 6;
                break;
            case "2024.5.9":
                dayweek = 6;
                break;
            case "2024.5.10":
                dayweek = 6;
                break;
            case "2024.6.12":
                dayweek = 6;
                break;
            case "2024.11.4":
                dayweek = 6;
                break;
            case "2024.12.30":
                dayweek = 6;
                break;
            case "2024.12.31":
                dayweek = 0;
                break;
        }
        return dayweek;
    }

    public static int diffDays2(Date date1, Date date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date1);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);

        int y1 = calendar1.get(Calendar.YEAR) - 1;
        int y2 = calendar2.get(Calendar.YEAR) - 1;
        return calendar2.get(Calendar.DAY_OF_YEAR) - calendar1.get(Calendar.DAY_OF_YEAR) +
                (y2 - y1) * 365 + (y2 / 4 - y1 / 4) - (y2 / 100 - y1 / 100) +  (y2 / 400 - y1 / 400);
    }

    public static HashMap<Date, String> getListAuto() {

        SQLProcessor sqlProcessor = null;

        HashMap<Date, String> ListAuto = new HashMap<>();
        try {

            sqlProcessor = new SQLProcessor("defaultDS");
            ResultSet rs = sqlProcessor.executeQuery("select * from \"AO_A96CEE_DAILY_DAU\" d\n" +
                    "join app_user u on d.\"USER_ID\" = u.id\n" +
                    "join \"AO_589059_AUDIT_ITEM\" ai on ai.\"AUTHOR_KEY\" = u.user_key\n" +
                    "and d.\"DATE\" between ai.\"START_TIME\" and ai.\"END_TIME\" \n" );

            while (rs.next()) {
                Date date = rs.getTimestamp("DATE");
                String summary = rs.getString("SUMMARY");
                ListAuto.put(date, summary);
            }
        } catch (GenericEntityException | SQLException ex) {
            log.error("Get audit data error: {}" + ex);
        } finally {
            if (sqlProcessor != null) {
                try {
                    sqlProcessor.close();
                } catch (GenericEntityException e) {
                    log.error("Get audit data error: {}" + e);
                }
            }
        }
        return ListAuto;
    }
}
