package ru.rosbank.jira.dau.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.dau.api.DailyDauService;
import ru.rosbank.jira.dau.api.DauService;

import javax.inject.Inject;

import static com.google.common.base.Preconditions.checkNotNull;

@Component
public class DauListener implements InitializingBean, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(DauListener.class);

    private final EventPublisher eventPublisher;
    private final DailyDauService dailyDauService;

    @Inject
    public DauListener(@ComponentImport EventPublisher eventPublisher,
                       @ComponentImport JiraAuthenticationContext authenticationContext,
                                  DailyDauService dailyDauService, DauService dauService
    ) {
        this.eventPublisher = checkNotNull(eventPublisher);
        this.dailyDauService = checkNotNull(dailyDauService);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling DauListener listener");
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling DauListener listener");
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {
        LOG.info("onIssueEvent");
        this.eventPublisher.publish(new DauEvent(issueEvent.getUser().getId(), issueEvent.getEventTypeId(), dailyDauService));
    }
}
