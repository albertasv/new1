package ru.rosbank.jira.dau.model;

import com.atlassian.jira.component.ComponentAccessor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;


import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DauModel {

    private Date date;
    private Long UserId;
    private Date joinedDate;
    private Boolean is1dayActive;
    private Boolean is7dayActive;
    private Boolean is28dayActive;
    private Boolean enabled;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long id) {
        this.UserId = id;
    }

    public Date getJoinedDate() {
        return joinedDate;
    }

    public void setJoinedDate(Date joinedDate) {
        this.joinedDate = joinedDate;
    }

    public Boolean getIs1dayActive() {
        return is1dayActive;
    }

    public void setIs1dayActive(Boolean is1dayActive) {  this.is1dayActive = is1dayActive;  }

    public Boolean getIs7dayActive() {
        return is7dayActive;
    }

    public void setIs7dayActive(Boolean is7dayActive) {
        this.is7dayActive = is7dayActive;
    }

    public Boolean getIs28dayActive() {
        return is28dayActive;
    }

    public void setIs28dayActive(Boolean is28dayActive) {
        this.is28dayActive = is28dayActive;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public DauModel(Date date, Long UserId, Date joinedDate, Boolean is1dayActive, Boolean is7dayActive, Boolean is28dayActive, Boolean enabled) {
        this.date = date;
        this.UserId = UserId;
        this.joinedDate = joinedDate;
        this.is1dayActive = is1dayActive;
        this.is7dayActive = is7dayActive;
        this.is28dayActive = is28dayActive;
        this.enabled = enabled;
    }
}
