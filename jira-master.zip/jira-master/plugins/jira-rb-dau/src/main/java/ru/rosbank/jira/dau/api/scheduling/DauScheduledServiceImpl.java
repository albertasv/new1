package ru.rosbank.jira.dau.api.scheduling;

import com.atlassian.beehive.ClusterLockService;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.scheduler.SchedulerService;
import com.atlassian.scheduler.SchedulerServiceException;
import com.atlassian.scheduler.config.*;
import com.atlassian.scheduler.status.JobDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;

import javax.annotation.PreDestroy;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.concurrent.locks.Lock;

@ExportAsService
@Named("dauScheduledService")
public class DauScheduledServiceImpl implements DauScheduledService, LifecycleAware {

    private static final Logger LOG = LoggerFactory.getLogger(DauScheduledServiceImpl.class);

    private final String DAU_CRON_EXPRESSION_EVERY_DAY;
    private final JobRunnerKey dauJobRunnerEveryDayKey =
            JobRunnerKey.of(DauScheduledServiceImpl.class.getName() + ":instance-dau-every_day");

    private final SchedulerService schedulerService;

    private final DauJobRunner DauJobRunner;

    private static final String LOCK_NAME = DauScheduledServiceImpl.class.getName() + ".lockedTask";

    private final ClusterLockService clusterLockService;

    @Inject
    public DauScheduledServiceImpl(
            @ComponentImport SchedulerService schedulerService,
            @ComponentImport ConfigLoader configLoader,
            @ComponentImport ClusterLockService clusterLockService,
            DauJobRunner dauJobRunner) {
        this.schedulerService = schedulerService;
        this.DauJobRunner = dauJobRunner;
        this.DAU_CRON_EXPRESSION_EVERY_DAY = configLoader.getDauScheduling();
        this.clusterLockService = clusterLockService;
    }

    @Override
    public void onStart() {
        reschedule();
    }

    @Override
    public void reschedule() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            LOG.info("Register dau scheduled service");
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(dauJobRunnerEveryDayKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(dauJobRunnerEveryDayKey);
            }
            schedulerService.registerJobRunner(dauJobRunnerEveryDayKey, DauJobRunner);
            JobConfig dauConfigEveryDay = JobConfig.forJobRunnerKey(dauJobRunnerEveryDayKey)
                    .withRunMode(RunMode.RUN_ONCE_PER_CLUSTER)
                    .withSchedule(Schedule.forCronExpression(DAU_CRON_EXPRESSION_EVERY_DAY));


            try {
                schedulerService.scheduleJobWithGeneratedId(dauConfigEveryDay);
            } catch (SchedulerServiceException ssex) {
                LOG.error("Unable to create financial schedule task", ssex);
            }
        } finally {
            lock.unlock();
        }
    }

    @PreDestroy
    public void onStop() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(dauJobRunnerEveryDayKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(dauJobRunnerEveryDayKey);
            }
        } finally {
            lock.unlock();
        }
    }
}

