package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.dau.model.DailyDauViewModel;

import java.util.List;

@Transactional
public interface DailyDauViewService {

    List<DailyDauViewModel> getAlldailydau();

    String getImage();
}
