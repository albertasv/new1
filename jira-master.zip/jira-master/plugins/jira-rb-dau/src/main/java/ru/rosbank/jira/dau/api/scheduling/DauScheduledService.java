package ru.rosbank.jira.dau.api.scheduling;

public interface DauScheduledService {
    void reschedule();
}
