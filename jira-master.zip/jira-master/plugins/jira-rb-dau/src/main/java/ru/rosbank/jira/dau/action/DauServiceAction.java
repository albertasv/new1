package ru.rosbank.jira.dau.action;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.google.common.base.Strings;
import ru.rosbank.jira.dau.api.DauService;
import ru.rosbank.jira.dau.api.DauViewService;
import ru.rosbank.jira.dau.model.DauViewModel;
import java.io.IOException;
import java.util.List;

public class DauServiceAction extends JiraWebActionSupport {

    DauViewService dauViewService;

    public DauServiceAction(DauViewService dauViewService, DauService dauService) {
        this.dauViewService = dauViewService;

        String sortParam = getHttpRequest().getParameter("sort");
        if (!Strings.isNullOrEmpty(sortParam)) {
            dauViewService.setSortView(sortParam);
        }
    }

    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public List<DauViewModel> getAlldau() {

       return dauViewService.getAllDauView();
    }

    public String getImage() throws IOException {return dauViewService.getImage( );  }

}