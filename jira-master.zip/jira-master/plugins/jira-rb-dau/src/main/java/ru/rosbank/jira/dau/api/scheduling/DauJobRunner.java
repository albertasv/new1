package ru.rosbank.jira.dau.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.dau.api.DauService;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.inject.Inject;
import javax.inject.Named;

@Named("dauJobRunner")
public class  DauJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(DauJobRunner.class);

    private final DauService dauService;

    @Inject
    public DauJobRunner( DauService dauService) {
        this.dauService = dauService;

    }

    @Nullable
    @Override
    @ParametersAreNonnullByDefault
    public JobRunnerResponse runJob(JobRunnerRequest jobRunnerRequest) {
        LOG.info("Executing DAU scheduled job for current day");

        try {
            if (dauService != null) {
                dauService.newDay();
            }
        } catch (Exception rex) {
            LOG.error("Exception in JobRunnerResponse.runJob method");
        }
        return JobRunnerResponse.success();
    }
}
