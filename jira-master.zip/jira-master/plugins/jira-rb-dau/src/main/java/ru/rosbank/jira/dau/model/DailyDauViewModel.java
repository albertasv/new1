package ru.rosbank.jira.dau.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DailyDauViewModel {
    private Date date;
    private Long UserId;
    private Long EventId;
    private String UserName;
    private String eventName;
    private String color;
    private Boolean isAuto;
    private String summary;



    public DailyDauViewModel(Date date, Long UserId, Long eventID, String eventName, String UserName,String color, boolean isAuto, String summary) {
        this.date = date;
        this.UserId = UserId;
        this.EventId = eventID;
        this.eventName = eventName;
        this.UserName = UserName;
        this.color = color;
        this.isAuto = isAuto;
        this.summary = summary;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String id) {
        this.UserName = id;
    }


    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long id) {
        this.UserId = id;
    }

    public Long getEventId() {
        return EventId;
    }

    public void setEventId(Long id) {
        this.EventId = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Boolean getIsAuto() { return isAuto; }

    public void setIsAuto(Boolean isAuto){ this.isAuto = isAuto; }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

}
