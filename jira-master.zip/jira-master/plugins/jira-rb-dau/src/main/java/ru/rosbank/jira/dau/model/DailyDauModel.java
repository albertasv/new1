package ru.rosbank.jira.dau.model;

import net.java.ao.schema.NotNull;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DailyDauModel {
    private Date date;
    private Long UserId;
    private Long EventId;
    private Boolean isAuto;

    public DailyDauModel(Date date, Long UserId, Long eventID, boolean isAuto) {
        this.date = date;
        this.UserId = UserId;
        this.EventId = eventID;
        this.isAuto = isAuto;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long id) {
        this.UserId = id;
    }

    public Long getEventId() {
        return EventId;
    }

    public void setEventId(Long id) { this.EventId = id; }

    public Boolean getIsAuto() { return isAuto; }

    public void setIsAuto(Boolean isAuto){ this.isAuto = isAuto; }
}
