package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.dau.DauUtil;
import ru.rosbank.jira.dau.ao.Dau;
import ru.rosbank.jira.dau.model.DauViewModel;

import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.inject.Named;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;
import static java.awt.image.BufferedImage.TYPE_INT_RGB;

@ExportAsService
@Named("dauViewServiceImpl")
public class DauViewServiceImpl implements DauViewService {

    private static final Logger log = LoggerFactory.getLogger(DauViewServiceImpl.class);

    private final ActiveObjects ao;
    final DateFormat dateFormat;
    JiraHome jiraHome;
    String sortList = "DATE";

    @Inject
    public DauViewServiceImpl(@ComponentImport JiraHome jiraHome, @ComponentImport ActiveObjects ao) {

        this.ao = checkNotNull(ao);
        this.jiraHome = jiraHome;
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    }

    @Override
    public void setSortView(String strSort){
        sortList = strSort;
    }

    @Override
    public List<DauViewModel> getAllDauView() {


        Date date_limit = new Date();
        date_limit = new Date(date_limit.getTime() - 100l*1000*3600*24);

        Dau[] dauDB = ao.find(Dau.class,
                Query.select()
                        .where("DATE > ?",date_limit)
                        .order("\""+sortList+"\"  DESC, \"DATE\" DESC")
        );

        DauViewModel[] view = new DauViewModel[dauDB.length];
        SimpleDateFormat formatTime = new SimpleDateFormat("EEE, yyyy-MM-dd");

        for (int i= 0; i < dauDB.length; i++) {

            Date dateLine = dauDB[i].getDate();
            ApplicationUser au = ComponentAccessor.getUserManager().getUserById(dauDB[i].getUserId()).orElse(null);
            String name = "";
            if (au != null) name = au.getDisplayName();
            else {
                log.debug("******************  au = null   for dauDB[i].getUserId():" + dauDB[i].getUserId() );
            }

            view[i] = new DauViewModel(formatTime.format(dateLine),
                    dauDB[i].getUserId(),
                    formatTime.format(dauDB[i].getJoinedDate()),
                    dauDB[i].getIs1dayActive(),
                    dauDB[i].getIs7dayActive(),
                    dauDB[i].getIs28dayActive(),
                    dauDB[i].getEnabled(),
                    name,
                    DauUtil.getWeekDay(dateLine));
        }

        return newArrayList(view);
    }


    public void clearTime() {
        ao.executeInTransaction(() -> {
            Dau[] dauDB = ao.find(Dau.class);
            for (Dau dau : dauDB) {
                Date dt = dau.getDate();
                dau.setDate(new Date(dt.getYear(), dt.getMonth(), dt.getDate()));
                dau.save();
            }
            return dauDB;
        });
    }

    public File getTmpDirectory() {
        File tempDirectory = new File(jiraHome.getSharedCachesDirectory(), "dau");
        if (!tempDirectory.exists()) {
            tempDirectory.mkdir();
        }
        return tempDirectory;
    }

    @Override
    public String getImage() throws IOException {

        int widthImage = 1400;
        int heighImage = 350;

        Date date_limit = new Date();
        date_limit = new Date(date_limit.getTime() - 100l*1000*3600*24);


        Dau[] dauDB = ao.find(Dau.class,
                Query.select()
                        .where("DATE > ?",date_limit)
                        .order("DATE DESC")

        );

        if (dauDB.length == 0) return "";

        Date dateLineFirst = dauDB[dauDB.length-1].getDate();

        Date dateLineLast = dauDB[0].getDate();

        int difDay = DauUtil.diffDays2(dateLineFirst, dateLineLast)+1;

        int maxYunit = 5000;

        int unit;

        if (maxYunit < 100)
            unit = 10;
        else if (maxYunit < 1000)
            unit = 100;
        else if (maxYunit < 5000)
            unit = 500;
        else if (maxYunit < 10000)
            unit = 1000;
        else if (maxYunit < 20000)
            unit = 2000;
        else
            unit = 10000;

        maxYunit = (int)(Math.ceil(maxYunit *1.0/ unit) * unit);

        Color bg = new Color(255,255,255);
        Color axis = new Color(100,100,100);
        Color axisL = new Color(180,180,180);
        Color eventColor = new Color(50,200,200);
        Color eventColor2 = new Color(50,100,200);
        SimpleDateFormat formatTime = new SimpleDateFormat("EEE, MMM dd");
        int dW = 10;
        int dxLeft = 50;
        int dxRight = 30;
        int dyBottom = 50;
        int dyTop = 30;
        int wDay = (widthImage- dxRight)/(difDay+1);
        double  dhLines = (heighImage - dyBottom - dyTop) * 1.0/ maxYunit;

        BufferedImage bi = new BufferedImage(widthImage, heighImage, TYPE_INT_RGB);
        Graphics2D g2 = bi.createGraphics();

        Font font = new Font("serif", Font.PLAIN, 10);
        g2.setColor(bg);
        g2.fillRect(0, 0, widthImage, heighImage);

        g2.setColor(axis);
        g2.drawLine(dxLeft, heighImage - dyBottom, dxLeft, dyTop);

        g2.setColor(axisL);

        for (int i = unit; i <= maxYunit; i += unit){
            g2.drawLine(dxLeft , (int)(heighImage - dyBottom - i*dhLines), dxLeft + (difDay)*wDay, (int)(heighImage - dyBottom - i*dhLines));
            g2.drawString(""+ i, 20, (int)(heighImage - dyBottom - i*dhLines));
        }

        Long time = dateLineFirst.getTime();
        g2.setFont(font);
        for (int i = 0; i < difDay; i++){
            g2.setColor(axis);
            g2.drawLine(dxLeft + i*wDay, heighImage - dyBottom, dxLeft + (i+1)*wDay+10, heighImage - dyBottom);
            g2.drawLine(dxLeft + (i+1)*wDay-dW/2, heighImage - dyBottom, dxLeft + (i+1)*wDay-dW/2, heighImage - dyBottom+3);

            Date curDate = new Date(time + i*86400000L);

            int countActive = ao.count(Dau.class,
                    Query.select()
                            .where("DATE = ? AND IS1DAY_ACTIVE = ?", curDate, true )

            );

            int countNotActive = ao.count(Dau.class,
                    Query.select()
                            .where("DATE = ? AND IS1DAY_ACTIVE = ?", curDate, false )

            );

            int dayweek = DauUtil.getWeekDay(curDate);

            if ((dayweek == 6) || (dayweek ==0))
                g2.setColor(Color.red);
            else
                g2.setColor(axis);

            AffineTransform saveTransform=g2.getTransform();
            AffineTransform affineTransform = new AffineTransform();
            affineTransform.setToTranslation(dxLeft - 30 + (i + 1) * wDay,heighImage - dyBottom + 30);
            affineTransform.rotate(Math.toRadians(-45), 0, 0);
            g2.setTransform(affineTransform);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
            g2.drawString("" + formatTime.format(curDate), -12, 5);
            g2.setTransform(saveTransform);
            g2.setColor(eventColor);
            g2.fillRect(dxLeft - dW + (i + 1) * wDay,  (int)(heighImage - dyBottom - countActive*dhLines), dW, (int)(countActive*dhLines));
            g2.setColor(eventColor2);
            g2.fillRect(dxLeft - dW + (i + 1) * wDay,  (int)(heighImage - dyBottom - (countActive*dhLines)) - (int)(countNotActive*dhLines), dW, (int)(countNotActive*dhLines));

        }
        g2.dispose();
        return DauUtil.renderBase64(bi, "DAU-Total");
    }
}

