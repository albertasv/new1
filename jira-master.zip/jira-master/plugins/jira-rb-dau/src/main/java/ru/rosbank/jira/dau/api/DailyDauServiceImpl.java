package ru.rosbank.jira.dau.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.dau.ao.DailyDau;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("dailyDauService")
public class DailyDauServiceImpl implements DailyDauService{

    private final ActiveObjects ao;
    private static final Logger LOG = LoggerFactory.getLogger(DailyDauServiceImpl.class);

    @Inject
    public DailyDauServiceImpl(@ComponentImport ActiveObjects ao ) { this.ao = checkNotNull(ao);   }

    @Override
    public DailyDau addDailyDau(Long id, Long eventId) {

        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("DATE", new Date())
                .put("USER_ID", id)
                .put("IS_AUTO", false)
                .put("EVENT_ID", eventId);

        final DailyDau dailyDau = ao.create(DailyDau.class, mapBuilder.build());

        dailyDau.save();

        return dailyDau;
    }

    @Override
    public List<DailyDau> getAllDailyActivities() {
        return newArrayList(ao.find(DailyDau.class,
                Query.select()
                        .order("DATE")));
    }

    @Override
    public void deleteAllDailyActivities() {

        DailyDau[] old = ao.find(DailyDau.class );

        for (DailyDau dau : old) {
                ao.delete(dau);
        }
    }
}
