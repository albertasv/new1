function oldCustomfieldSelect2() {
    //single select
    AJS.$("select:visible[id*='customfield']").not("[multiple]").not(".cascadingselect-parent").not(".cascadingselect-child").not("#customfield_13421").not("#customfield_10434").each(function() {
        new AJS.SingleSelect({
            element: this,
            itemAttrDisplayed: "label"
        });
    });

    //multi select
    AJS.$("select[multiple][id*='customfield']:visible").not(".cascadingselect-parent").not(".cascadingselect-child")
        .not(".js-request-participants-field").not(".js-request-organizations-field").not("#customfield_13421").not("#customfield_10434").each(function() {
        new AJS.MultiSelect({
            element: this,
            itemAttrDisplayed: "label"
        });
    });
}

function newCustomfieldSelect2() {
    //single select
    AJS.$("select:visible[id*='customfield']").not("[multiple]").not(".cascadingselect-parent").not(".cascadingselect-child").not("#customfield_13421").not("#customfield_10434").each(function() {
        if ($(this).find("option:eq(0)").val() === "-1") {
            $(this).find("option:eq(0)").prop('selected',false);
        }
        $(this).auiSelect2({ dropdownAutoWidth : true, containerCssClass : "pitronote-select2" });
    });

    //multi select
    AJS.$("select[multiple][id*='customfield']:visible").not(".cascadingselect-parent").not(".cascadingselect-child")
        .not(".js-request-participants-field").not(".js-request-organizations-field").not("#customfield_13421").not("#customfield_10434").each(function() {
        if ($(this).find("option:eq(0)").val() === "-1") {
            $(this).find("option:eq(0)").prop('selected',false);
        }
        $(this).auiSelect2({ dropdownAutoWidth : true, closeOnSelect: false, containerCssClass : "pitronote-select2"});
    });
}

function generalSelect2() {
    AJS.$("select[multiple]").not("#customfield_13421").not("#customfield_10434").each(function() {
        $(this).auiSelect2({ dropdownAutoWidth: true,
            closeOnSelect: false,
            width: 'resolve'});
    });

    AJS.$("select").not("[multiple]").not("#customfield_13421").not("#customfield_10434").each(function() {
        $(this).auiSelect2({ dropdownAutoWidth : true });
    });
}