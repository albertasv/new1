## Rosbank JIRA - SM integration Plugin
Description here