package ru.rosbank.jira.sm.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.sm.api.SmMessageQueueCleanerService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Named;

@Named("сleanSmMessageQueueJobRunner")
public class ScheduledCleanSmMessageQueueJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledCleanSmMessageQueueJobRunner.class);

    private final SmMessageQueueCleanerService smMessageQueueCleanerService;

    public ScheduledCleanSmMessageQueueJobRunner(SmMessageQueueCleanerService smMessageQueueCleanerService) {
        this.smMessageQueueCleanerService = smMessageQueueCleanerService;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest request) {
        LOG.debug("Starting of old SM messages deleting from database...");
        smMessageQueueCleanerService.cleanSmMessageQueue();
        return JobRunnerResponse.success();
    }
}
