package ru.rosbank.jira.sm.ao;

import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.StringLength;
import net.java.ao.schema.Unique;

import java.util.Date;

@Preload
public interface ConfigurationItem extends SmDictionary {

    /**
     * Код ИТ-системы
     *
     * @return
     */
    @NotNull
    @Unique
    @Override
    String getCode();

    @NotNull
    @Override
    void setCode(String code);

    /**
     * Наименование
     *
     * @return
     */
    @NotNull
    @Override
    String getName();

    @NotNull
    @Override
    void setName(String name);

    /**
     * Тип CI, system - ИТ система, service - ИТ услуга
     *
     * @return
     */
    @NotNull
    String getType();

    @NotNull
    void setType(String type);

    /**
     * Статус
     *
     * @return
     */
    @NotNull
    String getStatus();

    @NotNull
    void setStatus(String status);

    /**
     * Домен владельца ИТ-системы
     *
     * @return
     */
    String getDomain();

    void setDomain(String domain);

    /**
     * Владелец ИТ-системы
     *
     * @return
     */
    String getOwner();

    void setOwner(String owner);

    /**
     * Ответственный работник владельца системы
     *
     * @return
     */
    String getOwnerResponsible();

    void setOwnerResponsible(String ownerResponsible);

    /**
     * Подразделение/команда развития
     *
     * @return
     */
    String getTeam();

    void setTeam(String team);

    /**
     * Ответственный от развития
     *
     * @return
     */

    String getTeamResponsible();

    void setTeamResponsible(String teamResponsible);

    /**
     * Менеджер ИТ-системы (Application manager)
     *
     * @return
     */
    String getManager();

    void setManager(String manager);

    /**
     * Офицер ИБ
     *
     * @return
     */
    String getIsOfficer();

    void setIsOfficer(String isOfficer);

    /**
     * Дата регистрации
     *
     * @return
     */
    Date getRegisterDate();

    void setRegisterDate(Date registerDate);

    /**
     * Дата начала разработки
     *
     * @return
     */
    Date getStartDevDate();

    void setStartDevDate(Date startDevDate);

    /**
     * Дата ввода в эксплуатацию
     *
     * @return
     */
    Date getStartOperationDate();

    void setStartOperationDate(Date startOperationDate);

    /**
     * Дата начала отключения
     *
     * @return
     */
    Date getStartOutOfService();

    void setStartOutOfService(Date startOutOfService);

    /**
     * Дата вывода из эксплуатации
     *
     * @return
     */
    Date getOutOfServiceDate();

    void setOutOfServiceDate(Date outOfServiceDate);

    /**
     * Примечание
     *
     * @return
     */
    @StringLength(StringLength.UNLIMITED)
    String getComment();

    void setComment(String comment);

    /**
     * Дата последнего изменения из SM
     *
     * @return
     */
    @Override
    Date getLastUpdateDate();

    @Override
    void setLastUpdateDate(Date lastUpdateDate);

    @Override
    Date getLastSyncDate();

    @Override
    void setLastSyncDate(Date lastSyncDate);

    String getSensitivity();

    void setSensitivity(String sensitivity);

    String getProcessCriticality();

    void setProcessCriticality(String processCriticality);

    String getActualRto();

    void setActualRto(String actualRto);

    String getActualRpo();

    void setActualRpo(String actualRpo);

    static String toString(ConfigurationItem ci) {
        StringBuilder res = new StringBuilder();
        if (ci != null) {
            res.append("[")
                    .append(ci.getCode())
                    .append("] ")
                    .append(ci.getName());
        }
        return res.toString();
    }
}