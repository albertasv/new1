package ru.rosbank.jira.sm;

import com.atlassian.jira.model.querydsl.QPriority;

public enum Priority {

    LOW("10", "10003"),
    MEDIUM("20", "10002"),
    HIGH("30", "10001"),
    CRITICAL("40", "2");

    private String smId;
    private String jiraId;

    Priority(String smId, String jiraId) {
        this.smId = smId;
        this.jiraId = jiraId;
    }

    public String getSmId() {
        return smId;
    }

    public String getJiraId() {
        return jiraId;
    }

    public static Priority getBySmId(String smId) {
        for (Priority priority : Priority.values()) {
            if (String.valueOf(priority.getSmId()).equals(smId)) {
                return priority;
            }
        }
        return null;
    }
}
