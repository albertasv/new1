package ru.rosbank.jira.sm.connector.queue;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;

import javax.inject.Inject;
import java.util.Date;

/**
 * Инкапсулирует логику восстановления задачи отправки данных из БД в объект.
 */
@Component
public class SmMessageEntityToTaskHelper {

    private final IssueManager issueManager;

    private static final Logger LOG = LoggerFactory.getLogger(SmMessageEntityToTaskHelper.class);

    @Inject
    SmMessageEntityToTaskHelper(@ComponentImport IssueManager issueManager) {
        this.issueManager = issueManager;
    }

    public SmMessageSendingTaskModel taskEntityToObject(SmMessageSendingTaskEntity taskEntity) {
        SmMessage smMessage = restoreMessageFromSavedEntity(taskEntity);
        if (smMessage == null) {
            return null;
        }
        Integer taskId = taskEntity.getID();
        Date taskCreatedTime = taskEntity.getTaskCreatedTime();
        Date taskSentTime = taskEntity.getTaskSentTime();
        Long failedSyncCommentId = taskEntity.getFailedTaskSyncCommentId();

        return new SmMessageSendingTaskModel(taskId, taskCreatedTime, taskSentTime, smMessage, failedSyncCommentId);

    }

    private SmMessage restoreMessageFromSavedEntity(SmMessageSendingTaskEntity taskEntity) {

        String linkedIssueKey = taskEntity.getLinkedIssueKey();
        Issue linkedIssue = issueManager.getIssueObject(linkedIssueKey);

        if (linkedIssue == null) {
            LOG.error("Can not restore SM message entity from database: Issue does not exist anymore.");
            return null;
        }

        return new SmMessageBuilder()
                .linkedJiraIssue(linkedIssue)
                .toEndpoint(taskEntity.getTargetEndpoint())
                .usingMethod(taskEntity.getActionMethod())
                .withData(taskEntity.getJsonData())
                .mustAddCommentInIssue(taskEntity.getVerbose())
                .commentId(taskEntity.getCommentId())
                .build();
    }
}
