package ru.rosbank.jira.sm.model;

/**
 * Общий класс ответа абстрактного http-сервиса. Используется для инкапсуляции http-кода ответа сервиса и данных,
 * присланных в ответе.
 */
public class HttpServiceResponse {

    private final int responseCode;
    private final String responseBody;

    public HttpServiceResponse(int responseCode, String responseBody) {
        this.responseCode = responseCode;
        this.responseBody = responseBody;
    }

    public int getResponseCode() {
        return responseCode;
    }

    public String getResponseBody() {
        return responseBody;
    }

}
