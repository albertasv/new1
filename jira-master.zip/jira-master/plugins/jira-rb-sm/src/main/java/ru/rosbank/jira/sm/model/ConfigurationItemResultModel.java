package ru.rosbank.jira.sm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "ciResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class ConfigurationItemResultModel {
    private List<ConfigurationItemModel> items;
    private int total;

    public ConfigurationItemResultModel() {
    }

    public ConfigurationItemResultModel(List<ConfigurationItemModel> items, int total) {
        this.items = items;
        this.total = total;
    }

    public List<ConfigurationItemModel> getItems() {
        return items;
    }

    public void setItems(List<ConfigurationItemModel> items) {
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
