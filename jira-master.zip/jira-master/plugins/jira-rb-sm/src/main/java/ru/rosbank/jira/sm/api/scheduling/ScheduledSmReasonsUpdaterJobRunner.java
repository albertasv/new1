package ru.rosbank.jira.sm.api.scheduling;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.common.exceptions.LoadingSMReasonsException;
import ru.rosbank.jira.sm.api.SmReasonsUpdatingService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

/**
 * Класс, запускающий задачу по синхронизации справочников причин инцидентов по рассписанию
 */

@Named("smReasonsUpdaterJobRunner")
public class ScheduledSmReasonsUpdaterJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledSmReasonsUpdaterJobRunner.class);

    //** Объект (Bean) класса самой задачи, где выполняется вся работа. Передан в качестве параметра в конструктор
    private final SmReasonsUpdatingService smReasonsUpdatingService;

    private final ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final ServiceNames serviceName = ServiceNames.SM_REASONS_UPDATER;

    @Inject
    public ScheduledSmReasonsUpdaterJobRunner(@ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                              SmReasonsUpdatingService smReasonsUpdatingService) {
        this.smReasonsUpdatingService = smReasonsUpdatingService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }
    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest request) {
        LOG.info("Executing an updating SMReason database");
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
            new Date());
        try {
            if (smReasonsUpdatingService != null) {
                smReasonsUpdatingService.getSmReasons();
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                    new Date());
            }
        } catch (LoadingSMReasonsException lsrex) {
            LOG.error("Exception in SmReasonsUpdaterRunner.runJob method: {}",
                    ErrorStackTracer.getStackTrace(lsrex));
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(lsrex),
                new Date());
        }
        return JobRunnerResponse.success();
    }
}
