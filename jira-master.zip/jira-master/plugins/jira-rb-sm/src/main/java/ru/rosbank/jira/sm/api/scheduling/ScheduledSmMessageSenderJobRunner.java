package ru.rosbank.jira.sm.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.connector.queue.DatabaseQueuedSmMessageSender;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Inject;

@Component
public class ScheduledSmMessageSenderJobRunner implements JobRunner {

    DatabaseQueuedSmMessageSender databaseQueuedSmMessageSender;

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledSmMessageSenderJobRunner.class);


    @Inject
    public ScheduledSmMessageSenderJobRunner(DatabaseQueuedSmMessageSender databaseQueuedSmMessageSender) {
        this.databaseQueuedSmMessageSender = databaseQueuedSmMessageSender;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest request) {

        if (databaseQueuedSmMessageSender != null) {
            databaseQueuedSmMessageSender.sendSavedSmMessages();
        } else {
            LOG.error("SM messages sending failed.");
        }
        return JobRunnerResponse.success();
    }
}
