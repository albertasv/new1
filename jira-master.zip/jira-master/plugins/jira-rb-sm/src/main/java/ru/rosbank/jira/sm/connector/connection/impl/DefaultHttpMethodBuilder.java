package ru.rosbank.jira.sm.connector.connection.impl;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.EntityEnclosingMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.connector.connection.HttpMethodBuilder;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;

import java.io.UnsupportedEncodingException;

/**
 * Используется для создания инстансов http-методов коннектором к HP SM.
 * Реализация вынесена в отдельный класс для возможности проведения интеграционных тестов коннектора (HttpSmConnector)
 */
@Component
public class DefaultHttpMethodBuilder implements HttpMethodBuilder {

    private static final Logger LOG = LoggerFactory.getLogger("SM Integration");

    private final ConfigLoader config;

    @Autowired
    public DefaultHttpMethodBuilder(@ComponentImport ConfigLoader config) {
        this.config = config;
    }

    /**
     * Ожидается, что в параметре `url` будет передан адрес запроса без base URL. В процессе сборки запроса
     * base URL будет прочитан из конфигурационного файла.
     */
    @Override
    public HttpMethod buildMethod(SmActionMethod methodType, String url, String data) {

        String baseHpSmUrl = config.getSmActionUrl().replaceAll("/+$", "/");
        String effectiveUrl = baseHpSmUrl + url;

        LOG.debug("Generate request to HP SM: type - {}; url - {}; data - {}", methodType, effectiveUrl, data);

        EntityEnclosingMethod generatedMethod;
        switch (methodType) {
            case POST:
                generatedMethod = new PostMethod(effectiveUrl);
                break;
            case PUT:
                generatedMethod = new PutMethod(effectiveUrl);
                break;
            default:
                generatedMethod = null;
        }

        if (generatedMethod == null) {
            return null;
        }

        if (data != null) {
            try {
                StringRequestEntity requestEntity = new StringRequestEntity(data, "application/json", "UTF-8");
                generatedMethod.setRequestEntity(requestEntity);
            } catch (UnsupportedEncodingException e) {
                // в теории этот exception никогда не должен возникать
                throw new RuntimeException(e);
            }
        }

        setCommonHeaders(generatedMethod);

        return generatedMethod;

    }

    /**
     * Устанавливает минимальный набор необходимых заголовков для запроса в HP SM
     * * Basic-авторизаця
     * * Тип контента (application/json)
     * * Кодировка данных (UTF-8)
     */
    private void setCommonHeaders(HttpMethod httpMethod) {
        httpMethod.setRequestHeader("Authorization", "Basic " + config.getSmAuth());
        httpMethod.setRequestHeader("Content-Type", "application/json");
        httpMethod.setRequestHeader("charset", "UTF-8");
    }

}
