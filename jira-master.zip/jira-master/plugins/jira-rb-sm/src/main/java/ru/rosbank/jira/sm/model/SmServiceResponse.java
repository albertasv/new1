package ru.rosbank.jira.sm.model;

import java.util.List;

public interface SmServiceResponse {
    Integer getReturnCode();
    List<String> getMessages();
}
