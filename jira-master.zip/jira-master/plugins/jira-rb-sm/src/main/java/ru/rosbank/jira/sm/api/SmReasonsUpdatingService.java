package ru.rosbank.jira.sm.api;

import ru.rosbank.jira.common.exceptions.LoadingSMReasonsException;

public interface SmReasonsUpdatingService {
    void getSmReasons() throws LoadingSMReasonsException;
}
