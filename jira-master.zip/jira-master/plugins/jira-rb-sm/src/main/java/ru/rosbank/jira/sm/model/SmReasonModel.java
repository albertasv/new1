package ru.rosbank.jira.sm.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.sm.ao.SmReason;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement(name = "reason")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmReasonModel {

    private String code;
    private String name;
    private String group;

    private Date lastUpdateDate;
    private Date lastSyncDate;

    public SmReasonModel() {
    }

    public SmReasonModel(String code, String name, String group) {
        this.code = code;
        this.name = name;
        this.group = group;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Date getLastSyncDate() {
        return lastSyncDate;
    }

    public void setLastSyncDate(Date lastSyncDate) {
        this.lastSyncDate = lastSyncDate;
    }

    public static SmReasonModel convert(SmReason ci) {
        return new SmReasonModel(
                ci.getCode(),
                ci.getName(),
                ci.getGroupReason());
    }
}
