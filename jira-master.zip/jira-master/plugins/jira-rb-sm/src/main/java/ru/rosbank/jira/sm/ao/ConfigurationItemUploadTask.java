package ru.rosbank.jira.sm.ao;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.external.ActiveObjectsUpgradeTask;
import com.atlassian.activeobjects.external.ModelVersion;
import com.google.common.collect.ImmutableMap;
import com.mindprod.csv.CSVReader;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.sm.model.ConfigurationItemModel;
import ru.rosbank.jira.sm.model.ConfigurationItemStatus;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ConfigurationItemUploadTask implements ActiveObjectsUpgradeTask {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationItemUploadTask.class);

    @Override
    public ModelVersion getModelVersion() {
        return ModelVersion.valueOf("9");
    }

    @Override
    public void upgrade(ModelVersion modelVersion, ActiveObjects ao) {
        ao.migrate(ConfigurationItem.class);

        // Load init data
        if (getModelVersion().toString().equals("0")) {
            List<ConfigurationItemModel> data = loadCIFile();
            for (ConfigurationItemModel datum : data) {
                String type = datum.getType();
                String code = datum.getCode();
                String name = datum.getName();
                String status = datum.getStatus().getName();
                String sensitivity = datum.getSensitivity();
                String processCriticality = datum.getProcessCriticality();
                String actualRto = datum.getActualRto();
                String actualRpo = datum.getActualRpo();
                ConfigurationItem[] cis = ao.find(ConfigurationItem.class, Query.select().where("CODE = ?", code));
                LOG.debug("Loading CI {}:{}", code, name);
                if (cis.length == 0) {
                    ConfigurationItem ci = ao.create(ConfigurationItem.class, ImmutableMap.of("TYPE", type, "CODE", code, "NAME", name,
                            "STATUS", status));
                    if (type.equals("system")) {
                        ci.setSensitivity(sensitivity);
                        ci.setProcessCriticality(processCriticality);
                        ci.setActualRto(actualRto);
                        ci.setActualRpo(actualRpo);
                    }
                    ci.save();
                } else if (cis.length == 1) {
                    ConfigurationItem ci = cis[0];
                    ci.setType(type);
                    ci.setName(name);
                    ci.setStatus(status);
                    if (type.equals("system")) {
                        ci.setSensitivity(sensitivity);
                        ci.setActualRto(actualRto);
                        ci.setActualRpo(actualRpo);
                        ci.setProcessCriticality(processCriticality);
                    }
                    ci.save();
                }
            }
        }
    }

    public List<ConfigurationItemModel> loadCIFile() {
        List<ConfigurationItemModel> res = new ArrayList<>();
        ImmutableMap<String, String> filesToLoad = ImmutableMap.of("system", "ITSystem.csv", "service", "ITService.csv");
        for (String type : filesToLoad.keySet()) {
            String file = filesToLoad.get(type);
            CSVReader csvReader = null;
            try {
                csvReader = new CSVReader(new InputStreamReader(this.getClass().getResourceAsStream(file)));
                int counter = 5000;
                while (true) {
                    String[] fields = csvReader.getAllFieldsInLine();
                    String code = fields[0];
                    String status = fields[1];
                    String name = fields[3];
                    // String type1 = fields[2];
                    if (type.equals("system")) {
                        String sensitivity = fields[4];
                        String processCriticality = fields[5];
                        String actualRto = fields[6];
                        String actualRpo = fields[7];
                        LOG.info("Loading IT System -> {} {}", code, name);
                        res.add(new ConfigurationItemModel(type, code, name, ConfigurationItemStatus.getStatus(status),
                                sensitivity, processCriticality, actualRto, actualRpo));
                    } else
                        res.add(new ConfigurationItemModel(type, code, name, ConfigurationItemStatus.getStatus(status)));
                    LOG.debug("IT System type is: {};", type);
                    counter--;
                    // Too many CIs
                    if (counter < 0) {
                        break;
                    }
                }
            } catch (EOFException eof) {
                LOG.error("Error with loading IT Systems from *.csv", eof);
                // End of Line
            } catch (Exception ex) {
                LOG.error("Unexpected error with loading IT Systems from *.csv", ex);
            } finally {
                try {
                    if (csvReader != null) {
                        csvReader.close();
                    }
                } catch (IOException e) {
                }
            }
        }
        return res;
    }
}
