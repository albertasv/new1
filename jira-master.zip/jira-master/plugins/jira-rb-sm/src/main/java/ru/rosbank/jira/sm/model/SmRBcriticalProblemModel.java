package ru.rosbank.jira.sm.model;

import com.google.gson.annotations.SerializedName;

import java.util.Date;
import java.util.List;

/**
 * POJO-Класс для передачи данных из JIRA в SM
 */

public class SmRBcriticalProblemModel implements SmServiceResponse {


    @SerializedName("ReturnCode")
    private Integer returnCode;

    @SerializedName("Messages")
    private List<String> messages;

    @SerializedName("RBcriticalProblem")
    private RBcriticalProblemData data;

    public SmRBcriticalProblemModel() {
        this.data = new RBcriticalProblemData();
    }

    public SmRBcriticalProblemModel(RBcriticalProblemData data){
        this.data = data;
    }

    public RBcriticalProblemData getData() {
        return data;
    }

    public void setData(RBcriticalProblemData data) {
        this.data = data;
    }

    @Override
    public Integer getReturnCode() {
        return returnCode;
    }

    @Override
    public List<String> getMessages() {
        return messages;
    }

    public static class RBcriticalProblemData {

        private Long issueId;
        private String issueKey;

        //Номер инцидента. Уник ключ
        private String number;
        //Наименование мероприятия
        private String summary;
        //Описание мероприятия - Checklists + sub-tasks
        private String actionPlan;
        //Ответственный за создание АР

        @SerializedName("Priority")
        private String priority;
        private String assignee;
        //Ответственный исполнитель мероприятия
        private String eventAssignee;

        //Первоначальный срок исполнения
        private Date dueDate;
        //Отчет об исполнении - Checklists + sub-tasks
        private String report;

        private String issueStatus;

        public RBcriticalProblemData(){}

        public RBcriticalProblemData(String issueStatus) {
            this.issueStatus = issueStatus;
        }

        public Long getIssueId() {
            return issueId;
        }

        public void setIssueId(Long issueId) {
            this.issueId = issueId;
        }

        public String getIssueKey() {
            return issueKey;
        }

        public void setIssueKey(String issueKey) {
            this.issueKey = issueKey;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }

        public String getActionPlan() {
            return actionPlan;
        }

        public void setActionPlan(String actionPlan) {
            this.actionPlan = actionPlan;
        }

        /**
         * Ответственный за создание АР
         *
         * @return
         */
        public String getAssignee() {
            return assignee;
        }

        /**
         * Ответственный за создание АР
         *
         * @param assignee
         */
        public void setAssignee(String assignee) {
            this.assignee = assignee;
        }

        /**
         * Ответственный исполнитель мероприятия
         *
         * @return
         */
        public String getEventAssignee() {
            return eventAssignee;
        }

        /**
         * Ответственный исполнитель мероприятия
         *
         * @param eventAssignee
         */
        public void setEventAssignee(String eventAssignee) {
            this.eventAssignee = eventAssignee;
        }

        public Date getDueDate() {
            return dueDate;
        }

        public void setDueDate(Date dueDate) {
            this.dueDate = dueDate;
        }

        public String getReport() {
            return report;
        }

        public void setReport(String report) {
            this.report = report;
        }

        public String getIssueStatus() {
            return issueStatus;
        }

        public void setIssueStatus(String issueStatus) {
            this.issueStatus = issueStatus;
        }

        public String getPriority() {
            return priority;
        }

        public void setPriority(String priority) {
            this.priority = priority;
        }
    }
}
