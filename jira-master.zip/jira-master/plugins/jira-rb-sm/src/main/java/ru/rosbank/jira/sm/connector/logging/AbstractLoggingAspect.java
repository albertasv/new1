package ru.rosbank.jira.sm.connector.logging;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Инкапсулирует общие методы аспектов журналирования.
 */
public abstract class AbstractLoggingAspect {

    protected static final Logger LOG = LoggerFactory.getLogger("SM Integration");

    protected <T> T popArgForJoinPoint(JoinPoint joinPoint, int argNumber, Class<? extends T> argClass) {
        Object[] args = joinPoint.getArgs();
        if (args.length == 0 || argNumber >= args.length) {
            return null;
        }

        Object firstArg = args[argNumber];
        if (!argClass.isAssignableFrom(firstArg.getClass())) {
            return null;
        }

        return argClass.cast(firstArg);
    }

    protected String getCurrentThreadMarker() {

        Thread currentThread = Thread.currentThread();

        String currentThreadName = currentThread.getName();
        long currentThreadId = currentThread.getId();

        return currentThreadName + "#" + currentThreadId;

    }

}
