package ru.rosbank.jira.sm.ao;

import net.java.ao.Entity;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.Unique;

import java.util.Date;

public interface SmDictionary extends Entity {

    @NotNull
    @Unique
    String getCode();

    @NotNull
    void setCode(String code);

    String getName();

    void setName(String name);


    /**
     * Дата последнего изменения из SM
     *
     * @return
     */
    Date getLastUpdateDate();

    void setLastUpdateDate(Date lastUpdateDate);

    Date getLastSyncDate();

    void setLastSyncDate(Date lastSyncDate);
}
