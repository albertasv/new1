package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;
import ru.rosbank.jira.sm.model.SmMessageSendingTaskModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;


@ExportAsService
@Named("GetSmMessagesService")
public class GetSmMessagesServiceImpl implements GetSmMessagesService {

    private static final Logger LOG = LoggerFactory.getLogger(GetSmMessagesServiceImpl.class);

    private List<SmMessageSendingTaskModel> smMessageSendingTaskModelList = new ArrayList<>();

    private final ActiveObjects ao;

    @Inject
    public GetSmMessagesServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public List<SmMessageSendingTaskModel> getSmMessageSendingTasks() {
        SmMessageSendingTaskEntity[] tasks = ao.find(SmMessageSendingTaskEntity.class, Query.select().order("ID DESC"));
        LOG.debug("smMessageSendingTasks is: {}", tasks);
        smMessageSendingTaskModelList = SmMessageSendingTaskModel.convert(tasks);
        return smMessageSendingTaskModelList;
    }
}
