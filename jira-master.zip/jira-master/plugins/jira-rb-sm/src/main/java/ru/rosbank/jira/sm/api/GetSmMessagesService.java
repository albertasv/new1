package ru.rosbank.jira.sm.api;

import ru.rosbank.jira.sm.model.SmMessageSendingTaskModel;

import java.util.List;

public interface GetSmMessagesService {
    public List<SmMessageSendingTaskModel> getSmMessageSendingTasks();
}
