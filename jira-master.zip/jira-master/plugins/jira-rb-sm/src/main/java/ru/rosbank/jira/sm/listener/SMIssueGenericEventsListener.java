package ru.rosbank.jira.sm.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.SMUtils;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;
import ru.rosbank.jira.sm.model.SmRBcriticalProblemModel;
import ru.rosbank.jira.sm.model.SmRBprobsummaryModel;
import ru.rosbank.jira.sm.model.SmRBrequestTaskModel;

import javax.inject.Inject;

import static ru.rosbank.jira.sm.SMUtils.PROBLEM_PROJECT_KEY;

@Component
public class SMIssueGenericEventsListener extends AbstractSMIssueListener implements InitializingBean, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(SMIssueGenericEventsListener.class);

    private final EventPublisher eventPublisher;

    private final ConfigLoader config;

    private final SmService smService;

    private final CustomFieldManager customFieldManager;

    @Inject
    public SMIssueGenericEventsListener(
            @ComponentImport EventPublisher eventPublisher,
            @ComponentImport ConfigLoader config,
            @ComponentImport CustomFieldManager customFieldManager,
            SmService smService) {
        super(customFieldManager, config);
        this.eventPublisher = eventPublisher;
        this.config = config;
        this.customFieldManager = customFieldManager;
        this.smService = smService;
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling listener {}", SMIssueGenericEventsListener.class);
        eventPublisher.unregister(this);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling listener {}", SMIssueGenericEventsListener.class);
        eventPublisher.register(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {

        Long eventTypeId = issueEvent.getEventTypeId();

        if (eventTypeId.equals(EventType.ISSUE_GENERICEVENT_ID) || eventTypeId.equals(EventType.ISSUE_WORKSTARTED_ID)) {

            MutableIssue issue = (MutableIssue) issueEvent.getIssue();
            String statusName = issue.getStatus().getName();
            String smNumber = getSyncSmNumber(issue);
            String projectKey = issue.getProjectObject().getKey();

            // JIRA-6123 Проверка, отправлялся ли статус задачи в SM ранее.
            CustomField syncedWithSmStatusField = customFieldManager.getCustomFieldObject(config.getSyncedWithSmStatusFieldId());
            String syncedWithSmStatusFieldValueFromIssue =  (String) syncedWithSmStatusField.getValue(issue);
            String syncedWithSmStatusFieldValueFromConfig = config.getSyncedWithSmStatusFieldValue();
            if (!Strings.isNullOrEmpty(syncedWithSmStatusFieldValueFromIssue) &&
                    syncedWithSmStatusFieldValueFromIssue.equalsIgnoreCase(syncedWithSmStatusFieldValueFromConfig)) {
                return;
            }

            // JIRA-5404. Если задача из проекта PRB, то дополнительно отправляем инф-ю о статусе методом PUT
            if(!Strings.isNullOrEmpty(smNumber) && PROBLEM_PROJECT_KEY.equals(projectKey)) {
                String smUrl = "/RBcriticalProblem/" + smNumber;
                Gson gson = new Gson();
                String json = gson.toJson(new SmRBcriticalProblemModel(new SmRBcriticalProblemModel.RBcriticalProblemData(statusName)));
                sendSmMessage(smUrl, json, issue, SmActionMethod.PUT, issueEvent);
            }

            if (!Strings.isNullOrEmpty(smNumber) && smService.isSmIssueSource(issue)) {
                if (smNumber.contains("RFT")) {                            // Если наряд RFT
                    String smUrl = "/RBrequestTaskAction/" + smNumber + "/action/update";
                    Gson gson = new Gson();
                    String json = gson.toJson(new SmRBrequestTaskModel(new SmRBrequestTaskModel.SmRBrequestTaskActionModel(statusName)));
                    sendSmMessage(smUrl, json, issue, SmActionMethod.POST, issueEvent);
                } else {                                                   // Если инцидент IM
                    String smUrl = "/RBprobsummaryAction/" + smNumber + "/action/update";
                    Gson gson = new Gson();
                    String json = gson.toJson(new SmRBprobsummaryModel(new SmRBprobsummaryModel.SmRBprobsummaryActionModel(statusName)));
                    sendSmMessage(smUrl, json, issue, SmActionMethod.POST, issueEvent);
                }
            }

            // JIRA-6918 - Если при переводе задачи между статусами был оставлен комментарий с @smsync
            Comment comment = issueEvent.getComment();
            if (comment != null) {
                String smNumbers = smService.getSmNumber(issue);
                String smSyncMention = "[~" + config.getJiraSmUser() + "]";
                String body = comment.getBody();
                if (body.startsWith(smSyncMention)) {
                    smService.addSmSyncComment(issueEvent.getUser(), issue, smNumbers, comment, issueEvent);
                }
            }
        }
    }
    private void sendSmMessage(String smUrl, String json, MutableIssue issue, SmActionMethod smActionMethod, IssueEvent issueEvent) {
        if (json != null) {
            SmMessage smMessage = new SmMessageBuilder()
                    .toEndpoint(smUrl)
                    .withData(json)
                    .linkedJiraIssue(issue)
                    .usingMethod(smActionMethod)
                    .mustAddCommentInIssue(false)
                    .commentId(0L)
                    .taskAuthor(issueEvent.getUser().getUsername())
                    .build();
            smService.saveSmMessage(smMessage);
        }
    }
}
