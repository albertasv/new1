package ru.rosbank.jira.sm.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.model.ChangeItem;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.GenericValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.api.SmService;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

@Component
public class SMIssueUpdatedListener implements InitializingBean, DisposableBean {

    private static final Logger LOG = LoggerFactory.getLogger(SMIssueUpdatedListener.class);

    private static final String RESOLVE_REGISTRAR = "Не_решено_заявителем";

    private final EventPublisher eventPublisher;

    private final SmService smService;

    @Inject
    public SMIssueUpdatedListener(
            @ComponentImport EventPublisher eventPublisher,
            SmService smService) {
        this.eventPublisher = checkNotNull(eventPublisher);
        this.smService = smService;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling listener {}", SMIssueUpdatedListener.class);
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling listener {}", SMIssueUpdatedListener.class);
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {

        Long eventTypeId = issueEvent.getEventTypeId();

        if (!eventTypeId.equals(EventType.ISSUE_UPDATED_ID)) {
            return;
        }

        MutableIssue issue = (MutableIssue) issueEvent.getIssue();
        if (!smService.isSmIssueSource(issue)) {
            return;
        }

        String smNumbers = smService.getSmNumber(issue);
        if (Strings.isNullOrEmpty(smNumbers)) {
            return;
        }

        List<GenericValue> changelogGenericValues = getChangelogGenericValues(issueEvent);

        changelogGenericValues.forEach(changelogItem -> {
            String changedFieldName = (String) changelogItem.get(ChangeItem.FIELD);
            if ("duedate".equals(changedFieldName)) {
                String newDueDate = (String) changelogItem.get(ChangeItem.NEWSTRING);
                onDueDateUpdated(issue, smNumbers, newDueDate, issueEvent);
            } else if ("labels".equals(changedFieldName)) {
                String oldLabels = (String) changelogItem.get(ChangeItem.OLDSTRING);
                String newLabels = (String) changelogItem.get(ChangeItem.NEWSTRING);
                onLabelsUpdated(issue, smNumbers, oldLabels, newLabels, issueEvent);
            }
        });
    }

    private List<GenericValue> getChangelogGenericValues(IssueEvent issueEvent) {
        List<GenericValue> changelogGenericValues;

        try {
            changelogGenericValues = issueEvent.getChangeLog().getRelated("ChildChangeItem");
        } catch (GenericEntityException ex) {
            LOG.error("Search ChangeItems for linked SM Issue exception {}", ex);
            changelogGenericValues = new ArrayList<>();
        }
        return changelogGenericValues;
    }

    private void onLabelsUpdated(MutableIssue issue, String smNumbers, String oldLabels, String newLabels, IssueEvent issueEvent) {
        // JIRA-3157 Могло быть решено регистратором
        if (!oldLabels.contains(RESOLVE_REGISTRAR) && newLabels.contains(RESOLVE_REGISTRAR)) {
            smService.updateResolveRegistrar(issue, smNumbers, true);
        } else if (oldLabels.contains(RESOLVE_REGISTRAR) && !newLabels.contains(RESOLVE_REGISTRAR)) {
            smService.updateResolveRegistrar(issue, smNumbers, false);
        }
    }

    private void onDueDateUpdated(MutableIssue issue, String smNumbers, String newDueDate, IssueEvent issueEvent) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        try {
            smService.updateDueDate(issue, smNumbers, dateFormat.parse(newDueDate), issueEvent);
        } catch (Exception ex) {
            LOG.error("Update due date exception {}", ex);
        }
    }
}
