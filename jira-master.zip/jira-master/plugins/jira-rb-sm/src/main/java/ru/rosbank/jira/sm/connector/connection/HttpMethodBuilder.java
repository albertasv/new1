package ru.rosbank.jira.sm.connector.connection;

import org.apache.commons.httpclient.HttpMethod;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;

public interface HttpMethodBuilder {
    /**
     * Ожидается, что в параметре `url` будет передан адрес запроса без base URL. В процессе сборки запроса
     * base URL будет прочитан из конфигурационного файла.
     */
    HttpMethod buildMethod(SmActionMethod methodType, String url, String data);
}
