package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.common.exceptions.SmWorkGroupCreationException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupSearchingException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupUpdatingException;
import ru.rosbank.jira.sm.ao.SmWorkGroup;
import ru.rosbank.jira.sm.model.SmWorkGroupModel;

import java.util.List;

@Transactional
public interface SmWorGroupService
{
    List<SmWorkGroup> search(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupSearchingException;

    List<SmWorkGroup> search(String query) throws SmWorkGroupSearchingException;

    List<SmWorkGroup> searchAll();

    List<SmWorkGroup> search(int limit, int offset);

    void update(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupUpdatingException;

    void create(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupCreationException;

    SmWorkGroup getByCode(String code);

    SmWorkGroup getByName(String name);

    int total();
}
