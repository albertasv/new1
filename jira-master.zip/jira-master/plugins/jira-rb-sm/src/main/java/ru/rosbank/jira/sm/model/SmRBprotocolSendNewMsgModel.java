package ru.rosbank.jira.sm.model;

import com.google.gson.annotations.SerializedName;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.sm.SMEntityType;

import java.util.Collections;
import java.util.List;

@JsonIgnoreProperties
public class SmRBprotocolSendNewMsgModel implements SmServiceResponse {

    @SerializedName("ReturnCode")
    private Integer returnCode;

    @SerializedName("Messages")
    private List<String> messages;

    @SerializedName("RBprotocolSendNewMsg")
    private SmRBprotocolSendNewMsg data;

    public SmRBprotocolSendNewMsgModel() {
    }

    public SmRBprotocolSendNewMsgModel(String smNumber, String author, List<String> description) {
        this.data = new SmRBprotocolSendNewMsg(smNumber, author, description);
    }

    public SmRBprotocolSendNewMsg getData() {
        return data;
    }

    public void setData(SmRBprotocolSendNewMsg data) {
        this.data = data;
    }

    @Override
    public Integer getReturnCode() {
        return returnCode;
    }

    @Override
    public List<String> getMessages() {
        return messages;
    }

    public static class SmRBprotocolSendNewMsg {

        @SerializedName("NumberIM")
        private String smNumberIM;

        @SerializedName("NumberRFT")
        private String smNumberRFT;

        @SerializedName("OwnerID")
        private String author;

        @SerializedName("Description")
        private List<String> description;

        public SmRBprotocolSendNewMsg() {
        }

        public SmRBprotocolSendNewMsg(String smNumber, String author, List<String> description) {
            if (smNumber.contains(SMEntityType.IM.name())) // Если комментируем инцидент
            {
                this.smNumberIM = smNumber;
            } else {                                       // Если комментируем наряд
                this.smNumberRFT = smNumber;
            }
            this.author = author;
            this.description = description;
        }

        public String getSmNumber() {
            return smNumberIM;
        }

        public void setSmNumber(String smNumber) {
            this.smNumberIM = smNumber;
        }

        public String getSmNumberIM() {
            return smNumberIM;
        }

        public void setSmNumberIM(String smNumberIM) {
            this.smNumberIM = smNumberIM;
        }

        public String getSmNumberRFT() {
            return smNumberRFT;
        }

        public void setSmNumberRFT(String smNumberRFT) {
            this.smNumberRFT = smNumberRFT;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public List<String> getDescription() {
            if (description == null) {
                return Collections.emptyList();
            }
            return description;
        }

        public void setDescription(List<String> description) {
            this.description = description;
        }
    }
}
