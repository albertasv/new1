package ru.rosbank.jira.sm.action;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import ru.rosbank.jira.sm.api.GetSmMessagesService;
import ru.rosbank.jira.sm.model.SmMessageSendingTaskModel;


import java.util.List;

public class SmMessagesQueueAction extends JiraWebActionSupport {

    private GetSmMessagesService getSmMessagesService;


    public SmMessagesQueueAction(GetSmMessagesService getSmMessagesService) {
        this.getSmMessagesService = getSmMessagesService;
    }

    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public List<SmMessageSendingTaskModel> getSmMessageSendingTasks() {
        return getSmMessagesService.getSmMessageSendingTasks();
    }
}
