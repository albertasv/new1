package ru.rosbank.jira.sm.connector.logging;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import ru.rosbank.jira.sm.connector.message.SmMessage;

@Aspect
public class HpSmServiceLoggingAspect extends AbstractLoggingAspect {

    @Pointcut("execution(* ru.rosbank.jira.sm.connector.SmConnector.sendMessage(ru.rosbank.jira.sm.connector.message.SmMessage, java.util.Map<String, String>, Class<? extends ru.rosbank.jira.sm.connector.response.processor.SmResponseProcessor>))")
    public void sendingMessageObjectToSm() {
    }

    @After("sendingMessageObjectToSm()")
    public void logSendingMessageObjectToSm(JoinPoint joinPoint) {
        SmMessage sendingSmMessage = popArgForJoinPoint(joinPoint, 0, SmMessage.class);
        LOG.debug("Sending message object to SM is\n{}", sendingSmMessage);
    }

}
