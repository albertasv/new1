package ru.rosbank.jira.sm.connector;

/**
 * Список возможных вариантов ответов от HP SM.
 * Их, конечно же больше, но мы выделяем только эти.
 */
public enum SmResponseStatus {
    /**
     * Возвращается в случае успешного выполнения запроса.
     */
    SM_ISSUE_UPDATE_SUCCESSFULLY,
    /**
     * Запрашиваемый метод (SmActionMethod) не поддерживается.
     */
    SM_UNSUPPORTED_SERVICE_METHOD,
    /**
     * Возвращается в случае внутренних проблем на сервисе HP SM.
     * Для http-клиента - код ответа http = 500
     */
    SM_SERVICE_FAILURE,
    /**
     * В случае проблем со связностью с сервисом.
     * В процессе выполнения запроса возникли ошибки ввода-вывода.
     */
    SM_SERVICE_CONNECTIVITY_ERROR,
    /**
     * В случае, если не удалось распарсить тело ответа HP SM.
     */
    SM_BAD_RESPONSE_BODY,
    /**
     * В случае, когда http-код запроса >= 300, не равен 500, а поле returnCode ответа (если он есть) не равно 70
     */
    SM_UNKNOWN_ERROR,
    /**
     * Если сервис вернул ответ, поле returnCode которого = 70
     * Ддя http-клиента - код ответа http >= 300
     */
    SM_ISSUE_ALREADY_RESOLVED
}
