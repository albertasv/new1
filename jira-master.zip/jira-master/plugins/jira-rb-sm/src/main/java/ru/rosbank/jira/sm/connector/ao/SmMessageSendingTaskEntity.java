package ru.rosbank.jira.sm.connector.ao;

import net.java.ao.Entity;
import net.java.ao.schema.StringLength;
import net.java.ao.schema.Table;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;

import java.util.Date;

/**
 * Запись описывает задание на отправку сообщения в HP SM.
 */
@Table("SmExchangeTask")
public interface SmMessageSendingTaskEntity extends Entity {

    Date getTaskCreatedTime();

    void setTaskCreatedTime(Date date);

    Date getTaskSentTime();

    void setTaskSentTime(Date date);

    @StringLength(StringLength.UNLIMITED)
    String getTargetEndpoint();

    void setTargetEndpoint(String targetEndpoint);

    @StringLength(StringLength.UNLIMITED)
    String getJsonData();

    void setJsonData(String jsonData);

    SmActionMethod getActionMethod();

    void setActionMethod(SmActionMethod actionMethod);

    String getLinkedIssueKey();

    void setLinkedIssueKey(String linkedIssueKey);

    boolean getVerbose();

    void setVerbose(boolean verbose);

    @StringLength(StringLength.UNLIMITED)
    String getSmResponse();

    void setSmResponse(String smResponse);

    Long getCommentId();

    void setCommentId(Long commentId);

    Date getJiraAdminsNotificationTime();

    void setJiraAdminsNotificationTime(Date assigneeNotificationTime);

    Long getFailedTaskSyncCommentId();

    void setFailedTaskSyncCommentId(Long commentId);

    String getTaskAuthor();

    void setTaskAuthor(String taskAuthor);

}
