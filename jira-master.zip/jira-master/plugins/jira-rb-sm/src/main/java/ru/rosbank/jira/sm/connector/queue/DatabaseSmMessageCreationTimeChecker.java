package ru.rosbank.jira.sm.connector.queue;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;

import javax.inject.Inject;

/**
 * Класс, который проверяет время создания сообщения. И если разница между временем создания сообщения и текущим моментом
 * времени будет превышать указанную в конфигурации норму, то данный класс будет инициализировать отправку уведомления assignee.
 */

@Component
public class DatabaseSmMessageCreationTimeChecker {

    ActiveObjects ao;

    private static final Logger LOG = LoggerFactory.getLogger(DatabaseSmMessageCreationTimeChecker.class);

    @Inject
    public DatabaseSmMessageCreationTimeChecker(@ComponentImport ActiveObjects ao) {
        this.ao = ao;
    }

    public void checkSmMessageCreationTimeInDatabase(Query query) {
        SmMessageSendingTaskEntity[] sendingTaskEntities = ao.find(SmMessageSendingTaskEntity.class, query);
    }
}
