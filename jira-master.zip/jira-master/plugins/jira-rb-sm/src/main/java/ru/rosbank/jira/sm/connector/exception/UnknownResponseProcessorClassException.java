package ru.rosbank.jira.sm.connector.exception;

/**
 * Ошибка генерируется в том случае, когда в базе данных для задачи отправки данных в HP SM указан несуществующий класс
 * обработчика ответа. Такая ситуация может возникать в случае рефакторинга кода - когда один из обработчиков ответов
 * от HP SM был переименован, перемещен в другой пакет или удален.
 */
public class UnknownResponseProcessorClassException extends SmSendingTaskRestorationException {

    private final String expectedResponseProcessorClassName;

    public UnknownResponseProcessorClassException(String expectedResponseProcessorClassName) {
        this.expectedResponseProcessorClassName = expectedResponseProcessorClassName;
    }

    public String getExpectedResponseProcessorClassName() {
        return expectedResponseProcessorClassName;
    }

    @Override
    public String getMessage() {
        return "Saved HP SM response processor class not found: " + expectedResponseProcessorClassName;
    }

}
