package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.sm.ao.ConfigurationItem;
import ru.rosbank.jira.sm.model.ConfigurationItemModel;
import ru.rosbank.jira.sm.model.ConfigurationItemType;

import java.util.List;

@Transactional
public interface ConfigurationItemService {

    String add(ConfigurationItemType type, ConfigurationItemModel ciModel);

    List<ConfigurationItem> all();

    int total();

    ConfigurationItem getByCode(String code);

    /**
     * @param type   CI type
     * @param query  search query
     * @param all    returns all statuses if true or only actual
     * @param limit
     * @param offset
     * @return
     */
    List<ConfigurationItem> search(String type, String query, Long project, boolean all, int limit, int offset);

    /**
     * @param type  CI type
     * @param query search query
     * @param all   returns all statuses if true or only actual
     * @return
     */
    int total(String type, String query, Long project, boolean all);

    String update(ConfigurationItemModel ciModel);
}
