package ru.rosbank.jira.sm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "smWgResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class SmWorkGroupResultModel {

    private List<SmWorkGroupModel> items;

    private int total;

    public SmWorkGroupResultModel() {
    }

    public SmWorkGroupResultModel(List<SmWorkGroupModel> items) {
        this.items = items;
    }

    public SmWorkGroupResultModel(List<SmWorkGroupModel> items, int total) {
        this.items = items;
        this.total = total;
    }

    public List<SmWorkGroupModel> getItems() {
        return items;
    }

    public void setItems(List<SmWorkGroupModel> items) {
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
