package ru.rosbank.jira.sm.connector.connection.impl;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.FileRequestEntity;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.connector.connection.SmAttachmentSender;

import javax.inject.Inject;
import java.io.File;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
public class SmAttachmentSenderImpl implements SmAttachmentSender {

    private final ConfigLoader configLoader;

    private final Logger log = LoggerFactory.getLogger(SmAttachmentSenderImpl.class);

    @Inject
    public SmAttachmentSenderImpl(@ComponentImport ConfigLoader configLoader) {
        this.configLoader = configLoader;
    }

    @Override
    public void sendAttachmentToSm(String protocolRecordId, String requestJsonDataFromComment) {
        log.info("Start SM sending attachment process...");
        List<File> jiraAttachments = getAttachmentsFromIssue(requestJsonDataFromComment);
        HttpClient client = new HttpClient();
        final String sendAttachmentUrl = configLoader.getSmActionUrl() +
                "/RBprotocolCreate/" +
                protocolRecordId +
                "/attachments";
        for (File jiraAttachment : jiraAttachments) {
            PostMethod postAttachmentMethod = postSmAttachmentMethod(sendAttachmentUrl, jiraAttachment);
            try {
                client.executeMethod(postAttachmentMethod);
            } catch (Exception e) {
                log.error("Error in sendAttachmentToSm method: ", e);
            }
        }
    }

    private List<File> getAttachmentsFromIssue(String requestJsonData) {
        log.info("Start to get attachments for posting to SM...");
        List<File> downloadedAttachments = new ArrayList<>();
        HttpClient client = new HttpClient();
        Set<String> attachmentUrls = extractAttachmentLinks(requestJsonData);
        for (String attachmentUrl : attachmentUrls) {
            log.debug("Attachment url is {}", attachmentUrl);
            String attachmentExtension = defineAttachmentExtension(attachmentUrl);
            attachmentUrl = encodeInUTF8IfCyrillicFileNameInUrl(attachmentUrl);
            GetMethod getAttachmentMethod = getJiraAttachmentMethod(attachmentUrl);
            try {
                client.executeMethod(getAttachmentMethod);
            } catch (Exception e) {
                log.error("Error in executing getAttachmentMethod method: ", e);
            }

            try (InputStream is = getAttachmentMethod.getResponseBodyAsStream()) {
                log.info("Try to get attachment from response body...");
                File tempFile = File.createTempFile("attachment_" + new Date().getTime(), null);
                FileUtils.copyInputStreamToFile(is, tempFile);
                File newFile = new File(tempFile.getAbsolutePath().replaceAll(".tmp", "") + '.' + attachmentExtension);
                FileUtils.copyFile(tempFile, newFile);
                downloadedAttachments.add(newFile);
            } catch (Exception e) {
                log.error("Error in getResponseBodyAsStream method: ", e);
            }
        }
        return downloadedAttachments;
    }

    private GetMethod getJiraAttachmentMethod(String attachmentUrl) {
        final GetMethod get;
        get = new GetMethod(attachmentUrl);
        // TODO: Зашифровать пользователя Smsync и Base64 и сохранить в БД (AO_D46467_CREDENTIAL)
        get.setRequestHeader("Authorization", "Basic U01TeW5jOlJCd3NKaXJhMjAyMSE"); //SMSync User:Password (Base64)
        get.setRequestHeader("Content-Type", "application/json");
        get.setRequestHeader("charset", "UTF-8");
        return get;
    }

    private PostMethod postSmAttachmentMethod(String sendAttachmentUrl, File fileBody) {
        try {
            final PostMethod post = new PostMethod(sendAttachmentUrl);
            post.setRequestHeader("Authorization", "Basic " + configLoader.getSmAuth());
            post.setRequestHeader("Content-Type", "application/octet-stream");
            post.setRequestHeader("Content-Disposition", "attachment; filename*=UTF-8''" + fileBody.getName());
            RequestEntity requestEntity = new FileRequestEntity(fileBody, "application/octet-stream");
            post.setRequestEntity(requestEntity);
            return post;
        } catch (Exception e) {
            log.error("Error in smPostMethod method: ", e);
            return null;
        }
    }

    private Set<String> extractAttachmentLinks(String requestJsonData) {
        try {
            final String LINK_REGEX = "((http://|https://)(www.)?(([a-zA-Z0-9-]){2,2083}\\.){1,4}([a-zA-Z]){2,6}(/(([a-zA-Z-_/.0-9#:?=&;,]){0,2083})?){0,2083}?[^\\n\\r\\]}\"]*)";
            Set<String> links = new HashSet<>();
            Pattern p = Pattern.compile(LINK_REGEX, Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(requestJsonData);
            int linksCount = 0;
            while (m.find()) {
                List<String> splittedURLs = new ArrayList<>();
                String matcherContent = m.group();
                if (matcherContent.contains("\\n"))
                        splittedURLs = Arrays.asList(matcherContent.split("\\\\n"));
                Set<String> clearedURLs = splittedURLs.stream()
                        .filter(url -> url.matches(LINK_REGEX))
                        .map(url -> url.replaceAll("\\\\n", ""))
                        .map(url -> url.replaceAll("\\\\r", ""))
                        .map(String::trim)
                        .collect(Collectors.toSet());
                linksCount ++;
                links.addAll(clearedURLs);
                log.debug("Link to attachment {} is: {}", linksCount, matcherContent);
            }
            return links;
        } catch (Exception e) {
            log.debug("Can not to extract attachment link: {0}", e);
            return Collections.emptySet();
        }
    }

    private String defineAttachmentExtension(String attachmentUrl) {
        String revertedUrl = new StringBuilder(attachmentUrl).reverse().toString();
        String revertedExtension = revertedUrl.substring(0, revertedUrl.indexOf('.'));
        return new StringBuilder(revertedExtension).reverse().toString();
    }

    private String encodeInUTF8IfCyrillicFileNameInUrl(String attachmentUrl) {
        try {
            String revertedUrl = new StringBuilder(attachmentUrl).reverse().toString();
            String revertedFileName = revertedUrl.substring(0, revertedUrl.indexOf('/'));
            String straightFileName = new StringBuilder(revertedFileName).reverse().toString();
            String revertedUrlWithoutCyrillicFileName = revertedUrl.replaceAll(revertedFileName, "");
            String straightUrlWithoutCyrillicFileName = new StringBuilder(revertedUrlWithoutCyrillicFileName).reverse().toString();
            return straightUrlWithoutCyrillicFileName + URLEncoder.encode(straightFileName, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.debug("Error with URL encoding: {0}", e);
            return "";
        }
    }
}