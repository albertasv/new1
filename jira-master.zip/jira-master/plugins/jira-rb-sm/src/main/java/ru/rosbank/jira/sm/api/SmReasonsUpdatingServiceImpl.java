package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.util.json.JSONArray;
import com.atlassian.jira.util.json.JSONObject;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.exceptions.LoadingSMReasonsException;
import ru.rosbank.jira.sm.ao.SmReason;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Класс (Bean), где описан механизм выполнения задачи по синхронизации справочника причин инцидентов в SM.
 */

@ExportAsService
@Named("smReasonsUpdatingService")
public class SmReasonsUpdatingServiceImpl implements  SmReasonsUpdatingService {

    private static final Logger LOG = LoggerFactory.getLogger(SmReasonsUpdatingServiceImpl.class);

    private final ConfigLoader config;

    private final ActiveObjects ao;

    @Inject
    public SmReasonsUpdatingServiceImpl(@ComponentImport ConfigLoader config,
    @ComponentImport ActiveObjects ao,
    SmAsyncTaskExecutor asyncTaskExecutor) {
        this.config = checkNotNull(config);
        this.ao = checkNotNull(ao);
    }

    //** Главный метод, где описан механизм взаимодействия c REST API SM для получения причин инцидентов
        @Override
    public void getSmReasons() throws LoadingSMReasonsException {
        List<JSONObject> smReasons = new ArrayList<>();
        try {
            LOG.info("getSmReasons method is started");
            HttpClient client = new HttpClient();
            String smUrl = config.getSmActionUrl() + "/RBincreason?query="  + URLEncoder.encode("(VisibleScope=\"Инциденты Ришелье\")",
                    StandardCharsets.UTF_8.toString()) + "&view=expand";
            GetMethod getData = smGetMethod(smUrl);
            int responseCode = client.executeMethod(getData);
            if(responseCode >= 300) {
                LOG.error("SM connection error. Can not connect to " + smUrl + " resource. Response from server is " + responseCode);
            }
            try (InputStream in = getData.getResponseBodyAsStream()) {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                String response = org.apache.commons.io.IOUtils.toString(reader);
                JSONObject jObject = new JSONObject(response);
                JSONArray jArray = (JSONArray)jObject.get("content");
                if (jArray != null) {
                    for (int i = 0; i < jArray.length(); i++){
                        smReasons.add((JSONObject) jArray.get(i));
                    }
                }
            }
            for (int i = 0; i < smReasons.size(); i ++) {
                JSONObject rbIncreason = (JSONObject)smReasons.get(i).get("RBincreason");
                SmReason[] codes = ao.find(SmReason.class, Query.select().where("CODE = ?", rbIncreason.get("Number").toString()));
                if (codes != null && codes.length > 0) {
                    SmReason smReason = codes[0];
                    smReason.setCode(rbIncreason.get("Number").toString());
                    smReason.setName(rbIncreason.get("Name").toString());
                    smReason.setGroupReason(rbIncreason.get("Category").toString());
                    smReason.save();
                } else {
                    ao.create(SmReason.class, ImmutableMap.<String, Object>of(
                            "CODE", rbIncreason.get("Number").toString(),
                            "NAME", rbIncreason.get("Name").toString(),
                            "GROUP_REASON", rbIncreason.get("Category").toString())
                    );
                }
            }
        } catch(Exception ex) {
            LOG.debug("An error with SmReasonUpdatingService occurred", ex);
            throw new LoadingSMReasonsException(ex.getMessage(), ex.getStackTrace());
        }
    }
    private GetMethod smGetMethod(String smUrl) {
        final GetMethod get = new GetMethod(smUrl);
        get.setRequestHeader("Authorization", "Basic " + config.getSmAuth());
        get.setRequestHeader("Content-Type", "application/json");
        get.setRequestHeader("charset", "UTF-8");
        return get;
    }
}
