package ru.rosbank.jira.sm.model;

import com.google.gson.annotations.SerializedName;
import ru.rosbank.jira.sm.SmResolutionCode;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class SmRBrequestTaskModel implements SmServiceResponse {

    @SerializedName("ReturnCode")
    private Integer returnCode;

    @SerializedName("Messages")
    private List<String> messages;

    @SerializedName("RBrequestTaskAction")
    private SmRBrequestTaskActionModel data;

    public SmRBrequestTaskModel() {
    }

    @Override
    public List<String> getMessages() {
        if (messages == null) {
            return Collections.emptyList();
        }
        return messages;
    }

    public void setMessages(List<String> messages) {
        this.messages = messages;
    }

    public SmRBrequestTaskModel(SmRBrequestTaskActionModel data) {
        this.data = data;
    }

    public SmRBrequestTaskActionModel getData() {
        return data;
    }

    public void setData(SmRBrequestTaskActionModel data) {
        this.data = data;
    }

    @Override
    public Integer getReturnCode() {
        return returnCode == null ? 0 : returnCode;
    }

    public void setReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }

    public static class SmRBrequestTaskActionModel {

        @SerializedName("State")
        private String state;

        @SerializedName("AssigneeName")
        private String assignee;
        @SerializedName("ReportReason")
        private List<String> reportReason;
        @SerializedName("Resolution")
        private List<String> resolution;

        @SerializedName("Description")
        private List<String> description;
        @SerializedName("Number")

        private String smNumber;
        @SerializedName("GroupId")
        private String group;
        @SerializedName("Service")
        private String service;
        @SerializedName("ItSystem")
        private String itSystem;

        @SerializedName("Deadline")
        private Date deadline;
        @SerializedName("CompletionTime")
        private Date completionTime;

        @SerializedName("Priority")
        private String priority;
        @SerializedName("Impact")
        private String impact;

        @SerializedName("PlannedDateRealization")
        private Date dueDate;

        @SerializedName("NumberSD")
        private String numberSD;


        // JIRA-3061
        //«ResolutionCode» - Код закрытия.
        // Возможные значения: Решено, Решено с комментарием, Не актуально
        @SerializedName("ResolutionCode")
        private String resolutionCode;
        // JIRA-3021
        //«Reason» - Причина возникновения
        @SerializedName("Reason")
        private String causeReason;

        // JIRA-3157 Могло быть решено регистратором
        @SerializedName("ResolveRegistrar")
        private Boolean resolveRegistrar;

        public SmRBrequestTaskActionModel() {
        }

        public SmRBrequestTaskActionModel(String state) {
            this.state = state;
        }

        public SmRBrequestTaskActionModel(String state, String assignee, String resolution) {
            this.state = state;
            this.assignee = assignee;
            this.resolution = Arrays.asList(resolution);
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getAssignee() {
            return assignee;
        }

        public void setAssignee(String assignee) {
            this.assignee = assignee;
        }

        public List<String> getReportReason() {
            return reportReason;
        }

        public void setReportReason(List<String> reportReason) {
            this.reportReason = reportReason;
        }

        public List<String> getResolution() {
            return resolution;
        }

        public void setResolution(List<String> resolution) {
            this.resolution = resolution;
        }

        public List<String> getDescription() {
            return description;
        }

        public void setDescription(List<String> description) {
            this.description = description;
        }

        public String getSmNumber() {
            return smNumber;
        }

        public void setSmNumber(String smNumber) {
            this.smNumber = smNumber;
        }

        public String getGroup() {
            return group;
        }

        public void setGroup(String group) {
            this.group = group;
        }

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public String getItSystem() {
            return itSystem;
        }

        public void setItSystem(String itSystem) {
            this.itSystem = itSystem;
        }

        public Date getDeadline() {
            return deadline;
        }

        public void setDeadline(Date deadline) {
            this.deadline = deadline;
        }

        public Date getCompletionTime() {
            return completionTime;
        }

        public void setCompletionTime(Date completionTime) {
            this.completionTime = completionTime;
        }

        public String getPriority() {
            return priority;
        }

        public void setPriority(String priority) {
            this.priority = priority;
        }

        public String getImpact() {
            return impact;
        }

        public void setImpact(String impact) {
            this.impact = impact;
        }

        public Date getDueDate() {
            return dueDate;
        }

        public void setDueDate(Date dueDate) {
            this.dueDate = dueDate;
        }

        public String getResolutionCode() {
            return resolutionCode;
        }

        public void setResolutionCode(SmResolutionCode resolutionCode) {
            int resolutionCodeNumber = resolutionCode.getCode();
            this.resolutionCode = String.valueOf(resolutionCodeNumber);
        }

        public String getCauseReason() {
            return causeReason;
        }

        public void setCauseReason(String causeReason) {
            this.causeReason = causeReason;
        }

        public Boolean getResolveRegistrar() {
            return resolveRegistrar;
        }

        public void setResolveRegistrar(Boolean resolveRegistrar) {
            this.resolveRegistrar = resolveRegistrar;
        }

        public String getNumberSD() {
            return numberSD;
        }

        public void setNumberSD(String numberSD) {
            this.numberSD = numberSD;
        }
    }
}
