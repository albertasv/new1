package ru.rosbank.jira.sm.model;

import com.google.common.base.Strings;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@XmlRootElement(name = "createIssue")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmIssueModel {

    public SmIssueModel() {
    }

    private String project;

    private String issueType;

    private String reporter;

    private String assignee;

    private String summary;

    private String description;

    private String smNumber;

    private String smType;

    private List<String> attachments;

    private String priority;

    private String impact;

    private Date deadline;

    private String itSystem;

    private String service;

    private String extraInfo;

    private String smGroup;

    private Date startDate;

    private Integer ratingRichelieu;

    private Integer amountLinkedSd;

    private String themes;

    private String numberSD;

    private String commentFromPreviousIssue;

    private String activityType;

    private String environment;

    private String classification;

    private String testEnvironment;

    private List<SmCreateIssueLinkModel> links = new ArrayList<>();

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSmNumber() {
        return smNumber;
    }

    public void setSmNumber(String smNumber) {
        this.smNumber = smNumber;
    }

    public String getSmType() {
        return smType;
    }

    public void setSmType(String smType) {
        this.smType = smType;
    }

    public List<String> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<String> attachments) {
        this.attachments = attachments;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getImpact() {
        return impact;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public String getItSystem() {
        return itSystem;
    }

    public void setItSystem(String itSystem) {
        this.itSystem = itSystem;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    public String getSmGroup() {
        return smGroup;
    }

    public void setSmGroup(String smGroup) {
        this.smGroup = smGroup;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Integer getRatingRichelieu() {
        return ratingRichelieu;
    }

    public void setRatingRichelieu(Integer ratingRichelieu) {
        this.ratingRichelieu = ratingRichelieu;
    }

    public Integer getAmountLinkedSd() {
        return amountLinkedSd;
    }

    public void setAmountLinkedSd(Integer amountLinkedSd) {
        this.amountLinkedSd = amountLinkedSd;
    }

    public String getThemes() {
        return themes;
    }

    public void setThemes(String themes) {
        this.themes = themes;
    }

    public List<SmCreateIssueLinkModel> getLinks() {
        return links;
    }

    public void setLinks(List<SmCreateIssueLinkModel> links) {
        this.links = links;
    }

    public String getNumberSD() {
        return numberSD;
    }

    public void setNumberSD(String numberSD) {
        this.numberSD = numberSD;
    }

    public String getCommentFromPreviousIssue() {
        return commentFromPreviousIssue;
    }

    public void setCommentFromPreviousIssue(String commentFromPreviousIssue) {
        this.commentFromPreviousIssue = commentFromPreviousIssue;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getTestEnvironment() {
        return testEnvironment;
    }

    public void setTestEnvironment(String testEnvironment) {
        this.testEnvironment = testEnvironment;
    }

    public static class SmCreateIssueLinkModel {
        private String title;
        private String href;

        public String getTitle() {
            return Strings.isNullOrEmpty(title) ? href : title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getHref() {
            return href;
        }

        public void setHref(String href) {
            this.href = href;
        }
    }

    @Override
    public String toString() {
        return "SmIssueModel {" +
                "project='" + project + '\'' +
                ", issueType='" + issueType + '\'' +
                ", reporter='" + reporter + '\'' +
                ", assignee='" + assignee + '\'' +
                ", summary='" + summary + '\'' +
                ", description='" + description + '\'' +
                ", smNumber='" + smNumber + '\'' +
                ", smType='" + smType + '\'' +
                ", attachments=" + attachments +
                ", priority='" + priority + '\'' +
                ", impact='" + impact + '\'' +
                ", deadline=" + deadline +
                ", itSystem='" + itSystem + '\'' +
                ", service='" + service + '\'' +
                ", extraInfo='" + extraInfo + '\'' +
                ", smGroup='" + smGroup + '\'' +
                ", startDate=" + startDate +
                ", ratingRichelieu=" + ratingRichelieu +
                ", amountLinkedSd=" + amountLinkedSd +
                ", themes='" + themes + '\'' +
                ", numberSD='" + numberSD + '\'' +
                ", commentFromPreviousIssue='" + commentFromPreviousIssue + '\'' +
                ", activityType='" + activityType + '\'' +
                ", environment='" + environment + '\'' +
                ", classification='" + classification + '\'' +
                ", testEnvironment='" + testEnvironment + '\'' +
                ", links=" + links +
                '}';
    }
}
