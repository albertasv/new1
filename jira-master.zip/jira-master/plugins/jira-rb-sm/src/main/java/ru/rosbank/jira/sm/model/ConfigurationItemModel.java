package ru.rosbank.jira.sm.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.sm.ao.ConfigurationItem;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement(name = "ci")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigurationItemModel {

    private String type;

    private String code;

    private String name;

    private ConfigurationItemStatus status;

    private String statusCode;


    private String domain;

    private String owner;

    private String ownerResponsible;

    private String team;

    private String teamResponsible;

    private String manager;

    private String isOfficer;

    private Date registerDate;

    private Date startDevDate;

    private Date startOperationDate;

    private Date startOutOfService;

    private Date outOfServiceDate;

    private String comment;

    private Date lastUpdateDate;

    private Date lastSyncDate;

    String sensitivity;

    String processCriticality;

    String actualRto;

    String actualRpo;

    public ConfigurationItemModel() {
    }

    public ConfigurationItemModel(String type, String code, String name, ConfigurationItemStatus status) {
        this.type = type;
        this.code = code;
        this.name = name;
        this.status = status;
    }

    public ConfigurationItemModel(String type, String code, String name, ConfigurationItemStatus status,
                                  String sensitivity, String processCriticality, String actualRto, String actualRpo) {
        this.type = type;
        this.code = code;
        this.name = name;
        this.status = status;
        this.sensitivity = sensitivity;
        this.processCriticality = processCriticality;
        this.actualRto = actualRto;
        this.actualRpo = actualRpo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ConfigurationItemStatus getStatus() {
        return status;
    }

    public void setStatus(ConfigurationItemStatus status) {
        this.status = status;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getOwnerResponsible() {
        return ownerResponsible;
    }

    public void setOwnerResponsible(String ownerResponsible) {
        this.ownerResponsible = ownerResponsible;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getTeamResponsible() {
        return teamResponsible;
    }

    public void setTeamResponsible(String teamResponsible) {
        this.teamResponsible = teamResponsible;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getIsOfficer() {
        return isOfficer;
    }

    public void setIsOfficer(String isOfficer) {
        this.isOfficer = isOfficer;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public Date getStartDevDate() {
        return startDevDate;
    }

    public void setStartDevDate(Date startDevDate) {
        this.startDevDate = startDevDate;
    }

    public Date getStartOperationDate() {
        return startOperationDate;
    }

    public void setStartOperationDate(Date startOperationDate) {
        this.startOperationDate = startOperationDate;
    }

    public Date getStartOutOfService() {
        return startOutOfService;
    }

    public void setStartOutOfService(Date startOutOfService) {
        this.startOutOfService = startOutOfService;
    }

    public Date getOutOfServiceDate() {
        return outOfServiceDate;
    }

    public void setOutOfServiceDate(Date outOfServiceDate) {
        this.outOfServiceDate = outOfServiceDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Date getLastSyncDate() {
        return lastSyncDate;
    }

    public void setLastSyncDate(Date lastSyncDate) {
        this.lastSyncDate = lastSyncDate;
    }

    public String getSensitivity() {
        return sensitivity;
    }

    public void setSensitivity(String sensitivity) {
        this.sensitivity = sensitivity;
    }

    public String getProcessCriticality() {
        return processCriticality;
    }

    public void setProcessCriticality(String processCriticality) {
        this.processCriticality = processCriticality;
    }

    public String getActualRto() {
        return actualRto;
    }

    public void setActualRto(String actualRto) {
        this.actualRto = actualRto;
    }

    public String getActualRpo() {
        return actualRpo;
    }

    public void setActualRpo(String actualRpo) {
        this.actualRpo = actualRpo;
    }

    public static ConfigurationItemModel convert(ConfigurationItem ci) {
        return new ConfigurationItemModel(
                ci.getType(),
                ci.getCode(),
                ci.getName(),
                ConfigurationItemStatus.getStatus(ci.getStatus()));
    }

    @Override
    public String toString() {
        return "ConfigurationItemModel{" +
                "type='" + type + '\'' +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", status=" + status +
                ", statusCode='" + statusCode + '\'' +
                ", domain='" + domain + '\'' +
                ", owner='" + owner + '\'' +
                ", ownerResponsible='" + ownerResponsible + '\'' +
                ", team='" + team + '\'' +
                ", teamResponsible='" + teamResponsible + '\'' +
                ", manager='" + manager + '\'' +
                ", isOfficer='" + isOfficer + '\'' +
                ", registerDate=" + registerDate +
                ", startDevDate=" + startDevDate +
                ", startOperationDate=" + startOperationDate +
                ", startOutOfService=" + startOutOfService +
                ", outOfServiceDate=" + outOfServiceDate +
                ", comment='" + comment + '\'' +
                ", lastUpdateDate=" + lastUpdateDate +
                ", lastSyncDate=" + lastSyncDate +
                ", sensitivity='" + sensitivity + '\'' +
                ", processCriticality='" + processCriticality + '\'' +
                ", actualRto='" + actualRto + '\'' +
                ", actualRpo='" + actualRpo + '\'' +
                '}';
    }
}
