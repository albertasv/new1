package ru.rosbank.jira.sm.rest;


import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.*;
import ru.rosbank.jira.common.exceptions.SmWorkGroupCreationException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupSearchingException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupUpdatingException;
import ru.rosbank.jira.sm.ao.SmWorkGroup;
import ru.rosbank.jira.sm.api.SmWorGroupService;
import ru.rosbank.jira.sm.model.SmWorkGroupModel;
import ru.rosbank.jira.sm.model.SmWorkGroupResultModel;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * REST API класс для обновления справочника рабочих групп. Так как мастер справочник ИТ-систем находится в SM, то при его
 * обновлении SM отсылает обновлённые данные в наш справочник.
 */

@Path("/workgroup")
public class SmWorkGroupRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationItemRestResource.class);

    private final JiraAuthenticationContext authenticationContext;

    private final ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;


    private SmWorGroupService smWorGroupService;

    private final ConfigLoader config;

    private final int LIMIT_ELEMENTS = 10;

    @Inject
    public SmWorkGroupRestResource(@ComponentImport JiraAuthenticationContext authenticationContext,
                                   @ComponentImport ConfigLoader config,
                                   @ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                   SmWorGroupService smWorGroupService) {
        this.authenticationContext = checkNotNull(authenticationContext);
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
        this.smWorGroupService = smWorGroupService;
        this.config = config;
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/update")
    public Response update(List<SmWorkGroupModel>smWorkGroupModelList) {

        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        LOG.debug("SmWorkgroupRestLogging: LoggedIn user is {}, smWorkGroupModelList is: {}", loggedInUser.getUsername(),
                smWorkGroupModelList.get(0).toString());

        if (!config.getJiraSmUser().equalsIgnoreCase(loggedInUser.getUsername())) {
            externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_WORKGROUPS_UPDATER
                    , Statuses.FAILED
                    , Response.Status.FORBIDDEN.getReasonPhrase()
                    , new Date());
            return Response.status(Response.Status.FORBIDDEN).build();
        }

        try {
            for (SmWorkGroupModel smWorkGroupModel : smWorkGroupModelList) {
                if (!smWorGroupService.search(smWorkGroupModel).isEmpty()) {
                    smWorGroupService.update(smWorkGroupModel);
                }
                else {
                    smWorGroupService.create(smWorkGroupModel);
                }
            }
        } catch (SmWorkGroupSearchingException | SmWorkGroupUpdatingException | SmWorkGroupCreationException swex) {
            LOG.error("Exception in SmWorkGroupRestResource.update() method", ErrorStackTracer.getStackTrace(swex));
            externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_WORKGROUPS_UPDATER
                    , Statuses.FAILED
                    , ErrorStackTracer.getStackTrace(swex), new Date());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }

        externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_WORKGROUPS_UPDATER
                , Statuses.UPDATED
                , Statuses.UPDATED.getMessage()
                , new Date());
        return Response.ok(Response.Status.OK).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/search")
    public Response searchWorkGroups(@QueryParam("q") String query, @QueryParam("page") int page) {

        List<SmWorkGroupModel> result = new ArrayList<>();
        List<SmWorkGroup> smWorkGroupList;

        try {
            if (!Strings.isNullOrEmpty(query)) {
                smWorkGroupList = smWorGroupService.search(query);
            } else {
                smWorkGroupList = smWorGroupService.search(LIMIT_ELEMENTS, (page - 1) * LIMIT_ELEMENTS);
            }
        } catch (SmWorkGroupSearchingException swex) {
            externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_WORKGROUPS_UPDATER
                    , Statuses.FAILED
                    , swex.getMessage(), new Date());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }

        int total = smWorGroupService.total();
        if (!smWorkGroupList.isEmpty()) {
            for (SmWorkGroup smWorkGroup : smWorkGroupList) {
                result.add(SmWorkGroupModel.convert(smWorkGroup));
            }
            return Response.ok(new SmWorkGroupResultModel(result, total)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}
