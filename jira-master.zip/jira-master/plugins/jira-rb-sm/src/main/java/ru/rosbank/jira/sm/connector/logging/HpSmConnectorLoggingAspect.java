package ru.rosbank.jira.sm.connector.logging;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.message.SmMessage;

@Aspect
public class HpSmConnectorLoggingAspect extends AbstractLoggingAspect {

    @Pointcut("execution(* ru.rosbank.jira.sm.connector.connection.HttpSmConnector.sendMessage(..))")
    public void actuallySendingMessageToHpSm() {
    }

    @Around("actuallySendingMessageToHpSm()")
    public SmResponseStatus logHttpInteractionStatus(ProceedingJoinPoint proceedingJoinPoint) {
        try {
            SmMessage sendingSmMessage = popArgForJoinPoint(proceedingJoinPoint, 0, SmMessage.class);
            LOG.debug("Try to send message to HP SM:\n{}", sendingSmMessage);
            SmResponseStatus sendingResult = (SmResponseStatus) proceedingJoinPoint.proceed();
            LOG.debug("HP SM response: {}", sendingResult);
            return sendingResult;
        } catch (Throwable e) {
            return SmResponseStatus.SM_SERVICE_CONNECTIVITY_ERROR;
        }
    }

}
