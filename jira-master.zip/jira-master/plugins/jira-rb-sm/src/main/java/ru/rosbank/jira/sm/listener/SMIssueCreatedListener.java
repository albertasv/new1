package ru.rosbank.jira.sm.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.customfields.option.Option;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.SMEntityType;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;
import ru.rosbank.jira.sm.model.SmRBcriticalProblemModel;

import javax.inject.Inject;
import java.util.Set;
import java.util.TreeSet;

import static com.google.common.base.Preconditions.checkNotNull;
import static ru.rosbank.jira.sm.SMUtils.*;

@Component
public class SMIssueCreatedListener extends AbstractSMIssueListener implements InitializingBean, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(SMIssueCreatedListener.class);

    private final EventPublisher eventPublisher;
    private final JiraAuthenticationContext authenticationContext;
    private final CustomFieldManager customFieldManager;
    private final ConfigLoader config;

    private final SmService smService;

    @Inject
    public SMIssueCreatedListener(
            @ComponentImport EventPublisher eventPublisher,
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport CustomFieldManager customFieldManager,
            @ComponentImport ConfigLoader config, SmService smService) {
        super(customFieldManager, config);
        this.eventPublisher = eventPublisher;
        this.authenticationContext = checkNotNull(authenticationContext);
        this.smService = smService;
        ;
        this.customFieldManager = customFieldManager;
        this.config = config;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling listener {}", SMIssueCreatedListener.class);
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling listener {}", SMIssueCreatedListener.class);
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {

        Long eventTypeId = issueEvent.getEventTypeId();

        if (eventTypeId.equals(EventType.ISSUE_CREATED_ID) || eventTypeId.equals(EventType.ISSUE_UPDATED_ID)) {

            MutableIssue issue = (MutableIssue) issueEvent.getIssue();
            ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
            String projectKey = issue.getProjectObject().getKey();
            String smNumbers = getSyncSmNumber(issue);

            if (!Strings.isNullOrEmpty(smNumbers)) {
                // Create SM links
                LOG.debug("Issue {} created/updated. SM numbers are {}", issue.getKey(), smNumbers);
                Set<String> incidents = new TreeSet<>(getSMNumbers(smNumbers, SMEntityType.IM.name()));
                addSMLinks(issue, loggedInUser, incidents, SMEntityType.IM, config);
                Set<String> sds = new TreeSet<>(getSMNumbers(smNumbers, SMEntityType.SD.name()));
                addSMLinks(issue, loggedInUser, sds, SMEntityType.SD, config);
                Set<String> rfts = new TreeSet<>(getSMNumbers(smNumbers, SMEntityType.RFT.name()));
                addSMLinks(issue, loggedInUser, rfts, SMEntityType.RFT, config);
                LOG.debug("SM links was added.");
                // !Create SM links

                // PRB critical incident
                if (PROBLEM_PROJECT_KEY.equals(projectKey) && eventTypeId.equals(EventType.ISSUE_UPDATED_ID)) {
                    Option problemSource = (Option) issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getJiraProblemSourceFieldId()));
                    if (problemSource != null && problemSource.getValue() != null
                                && problemSource.getValue().contains("Инцидент\\сбой")) {
                        LOG.debug("Forming data for critical incident from {}", issue.getKey());

                        // From: LYUBANOV Dmitriy <Dmitriy.Lyubanov@rosbank.ru>
                        // SM: В параметр «dueDate» надо передавать дату такого формата «ГГГГ-ММ-ДДTЧЧ:ММ:СС»
                        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
                        SmRBcriticalProblemModel jsonData = new SmRBcriticalProblemModel();

                        jsonData.getData().setIssueId(issue.getId());
                        jsonData.getData().setIssueKey(issue.getKey());
                        jsonData.getData().setSummary(issue.getSummary());
                        jsonData.getData().setIssueStatus(issue.getStatus().getName());

                        //Ответственный за создание АР
                        ApplicationUser projectLead = issue.getProjectObject().getProjectLead();
                        if (projectLead != null) {
                            jsonData.getData().setAssignee(projectLead.getUsername());
                        }

                        ApplicationUser assignee = issue.getAssignee();
                        if (assignee != null) {
                            jsonData.getData().setEventAssignee(assignee.getUsername());
                        }

                        jsonData.getData().setActionPlan(getActionPlan(issue));
                        CustomField solutionCustomField = customFieldManager.getCustomFieldObject(config.getJiraSolutionFieldId());
                        jsonData.getData().setReport((String) issue.getCustomFieldValue(solutionCustomField));
                        jsonData.getData().setDueDate(issue.getDueDate());


                        Set<String> imNumbers = new TreeSet<>(getSMNumbers(smNumbers, SMEntityType.IM.name()));
                        for (String imNumber : imNumbers) {
                            jsonData.getData().setNumber(imNumber);
                            String json = gson.toJson(jsonData);
                            if (json != null) {
                                LOG.debug("Sending data for critical incident {} ", imNumber);
                                String smUrl = "/RBcriticalProblem/" + imNumber;

                                SmMessage smMessage = new SmMessageBuilder()
                                        .toEndpoint(smUrl)
                                        .withData(json)
                                        .linkedJiraIssue(issue)
                                        .usingMethod(SmActionMethod.PUT)
                                        .mustAddCommentInIssue(false)
                                        .commentId(0L)
                                        .taskAuthor(issueEvent.getUser().getUsername())
                                        .build();
                                smService.saveSmMessage(smMessage);
                            }
                        }
                    }
                }
                // !PRB critical incident
            }
        }
    }

    private String getActionPlan(Issue issue) {
        StringBuilder res = new StringBuilder();
        CustomField checklistsField = customFieldManager.getCustomFieldObject(config.getJiraChecklistsFieldId());
        Object checlists = issue.getCustomFieldValue(checklistsField);
        if (checlists != null) {
            res.append(checlists);
        }
        for (Issue subtask : issue.getSubTaskObjects()) {
            if (res.length() != 0) {
                res.append("\n");
            }
            res.append(subtask.getStatus().getName()).append(" ")
                    .append(subtask.getKey()).append(" ")
                    .append(subtask.getSummary());
        }
        return res.toString();
    }

}
