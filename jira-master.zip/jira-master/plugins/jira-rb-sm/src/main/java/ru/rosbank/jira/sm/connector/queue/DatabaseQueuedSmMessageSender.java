package ru.rosbank.jira.sm.connector.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.SMUtils;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.connection.HttpSmConnector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

@Component
public class DatabaseQueuedSmMessageSender {

    private static final Logger LOG = LoggerFactory.getLogger(DatabaseQueuedSmMessageSender.class);

    private final HttpSmConnector httpSmConnector;

    private final ReentrantLock lock = new ReentrantLock();

    private final SmService smService;

    public DatabaseQueuedSmMessageSender(HttpSmConnector httpSmConnector, SmService smService) {
        this.httpSmConnector = httpSmConnector;
        this.smService = smService;
    }

    public void sendSavedSmMessages() {
        Thread.currentThread().setName("DatabaseQueuedSmMessageSender");
        if (lock.isLocked()) {
            return;
        }
        lock.lock();
        try {
            List<SmMessageSendingTaskModel> sendingTasks = smService.getSavedSendingSmTasks();
            if (sendingTasks.size() == 0)
                return;
            Map<String, ArrayList<SmMessageSendingTaskModel>> sendingSmTasksSortedByIssueKey = sortSmSendingTasksByIssueKey(sendingTasks);
            sendSmMessagesFromSavedTasks(sendingSmTasksSortedByIssueKey);
        } catch (Exception e) {
            LOG.error("Some error with database connection occurred: ", e);
            throw new RuntimeException(e);
        } finally {
            lock.unlock();
        }
    }

    private void sendSmMessagesFromSavedTasks(Map<String, ArrayList<SmMessageSendingTaskModel>> sendingTasks) {
        for (String currentIssueKey: sendingTasks.keySet()) {
            sendSmMessagesFromSavedTasks(sendingTasks.get(currentIssueKey));
        }
    }

    private void sendSmMessagesFromSavedTasks(ArrayList<SmMessageSendingTaskModel> sendingTasks) {
        for (SmMessageSendingTaskModel sendingTask: sendingTasks) {
            SmResponseStatus smResponseStatus = httpSmConnector.sendMessage(sendingTask.getId(), sendingTask.getMessage());
            switch (smResponseStatus) {
                case SM_UNKNOWN_ERROR:
                case SM_SERVICE_CONNECTIVITY_ERROR:
                case SM_SERVICE_FAILURE:
                    LOG.error("Failed to send message: \n {} \n to SM.\n Response status is: {}", sendingTask, smResponseStatus);
                    break;
                default:
                    LOG.debug("Successfully sent to SM:\n{}", sendingTask);
                    smService.markAsSent(sendingTask);
                    long failedSyncCommentId = sendingTask.getFailedSyncCommentId();
                    if (failedSyncCommentId != 0) {
                        SMUtils.deleteFailedTaskSyncComment(sendingTask.getFailedSyncCommentId());
                    }
            }
        }
    }

    private Map<String, ArrayList<SmMessageSendingTaskModel>> sortSmSendingTasksByIssueKey(List<SmMessageSendingTaskModel> sendingTasks) {

        Map<String, ArrayList<SmMessageSendingTaskModel>> sortedTasks = new HashMap<>();

        String currentIssueKey;

        for (SmMessageSendingTaskModel sendingTask: sendingTasks) {
            currentIssueKey = sendingTask.getMessage().getLinkedJiraIssue().getKey();
            sortedTasks.computeIfAbsent(currentIssueKey, k -> new ArrayList<>()).add(sendingTask);
        }

        return sortedTasks;

    }
}
