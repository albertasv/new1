package ru.rosbank.jira.sm.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.api.SmService;
import javax.inject.Inject;
import static com.google.common.base.Preconditions.checkNotNull;

@Component
public class SMIssueCommentedListener implements InitializingBean, DisposableBean {

    private static final Logger LOG = LoggerFactory.getLogger(SMIssueCommentedListener.class);

    private final EventPublisher eventPublisher;
    private final SmService smService;
    private final ConfigLoader config;

    @Inject
    public SMIssueCommentedListener(
            @ComponentImport EventPublisher eventPublisher,
            @ComponentImport ConfigLoader config,
            SmService smService) {
        this.eventPublisher = checkNotNull(eventPublisher);
        this.config = checkNotNull(config);
        this.smService = smService;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling listener {}", SMIssueCommentedListener.class);
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling listener {}", SMIssueCommentedListener.class);
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {

        Long eventTypeId = issueEvent.getEventTypeId();

        if (eventTypeId.equals(EventType.ISSUE_COMMENTED_ID)) {

            MutableIssue issue = (MutableIssue) issueEvent.getIssue();
            String smNumbers = smService.getSmNumber(issue);
            boolean smIssueSource = smService.isSmIssueSource(issue);

            if (!Strings.isNullOrEmpty(smNumbers) && smIssueSource) {

                Comment comment = issueEvent.getComment();
                String body = comment.getBody();
                String smSyncMention = "[~" + config.getJiraSmUser() + "]";

                // Send to SM if smsync user mentioned
                if (body.contains(smSyncMention)) {
                    smService.addSmSyncComment(issueEvent.getUser(), issue, smNumbers, comment, issueEvent);
                }
            }
        }
    }
}
