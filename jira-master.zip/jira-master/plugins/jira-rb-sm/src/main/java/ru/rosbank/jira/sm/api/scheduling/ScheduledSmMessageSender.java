package ru.rosbank.jira.sm.api.scheduling;

import com.atlassian.beehive.ClusterLockService;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.scheduler.SchedulerService;
import com.atlassian.scheduler.SchedulerServiceException;
import com.atlassian.scheduler.config.JobConfig;
import com.atlassian.scheduler.config.JobRunnerKey;
import com.atlassian.scheduler.config.RunMode;
import com.atlassian.scheduler.config.Schedule;
import com.atlassian.scheduler.status.JobDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.RbCommonScheduledService;

import javax.annotation.PreDestroy;
import javax.inject.Named;
import java.util.List;
import java.util.concurrent.locks.Lock;

@ExportAsService
@Named("scheduledSmMessageSender")
public class ScheduledSmMessageSender implements RbCommonScheduledService, LifecycleAware {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledSmMessageSender.class);

    private final JobRunnerKey jobRunnerKey = JobRunnerKey.of(ScheduledSmMessageSender.class.getName());

    private final SchedulerService schedulerService;

    private final ScheduledSmMessageSenderJobRunner jobRunner;

    private static final String LOCK_NAME = ScheduledSmMessageSender.class.getName() + ".lockedTask";

    private final ClusterLockService clusterLockService;

    public ScheduledSmMessageSender(
            @ComponentImport SchedulerService schedulerService,
            @ComponentImport ClusterLockService clusterLockService,
            ScheduledSmMessageSenderJobRunner jobRunner) {
        this.jobRunner = jobRunner;
        this.schedulerService = schedulerService;
        this.clusterLockService = clusterLockService;
    }


    @Override
    public void onStart() {
        reschedule();
    }

    @Override
    public void reschedule() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            LOG.info("Register SM message scheduled sender");
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }
            schedulerService.registerJobRunner(jobRunnerKey, jobRunner);
            JobConfig smMessageMessageSenderJobConfigEveryDay = JobConfig.forJobRunnerKey(jobRunnerKey)
                    .withRunMode(RunMode.RUN_ONCE_PER_CLUSTER)
                    .withSchedule(Schedule.forInterval(180000, null));

            try {
                schedulerService.scheduleJobWithGeneratedId(smMessageMessageSenderJobConfigEveryDay);
            } catch (SchedulerServiceException smex) {
                LOG.error("Unable to create SM message sending scheduled task", smex);
            }
        } finally {
            lock.unlock();
        }
    }

    @PreDestroy
    public void onStop() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }
        } finally {
            lock.unlock();
        }
    }
}
