package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.tx.Transactional;

@Transactional
public interface SmMessageQueueCleanerService {
    void cleanSmMessageQueue();
}
