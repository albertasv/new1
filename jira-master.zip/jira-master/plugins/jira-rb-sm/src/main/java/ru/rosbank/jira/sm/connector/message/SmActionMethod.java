package ru.rosbank.jira.sm.connector.message;

public enum SmActionMethod {
    POST,
    PUT
}
