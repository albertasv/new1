package ru.rosbank.jira.sm.connector;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.mail.Email;
import com.atlassian.mail.MailException;
import com.atlassian.mail.server.SMTPMailServer;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;

import javax.inject.Inject;

/**
 * Класс, который отправляет сообщения администраторам Jira о том, что задача не синхронизировалась с нарядом/инцидентом в SM в течение
 * определённого времени
 */

@Component
public class JiraAdminsNotificator {

    private final SMTPMailServer mailServer;

    private static final Logger LOG = LoggerFactory.getLogger(JiraAdminsNotificator.class);

    private final ConfigLoader configLoader;

    @Inject
    public JiraAdminsNotificator(@ComponentImport ConfigLoader configLoader) {
        this.mailServer = ComponentAccessor.getMailServerManager().getDefaultSMTPMailServer();
        this.configLoader = configLoader;
    }

    public boolean notifyAboutSmSyncFailureByEmail(SmMessageSendingTaskEntity sendingTaskEntity, String smResponse) {
        //CERT и TEST не имеют интеграции с почтовым сервером
        String jiraEnvironment = configLoader.getJiraEnvironment();
        if (jiraEnvironment.equals("CERT") || jiraEnvironment.equals("TEST")) {
            return true;
        }

        Issue issue = ComponentAccessor.getIssueManager().getIssueObject(sendingTaskEntity.getLinkedIssueKey());
        if (issue != null) {
            ApplicationUser jiraAdmin = ComponentAccessor.getUserManager().getUserByName("ppmsync");
            Email email = new Email(jiraAdmin.getEmailAddress());
            email.setMimeType("text/plain");

            Comment comment = null;
            if (sendingTaskEntity.getCommentId() != null) {
                comment = ComponentAccessor.getCommentManager().getCommentById(sendingTaskEntity.getCommentId());
            }
            if (!Strings.isNullOrEmpty(smResponse) && comment == null) {

                email.setSubject("Сбой синхронизации задачи " + issue.getKey() + " с HPSM");
                email.setBody("Изменение задачи: " + issue.getKey() + " не синхронизировано с HPSM. \n" +
                        "Ответ от HPSM: " + smResponse + "\nОбратитесь к администраторам Jira.");

            } else if (!Strings.isNullOrEmpty(smResponse) && comment != null) {

                email.setSubject("Сбой синхронизации комментария в задаче " + issue.getKey() + " с HPSM");
                email.setBody("Комментарий " + comment.getBody() + " не синхронизирован с HPSM.\n" +
                        "Ответ от HPSM: " + smResponse + "\nОбратитесь к администраторам Jira.");

            } else if (Strings.isNullOrEmpty(smResponse) && comment == null) {

                email.setSubject("Сбой синхронизации задачи " + issue.getKey() + " с HPSM");
                email.setBody("Изменение задачи: " + issue.getKey() + " не синхронизировано с HPSM. \n" +
                        "по неустановленной причине. Обратитесь к администраторам Jira");

            } else if (Strings.isNullOrEmpty(smResponse) && comment != null) {

                email.setSubject("Сбой синхронизации комментария в задаче " + issue.getKey() + " с HPSM");
                email.setBody("Комментарий " + comment.getBody() + " не синхронизирован с HPSM по неустановленной причине. " +
                        "Обратитесь к администраторам Jira.");
            }

            try {
                mailServer.send(email);
            } catch (MailException mex) {
                LOG.error("Some error with assignee notification: " + mex);
                return false;
            }
        }
        return true;
    }
}
