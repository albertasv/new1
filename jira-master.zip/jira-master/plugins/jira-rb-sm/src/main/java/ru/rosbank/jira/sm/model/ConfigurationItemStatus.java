package ru.rosbank.jira.sm.model;

import org.codehaus.jackson.annotate.JsonValue;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(using = ConfigurationItemStatusSerializer.class)
public enum ConfigurationItemStatus {
    //05	Исследование
    DISCOVERY(5, "Discovery"),
    //10	Новый/В разработке
    NEW(10, "New"),
    //30	Опытная эксплуатация
    TRIAL_OPERATION(30, "Trial Operation"),
    //40	В эксплуатации
    IN_OPERATION(40, "In Operation"),
    //80	Снят с эксплуатации
    OUT_OF_SERVICE(80, "Out of Service"),
    //90	В архивном режиме
    ARCHIVE(90, "Archive"),
    //91	Декомиссия
    DECOMMISSION(91, "Decommission");

    private int code;
    private String name;

    @JsonValue
    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    ConfigurationItemStatus(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ConfigurationItemStatus getStatus(String code) {
        try {
            int iCode = Integer.parseInt(code);
            for (ConfigurationItemStatus ciStatus : ConfigurationItemStatus.values()) {
                if (ciStatus.getCode() == iCode) {
                    return ciStatus;
                }
            }
        } catch (Exception ex) {
        }
        return null;
    }
}
