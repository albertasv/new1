package ru.rosbank.jira.sm.listener;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.user.ApplicationUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;

import java.util.UUID;


public abstract class AbstractSMIssueListener {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractSMIssueListener.class);

    private final CustomFieldManager customFieldManager;
    private final ConfigLoader config;

    protected AbstractSMIssueListener(CustomFieldManager customFieldManager, ConfigLoader config) {
        this.customFieldManager = customFieldManager;
        this.config = config;
    }

    /**
     * @param issue
     * @return smNumber field ("Номер инцидента в SM") value if "Issue Source" field is equals to 'SM'
     */
    protected String getSyncSmNumber(Issue issue) {
        try {
            CustomField smNumberField = customFieldManager.getCustomFieldObject(config.getJiraSmNumberFieldId());
            return (String) issue.getCustomFieldValue(smNumberField);
        } catch (NullPointerException ex) {
            return "";
        }
    }

    private void createIssueComment(Issue issue, ApplicationUser syncUser, String message) {
        ComponentAccessor.getCommentManager().create(issue, syncUser, message, true);
    }

    private boolean errorCode(int responseCode) {
        return responseCode >= 300 || responseCode == 70;
    }

    private void handleErrorCode(int responseCode, String msg, boolean addComment, Issue issue, ApplicationUser syncUser) {
        String uuid = UUID.randomUUID().toString();
        if (addComment || forceComment(responseCode)) {
            String message = errorMessage(responseCode, uuid);
            createIssueComment(issue, syncUser, message);
        }
        LOG.error("{} - {}", uuid, msg);
    }

    private boolean forceComment(int responseCode) {
        return responseCode == 500 || responseCode == 70;
    }

    private String errorMessage(int responseCode, String uuid) {
        if (responseCode == 70) {
            return "Попытка выполнить инцидент, который выполнен ранее или закрыт. Return Code: " +
                    responseCode + ".";
        }
        if (responseCode == 500) {
            return "Во время отправки решения в SM произошла ошибка. HTTP Code: " + responseCode +
                    ".\n Обратитесь к администраторам " + uuid;
        }
        return "Код ошибки не распознан обработчиком. Обратитесь к администраторам. HTTP Code: " +
                responseCode + uuid;
    }

}
