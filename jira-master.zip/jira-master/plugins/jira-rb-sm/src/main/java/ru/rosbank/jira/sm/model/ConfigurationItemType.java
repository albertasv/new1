package ru.rosbank.jira.sm.model;

public enum ConfigurationItemType {
    SYSTEM("system"), SERVICE("service");

    private String type;

    ConfigurationItemType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static ConfigurationItemType getType(String type) {
        for (ConfigurationItemType value : ConfigurationItemType.values()) {
            if (value.getType().equalsIgnoreCase(type)) {
                return value;
            }
        }
        return null;
    }
}
