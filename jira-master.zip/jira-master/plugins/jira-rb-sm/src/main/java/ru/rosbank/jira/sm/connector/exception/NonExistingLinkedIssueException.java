package ru.rosbank.jira.sm.connector.exception;

/**
 * Ошибка генерируется в том случае, когда в базе данных сохранена задача отправки информации в HP SM, связанная с
 * несуществующей задачей Jira.
 */
public class NonExistingLinkedIssueException extends SmSendingTaskRestorationException {

    private final String savedIssueKey;

    public NonExistingLinkedIssueException(String savedIssueKey) {
        this.savedIssueKey = savedIssueKey;
    }

    public String getSavedIssueKey() {
        return savedIssueKey;
    }

    @Override
    public String getMessage() {
        return "Message to HP SM saved for nonexistent issue with key " + savedIssueKey;
    }

}
