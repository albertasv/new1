package ru.rosbank.jira.sm.connector.message;

import com.atlassian.jira.issue.Issue;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import org.springframework.stereotype.Service;

@Service
@ExportAsService
public class SmMessageBuilder {

    private String targetEndpoint;
    private String jsonData;
    private SmActionMethod actionMethod;
    private Issue linkedJiraIssue;
    private boolean mustAddCommentInIssue;
    private Long commentId;
    private String taskAuthor;

    public SmMessageBuilder toEndpoint(String targetEndpoint) {
        this.targetEndpoint = targetEndpoint;
        return this;
    }

    public SmMessageBuilder withData(String jsonData) {
        this.jsonData = jsonData;
        return this;
    }

    public SmMessageBuilder usingMethod(SmActionMethod actionMethod) {
        this.actionMethod = actionMethod;
        return this;
    }

    public SmMessageBuilder linkedJiraIssue(Issue linkedJiraIssue) {
        this.linkedJiraIssue = linkedJiraIssue;
        return this;
    }

    public SmMessageBuilder mustAddCommentInIssue(boolean mustAddCommentInIssue) {
        this.mustAddCommentInIssue = mustAddCommentInIssue;
        return this;
    }

    public SmMessageBuilder commentId(Long commentId) {
        this.commentId = commentId;
        return this;
    }
    public SmMessageBuilder taskAuthor(String taskAuthor) {
        this.taskAuthor = taskAuthor;
        return this;
    }

    public SmMessage build() {
        return new SmMessage(targetEndpoint, jsonData, actionMethod, linkedJiraIssue, mustAddCommentInIssue, commentId, taskAuthor);
    }

}
