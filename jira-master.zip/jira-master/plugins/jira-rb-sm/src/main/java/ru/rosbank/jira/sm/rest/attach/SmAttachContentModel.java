package ru.rosbank.jira.sm.rest.attach;

public class SmAttachContentModel {

    private SmAttachModel attachment;

    public SmAttachModel getAttachment() {
        return attachment;
    }

    public void setAttachment(SmAttachModel attachment) {
        this.attachment = attachment;
    }
}
