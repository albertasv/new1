package ru.rosbank.jira.sm.rest;

import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService;
import com.atlassian.jira.bc.project.ProjectService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.ConstantsManager;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventDispatchOption;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.exception.CreateException;
import com.atlassian.jira.exception.DataAccessException;
import com.atlassian.jira.issue.*;
import com.atlassian.jira.issue.attachment.CreateAttachmentParamsBean;
import com.atlassian.jira.issue.customfields.manager.OptionsManager;
import com.atlassian.jira.issue.customfields.option.Option;
import com.atlassian.jira.issue.customfields.option.Options;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.config.FieldConfig;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.issue.label.LabelManager;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.link.IssueLinkTypeManager;
import com.atlassian.jira.issue.link.RemoteIssueLink;
import com.atlassian.jira.issue.link.RemoteIssueLinkBuilder;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.ErrorCollection;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.IOUtils;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.sm.Priority;
import ru.rosbank.jira.sm.SMEntityType;
import ru.rosbank.jira.sm.connector.logging.SmMessagesLogging;
import ru.rosbank.jira.sm.model.SmCreateIssueResultModel;
import ru.rosbank.jira.sm.model.SmIssueModel;
import ru.rosbank.jira.sm.rest.attach.SmAttachContentModel;
import ru.rosbank.jira.sm.rest.attach.SmAttachMetaModel;
import ru.rosbank.jira.sm.rest.attach.SmAttachModel;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Основной REST API класс для использования системой SM в рамках синхронизации с инцидентами и нарядами в SM.
 * При назначении инцидента/наряда на определённую рабочую группу в SM, SM передаёт через данный API информацию для заведения
 * связанной задачи в JIRA.
 */
@Path("/issue")
public class SmIssueRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(SmIssueRestResource.class);

    private final JiraAuthenticationContext authenticationContext;

    private final IssueService issueService;

    private final ProjectService projectService;

    private final ConstantsManager constantsManager;

    private final EventPublisher eventPublisher;

    private final ConfigLoader config;

    private final IssueManager issueManager;

    private final CustomFieldManager customFieldManager;

    private final SmMessagesLogging smMessagesLogging;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    private final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

    public SmIssueRestResource(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport IssueService issueService,
            @ComponentImport ProjectService projectService,
            @ComponentImport ConstantsManager constantsManager,
            @ComponentImport EventPublisher eventPublisher,
            @ComponentImport ConfigLoader config,
            @ComponentImport CustomFieldManager customFieldManager,
            SmMessagesLogging smMessagesLogging) {
        this.authenticationContext = authenticationContext;
        this.issueService = issueService;
        this.projectService = projectService;
        this.constantsManager = constantsManager;
        this.eventPublisher = eventPublisher;
        this.config = config;
        this.issueManager = ComponentAccessor.getIssueManager();
        this.customFieldManager = customFieldManager;
        this.smMessagesLogging = smMessagesLogging;
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/create")
    public Response createIssue(SmIssueModel createIssue) {
        smMessagesLogging.logSmToJiraMessage("New issue from SM: ", createIssue.toString());
        ApplicationUser user = authenticationContext.getLoggedInUser();
        SmCreateIssueResultModel result = new SmCreateIssueResultModel();

        // For SM parameters
        // String smType = updateIssue.getSmType();
        String smNumber = createIssue.getSmNumber();

        // Check required fields
        String projectKey = createIssue.getProject();
        Project project = projectService.getProjectByKey(user, projectKey).getProject();
        if (project == null) {
            return error(400, "There is no project with key " + projectKey);
        }

        String issueTypeName = createIssue.getIssueType();
        IssueType issueType = constantsManager.getAllIssueTypeObjects().stream()
                .filter(it -> it.getName().equalsIgnoreCase(issueTypeName))
                .findFirst().orElse(null);

        if (issueType == null) {
            return error(400, "There is no issue type with name " + issueTypeName);
        }


        List<Issue> duplicatesInOneProject = getDuplicatesInOneProject(project.getId(), issueType.getId(), smNumber);
        List<Issue> openedDuplicates = duplicatesInOneProject.stream().filter(issue -> issue.getResolution() == null).collect(Collectors.toList());
        List<Issue> allDuplicates = new ArrayList<>(getDuplicatesInDiffProjects(project.getId(), smNumber));
        allDuplicates.addAll(duplicatesInOneProject);
        // JIRA-2967 If there is open duplicate return it
        if (!openedDuplicates.isEmpty()) {
            result.setIssueId(openedDuplicates.get(0).getId());
            result.setIssueKey(openedDuplicates.get(0).getKey());
            return Response.ok(result).build();
        }

        String summary = duplicatesInOneProject.isEmpty() ? createIssue.getSummary() : ("(Повтор) " + createIssue.getSummary());

        if (Strings.isNullOrEmpty(summary)) {
            return error(400, "Summary field is required");
        } else if (Arrays.asList("RR", "GLQ").contains(projectKey)) {
            // JIRA-45 Add SM number for RR and GLQ projects
            summary = smNumber + " - " + summary;
        }

        String reporter = createIssue.getReporter();
        if (Strings.isNullOrEmpty(reporter)) {
            return error(400, "Reporter field is required");
        }

        //! Check required fields

        IssueInputParameters issueInputParameters = issueService.newIssueInputParameters()
                .setProjectId(project.getId()).setIssueTypeId(issueType.getId())
                .setSummary(summary)
                .setReporterId(reporter);
        issueInputParameters.setSkipScreenCheck(true);

        // JIRA-1885 Environment Found is required for Bug
        if ("Bug".equalsIgnoreCase(issueType.getName())) {
            Long environmentFoundFieldId = config.getEnvironmentFoundFieldId();
            if (environmentFoundFieldId != null) {
                issueInputParameters = issueInputParameters.addCustomFieldValue(environmentFoundFieldId,
                        config.getEnvironmentFoundProdOptionId());
            }
        }

        // JIRA-5322 SPTtype field is required
        if("SPT".equalsIgnoreCase(projectKey)) {
            Long sptTypeFieldId = config.getSptTypeFieldId();
            if (sptTypeFieldId != null) {
                issueInputParameters = issueInputParameters.addCustomFieldValue(sptTypeFieldId,
                        config.getSptTypeProdOptionId());
            }
        }

        // !JIRA-1885 Environment Found is required

        String description = createIssue.getDescription();
        // JIRA-3059 Trim with limit of description length
        description = description.substring(0, Math.min(description.length(), 32767));
        // JIRA-3854 выделить жирным и красным шрифтом слово VIP
        if (description.contains("VIP")) {
            description = description.replace("VIP", "{color:#FF0000}*VIP*{color}");
        }
        issueInputParameters.setDescription(description);

        String assignee = createIssue.getAssignee();
        issueInputParameters.setAssigneeId(assignee);


        // Set priority
        String priority = createIssue.getPriority();
        if (!Strings.isNullOrEmpty(priority)) {
            Priority smPriority = Priority.getBySmId(priority);
            issueInputParameters.setPriorityId(smPriority == null ? Priority.LOW.getJiraId() : smPriority.getJiraId());
        }

        // Set Deadline
        Date deadline = createIssue.getDeadline();
        if (deadline != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(deadline);
            calendar.add(Calendar.HOUR, -3);
            deadline = calendar.getTime();
            issueInputParameters.setDueDate(dateFormat.format(deadline));
            // JIRA-2086 Крайний срок в SM
            Long smDeadlineFieldId = config.getJiraSmDeadlineFieldId();
            if (smDeadlineFieldId != null) {
                issueInputParameters = issueInputParameters.addCustomFieldValue(smDeadlineFieldId, dateTimeFormat.format(deadline));
            }
        }

        // Set Impact / Ценность
        String impact = createIssue.getImpact();
        if (!Strings.isNullOrEmpty(impact)) {
            String impactString = getSmImpact(impact);
            Long impactFieldId = config.getJiraImpactFieldId();
            if (impactString != null && impactFieldId != null) {
                issueInputParameters = issueInputParameters.addCustomFieldValue(impactFieldId, impactString);
            }
        }

        // Номер в SM
        Long smNumberFieldId = config.getJiraSmNumberFieldId();
        if (!Strings.isNullOrEmpty(smNumber) && smNumberFieldId != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(smNumberFieldId, smNumber);
        }

        // IT System
        String itSystemCode = createIssue.getItSystem();
        Long jiraItSystemFieldId = config.getJiraItSystemFieldId();
        if (!Strings.isNullOrEmpty(itSystemCode) && jiraItSystemFieldId != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(jiraItSystemFieldId,
                    itSystemCode);
        }

        // IT Service
        Long jiraServiceFieldId = config.getJiraServiceFieldId();
        String serviceCode = createIssue.getService();
        if (!Strings.isNullOrEmpty(serviceCode) && jiraServiceFieldId != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(jiraServiceFieldId,
                    serviceCode);
        }

        // Execution Group
        Long groupFieldId = config.getJiraGroupFieldId();
        String group = createIssue.getSmGroup();
        if (!Strings.isNullOrEmpty(group) && groupFieldId != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(groupFieldId,
                    group);
        }

        // Issue Source
        Long jiraIssueSourceFieldId = config.getJiraIssueSourceFieldId();
        if (jiraIssueSourceFieldId != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(jiraIssueSourceFieldId, "SM");
        }

        // Рейтинг Richelieu. JIRA-2192
        Integer ratingRichelieu = createIssue.getRatingRichelieu();
        if (ratingRichelieu != null) {
            Long ordinalPriorityFieldId = config.getJiraOrdinalPriorityFieldId();
            issueInputParameters = issueInputParameters.addCustomFieldValue(ordinalPriorityFieldId,
                    String.valueOf(ratingRichelieu));
        }

        // Кол-во привязанных SD
        Long amountLinkedSdFieldId = config.getJiraSmAmountLinkedSdFieldId();
        Integer amountLinkedSd = createIssue.getAmountLinkedSd();
        if (amountLinkedSdFieldId != null && amountLinkedSd != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(amountLinkedSdFieldId, String.valueOf(amountLinkedSd));
        }

        String themes = createIssue.getThemes();
        if (themes != null) {
            Long themesFieldId = config.getJiraThemesFieldId();
            issueInputParameters = issueInputParameters.addCustomFieldValue(themesFieldId, themes);
        }

        // Start Date. JIRA-2266
        Long startDateFieldId = config.getStartDateFieldId();
        Date startDate = createIssue.getStartDate();
        if (startDateFieldId != null && startDate != null) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(startDateFieldId, dateFormat.format(startDate));
        }

        // Problem Source as constant. JIRA-2266
        Long problemSourceFieldId = config.getJiraProblemSourceFieldId();
        Long problemSourceFieldDefaultOptionId = config.getJiraProblemSourceFieldDefaultOptionId();
        if (problemSourceFieldId != null && problemSourceFieldDefaultOptionId != null
                && projectKey.equals(config.getJiraProblemProject()) && createIssue.getIssueType().equals("Problem")) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(problemSourceFieldId,
                    String.valueOf(problemSourceFieldDefaultOptionId));
        }

        // Тестовое окружение. JIRA-7912
        Long testEnvironmentFieldId = config.getTestEnvironmentFieldId();
        String testEnvironmentFieldValue = createIssue.getTestEnvironment();
        if (!Strings.isNullOrEmpty(testEnvironmentFieldValue)) {
            issueInputParameters = issueInputParameters.addCustomFieldValue(testEnvironmentFieldId, testEnvironmentFieldValue);
        }

        IssueService.CreateValidationResult validationResult = issueService.validateCreate(user, issueInputParameters);
        ErrorCollection errorCollection = validationResult.getErrorCollection();
        ApplicationUser smSyncUser = ComponentAccessor.getUserManager().getUserByName("SMSync");
        // Check reporter
        String reporterError = null;
        if (errorCollection.getErrors().containsKey("reporter")) {
            reporterError = errorCollection.getErrors().get("reporter");
            issueInputParameters = issueInputParameters.setReporterId(smSyncUser.getUsername());
            validationResult = issueService.validateCreate(user, issueInputParameters);
            errorCollection = validationResult.getErrorCollection();
        }
        // Check assignee
        String assigneeError = null;
        if (errorCollection.getErrors().containsKey("assignee")) {
            assigneeError = errorCollection.getErrors().get("assignee");

            issueInputParameters = issueInputParameters.setAssigneeId(smSyncUser.getUsername());
            validationResult = issueService.validateCreate(user, issueInputParameters);
            errorCollection = validationResult.getErrorCollection();
        }

        IssueService.IssueResult issueResult;
        if (errorCollection.hasAnyErrors()) {
            String errors = errorCollection.getErrors()
                    .entrySet()
                    .stream()
                    .map(e -> e.getKey() + " -> " + e.getValue())
                    .collect(Collectors.joining(" | "));
            LOG.debug("Errors 1: {}", errors);
            return error(500, "Errors 1: " + errors);
        } else {
            issueResult = issueService.create(user, validationResult);
        }

        if (issueResult.getErrorCollection().hasAnyErrors()) {
            String errors = issueResult.getErrorCollection().getErrors()
                    .entrySet()
                    .stream()
                    .map(e -> e.getKey() + " -> " + e.getValue())
                    .collect(Collectors.joining(" | "));
            LOG.debug("Errors 2: {}", errors);
            return error(500, "Errors 2: " + errors);
        }

        MutableIssue issue = issueResult.getIssue();

        // Environment found. JIRA-7490
        String environmentFoundFieldNewValue = createIssue.getEnvironment();
        Long environmentFoundFieldId = config.getEnvironmentFoundFieldId();
        singleChoiceSelectListUpdate(environmentFoundFieldNewValue, environmentFoundFieldId, issue, smSyncUser);


        // Activity type. JIRA-7490
        String activityTypeFieldNewValue = createIssue.getActivityType();
        Long activityTypeFieldId = config.getActivityTypeFieldId();
        singleChoiceSelectListUpdate(activityTypeFieldNewValue, activityTypeFieldId, issue, smSyncUser);


        if (issue != null) {
            // Reporter error
            if (!Strings.isNullOrEmpty(reporterError)) {
                ComponentAccessor.getCommentManager().create(issue, user,
                        reporter + " reporter error: " + reporterError + "\n" +
                                "Changed to SMSync service user.", true);
            }
            // Assignee error
            if (!Strings.isNullOrEmpty(assigneeError)) {
                ComponentAccessor.getCommentManager().create(issue, user,
                        assignee + " assignee error: " + assigneeError + "\n" +
                                "Changed to SMSync service user.", true);
            }

            // Дополнительная информация
            String extraInfo = createIssue.getExtraInfo();
            if (!Strings.isNullOrEmpty(extraInfo)) {
                ComponentAccessor.getCommentManager().create(issue, user,
                        "Дополнительная информация:\n" +
                                extraInfo, false);
                // Add Hashtags
                Set<String> tags = getTags(extraInfo);
                if (!tags.isEmpty()) {
                    LabelManager labelManager = ComponentAccessor.getComponent(LabelManager.class);
                    labelManager.setLabels(user, issue.getId(), tags, false, false);
                }
            }

            // Process attachments
            // JIRA-3649 - Наряд не имеет вложений в SM, вложения необходимо будет скачивать по номеру SD

            // Номер SD (если Issue связана с нарядом, то в Jira приходит и номер SD для скачивания вложений. JIRA-3637)
            String numberSD = createIssue.getNumberSD();
            LOG.debug("SD number is:  {}", numberSD);
            if (numberSD != null) {
                addAttachments(smNumber, numberSD, issue, user);
            } else {
                addAttachments(smNumber, "", issue, user);
            }

            // Комментарий из предыдущей отменённой задачи. JIRA-6318
            String commentFromPreviousIssue = createIssue.getCommentFromPreviousIssue();
            if (!Strings.isNullOrEmpty(commentFromPreviousIssue)) {
                ComponentAccessor.getCommentManager().create(issue, user, "*Причина переназначения (решение из предыдущей задачи):* "
                        + commentFromPreviousIssue, false);
            }

            // JIRA-3038 Поле "ссылка на Ришелье" доработка интеграции HPSM->JIRA - добавляются любые ссылки
            addExternalLinks(issue, user, createIssue.getLinks());

            // JIRA-2116
            // Обеспечить преемственность, прозрачность и полноту информации для 3Л в случае повторной передачи инцидента на 3Л после успешного закрытия бага
            if (!allDuplicates.isEmpty()) {
                IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
                Long splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(config.getRelatesIssueLinkType()).getId();
                for (Issue duplicate : allDuplicates) {
                    try {
                        issueLinkManager.createIssueLink(
                                issue.getId(),
                                duplicate.getId(),
                                splitLinkType,
                                0l,
                                user
                        );
                    } catch (CreateException cex) {
                        LOG.error("Issue link error - {}", cex, cex);
                    }
                }
            }

            // Set response result
            result.setIssueId(issue.getId());
            result.setIssueKey(issue.getKey());
        }
        return Response.ok(result).build();
    }

    private void singleChoiceSelectListUpdate(String fieldNewValue,
                                              Long fieldId,
                                              MutableIssue issue,
                                              ApplicationUser smSyncUser) {
        List<Option> foundOptions = new ArrayList<>();
        CustomField customField = customFieldManager.getCustomFieldObject(fieldId);
        FieldConfig fieldConfig  = Objects.requireNonNull(customField).getRelevantConfig(issue);
        OptionsManager optionsManager = ComponentAccessor.getOptionsManager();
        Options options = optionsManager.getOptions(fieldConfig);

        if (options == null)
            return;

        if (options.isEmpty()) {
           List<Option> rootOptions = options.getRootOptions();
            if (!rootOptions.isEmpty()) {
                foundOptions = options.getRootOptions()
                        .stream()
                        .filter(option -> option.getValue().equals(fieldNewValue))
                        .collect(Collectors.toList());
            }
        } else {
            foundOptions = options
                    .stream()
                    .filter(option -> option.getValue().equals(fieldNewValue))
                    .collect(Collectors.toList());        }

        if (!foundOptions.isEmpty()) {
            issue.setCustomFieldValue(customField, foundOptions.get(0));
            issueManager.updateIssue(smSyncUser, issue, EventDispatchOption.ISSUE_UPDATED, false);
        }
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/update/{issueKey}")
    public Response updateIssue(@PathParam("issueKey") String issueKey,
                                SmIssueModel updateIssue) {
        smMessagesLogging.logSmToJiraMessage("Updating issue from SM: ", updateIssue.toString());
        if (!Strings.isNullOrEmpty(issueKey)) {
            MutableIssue issue = issueManager.getIssueByKeyIgnoreCase(issueKey);
            if (issue != null) {

                LOG.debug("Update issue from SM: {}", updateIssue.getSmNumber());
                ApplicationUser user = authenticationContext.getLoggedInUser();


                boolean hasChanges = false;
                IssueInputParameters issueInputParameters = issueService.newIssueInputParameters();
                issueInputParameters.setSkipScreenCheck(true);

                // Set priority
                String priority = updateIssue.getPriority();
                if (!Strings.isNullOrEmpty(priority)) {
                    Priority smPriority = Priority.getBySmId(priority);
                    if (smPriority != null) {
                        issueInputParameters.setPriorityId(smPriority.getJiraId());
                        hasChanges = true;
                    }
                }

                // Set Deadline
                // JIRA-2086 Крайний срок в SM
                Date deadline = updateIssue.getDeadline();
                if (deadline != null) {
                    // JIRA-2086 Крайний срок в SM
                    Long smDeadlineFieldId = config.getJiraSmDeadlineFieldId();
                    if (smDeadlineFieldId != null) {
                        issueInputParameters = issueInputParameters.addCustomFieldValue(smDeadlineFieldId, dateTimeFormat.format(deadline));
                    }
                    hasChanges = true;
                }

                // Set Impact / Ценность
                String impact = updateIssue.getImpact();
                if (!Strings.isNullOrEmpty(impact)) {
                    String impactString = getSmImpact(impact);
                    Long impactFieldId = config.getJiraImpactFieldId();
                    if (impactString != null && impactFieldId != null) {
                        issueInputParameters = issueInputParameters.addCustomFieldValue(impactFieldId, impactString);
                        hasChanges = true;
                    }
                }

                // IT System
                String itSystemCode = updateIssue.getItSystem();
                Long jiraItSystemFieldId = config.getJiraItSystemFieldId();
                if (!Strings.isNullOrEmpty(itSystemCode) && jiraItSystemFieldId != null) {
                    issueInputParameters = issueInputParameters.addCustomFieldValue(jiraItSystemFieldId,
                            itSystemCode);
                    hasChanges = true;
                }

                // IT Service
                Long jiraServiceFieldId = config.getJiraServiceFieldId();
                String serviceCode = updateIssue.getService();
                if (!Strings.isNullOrEmpty(serviceCode) && jiraServiceFieldId != null) {
                    issueInputParameters = issueInputParameters.addCustomFieldValue(jiraServiceFieldId,
                            serviceCode);
                    hasChanges = true;
                }

                // Execution Group
                Long groupFieldId = config.getJiraGroupFieldId();
                String group = updateIssue.getSmGroup();
                if (!Strings.isNullOrEmpty(group) && groupFieldId != null) {
                    issueInputParameters = issueInputParameters.addCustomFieldValue(groupFieldId,
                            group);
                    hasChanges = true;
                }

                // Рейтинг Richelieu. JIRA-2192
                Integer ratingRichelieu = updateIssue.getRatingRichelieu();
                if (ratingRichelieu != null) {
                    Long ordinalPriorityFieldId = config.getJiraOrdinalPriorityFieldId();
                    issueInputParameters = issueInputParameters.addCustomFieldValue(ordinalPriorityFieldId,
                            String.valueOf(ratingRichelieu));
                    hasChanges = true;
                }

                // Кол-во привязанных SD
                Integer amountLinkedSd = updateIssue.getAmountLinkedSd();
                if (amountLinkedSd != null) {
                    Long amountLinkedSdFieldId = config.getJiraSmAmountLinkedSdFieldId();
                    issueInputParameters = issueInputParameters.addCustomFieldValue(amountLinkedSdFieldId, String.valueOf(amountLinkedSd));
                    hasChanges = true;
                }

                String themes = updateIssue.getThemes();
                if (themes != null) {
                    Long themesFieldId = config.getJiraThemesFieldId();
                    issueInputParameters = issueInputParameters.addCustomFieldValue(themesFieldId, themes);
                    hasChanges = true;
                }

                // Start Date. JIRA-2266
                Long startDateFieldId = config.getStartDateFieldId();
                Date startDate = updateIssue.getStartDate();
                if (startDateFieldId != null && startDate != null) {
                    issueInputParameters = issueInputParameters.addCustomFieldValue(startDateFieldId, dateFormat.format(startDate));
                    hasChanges = true;
                }

                SmCreateIssueResultModel result = new SmCreateIssueResultModel();
                result.setIssueId(issue.getId());
                result.setIssueKey(issue.getKey());

                if (hasChanges) {
                    IssueService.UpdateValidationResult validationResult = issueService.validateUpdate(user, issue.getId(), issueInputParameters);

                    ErrorCollection errorCollection = validationResult.getErrorCollection();
                    IssueService.IssueResult issueResult;
                    if (errorCollection.hasAnyErrors()) {
                        String errors = errorCollection.getErrors()
                                .entrySet()
                                .stream()
                                .map(e -> e.getKey() + " -> " + e.getValue())
                                .collect(Collectors.joining(" | "));
                        return error(500, "Validation update errors: " + errors);
                    } else {
                        issueResult = issueService.update(user, validationResult);
                        ErrorCollection updateErrorCollection = issueResult.getErrorCollection();
                        if (updateErrorCollection.hasAnyErrors()) {
                            String errors = errorCollection.getErrors()
                                    .entrySet()
                                    .stream()
                                    .map(e -> e.getKey() + " -> " + e.getValue())
                                    .collect(Collectors.joining(" | "));
                            return error(500, "Update errors: " + errors);
                        }
                    }
                    result.setMessage("Updated successfully");
                } else {
                    result.setMessage("Has no changes");
                }
                return Response.ok(result).build();
            }
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/pushsmissue/{issuekey}")
    public Response pushIssueToSm(@PathParam("issuekey") String issueKey) {

        CustomField syncedWithSmStatusField = customFieldManager.getCustomFieldObject(config.getSyncedWithSmStatusFieldId());
        MutableIssue issue = issueManager.getIssueObject(issueKey);
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        issue.setCustomFieldValue(syncedWithSmStatusField, null);
        issueManager.updateIssue(loggedInUser, issue, EventDispatchOption.ISSUE_UPDATED, false);


        if (Strings.isNullOrEmpty(issueKey)) {
            return error(500, "Bad request. Issuekey was not specified");
        }

        ApplicationUser user = authenticationContext.getLoggedInUser();
        try {
            if (issue == null) {
                return error(500, "Issue was not found");
            }
            IssueEvent issueEvent = new IssueEvent(issue, null, user, EventType.ISSUE_RESOLVED_ID, false);
            eventPublisher.publish(issueEvent);
            LOG.debug("Issue event {} for issue {} was generated successfully", issueEvent, issue.getKey());
        } catch (DataAccessException dex) {
            LOG.debug("Can not push jiraissue to SM: {}", ErrorStackTracer.getStackTrace(dex));
            return error(500, "Can not push jiraissue to SM");
        }
        return Response.status(Response.Status.OK).entity("Issue " + issueKey +" decision was sent to HPSM").build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/issuesource/{issuekey}")
    public Response getIssueSourceFieldValue(@PathParam("issuekey") String issueKey) {
        CustomField issueSourceField = customFieldManager.getCustomFieldObject(config.getJiraIssueSourceFieldId());
        MutableIssue issue = issueManager.getIssueObject(issueKey);
        String issueSourceFieldValue = (String) issue.getCustomFieldValue(issueSourceField);
        return Response.status(Response.Status.OK).entity("{\"issueSource\": \"" + issueSourceFieldValue + "\"}").build();
    }


    private String getSmImpact(String impact) {
        String impactString = null;
        switch (impact) {
            // 40 -> Компания
            case "40":
                impactString = "Компания";
                break;
            // 30 -> Филиал
            case "30":
                impactString = "Филиал";
                break;
            // 20 -> Подразделение
            case "20":
                impactString = "Подразделение";
                break;
            // 10 -> Пользователь
            case "10":
                impactString = "Пользователь";
                break;
        }
        return impactString;
    }

    private Response error(int status, String message) {
        SmCreateIssueResultModel result = new SmCreateIssueResultModel();
        result.setMessage(message);
        // TODO send email?
        return Response.status(status).entity(result).build();
    }

    /**
     * JIRA-1054 Проверка на дубли при создании задач в JIRA по триггеру SM
     *
     * @return
     */
    private List<Issue> getDuplicatesInOneProject(long projectId, String issueType, String smNumber) {
        String sqlTemplate = "SELECT (p.pkey||\'-\'||i.issuenum) issue_key FROM jiraissue i " +
                "JOIN customfieldvalue c on i.id = c.issue " +
                "JOIN project p on i.project = p.id " +
                "WHERE p.id = %s AND i.issuetype = \'%s\' AND c.customfield = %s AND c.stringvalue = \'%s\' ORDER BY issue_key ASC";
        String sqlQuery = String.format(sqlTemplate, projectId, issueType, config.getJiraSmNumberFieldId(), smNumber);
        return getDuplicates(smNumber, sqlQuery);
    }

    private List<Issue> getDuplicatesInDiffProjects(long projectId, String smNumber) {
        String sqlTemplate = "SELECT (p.pkey||\'-\'||i.issuenum) issue_key FROM jiraissue i " +
                "JOIN customfieldvalue c on i.id = c.issue " +
                "JOIN project p on i.project = p.id " +
                "WHERE p.id <> %s AND c.customfield = %s AND c.stringvalue = \'%s\' ORDER BY issue_key ASC";
        String sqlQuery = String.format(sqlTemplate, projectId, config.getJiraSmNumberFieldId(), smNumber);
        return getDuplicates(smNumber, sqlQuery);
    }

    private List<Issue> getDuplicates(String smNumber, String sqlQuery) {
        SQLProcessor sqlProcessor = new SQLProcessor("defaultDS");
        List<String> issueKeys =  new ArrayList<>();
        List<Issue> searchResults = new ArrayList<>();
        try {
            ResultSet rs = sqlProcessor.executeQuery(sqlQuery);
            while (rs.next()) {
                String issueKey = rs.getString("issue_key");
                issueKeys.add(issueKey);
                LOG.debug("Created issue has duplicate: {}", issueKey);
            }
            issueKeys.forEach(key -> searchResults.add(issueManager.getIssueByCurrentKey(key)));
            return searchResults;
        } catch (GenericEntityException | SQLException ex) {
            LOG.error("Exception in getting issue duplicates for smNumber {}", smNumber, ex);
        }finally {
            try {
                sqlProcessor.close();
            } catch (GenericEntityException e) {
                LOG.error("SQL processing exception in getting duplicates of issue", e);
            }
        }
        return Collections.emptyList();
    }

    private void addAttachments(String smNumber, String numberSD, MutableIssue issue, ApplicationUser user) {
        try {
            List<String> smAttachmentUrls = new ArrayList<>();
            if (smNumber.contains(SMEntityType.IM.name()) && numberSD.equals("")) {
                smAttachmentUrls.add(config.getSmActionUrl() + "/RBprobsummaryAction/" + smNumber + "/attachments");
            } else if (smNumber.contains(SMEntityType.IM.name()) && !numberSD.equals("")) {
                smAttachmentUrls.add(config.getSmActionUrl() + "/RBprobsummaryAction/" + smNumber + "/attachments");
                smAttachmentUrls.add(config.getSmActionUrl() + "/interactions/" +  numberSD + "/attachments");
            } else {
                smAttachmentUrls.add(config.getSmActionUrl() + "/interactions/" +  numberSD + "/attachments");
            }

            for (String smAttachmentUrl : smAttachmentUrls) {

                LOG.debug("SM attachment URL is: {}", smAttachmentUrl);
                HttpClient client = new HttpClient();

                GetMethod getAttachmentsMeta = smGetMethod(smAttachmentUrl);
                int responseCode = client.executeMethod(getAttachmentsMeta);
                if (responseCode >= 300) {
                    ComponentAccessor.getCommentManager().create(issue, user, "Во время загрузки вложений из SM произошла ошибка. HTTP Code: " +
                            responseCode, true);
                    return;
                }
                SmAttachMetaModel attachMeta;
                try (InputStream in = getAttachmentsMeta.getResponseBodyAsStream()) {
                    final Gson gson = new Gson();
                    final BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    attachMeta = gson.fromJson(reader, SmAttachMetaModel.class);
                }
                if (attachMeta != null && attachMeta.getContent() != null) {
                    for (SmAttachContentModel attachWrapper : attachMeta.getContent()) {
                        SmAttachModel attachModel = attachWrapper.getAttachment();
                        String cid = attachModel.getCid();

                        GetMethod getAttachments = smGetMethod(smAttachmentUrl + "/" + cid);
                        responseCode = client.executeMethod(getAttachments);
                        String smResultNumber = smAttachmentUrl.contains(smNumber) ? smNumber : numberSD; /* Указатель того, ->
                         -> откуда не скачалось вложение: из инцидента IM или из обращения SD, чтобы отразить информацию в комментарии Issue */
                        if (responseCode >= 300) {
                            ComponentAccessor.getCommentManager().create(issue, user, "Во время загрузки вложения из SM произошла ошибка. HTTP Code: " +
                                    responseCode + ", номер объекта SM: " + smResultNumber + ", ID вложения " + cid, true);
                        } else {
                            try {
                                try (InputStream is = getAttachments.getResponseBodyAsStream()) {
                                    File tempFile = File.createTempFile("attachments" + new Date().getTime(), null);
                                    FileOutputStream out = new FileOutputStream(tempFile);
                                    IOUtils.copy(is, out);
                                    AttachmentManager attachmentManager = ComponentAccessor.getAttachmentManager();
                                    CreateAttachmentParamsBean bean = new CreateAttachmentParamsBean.Builder(tempFile,
                                            attachModel.getName().replaceAll("/", "_"),
                                            attachModel.getMineType(),
                                            user,
                                            issue).build();
                                    attachmentManager.createAttachment(bean);
                                }
                            } catch (Exception e) {
                                String comment = "Во время загрузки вложения из SM произошла ошибка: "
                                        + smResultNumber + " " + cid + " " + ErrorStackTracer.getStackTrace(e);
                                ComponentAccessor.getCommentManager().create(issue, user, comment, true);
                                LOG.error("SM attachment loading error " + smNumber + " " + cid + " {}", ErrorStackTracer.getStackTrace(e));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            String comment = "Во время загрузки вложений из SM произошла ошибка: " + ErrorStackTracer.getStackTrace(e);
            ComponentAccessor.getCommentManager().create(issue, user, comment, true);
            LOG.error("Unrecognized SM attachment loading error {}", ErrorStackTracer.getStackTrace(e));
        }
    }

    private void addExternalLinks(Issue issue, ApplicationUser loggedInUser, List<SmIssueModel.SmCreateIssueLinkModel> links) {
        RemoteIssueLinkService remoteIssueLinkService = ComponentAccessor.getComponent(RemoteIssueLinkService.class);
        List<RemoteIssueLink> existLinks = remoteIssueLinkService.getRemoteIssueLinksForIssue(loggedInUser, issue).getRemoteIssueLinks();
        for (SmIssueModel.SmCreateIssueLinkModel link : links) {
            if (!existLinks.stream().anyMatch(existLink -> !Strings.isNullOrEmpty(existLink.getUrl()) && existLink.getUrl().contains(link.getHref()))) {
                RemoteIssueLinkBuilder linkBuilder = new RemoteIssueLinkBuilder();
                linkBuilder.issueId(issue.getId());
                linkBuilder.title(link.getTitle());
                linkBuilder.url(link.getHref());
                RemoteIssueLinkService.CreateValidationResult validateCreate = remoteIssueLinkService.validateCreate(loggedInUser, linkBuilder.build());
                if (validateCreate.isValid()) {
                    remoteIssueLinkService.create(loggedInUser, validateCreate);
                }
            }
        }
    }

    private Set<String> getTags(String text) {
        Set<String> res = new HashSet<>();
        String regex = "#[A-Za-z0-9_]+";
        Matcher m = Pattern.compile(regex).matcher(text);

        int counter = 0;
        while (m.find() && counter < 5) {
            String tag = m.group();
            if (tag.length() > 0) {
                res.add(tag.substring(1));
            }
            counter++;
        }
        return res;
    }

    private GetMethod smGetMethod(String smUrl) {
        final GetMethod get = new GetMethod(smUrl);
        get.setRequestHeader("Authorization", "Basic " + config.getSmAuth());
        get.setRequestHeader("Content-Type", "application/json");
        get.setRequestHeader("charset", "UTF-8");
        return get;
    }
}