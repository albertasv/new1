package ru.rosbank.jira.sm.connector.logging;

import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

@Component
public class SmMessagesLogging {


    private String jiraHomePath;


    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(SmMessagesLogging.class);

    public SmMessagesLogging(@ComponentImport JiraHome jiraHome) {
        jiraHomePath = jiraHome.getHomePath();
    }

    public void logJiraToSmMessage(String userText, String mainMessage) {
        try {
            Logger logger = Logger.getLogger("SM Message Outgoing File Logger");
            FileHandler fh = new FileHandler(jiraHomePath + "/SM_OUTGOING_LOGS/smOutgoingMessageLog.log", 20000000, 1, true);
            log(fh, logger, userText + mainMessage);
        } catch (Exception ex) {
            LOG.error("Some error in SM outgoing message logging {}", ex.getMessage());
        }
    }

    public void logSmToJiraMessage(String userText, String mainMessage) {
        try {
            Logger logger = Logger.getLogger("SM Message Incoming File Logger");
            FileHandler fh = new FileHandler(jiraHomePath + "/SM_INCOMING_LOGS/smIncomingMessageLog.log", 20000000, 1, true);
            log(fh, logger, userText + mainMessage);
        } catch (Exception ex) {
            LOG.error("Some error in SM incoming message logging {}", ex.getMessage());
        }
    }

    private void log(FileHandler fileHandler, Logger logger, String text) {
        SimpleFormatter formatter = new SimpleFormatter();
        fileHandler.setFormatter(formatter);
        logger.addHandler(fileHandler);
        logger.info(text);
        logger.removeHandler(fileHandler);
        fileHandler.close();
    }

}
