package ru.rosbank.jira.sm.connector.connection;

public interface SmAttachmentSender {

    void sendAttachmentToSm(String protocolRecordId, String attachmentUrl);
}