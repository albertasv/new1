package ru.rosbank.jira.sm.model;

import com.google.common.base.Strings;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import ru.rosbank.jira.sm.ao.SmWorkGroup;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

/**
 * POJO-класс хранения сущности рабочей группы SM из БД в среде java
 */

@XmlRootElement(name="smWorkGroup")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmWorkGroupModel implements Comparable {

    @JsonProperty("ID")
    private String code;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("ManagerLogin")
    private String managerLogin = "";

    @JsonProperty("WorkIM")
    private boolean workIm;

    @JsonProperty("WorkRFT")
    private boolean workRft;

    @JsonProperty("Blocked")
    private boolean blocked;

    private Date lastUpdateDate;

    public SmWorkGroupModel() {
    }

    public SmWorkGroupModel(String code, String name, String managerLogin, boolean workIm, boolean workRft, boolean blocked, Date lastUpdateDate) {
        this.code = code;
        this.name = name;
        if (Strings.isNullOrEmpty(managerLogin)) {
            this.managerLogin = "";
        } else {
            this.managerLogin = managerLogin;
        }
        this.workIm = workIm;
        this.workRft = workRft;
        this.lastUpdateDate = lastUpdateDate;
        this.blocked=blocked;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManagerLogin() {
        return managerLogin;
    }

    public void setManagerLogin(String managerLogin) {
        if (managerLogin.length() == 0) {
            this.managerLogin = "";
        } else {
            this.managerLogin = managerLogin;
        }
    }

    public boolean isWorkIm() {
        return workIm;
    }

    public void setWorkIm(boolean workIm) {
        this.workIm = workIm;
    }

    public boolean isWorkRft() {
        return workRft;
    }

    public void setWorkRft(boolean workRft) {
        this.workRft = workRft;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public static SmWorkGroupModel convert(SmWorkGroup smWorkGroup) {
        return new SmWorkGroupModel(
                smWorkGroup.getCode(),
                smWorkGroup.getName(),
                smWorkGroup.getManagerLogin(),
                smWorkGroup.getWorkIm(),
                smWorkGroup.getWorkRft(),
                smWorkGroup.getBlocked(),
                smWorkGroup.getLastUpdateDate());
    }

    public String toString() {
        return "SmWorkgroupModel{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", managerLogin='" + managerLogin + '\'' +
                ", workWithIncident='" + workIm + '\'' +
                ", workWithSdAndRft='" + workRft + '\'' +
                ", blocked='" + blocked + '\''+
                '}';
    }

    @Override
    public int compareTo(Object otherSmWorkGroupModel) {
        return this.name.compareTo(((SmWorkGroupModel) otherSmWorkGroupModel).name);
    }

}
