package ru.rosbank.jira.sm.rest.attach;

import java.util.List;

public class SmAttachMetaModel {

    private List<SmAttachContentModel> content;

    public List<SmAttachContentModel> getContent() {
        return content;
    }

    public void setContent(List<SmAttachContentModel> content) {
        this.content = content;
    }
}
