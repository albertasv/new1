package ru.rosbank.jira.sm.customfields;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.customfields.impl.GenericTextCFType;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.customfields.persistence.CustomFieldValuePersister;
import com.atlassian.jira.issue.customfields.persistence.PersistenceFieldType;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.TextFieldCharacterLengthValidator;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutItem;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ProjectPropertyModel;
import ru.rosbank.jira.common.api.ProjectPropertyService;
import ru.rosbank.jira.sm.ao.SmWorkGroup;
import ru.rosbank.jira.sm.api.SmWorGroupService;
import ru.rosbank.jira.sm.model.SmWorkGroupModel;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Класс-контекст для кастомного поля SM Workgroup
 */

public class SmWokGroupField extends GenericTextCFType {

    private static final Logger LOG = LoggerFactory.getLogger(SmWokGroupField.class);
    SmWorGroupService smWorGroupService;

    ProjectPropertyService projectPropertyService;

    protected SmWokGroupField(@ComponentImport CustomFieldValuePersister customFieldValuePersister,
                              @ComponentImport GenericConfigManager genericConfigManager,
                              @ComponentImport TextFieldCharacterLengthValidator textFieldCharacterLengthValidator,
                              @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
                              @ComponentImport ProjectPropertyService projectPropertyService,
                              SmWorGroupService smWorGroupService) {
        super(customFieldValuePersister, genericConfigManager, textFieldCharacterLengthValidator, jiraAuthenticationContext);
        this.projectPropertyService = projectPropertyService;
        this.smWorGroupService = smWorGroupService;
    }

    @Override
    public Map<String, Object> getVelocityParameters(final Issue issue,
                                                     final CustomField field,
                                                     final FieldLayoutItem fieldLayoutItem) {
        final Map<String, Object> map = super.getVelocityParameters(issue, field, fieldLayoutItem);
        map.put("workGroups", getSmWorkGroupModelList(issue));
        map.put("esc", new EscapeTool());
        Object smWorkGroupName;
        if (issue != null) {
            if (issue.isCreated()) {
                smWorkGroupName = this.getValueFromIssue(field, issue);
            } else {
                smWorkGroupName = this.getDefaultValue(field.getRelevantConfig(issue));
            }
        } else {
            // NULL
            smWorkGroupName = map.get("value");
        }

        if (smWorkGroupName != null) {
            SmWorkGroup smWorkGroup = smWorGroupService.getByName((String) smWorkGroupName);
            if (smWorkGroup != null) {
                map.put("value", SmWorkGroupModel.convert(smWorkGroup));
            }
        } else {
            map.remove("value");
        }

        return map;
    }

    @Nonnull
    @Override
    protected PersistenceFieldType getDatabaseType() {
        return PersistenceFieldType.TYPE_LIMITED_TEXT;
    }

    // JIRA-6459
    private List<SmWorkGroupModel> getSmWorkGroupModelList(Issue issue) {
        Project project = issue.getProjectObject();
        ProjectPropertyModel projectProperty = projectPropertyService.search(project.getId(), "favorite.sm.workgroups");
        List<SmWorkGroupModel> workGroupModelList = smWorGroupService.searchAll().stream().map(smWorkGroup ->
                        SmWorkGroupModel.convert(smWorkGroup))
                .collect(Collectors.toList());
        Collections.sort(workGroupModelList);
        List<SmWorkGroupModel> workGroupModelListWithFavoriteGroupsInTheBeginnig = new ArrayList<>();
        if (projectProperty != null) {
            String[] favoriteWorkGroupCodes = projectProperty.getValue().split(",");
            for (int i = 0; i < favoriteWorkGroupCodes.length; i++) {
                for (int j = 0; j < workGroupModelList.size(); j++) {
                    if (favoriteWorkGroupCodes[i].equals(workGroupModelList.get(j).getCode())) {
                        String newName = workGroupModelList.get(j).getName() + " ✱";
                        workGroupModelList.get(j).setName(newName);
                        workGroupModelListWithFavoriteGroupsInTheBeginnig.add(workGroupModelList.get(j));
                    }
                }
            }
        }
        workGroupModelList.removeAll(workGroupModelListWithFavoriteGroupsInTheBeginnig);
        workGroupModelListWithFavoriteGroupsInTheBeginnig.addAll(workGroupModelList);
        return workGroupModelListWithFavoriteGroupsInTheBeginnig;
    }

    @Override
   public String getSingularObjectFromString(String string) {
        return string.replace(" ✱", "").trim();
    }

}
