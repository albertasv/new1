package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.component.pico.ComponentManager;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.RendererManager;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.issue.comments.CommentManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.renderer.IssueRenderContext;
import com.atlassian.jira.issue.fields.renderer.JiraRendererPlugin;
import com.atlassian.jira.issue.fields.renderer.wiki.AtlassianWikiRenderer;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.json.JSONException;
import com.atlassian.jira.util.json.JSONObject;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.java.ao.Query;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.SMEntityType;
import ru.rosbank.jira.sm.ao.SmReason;
import ru.rosbank.jira.sm.connector.JiraAdminsNotificator;
import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;
import ru.rosbank.jira.sm.connector.queue.SmMessageEntityToTaskHelper;
import ru.rosbank.jira.sm.connector.queue.SmMessageSendingTaskModel;
import ru.rosbank.jira.sm.model.SmRBprobsummaryModel;
import ru.rosbank.jira.sm.model.SmRBprotocolSendNewMsgModel;
import ru.rosbank.jira.sm.model.SmRBrequestTaskModel;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;
import static ru.rosbank.jira.sm.SMUtils.ISSUE_SOURCE_SM;
import static ru.rosbank.jira.sm.SMUtils.getSMNumbers;

/**
 * Реализация сервисов, которые предоставляют собой различные методы для работы с текстовыми сообщениями, комментариями, ссылками и т.п.
 */

@Service
public class SmServiceImpl implements SmService {
    private static final Logger LOG = LoggerFactory.getLogger(SmServiceImpl.class);

    private final ConfigLoader configLoader;

    private final SmAsyncTaskExecutor asyncTaskExecutor;


    private final CustomFieldManager customFieldManager;

    private final ActiveObjects ao;

    private final SmMessageEntityToTaskHelper smMessageEntityToTaskHelper;

    private final JiraAdminsNotificator jiraAdminsNotificator;

    private final CommentManager commentManager;

    private static final String SAVED_TASK_FIELDS = "ID, " +
            "TASK_CREATED_TIME, " +
            "TASK_SENT_TIME, " +
            "TARGET_ENDPOINT, " +
            "JSON_DATA, " +
            "ACTION_METHOD, " +
            "LINKED_ISSUE_KEY, " +
            "VERBOSE, " +
            "SM_RESPONSE" +
            "COMMENT_ID" +
            "TASK_AUTHOR";



    @Inject
    public SmServiceImpl(@ComponentImport ConfigLoader configLoader,
                         @ComponentImport ActiveObjects ao,
                         SmAsyncTaskExecutor asyncTaskExecutor, SmMessageEntityToTaskHelper smMessageEntityToTaskHelper, JiraAdminsNotificator jiraAdminsNotificator) {
        this.configLoader = checkNotNull(configLoader);
        this.ao = checkNotNull(ao);
        this.asyncTaskExecutor = checkNotNull(asyncTaskExecutor);
        this.smMessageEntityToTaskHelper = smMessageEntityToTaskHelper;
        this.jiraAdminsNotificator = jiraAdminsNotificator;
        customFieldManager = ComponentAccessor.getCustomFieldManager();
        commentManager = ComponentAccessor.getCommentManager();
    }

    @Override
    public void updateDueDate(Issue issue, String smNumber, Date due, IssueEvent issueEvent) {
        LOG.info("Update sm {} due date {}", smNumber, due);
        asyncTaskExecutor.execute(() -> {
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss+03:00").create();
            if (smNumber.contains(SMEntityType.IM.name())) {                  // Если Issue связана с инцидентом
                String smUrl = "/RBprobsummaryAction/" + smNumber + "/action/update";
                SmRBprobsummaryModel.SmRBprobsummaryActionModel data = new SmRBprobsummaryModel.SmRBprobsummaryActionModel();
                data.setDueDate(due);
                String json = gson.toJson(new SmRBprobsummaryModel(data));
                if (json != null) {
                    SmMessage smMessage = new SmMessageBuilder()
                            .toEndpoint(smUrl)
                            .withData(json)
                            .linkedJiraIssue(issue)
                            .usingMethod(SmActionMethod.POST)
                            .mustAddCommentInIssue(false)
                            .commentId(0L)
                            .taskAuthor(issueEvent.getUser().getUsername())
                            .build();
                    saveSmMessage(smMessage);
                }
            } else {                                                           // Если Issue связана с нарядом
                String smUrl = "/RBrequestTaskAction/" + smNumber + "/action/update";
                SmRBrequestTaskModel.SmRBrequestTaskActionModel data = new SmRBrequestTaskModel.SmRBrequestTaskActionModel();
                data.setDueDate(due);
                String json = gson.toJson(new SmRBrequestTaskModel(data));
                if (json != null) {
                    SmMessage smMessage = new SmMessageBuilder()
                            .toEndpoint(smUrl)
                            .withData(json)
                            .linkedJiraIssue(issue)
                            .usingMethod(SmActionMethod.POST)
                            .mustAddCommentInIssue(false)
                            .commentId(0L)
                            .taskAuthor(issueEvent.getUser().getUsername())
                            .build();
                    saveSmMessage(smMessage);
                }
            }
        });
    }

    @Override
    public void updateResolveRegistrar(Issue issue, String smNumber, boolean resolveRegistrar) {
        LOG.info("Update sm {} resolveRegistrar {}", smNumber, resolveRegistrar);
        asyncTaskExecutor.execute(() -> {
            String smUrl = "/RBprobsummaryAction/" + smNumber + "/action/update";
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
            SmRBprobsummaryModel.SmRBprobsummaryActionModel data = new SmRBprobsummaryModel.SmRBprobsummaryActionModel();
            data.setResolveRegistrar(resolveRegistrar);
            String json = gson.toJson(new SmRBprobsummaryModel(data));
            if (json != null) {
                SmMessage smMessage = new SmMessageBuilder()
                        .toEndpoint(smUrl)
                        .withData(json)
                        .linkedJiraIssue(issue)
                        .usingMethod(SmActionMethod.POST)
                        .mustAddCommentInIssue(false)
                        .commentId(0L)
                        .build();
                saveSmMessage(smMessage);
            }
        });
    }

    @Override
    public String getSmNumber(Issue issue) {
        try {
            CustomField smNumberField = customFieldManager.getCustomFieldObject(configLoader.getJiraSmNumberFieldId());
            return (String) issue.getCustomFieldValue(smNumberField);
        } catch (NullPointerException ex) {
            return "";
        }
    }

    @Override
    public boolean isSmIssueSource(Issue issue) {
        try {
            CustomField smSourceField = customFieldManager.getCustomFieldObject(configLoader.getJiraIssueSourceFieldId());
            String smSource = (String) issue.getCustomFieldValue(smSourceField);
            return ISSUE_SOURCE_SM.equalsIgnoreCase(smSource);
        } catch (NullPointerException ex) {
            return false;
        }
    }


    @Override
    public SmReason getReasonByCode(String code) {
        SmReason[] items = ao.find(SmReason.class, Query.select().where("\"CODE\" = ?", code));
        if (items.length == 1) {
            return items[0];
        }
        return null;
    }

    private final static String REASON_SEARCH_QUERY = "(LOWER(\"CODE\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"GROUP_REASON\" COLLATE \"en_US\") LIKE ?)";

    @Override
    public List<SmReason> searchReason(String query, int pageMax, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(SmReason.class,
                    Query.select()
                            .order("\"NAME\"")
                            .limit(pageMax)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(SmReason.class, Query.select()
                .where(REASON_SEARCH_QUERY,
                        likeQuery, likeQuery, likeQuery)
                .order("\"NAME\"")
                .limit(pageMax)
                .offset(offset)
        ));
    }

    @Override
    public int totalReason(String query) {
        if (Strings.isNullOrEmpty(query)) {
            return ao.count(SmReason.class, Query.select());
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(SmReason.class, Query.select()
                .where(REASON_SEARCH_QUERY, likeQuery, likeQuery, likeQuery));
    }

    @Override
    public void saveSmMessage(SmMessage message) {
        saveSendingSmTask(message);
    }

    public List<SmMessageSendingTaskModel> getSavedSendingSmTasks() {

        Query selectAllUnsentTasksQuery = Query.select(SAVED_TASK_FIELDS)
                .where("TASK_SENT_TIME is NULL AND JIRA_ADMINS_NOTIFICATION_TIME is NULL")
                .order("LINKED_ISSUE_KEY, TASK_CREATED_TIME");

        return getAndCheckSavedSendingSmTasksWithQuery(selectAllUnsentTasksQuery);
    }

    private List<SmMessageSendingTaskModel> getAndCheckSavedSendingSmTasksWithQuery(Query sendingTaskQuery) {
        List<SmMessageSendingTaskModel> savedSendingTasks = new ArrayList<>();
        try {
            SmMessageSendingTaskEntity[] sendingTaskEntities = ao.find(SmMessageSendingTaskEntity.class, sendingTaskQuery);
            LOG.debug("Sending task entities count is: {}", sendingTaskEntities.length);
            if (sendingTaskEntities.length == 0) {
                return savedSendingTasks;
            }
            for (SmMessageSendingTaskEntity smMessageSendingTaskEntity : sendingTaskEntities) {
                boolean authorNotified = checkAndNotifyIfTaskSentTimeOverdue(smMessageSendingTaskEntity);
                boolean syncFailCommentAdded = false;
                if (authorNotified) {
                    syncFailCommentAdded = addFailedTaskSyncComment(smMessageSendingTaskEntity);
                }
                if (authorNotified && syncFailCommentAdded) {
                    markAsNotified(smMessageSendingTaskEntity);
                }
                SmMessageSendingTaskModel taskModel = smMessageEntityToTaskHelper.taskEntityToObject(smMessageSendingTaskEntity);
                savedSendingTasks.add(taskModel);
            }
            return savedSendingTasks;
        } catch (Exception e) {
            LOG.error("Some exception in getting sending tasks from database", e);
            return savedSendingTasks;
        }
    }

    public void saveSendingSmTask(SmMessage message) {
        SmMessageSendingTaskModel sendingTask = new SmMessageSendingTaskModel(0, new Date(), null, message, 0L);
        saveSendingSmTask(sendingTask);
    }

    private void saveSendingSmTask(SmMessageSendingTaskModel sendingTask) {
        Map<String, Object> taskEntityParams = buildTaskEntityFieldValues(sendingTask);
        SmMessageSendingTaskEntity createdTaskEntity = ao.create(SmMessageSendingTaskEntity.class, taskEntityParams);
    }

    public void markAsSent(SmMessageSendingTaskModel sendingTask) {
        Date currentDate = new Date();
        Integer sendingTaskId = sendingTask.getId();
        ao.executeInTransaction(() -> {
            SmMessageSendingTaskEntity sendingTaskEntity = ao.get(SmMessageSendingTaskEntity.class, sendingTaskId);
            if (sendingTaskEntity != null) {
                sendingTaskEntity.setTaskSentTime(currentDate);
                sendingTaskEntity.save();
            }
            return null;
        });
    }

    public void markAsNotified(SmMessageSendingTaskEntity sendingTaskEntity) {
        Date currentDate = new Date();
        ao.executeInTransaction(() -> {
            sendingTaskEntity.setJiraAdminsNotificationTime(currentDate);
            sendingTaskEntity.save();
            return null;
        });
    }

    private Map<String, Object> buildTaskEntityFieldValues(SmMessageSendingTaskModel sendingTask) {

        Map<String, Object> entityFieldValues = new HashMap<>();

        SmMessage smMessage = sendingTask.getMessage();

        entityFieldValues.put("TASK_CREATED_TIME", sendingTask.getTaskCreatedTime());
        entityFieldValues.put("TARGET_ENDPOINT", smMessage.getTargetEndpoint());
        entityFieldValues.put("JSON_DATA", smMessage.getJsonData());
        entityFieldValues.put("ACTION_METHOD", smMessage.getActionMethod());
        entityFieldValues.put("LINKED_ISSUE_KEY", smMessage.getLinkedJiraIssue().getKey());
        entityFieldValues.put("VERBOSE", smMessage.mustAddCommentInIssue());
        entityFieldValues.put("COMMENT_ID", smMessage.getCommentId());
        entityFieldValues.put("FAILED_TASK_SYNC_COMMENT_ID", 0L);
        entityFieldValues.put("TASK_AUTHOR", smMessage.getTaskAuthor());
        return entityFieldValues;

    }

    public void saveSmResponse(int sendingTaskId, String smResponseBody) {
        ao.executeInTransaction(() -> {
            SmMessageSendingTaskEntity sendingTaskEntity = ao.get(SmMessageSendingTaskEntity.class, sendingTaskId);
            if (sendingTaskEntity != null) {
                sendingTaskEntity.setSmResponse(smResponseBody);
                sendingTaskEntity.save();
            }
            return null;
        });
    }

    public boolean checkAndNotifyIfTaskSentTimeOverdue(SmMessageSendingTaskEntity sendingTaskEntity) {
        Date taskSentTime = sendingTaskEntity.getTaskSentTime();
        Date taskCreatedTime = sendingTaskEntity.getTaskCreatedTime();
        Date jiraAdminsNotificationTime = sendingTaskEntity.getJiraAdminsNotificationTime();
        Long failedTaskSyncCommentId = sendingTaskEntity.getFailedTaskSyncCommentId();
        final long possibleOverdueTime = 3600000; // 1 hour = 3600000 in milliseconds
        final long deltaBetweenCreationTimeAndNow = new Date().getTime() - taskCreatedTime.getTime();
        boolean usersNotified = false;
        if (taskSentTime == null && jiraAdminsNotificationTime == null  &&
                deltaBetweenCreationTimeAndNow > possibleOverdueTime && (failedTaskSyncCommentId == 0 || failedTaskSyncCommentId == null)) {
            usersNotified = jiraAdminsNotificator.notifyAboutSmSyncFailureByEmail(sendingTaskEntity,
                    sendingTaskEntity.getSmResponse());
        }
        return usersNotified;
    }

    public void addSmSyncComment(ApplicationUser author, Issue issue, String smNumber, Comment comment, IssueEvent issueEvent) {
        asyncTaskExecutor.execute(() -> {
            LOG.debug("Sending comment to SM for {}", smNumber);

            SmResponseStatus commentSyncStatus = SmResponseStatus.SM_ISSUE_UPDATE_SUCCESSFULLY;
            JiraRendererPlugin renderer = ComponentManager.getInstance().getComponent(RendererManager.class)
                    .getRendererForType(AtlassianWikiRenderer.RENDERER_TYPE);
            String commentHtml = renderer.render(comment.getBody(), new IssueRenderContext(issue));
            LOG.debug("Comment in issue {} equals: {}", issue.getKey(), commentHtml);
            Document commentDocument = Jsoup.parse(commentHtml, "", Parser.htmlParser());

            // JIRA-3274 форматируем текст комментария, так как в SM изображения и значки не отображаются
            commentDocument.select("ol").forEach(list -> {
                Elements liElems = list.select("li");
                for (int i = 0; i < liElems.size(); i++) {
                    Element elem = liElems.get(i);
                    elem.text((i + 1) + ". " + elem.text());
                }
            });

            commentDocument.select("ul").forEach(list -> {
                Elements liElems = list.select("li");
                for (int i = 0; i < liElems.size(); i++) {
                    Element elem = liElems.get(i);
                    elem.text("• " + elem.text());
                }
            });

            commentDocument.select("p").forEach(elemsListOfP -> {
                Elements imgElems = elemsListOfP.select("img[src]");
                if (!imgElems.isEmpty()) {
                    String text = "";
                    for (int j = 0; j < imgElems.size(); j++) {
                        if (imgElems.get(j).attr("src").contains("star_red.png")) {
                            text = text + "(*r)";
                        } else if (imgElems.get(j).attr("src").contains("star_blue.png")) {
                            text = text + "(*b)";
                        } else if (imgElems.get(j).attr("src").contains("star_green.png")) {
                            text = text + "(*g)";
                        } else if (imgElems.get(j).attr("src").contains("star_yellow.png")) {
                            text = text + "(*y)";
                        }
                    }
                    String elementTextWithCorrectSpaces = elemsListOfP.text().replace("\u00a0", " ");
                    elemsListOfP.text(text + elementTextWithCorrectSpaces);
                }
            });

            Document.OutputSettings outputSettings = new Document.OutputSettings();
            outputSettings.prettyPrint(false);
            commentDocument.outputSettings(outputSettings);
            String commentText = Jsoup.clean(commentDocument.html().replaceAll("\\\\n", "\n"), "", Whitelist.none(), outputSettings);
            List<String> description = new ArrayList<>();
            description.add(commentText);

            Gson gson = new Gson();
            String json = gson.toJson(new SmRBprotocolSendNewMsgModel(smNumber, author.getUsername(), description));
            if (json != null) {
                SmMessage smMessage = new SmMessageBuilder()
                        .toEndpoint("/RBprotocolSendNewMsg")
                        .withData(json)
                        .linkedJiraIssue(issue)
                        .usingMethod(SmActionMethod.POST)
                        .mustAddCommentInIssue(false)
                        .commentId(issueEvent.getComment().getId())
                        .taskAuthor(issueEvent.getUser().getUsername())
                        .build();
                LOG.debug("SM Message is: {}", smMessage.toString());
                saveSmMessage(smMessage);
            }
            LOG.debug("Comment sending SM for {} status {}", smNumber, commentSyncStatus);
        });
    }

    //TODO: Разбить метод на несколько более маленьких
    public boolean addFailedTaskSyncComment(SmMessageSendingTaskEntity sendingTaskEntity) {
        IssueManager issueManager = ComponentAccessor.getIssueManager();
        Issue issue = issueManager.getIssueObject(sendingTaskEntity.getLinkedIssueKey());

        if (issue == null) {
            return false;
        }

        ApplicationUser syncUser = ComponentAccessor.getUserManager().getUserByName("smsync");
        String taskAuthorName = sendingTaskEntity.getTaskAuthor();
        ApplicationUser taskAuthor = ComponentAccessor.getUserManager().getUserByName(taskAuthorName);
        assert taskAuthor != null;

        String smResponseBody = sendingTaskEntity.getSmResponse();

        Date taskUpdateDateTime = sendingTaskEntity.getTaskCreatedTime();
        String taskUpdateDateTimeString = new SimpleDateFormat("y-M-d HH:mm").format(taskUpdateDateTime);

        String commentText = "";

        String smNumber;
        String prefix;
        String targetEndpoint = sendingTaskEntity.getTargetEndpoint();
        if (targetEndpoint.contains("RFT")) {
            prefix = "RFT";
            List<String> availableSmNumbers = getSMNumbers(targetEndpoint, prefix);
            smNumber = !availableSmNumbers.isEmpty() ? "нарядом " + availableSmNumbers.get(0) : "";
        } else if (targetEndpoint.contains("IM")) {
            prefix = "IM";
            List<String> availableSmNumbers = getSMNumbers(targetEndpoint, prefix);
            smNumber = !availableSmNumbers.isEmpty() ? "инцидентом " + availableSmNumbers.get(0) : "";
        } else {
            List<String> availableSmImNumbers = getSMNumbers(sendingTaskEntity.getJsonData(),"IM");
            List<String> availableSmRftNumbers = getSMNumbers(sendingTaskEntity.getJsonData(),"RFT");
            if (!availableSmImNumbers.isEmpty())
                smNumber = "инцидентом " + availableSmImNumbers.get(0);
            else if (!availableSmRftNumbers.isEmpty())
                smNumber = "нарядом " + availableSmRftNumbers.get(0);
            else
                smNumber = "";
        }

        if (Strings.isNullOrEmpty(smResponseBody)) {
            commentText = "{quote}{{[~" + taskAuthor.getUsername() + "] Обновление задачи от " + taskUpdateDateTimeString +
                    " не было синхронизировано с " + smNumber + " SM в течение 60 минут. {color:#FF0000}[*Обратитесь к администраторам Jira,создав Ticket в проекте Jira Dev Team (JIRA).*" +
                    "|https://jirahq.rosbank.rus.socgen:8443/projects/JIRA]{color}}}{quote}";
        } else {
            String smResponseMessages = "";
            int returnCode = 0;

            try {
                JSONObject smResponseBodyInJsonFormat = new JSONObject(sendingTaskEntity.getSmResponse());
                smResponseMessages = smResponseBodyInJsonFormat.getString("Messages");
                returnCode = Integer.parseInt(smResponseBodyInJsonFormat.getString("ReturnCode").trim());
            } catch (JSONException jsex) {
                LOG.error("SM response parsing exception: ", jsex);
            }

            if (Strings.isNullOrEmpty(smResponseMessages)) {
                commentText = "{quote}{{[~" + taskAuthor.getUsername() + "] Обновление задачи от " + taskUpdateDateTimeString +
                        " не было синхронизировано с " + smNumber + " SM в течение 60 минут. {color:#FF0000}[*Обратитесь к администраторам Jira,создав Ticket в проекте Jira Dev Team (JIRA).*" +
                        "|https://jirahq.rosbank.rus.socgen:8443/projects/JIRA]{color}}}{quote}";
            } else {

                // Чтобы корректно рендерились браузером комментарии в задаче Jira
                smResponseMessages = smResponseMessages
                        .replaceAll("\\[", "")
                        .replaceAll("\\]","")
                        .replaceAll("\\{", "")
                        .replaceAll("\\}","");

                String reason = "";

                switch (returnCode) {
                    case 3:
                        reason = configLoader.getSmReturnCode3Message();
                        break;
                    case 51:
                        reason = configLoader.getSmReturnCode51Message();
                        break;
                    case 71:
                        reason = configLoader.getSmReturnCode71Message();
                        break;
                }
                if (returnCode != 0 && returnCode != 70) {
                    commentText = "{quote}{{[~" + taskAuthor.getUsername() + "] Обновление задачи от " + taskUpdateDateTimeString +
                            " не было синхронизировано с "+ smNumber +" SM в течение 60 минут. Сообщение от SM: " +
                            smResponseMessages + ". Причина ошибки: " + reason +
                            " {color:#FF0000}[*Обратитесь к администраторам SM, оставив обращение на портале SM.*" +
                            "|https://sm.rosbank.rus.socgen/sm/ess.do?file=rbactivelink&role=ess&ctx=docEngine&query=name%3D%22RB.Portal.Request.R1315%22&action=&title=sm]{color}}}{quote}";
                }
            }
        }

        Comment comment = commentManager.create(issue, syncUser, commentText, false);
        sendingTaskEntity.setFailedTaskSyncCommentId(comment.getId());
        sendingTaskEntity.save();
        return true;
    }
}
