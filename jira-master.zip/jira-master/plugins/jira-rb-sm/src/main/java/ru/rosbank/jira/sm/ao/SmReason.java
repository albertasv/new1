package ru.rosbank.jira.sm.ao;

import net.java.ao.Preload;
import net.java.ao.schema.NotNull;

@Preload
public interface SmReason extends SmDictionary {

    @NotNull
    String getGroupReason();

    @NotNull
    void setGroupReason(String groupReason);

}