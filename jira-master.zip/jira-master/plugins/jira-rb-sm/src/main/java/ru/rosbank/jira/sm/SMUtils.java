package ru.rosbank.jira.sm;

import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.issue.comments.CommentManager;
import com.atlassian.jira.issue.comments.MutableComment;
import com.atlassian.jira.issue.link.RemoteIssueLink;
import com.atlassian.jira.issue.link.RemoteIssueLinkBuilder;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.api.SmAsyncTaskExecutor;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.connector.JiraAdminsNotificator;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.model.SmIssueType;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SMUtils {

    /**
     * @param text
     * @param prefix - IM, SD, RFT etc
     * @return
     */

    public static final String ISSUE_SOURCE_SM = "SM";

    public static final String PROBLEM_PROJECT_KEY = "PRB";

    private static final CommentManager commentManager = ComponentAccessor.getCommentManager();

    private static final ApplicationUser applicationUser = ComponentAccessor.getUserManager().getUserByName("smsync");

    private static final Logger LOG = LoggerFactory.getLogger(SMUtils.class);

    public SMUtils() {
    }

    public static List<String> getSMNumbers(String text, String prefix) {
        List<String> res = new ArrayList<>();
        if (Strings.isNullOrEmpty(text) || Strings.isNullOrEmpty(prefix)) {
            return res;
        }

        String regex = prefix + "[0-9_]+";
        Matcher m = Pattern.compile(regex).matcher(text);
        int counter = 0;
        while (m.find() && counter < 100) {
            String tag = m.group();
            if (tag.length() > 0) {
                res.add(tag);
            }
            counter++;
        }
        return res;
    }

    public static void addSMLinks(Issue issue, ApplicationUser loggedInUser, Set<String> smNumbers, SMEntityType smEntityType, ConfigLoader config) {
        RemoteIssueLinkService remoteIssueLinkService = ComponentAccessor.getComponent(RemoteIssueLinkService.class);
        List<RemoteIssueLink> existLinks = remoteIssueLinkService.getRemoteIssueLinksForIssue(loggedInUser, issue).getRemoteIssueLinks();
        for (String smNumber : smNumbers) {
            RemoteIssueLinkBuilder linkBuilder = new RemoteIssueLinkBuilder();
            linkBuilder.issueId(issue.getId());
            String smUrl;
            if (smEntityType.equals(SMEntityType.IM) && smNumber.contains("IM")) {
                linkBuilder.title("Инцидент в SM " + smNumber);
                smUrl = config.getSmUrl() + "index.do?ctx=docEngine&file=probsummary&query=number%3D%22" + smNumber + "%22";
            }
            else if (smEntityType.equals(SMEntityType.SD) && smNumber.contains("SD")) {
                linkBuilder.title("Обращение в SM " + smNumber);
                smUrl = config.getSmUrl() + "index.do?ctx=docEngine&file=incidents&query=incident.id%3D%22" + smNumber + "%22";
            }
            else if (smEntityType.equals(SMEntityType.RFT) && smNumber.contains("RFT")) {
                linkBuilder.title("Наряд в SM " + smNumber);
                smUrl = config.getSmUrl() + "index.do?ctx=docEngine&file=requestTask&query=number%3D%22" + smNumber + "%22";
            }
            else continue;

            if (!existLinks.stream().anyMatch(existLink -> !Strings.isNullOrEmpty(existLink.getUrl()) && existLink.getUrl().contains(smNumber))) {
                linkBuilder.url(smUrl);
            }

            RemoteIssueLinkService.CreateValidationResult validateCreate = remoteIssueLinkService.validateCreate(loggedInUser, linkBuilder.build());
            if (validateCreate.isValid()) {
                remoteIssueLinkService.create(loggedInUser, validateCreate);
            }
        }
    }

    public static SmIssueType findSmIssueTypeFromEndpointUrl(String endpointUrl) {
        return (endpointUrl.contains("RBprobsummaryAction"))
                ? SmIssueType.INCIDENT
                : SmIssueType.TASK;
    }

    //для того, чтобы в SM приходили корректные символы " ", <> и &
    public static String fixGtLtAmpChars(String jsonDocument) {
        return jsonDocument
                .replace("\\u0026lt;", "<")
                .replace("\\u0026gt;", ">")
                .replace("\\u0026amp;", "&")
                .replace("\\u0026nbsp;", " ");
    }

    public static void addSmDeliveryStatusMessageIfComment(ApplicationUser syncUser, SmMessage message, boolean successDeliveryToSm) {
        ComponentAccessor.getJiraAuthenticationContext().setLoggedInUser(syncUser);

        if (message.getCommentId() != 0L && successDeliveryToSm == true) {
            String warning = "{noformat}Комментарий успешно отправлен в SM, его дальнейшее редактирование/удаление не синхронизируется.{noformat}";
            MutableComment comment = (MutableComment) commentManager.getCommentById(message.getCommentId());
            if (comment != null) {
                comment.setBody(comment.getBody() + warning);
                commentManager.update(comment, false);
            }
        } else if (message.getCommentId() != 0L && successDeliveryToSm == false) {
            String warning = "{noformat}Во время отправки комментария в SM произошла ошибка. Создайте новый " +
                    "комментарий или обратитесь к администратору Jira.{noformat}";
            MutableComment comment = (MutableComment) commentManager.getCommentById(message.getCommentId());
            if (comment != null) {
                comment.setBody(comment.getBody() + warning);
                commentManager.update(comment, false);
            }
        }
    }


    public static void addResolvedMessageInComment(Issue issue, ApplicationUser syncUser) {
        if (issue == null) {
            return;
        }
        String comment = "Информация о решении отправлена в SM.";
        commentManager.create(issue, syncUser, comment, false);
    }
    public static void deleteFailedTaskSyncComment(Long commentId) {
        Comment comment = commentManager.getCommentById(commentId);
        commentManager.delete(comment, false, applicationUser);
    }
}
