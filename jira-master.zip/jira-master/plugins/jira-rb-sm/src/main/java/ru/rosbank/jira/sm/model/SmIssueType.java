package ru.rosbank.jira.sm.model;

/**
 * Список возможных типов задач в HP SM.
 * Для каждого типа задач используется определенная схема URL.
 */
public enum SmIssueType {
    INCIDENT,
    TASK
}
