package ru.rosbank.jira.sm.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component(value = "smAsyncTaskExecutor")
public class SmAsyncTaskExecutor implements AsyncTaskExecutor {

    private static final Logger LOG = LoggerFactory.getLogger(SmAsyncTaskExecutor.class);
    private final ExecutorService executor = Executors.newCachedThreadPool(new SmAsyncTaskExecutor.NamedThreadFactory());

    public SmAsyncTaskExecutor() {
    }

    @Override
    public void execute(Runnable task, long startTimeout) {
        this.executor.execute(task);
    }

    @Override
    public Future<?> submit(Runnable task) {
        return this.executor.submit(task);
    }

    @Override
    public <T> Future<T> submit(Callable<T> task) {
        return this.executor.submit(task);
    }

    @Override
    public void execute(Runnable task) {
        this.execute(task, -1L);
    }

    @PreDestroy
    public void shutdown() {
        LOG.debug("Attempting to shutdown ExecutorService for SmAsyncTaskExecutor");
        this.executor.shutdown();

        try {
            if (this.executor.awaitTermination(5L, TimeUnit.SECONDS)) {
                LOG.debug("ExecutorService has shutdown gracefully");
            } else {
                LOG.warn("ExecutorService did not shutdown within the timeout; forcing shutdown");
                this.executor.shutdownNow();
                if (this.executor.awaitTermination(5L, TimeUnit.SECONDS)) {
                    LOG.debug("ExecutorService has been forced to shutdown");
                } else {
                    LOG.warn("ExecutorService did not shutdown; it will be abandoned");
                }
            }
        } catch (InterruptedException var2) {
            LOG.warn("Interrupted while waiting for the executor service to shutdown; some worker threads may still be running");
            Thread.currentThread().interrupt();
        }
    }

    private static class NamedThreadFactory implements ThreadFactory {
        private final AtomicInteger counter;

        private NamedThreadFactory() {
            this.counter = new AtomicInteger();
        }

        public Thread newThread(Runnable r) {
            Thread thread = new Thread(r);
            thread.setDaemon(false);
            thread.setName("SmAsyncTaskExecutor::Thread " + this.counter.incrementAndGet());
            return thread;
        }
    }
}

