package ru.rosbank.jira.sm.api;

import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.bc.issue.comment.CommentService;
import com.atlassian.jira.bc.issue.link.RemoteIssueLinkService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.SubTaskManager;
import com.atlassian.jira.event.issue.IssueEventBundleFactory;
import com.atlassian.jira.event.issue.IssueEventManager;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueInputParameters;
import com.atlassian.jira.issue.comments.CommentManager;
import com.atlassian.jira.issue.context.IssueContextImpl;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.FieldManager;
import com.atlassian.jira.issue.fields.config.manager.PrioritySchemeManager;
import com.atlassian.jira.issue.fields.screen.FieldScreenRendererFactory;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.security.xsrf.RequiresXsrfCheck;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.web.action.issue.AbstractIssueLinkAction;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.Priority;
import ru.rosbank.jira.sm.SMEntityType;
import ru.rosbank.jira.sm.listener.SMIssueCreatedListener;
import ru.rosbank.jira.sm.model.SmRBprobsummaryModel;

import javax.inject.Inject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


import static ru.rosbank.jira.sm.SMUtils.addSMLinks;
import static ru.rosbank.jira.sm.SMUtils.getSMNumbers;

public class LinkSMAction extends AbstractIssueLinkAction {

    private final IssueService issueService;
    private final ConfigLoader config;

    private final CommentManager commentManager;
    private final CustomFieldManager customFieldManager;

    private static final Logger LOG = LoggerFactory.getLogger(SMIssueCreatedListener.class);


    @Inject
    public LinkSMAction(@ComponentImport SubTaskManager subTaskManager,
                        @ComponentImport FieldScreenRendererFactory fieldScreenRendererFactory,
                        @ComponentImport FieldManager fieldManager,
                        @ComponentImport ProjectRoleManager projectRoleManager,
                        @ComponentImport CommentService commentService,
                        @ComponentImport UserUtil userUtil,
                        @ComponentImport RemoteIssueLinkService remoteIssueLinkService,
                        @ComponentImport EventPublisher eventPublisher,
                        @ComponentImport IssueEventManager issueEventManager,
                        @ComponentImport IssueEventBundleFactory issueEventBundleFactory,
                        @ComponentImport ConfigLoader config,
                        @ComponentImport CustomFieldManager customFieldManager,
                        @ComponentImport CommentManager commentManager,
                        IssueService issueService) {
        super(subTaskManager, fieldScreenRendererFactory, fieldManager, projectRoleManager, commentService, userUtil, remoteIssueLinkService, eventPublisher, issueEventManager, issueEventBundleFactory);
        this.customFieldManager = customFieldManager;
        this.commentManager = commentManager;
        this.issueService = issueService;
        this.config = config;
    }

    /**
     * Номера инцидентов, отображаемые в форме линковки
     *
     * @return
     */
    public String getDefaultIMValue() {
        Issue issueObject = this.getIssueObject();
        CustomField smNumberField = customFieldManager.getCustomFieldObject(config.getJiraSmNumberFieldId());
        String imValue = (String) issueObject.getCustomFieldValue(smNumberField);
        return getSMNumbers(imValue, "IM").stream().collect(Collectors.joining(","));
    }

    /**
     * Номера обращений, отображаемые в форме линковки
     *
     * @return
     */

    //Данный метод ни для чего пока что не используется
    public String getSDValues() {
        Issue issueObject = this.getIssueObject();
        CustomField smNumberField = customFieldManager.getCustomFieldObject(config.getJiraSmNumberFieldId());
        String imValue = (String) issueObject.getCustomFieldValue(smNumberField);
        return getSMNumbers(imValue, "SD").stream().collect(Collectors.joining(","));
    }

    @RequiresXsrfCheck
    protected String doExecute() {
        boolean hasChanges = false;
        Issue issue = this.getIssueObject();
        ApplicationUser user = this.getLoggedInUser();
        IssueInputParameters updateParameters = issueService.newIssueInputParameters();
        updateParameters.setSkipScreenCheck(true);

        // Get parameters
        List<String> iMValues = getSMNumbers(this.getHttpRequest().getParameter("iMValues"), SMEntityType.IM.name());
        List<String> sDValues = getSMNumbers(this.getHttpRequest().getParameter("sDValues"), SMEntityType.SD.name());
        Set<String> allSmValues = new TreeSet<>();
        String[] newImValues = {};

        if (!sDValues.isEmpty()) {
            allSmValues.addAll(sDValues);
        }

        if (!iMValues.isEmpty()) {
            newImValues = iMValues.toArray(String[]::new);
            allSmValues.addAll(iMValues);
        }

        Long smNumberFieldId = config.getJiraSmNumberFieldId();
        CustomField smNumberField = customFieldManager.getCustomFieldObject(smNumberFieldId);
        String currentSmSyncValue = (String) issue.getCustomFieldValue(smNumberField);

        // Если таска вообще не синхронизирована с SM, добавляем номер первого (если указан не один, а несколько)
        // наряда/инцидента, который указан в поле "Добавить номер наряда/инцидента в SM".
        if (Strings.isNullOrEmpty(currentSmSyncValue) && newImValues.length != 0) {
            hasChanges = true;
            if (smNumberFieldId != null) {
                updateParameters.addCustomFieldValue(smNumberFieldId, newImValues[0]);
            }
        }

        // Add SM Links
        if (!allSmValues.isEmpty()) {
            ApplicationUser loggedInUser = this.getLoggedInUser();
            for (SMEntityType smEntityType : SMEntityType.values()) {
                addSMLinks(issue, loggedInUser, allSmValues, smEntityType, config);
            }
        }

        // Sync task and incident. Get data from incident
        String iMSync = this.getHttpRequest().getParameter("iMSync");
        if (!Strings.isNullOrEmpty(iMSync) && !iMValues.isEmpty()) {
            hasChanges = true;

            List<SmRBprobsummaryModel> incidents = getIMData(iMValues, issue, user);
            if (incidents.size() == 1) {
                SmRBprobsummaryModel incident = incidents.get(0);
                if (incident != null && incident.getData() != null) {
                    // IT System
                    Long systemFieldId = config.getJiraItSystemFieldId();
                    String system = incident.getData().getItSystem();
                    if (!Strings.isNullOrEmpty(system) && systemFieldId != null) {
                        updateParameters.addCustomFieldValue(systemFieldId, system);
                    }

                    // IT Service
                    Long serviceFieldId = config.getJiraServiceFieldId();
                    String serviceCode = incident.getData().getService();
                    if (!Strings.isNullOrEmpty(serviceCode) && serviceFieldId != null) {
                        updateParameters.addCustomFieldValue(serviceFieldId, serviceCode);
                    }

                    // Start Date
                    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
                    Long startDateFieldId = config.getJiraStartDateFieldId();
                    Date completionTime = incident.getData().getCompletionTime();
                    if (startDateFieldId != null) {
                        updateParameters.addCustomFieldValue(startDateFieldId, completionTime != null ? sdf.format(completionTime) : null);
                    }

                    // Крайний срок в SM
                    SimpleDateFormat sdtf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                    Long smDeadlineFieldId = config.getJiraSmDeadlineFieldId();
                    Date smDeadLine = incident.getData().getDeadline();
                    if (smDeadlineFieldId != null) {
                        updateParameters.addCustomFieldValue(smDeadlineFieldId, smDeadLine != null ? sdtf.format(smDeadLine) : null);
                    }

                    // SM Priority
                    Priority priority = Priority.getBySmId(incident.getData().getPriority());
                    if (priority != null) {
                        List<String> priorities = ComponentAccessor.getComponent(PrioritySchemeManager.class)
                                .getOptions(new IssueContextImpl(issue.getProjectId(), issue.getIssueTypeId()));
                        String priorityJiraId = priority.getJiraId();
                        if (priorities.contains(priorityJiraId)) {
                            updateParameters.setPriorityId(priorityJiraId);
                        }
                    }

                    // TODO: Загрузка вложений
                }
            }
        }

        if (hasChanges) {
            this.createAndDispatchComment();

            // UPDATE
            IssueService.UpdateValidationResult updateValidationResult =
                    issueService.validateUpdate(user, issue.getId(), updateParameters);
            if (!updateValidationResult.getErrorCollection().hasAnyErrors()) {
                issueService.update(user, updateValidationResult);
            } else {
                String errors = updateValidationResult.getErrorCollection().getErrors()
                        .entrySet()
                        .stream()
                        .map(e -> e.getKey() + " -> " + e.getValue())
                        .collect(Collectors.joining(" | "));
                commentManager.create(issue, user, "Validation error: " + errors, false);
            }
        }
        return this.returnComplete(this.getRedirectUrl());
    }

    private List<SmRBprobsummaryModel> getIMData(List<String> iMValues, Issue issue, ApplicationUser user) {
        List<SmRBprobsummaryModel> res = new ArrayList<>();
        HttpClient client = new HttpClient();

        for (String imValue : iMValues) {
            try {
                String smUrl = config.getSmActionUrl() + "/RBprobsummaryAction/" + imValue;
                GetMethod getData = smGetMethod(smUrl);
                int responseCode = client.executeMethod(getData);
                if (responseCode >= 300) {
                    commentManager.create(issue, user,
                            "Во время загрузки данных из SM произошла ошибка. HTTP Code: " + responseCode, true);
                    continue;
                }
                SmRBprobsummaryModel incidentModel = null;
                try (InputStream in = getData.getResponseBodyAsStream()) {
                    GsonBuilder gsonBuilder = new GsonBuilder();
                    gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
                    final Gson gson = gsonBuilder.create();
                    final BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    incidentModel = gson.fromJson(reader, SmRBprobsummaryModel.class);
                }
                if (incidentModel != null) {
                    res.add(incidentModel);
                }
            } catch (Exception e) {
                String comment = "Во время загрузки вложений из SM произошла ошибка: " + e.getMessage();
                commentManager.create(issue, user, comment, true);
                LOG.error("SM attachment loading error", e);
            }
        }

        return res;
    }

    private GetMethod smGetMethod(String smUrl) {
        final GetMethod get = new GetMethod(smUrl);
        get.setRequestHeader("Authorization", "Basic " + config.getSmAuth());
        get.setRequestHeader("Content-Type", "application/json");
        get.setRequestHeader("charset", "UTF-8");
        return get;
    }
}
