package ru.rosbank.jira.sm.connector.message;

import com.atlassian.jira.issue.Issue;

/**
 * Инкапсулирует данные, необходимые для RPC HP SM
 */
public class SmMessage {

    /**
     * Полный URL, на который нужно отправить запрос
     */
    private final String targetEndpoint;

    /**
     * Отправляемые данные
     */
    private final String jsonData;

    /**
     * Используемый метод.
     * По факту - алиас для HTTP-методов (POST, PUT, GET, etc).
     */
    private final SmActionMethod actionMethod;

    /**
     * Задача, с которой связан запрос. Используется для добавления информации о результате
     * выполнения запроса (в эту задачу будут добавляться комментарии с соответсвующей информацией)
     * Комментарий об успешном выполнении запроса будет добавлен только тогда, когда поле
     * mustAddCommentInIssue = true
     */
    private final Issue linkedJiraIssue;

    /**
     * Обозначает необходимость добавления комментария в issue если запрос был выполнен успешно
     */
    private final boolean mustAddCommentInIssue;

    private final Long commentId;

    private final String taskAuthor;

    public SmMessage(String targetEndpoint,
                     String jsonData,
                     SmActionMethod actionMethod,
                     Issue linkedJiraIssue,
                     boolean mustAddCommentInIssue,
                     Long commentId, String taskAuthor) {
        this.targetEndpoint = targetEndpoint;
        this.jsonData = jsonData;
        this.actionMethod = actionMethod;
        this.linkedJiraIssue = linkedJiraIssue;
        this.mustAddCommentInIssue = mustAddCommentInIssue;
        this.commentId = commentId;
        this.taskAuthor = taskAuthor;
    }

    public String getTargetEndpoint() {
        return targetEndpoint;
    }

    public String getJsonData() {
        return jsonData;
    }

    public SmActionMethod getActionMethod() {
        return actionMethod;
    }

    public Issue getLinkedJiraIssue() {
        return linkedJiraIssue;
    }

    public boolean mustAddCommentInIssue() {
        return mustAddCommentInIssue;
    }

    // Jira-5595 Поле commentId позволяет определять, является сообщение в SM комментарием в задаче (commentId != 0L) или оно связано
    // с другим событием в Jira (commentId = 0L)
    public Long getCommentId() { return commentId; }

    public String getTaskAuthor() {
      return taskAuthor;
    }

    @Override
    public String toString() {
        return "SmMessage{\n" +
               "    targetEndpoint='" + targetEndpoint + "',\n" +
               "    jsonData='" + jsonData + "',\n" +
               "    actionMethod=" + actionMethod + ",\n" +
               "    linkedJiraIssue=" + linkedJiraIssue + ",\n" +
               "    mustAddCommentInIssue=" + mustAddCommentInIssue + "\n" +
               "    commentId=" + commentId + "\n" +
               "}";
    }

}
