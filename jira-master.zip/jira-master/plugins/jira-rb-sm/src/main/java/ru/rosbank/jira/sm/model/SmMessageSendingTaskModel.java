package ru.rosbank.jira.sm.model;

import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Объект задачи по отправке сообщения в HP SM.
 * Используется для вывода очереди сообщений в SM на UI Jira при переходе в пункт меню Service.
 */

public class SmMessageSendingTaskModel {

    private int id;

    private String actionMethod;

    private String jsonData;

    private String linkedIssueKey;

    private String targetEndPoint;

    private boolean verbose;

    private Date taskCreatedTime;

    private Date taskSentTime;

    private String smResponse;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getActionMethod() {
        return actionMethod;
    }

    public void setActionMethod(String actionMethod) {
        this.actionMethod = actionMethod;
    }

    public String getJsonData() {
        return jsonData;
    }

    public void setJsonData(String jsonData) {
        this.jsonData = jsonData;
    }

    public String getLinkedIssueKey() {
        return linkedIssueKey;
    }

    public void setLinkedIssueKey(String linkedIssueKey) {
        this.linkedIssueKey = linkedIssueKey;
    }

    public String getTargetEndPoint() {
        return targetEndPoint;
    }

    public void setTargetEndPoint(String targetEndPoint) {
        this.targetEndPoint = targetEndPoint;
    }

    public boolean isVerbose() {
        return verbose;
    }

    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    public Date getTaskCreatedTime() {
        return taskCreatedTime;
    }

    public void setTaskCreatedTime(Date taskCreatedTime) {
        this.taskCreatedTime = taskCreatedTime;
    }

    public Date getTaskSentTime() {
        return taskSentTime;
    }

    public void setTaskSentTime(Date taskSentTime) {
        this.taskSentTime = taskSentTime;
    }

    public String getSmResponse() {
        return smResponse;
    }

    public void setSmResponse(String smResponse) {
        this.smResponse = smResponse;
    }

    public static List<SmMessageSendingTaskModel> convert(SmMessageSendingTaskEntity[] items) {
        List<SmMessageSendingTaskModel> smMessageSendingTaskModelList = new ArrayList<>();
        for (int i = 0; i < items.length; i ++) {
            SmMessageSendingTaskModel smMessageSendingTaskModel = new SmMessageSendingTaskModel();
            smMessageSendingTaskModel.setId(items[i].getID());
            smMessageSendingTaskModel.setActionMethod(items[i].getActionMethod().toString());
            smMessageSendingTaskModel.setJsonData(items[i].getJsonData());
            smMessageSendingTaskModel.setLinkedIssueKey(items[i].getLinkedIssueKey());
            smMessageSendingTaskModel.setTargetEndPoint(items[i].getTargetEndpoint());
            smMessageSendingTaskModel.setTaskCreatedTime(items[i].getTaskCreatedTime());
            smMessageSendingTaskModel.setVerbose(items[i].getVerbose());
            smMessageSendingTaskModel.setTaskSentTime(items[i].getTaskSentTime());
            smMessageSendingTaskModel.setSmResponse(items[i].getSmResponse());
            smMessageSendingTaskModelList.add(smMessageSendingTaskModel);
        }
        return smMessageSendingTaskModelList;
    }


}
