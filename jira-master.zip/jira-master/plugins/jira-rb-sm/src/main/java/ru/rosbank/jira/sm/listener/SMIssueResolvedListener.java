package ru.rosbank.jira.sm.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventDispatchOption;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.resolution.Resolution;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.ProjectPropertyConstants;
import ru.rosbank.jira.common.api.ProjectPropertyModel;
import ru.rosbank.jira.common.api.ProjectPropertyService;
import ru.rosbank.jira.sm.ao.SmWorkGroup;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.api.SmWorGroupService;
import ru.rosbank.jira.sm.SmResolutionCode;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;
import ru.rosbank.jira.sm.model.SmRBprobsummaryModel;
import ru.rosbank.jira.sm.model.SmRBrequestTaskModel;

import javax.inject.Inject;

import static com.google.common.base.Preconditions.checkNotNull;

@Component
public class SMIssueResolvedListener extends AbstractSMIssueListener implements InitializingBean, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(SMIssueResolvedListener.class);

    private final EventPublisher eventPublisher;

    private final ProjectPropertyService projectPropertyService;

    private final ConfigLoader config;

    private final CustomFieldManager customFieldManager;

    private final SmWorGroupService smWorGroupService;

    private final IssueManager issueManager;

    private final SmService smService;

    @Inject
    public SMIssueResolvedListener(
            @ComponentImport EventPublisher eventPublisher,
            @ComponentImport ProjectPropertyService projectPropertyService,
            @ComponentImport CustomFieldManager customFieldManager,
            @ComponentImport ConfigLoader config,
            @ComponentImport IssueManager issueManager,
            SmWorGroupService smWorGroupService,
            SmService smService) {
        super(customFieldManager , config);
        this.eventPublisher = checkNotNull(eventPublisher);
        this.projectPropertyService = projectPropertyService;
        this.config = checkNotNull(config);
        this.customFieldManager = customFieldManager;
        this.smWorGroupService = smWorGroupService;
        this.issueManager = issueManager;
        this.smService = smService;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling listener {}", SMIssueResolvedListener.class);
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling listener {}", SMIssueResolvedListener.class);
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {

        Long eventTypeId = issueEvent.getEventTypeId();
        if (!eventTypeId.equals(EventType.ISSUE_RESOLVED_ID)) {
            return;
        }

        // JIRA-6123 Проверка, отправлялось ли решение по задаче в SM ранее.
        MutableIssue issue = (MutableIssue) issueEvent.getIssue();
        CustomField syncedWithSmStatusField = customFieldManager.getCustomFieldObject(config.getSyncedWithSmStatusFieldId());
        String syncedWithSmStatusFieldValueFromIssue =  (String) syncedWithSmStatusField.getValue(issue);
        String syncedWithSmStatusFieldValueFromConfig = config.getSyncedWithSmStatusFieldValue();
        if (!Strings.isNullOrEmpty(syncedWithSmStatusFieldValueFromIssue) &&
                syncedWithSmStatusFieldValueFromIssue.equalsIgnoreCase(syncedWithSmStatusFieldValueFromConfig)) {
            return;
        }

        LOG.info("Issue {} has been resolved at {}.", issue.getKey(), issue.getResolutionDate());

        if (!smService.isSmIssueSource(issue) && !issue.getKey().contains("PRB")) {
            return;
        }

        String smNumber = getSyncSmNumber(issue);
        if (Strings.isNullOrEmpty(smNumber)) {
            return;
        }

        String statusName = issue.getStatus().getName();

        StringBuilder reasonSb = new StringBuilder();
        reasonSb.append("Добрый день! Связанная с Вашим обращением задача в Jira с номером: ").append(issue.getKey()).append(" ");
        reasonSb.append("завершилась со статусом: ").append(statusName).append(".");
        String reason = reasonSb.toString();

        // Resolved
        Resolution resolution = issue.getResolution();
        if (resolution == null) {
            return;
        }

        String resolutionName = resolution.getName();
        if (Strings.isNullOrEmpty(resolutionName)) {
            return;
        }

        StringBuilder smResolution = new StringBuilder();
        String assignee = issue.getAssignee() != null ? issue.getAssignee().getName() : "";

        // Добавлен комментарий к решению
        Comment comment = issueEvent.getComment();
        boolean hasComment = false;
        if (comment != null) {
            smResolution
                    .append("Комментарий исполнителя: ")
                    .append(comment.getBody());
            hasComment = true;
        } else {
            smResolution.append("Выполнено");
        }

        //Получение информации о группе для переназначения инцидента/наряда
        Long smWorkGroupFieldId = config.getSmWorkGroupFieldId();
        CustomField smWorkGroupField = customFieldManager.getCustomFieldObject(smWorkGroupFieldId);
        String smWorkGroupFieldValue = (String) smWorkGroupField.getValue(issue);
        String smWorkGroupCode;

        if (Strings.isNullOrEmpty(smWorkGroupFieldValue)) {
            smWorkGroupCode = "";
        } else {
            SmWorkGroup smWorkGroup = smWorGroupService.getByName(smWorkGroupFieldValue);
            if (smWorkGroup != null) {
                smWorkGroupCode = smWorGroupService.getByName(smWorkGroupFieldValue).getCode();
            } else {
                smWorkGroupCode = "";
            }
        }

        if (smNumber.contains("IM")) {
            onSmIncidentResolved(issue,  statusName, smNumber, reason, resolutionName, smResolution, assignee, hasComment,
                    smWorkGroupCode, issueEvent);
        } else {
            onSmOrderResolved(issue, statusName, smNumber, resolutionName, smResolution, assignee, hasComment,
                    smWorkGroupCode, issueEvent);
        }

        // JIRA-6123 Проставляем признак отправки решения в SM
        issue.setCustomFieldValue(syncedWithSmStatusField, syncedWithSmStatusFieldValueFromConfig);
        issueManager.updateIssue(issueEvent.getUser(), issue, EventDispatchOption.ISSUE_UPDATED, false);

    }

    // Если Issue связана с нарядом RFT в SM
    private void onSmOrderResolved(MutableIssue issue, String statusName, String smNumber,
                                   String resolutionName, StringBuilder smResolution, String assignee, boolean hasComment,
                                   String smWorkGroupCodeValue, IssueEvent issueEvent) {
        SmRBrequestTaskModel.SmRBrequestTaskActionModel taskActionModel = new SmRBrequestTaskModel.SmRBrequestTaskActionModel(
                statusName,
                assignee,
                smResolution.toString()
        );

        if (!Strings.isNullOrEmpty(smWorkGroupCodeValue)) {
            taskActionModel.setGroup(smWorkGroupCodeValue);
        }

        String smUrl = "/RBrequestTaskAction/" + smNumber;

        if (resolutionName.equalsIgnoreCase("Done") || resolutionName.equalsIgnoreCase("Fixed")) {

            // JIRA-2002 & JIRA-2072
            ProjectPropertyModel property = projectPropertyService
                    .search(issue.getProjectObject().getId(), ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION);
            String propertyValue = property == null ?
                    ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION_EXECUTE : property.getValue();
            smUrl = smUrl + "/action/" + propertyValue;
            taskActionModel.setResolutionCode(SmResolutionCode.COMPLETED_SUCCESSFULLY);

        } else {
            // Other resolutions
            smUrl = smUrl + "/action/" + ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION_EXECUTE;
            taskActionModel.setResolutionCode(SmResolutionCode.INCORRECT_ROUTING);
        }

        Gson gson = new Gson();
        String json = gson.toJson(new SmRBrequestTaskModel(taskActionModel));
        LOG.debug("Тело наряда RFT с номером {} выглядит так: {}", smNumber, json);

        if (json != null) {
            SmMessage smMessage = new SmMessageBuilder()
                    .toEndpoint(smUrl)
                    .withData(json)
                    .linkedJiraIssue(issue)
                    .usingMethod(SmActionMethod.POST)
                    .mustAddCommentInIssue(true)
                    .commentId(0L)
                    .taskAuthor(issueEvent.getUser().getUsername())
                    .build();
            smService.saveSmMessage(smMessage);
        }
    }

    // Если Issue связана с инцидентом IM в SM
    private void onSmIncidentResolved(MutableIssue issue, String statusName, String smNumber,
                                      String reason, String resolutionName, StringBuilder smResolution, String assignee, boolean hasComment,
                                      String smWorkGroupCodeValue, IssueEvent issueEvent) {
        SmRBprobsummaryModel.SmRBprobsummaryActionModel summaryActionModel = new SmRBprobsummaryModel.SmRBprobsummaryActionModel(
                statusName,
                assignee,
                reason,
                smResolution.toString()
        );

        if (!Strings.isNullOrEmpty(smWorkGroupCodeValue)) {
            summaryActionModel.setGroup(smWorkGroupCodeValue);
        }

        // JIRA-3021
        // «Reason» - Причина
        Long smCauseReasonFieldId = config.getJiraSmCauseReasonFieldId();
        if (smCauseReasonFieldId != null) {
            CustomField smCauseReasonField = customFieldManager.getCustomFieldObject(smCauseReasonFieldId);
            if (smCauseReasonField != null) {
                String smCauseReason = (String) issue.getCustomFieldValue(smCauseReasonField);
                if (!Strings.isNullOrEmpty(smCauseReason)) {
                    summaryActionModel.setCauseReason(smCauseReason);
                }
            }
        }

        String smUrl = "/RBprobsummaryAction/" + smNumber;
        if (resolutionName.equalsIgnoreCase("Done") || resolutionName.equalsIgnoreCase("Fixed")) {

            // JIRA-2002 & JIRA-2072
            ProjectPropertyModel property = projectPropertyService
                    .search(issue.getProjectObject().getId(), ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION);
            String propertyValue = property == null ?
                    ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION_EXECUTE : property.getValue();
            smUrl = smUrl + "/action/" + propertyValue;

            //JIRA-3061
            //«ResolutionCode» - Код закрытия. Значения: Решено, Решено с комментарием, Не актуально
            if (hasComment) {
                summaryActionModel.setResolutionCode("Решено с комментарием");
            } else {
                summaryActionModel.setResolutionCode("Решено");
            }
        } else {
            // Other resolutions
            smUrl = smUrl + "/action/" + ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION_REASSIGN;
        }

        Gson gson = new Gson();
        String json = gson.toJson(new SmRBprobsummaryModel(summaryActionModel));
        if (json != null) {
            SmMessage smMessage = new SmMessageBuilder()
                    .toEndpoint(smUrl)
                    .withData(json)
                    .linkedJiraIssue(issue)
                    .usingMethod(SmActionMethod.POST)
                    .mustAddCommentInIssue(true)
                    .commentId(0L)
                    .taskAuthor(issueEvent.getUser().getUsername())
                    .build();
            LOG.debug("SM Message resolved: {}", smMessage.toString());
            smService.saveSmMessage(smMessage);
        }
    }

}
