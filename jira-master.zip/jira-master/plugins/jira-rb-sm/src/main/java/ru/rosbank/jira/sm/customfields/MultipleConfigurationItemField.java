package ru.rosbank.jira.sm.customfields;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.customfields.ProjectImportLabelFieldParser;
import com.atlassian.jira.issue.customfields.impl.LabelsCFType;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutItem;
import com.atlassian.jira.issue.fields.rest.json.beans.JiraBaseUrls;
import com.atlassian.jira.issue.label.Label;
import com.atlassian.jira.issue.label.LabelManager;
import com.atlassian.jira.issue.label.LabelUtil;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ProjectPropertyService;
import ru.rosbank.jira.sm.api.ConfigurationItemService;
import ru.rosbank.jira.sm.model.ConfigurationItemModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static ru.rosbank.jira.common.api.ProjectPropertyConstants.SYSTEMS_CONTEXT;

public class MultipleConfigurationItemField extends LabelsCFType {
    private static final Logger LOG = LoggerFactory.getLogger(MultipleConfigurationItemField.class);

    private final ProjectPropertyService projectPropertyService;
    private final ConfigurationItemService ciService;

    public static final String CODE_MULTI_SEPARATOR = " ";
    public static final String NAME_MULTI_SEPARATOR = "#@#";

    public MultipleConfigurationItemField(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport IssueManager issueManager,
            @ComponentImport GenericConfigManager genericConfigManager,
            @ComponentImport LabelUtil labelUtil,
            @ComponentImport LabelManager labelManager,
            @ComponentImport ProjectImportLabelFieldParser projectImportableCustomFieldParser,
            @ComponentImport JiraBaseUrls jiraBaseUrls,
            @ComponentImport ProjectPropertyService projectPropertyService,
            ConfigurationItemService ciService) {
        super(authenticationContext, issueManager, genericConfigManager, labelUtil, labelManager, projectImportableCustomFieldParser, jiraBaseUrls);
        this.projectPropertyService = projectPropertyService;
        this.ciService = ciService;
    }

    @Override
    public Map<String, Object> getVelocityParameters(final Issue issue,
                                                     final CustomField field,
                                                     final FieldLayoutItem fieldLayoutItem) {
        final Map<String, Object> map = super.getVelocityParameters(issue, field, fieldLayoutItem);
        map.put("esc", new EscapeTool());
        map.put("type", this.getDescriptor().getParams().get("type"));

        Object itemCodes;
        if (issue != null) {
            if (issue.isCreated()) {
                itemCodes = this.getValueFromIssue(field, issue);
            } else {
                itemCodes = this.getDefaultValue(field.getRelevantConfig(issue));
            }

            if (projectPropertyService.search(issue.getProjectId(), SYSTEMS_CONTEXT) != null) {
                map.put("project", issue.getProjectId());
            }
        } else {
            // NULL
            itemCodes = map.get("value");
        }

        if (itemCodes != null) {
            List<ConfigurationItemModel> res = new ArrayList<>();
            try {
                for (Label itemCode : (Set<Label>) itemCodes) {
                    ConfigurationItemModel item = ConfigurationItemModel.convert(ciService.getByCode(itemCode.getLabel()));
                    res.add(item);
                }
                map.put("value", res);
            } catch (NullPointerException ex) {
                LOG.error("Configuration item rendering exception: {}", ex.getMessage());
            }
            map.put("valueCodes", res.stream().map(ConfigurationItemModel::getCode).collect(Collectors.joining(CODE_MULTI_SEPARATOR)));
            map.put("valueNames", res.stream().map(ConfigurationItemModel::getName).collect(Collectors.joining(NAME_MULTI_SEPARATOR)));
        } else {
            map.remove("value");
        }
        return map;
    }
}