package ru.rosbank.jira.sm.connector.connection;

import org.apache.commons.httpclient.HttpClient;

public interface SmHttpClientBuilder {
    HttpClient buildHttpClient();
}
