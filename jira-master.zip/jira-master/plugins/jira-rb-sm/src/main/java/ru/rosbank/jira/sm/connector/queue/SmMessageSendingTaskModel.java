package ru.rosbank.jira.sm.connector.queue;

import ru.rosbank.jira.sm.connector.message.SmMessage;

import java.util.Date;

/**
 * Объект задачи по отправке сообщения в HP SM.
 * Инкапсулирует сообщение, которое нужно отправить, и класс колбэка, который нужно выполнить после получения результата
 * отправки.
 */
public class SmMessageSendingTaskModel {

    private final Integer id;
    private final Date taskCreatedTime;
    private final Date taskSentTime;
    private final SmMessage message;

    private final Long failedSyncCommentId;

    public SmMessageSendingTaskModel(Integer id, Date taskCreatedTime, Date taskSentTime, SmMessage message, Long failedSyncCommentId) {
        this.id = id;
        this.taskCreatedTime = taskCreatedTime;
        this.taskSentTime = taskSentTime;
        this.message = message;
        this.failedSyncCommentId = failedSyncCommentId;
    }

    public Integer getId() {
        return id;
    }

    public Date getTaskCreatedTime() {
        return taskCreatedTime;
    }

    public Date getTaskSentTime() {
        return taskSentTime;
    }

    public SmMessage getMessage() {
        return message;
    }

    public Long getFailedSyncCommentId() {
        return failedSyncCommentId;
    }


    @Override
    public String toString() {
        return "SmMessageSendingTaskModel{\n" +
                "    taskCreatedTime=" + taskCreatedTime + ",\n" +
                "    message=" + message.toString().replaceAll("\n", "\n    ") + ",\n" + "}";
    }

}
