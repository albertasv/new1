package ru.rosbank.jira.sm.connector.connection;

import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.gson.*;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.sm.SMUtils;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.logging.SmMessagesLogging;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.model.*;

import javax.inject.Inject;
import java.io.IOException;

import static com.google.common.base.Preconditions.checkNotNull;
import static ru.rosbank.jira.sm.SMUtils.*;

/**
 * Реализация коннектора к сервису HP SM. Инкапсулирует всё "низкоуровневое" общение с HP SM по http протоколу.
 */
@Component
@Scope("prototype")
public class HttpSmConnector {


    private final ConfigLoader config;

    private final UserManager userManager;

    private final SmHttpClientBuilder httpClientBuilder;

    private final HttpMethodBuilder methodBuilder;

    private final SmMessagesLogging smMessagesLogging; //JIRA-5563 Отдельное логирование попыток отправки сообщений в SM

    private final SmService smService;

    private final SmAttachmentSender smAttachmentSender;

    private final Logger log = LoggerFactory.getLogger(HttpSmConnector.class);


    @Inject
    public HttpSmConnector(@ComponentImport ConfigLoader config,
                           @ComponentImport UserManager userManager,
                           SmHttpClientBuilder httpClientBuilder,
                           HttpMethodBuilder methodBuilder,
                           SmMessagesLogging smMessagesLogging, SmService smService, SmAttachmentSender smAttachmentSender) {
        this.config = checkNotNull(config);
        this.userManager = userManager;
        this.httpClientBuilder = httpClientBuilder;
        this.methodBuilder = methodBuilder;
        this.smMessagesLogging = smMessagesLogging;
        this.smService = smService;
        this.smAttachmentSender = smAttachmentSender;
    }

    public SmResponseStatus sendMessage(int taskId, SmMessage message) {

        String requestJsonObject = fixGtLtAmpChars(message.getJsonData());
        HttpMethod httpMethod = methodBuilder.buildMethod(message.getActionMethod(), message.getTargetEndpoint(), requestJsonObject);
        SmIssueType smIssueType = SMUtils.findSmIssueTypeFromEndpointUrl(message.getTargetEndpoint());
        ApplicationUser syncUser = userManager.getUserByName(config.getJiraSmUser());

        if (httpMethod == null) {
            return SmResponseStatus.SM_UNSUPPORTED_SERVICE_METHOD;
        }

        HttpServiceResponse httpSmServiceResponse;
        String smResponseBody;

        try {
            smMessagesLogging.logJiraToSmMessage("Attempt to send message to SM: ", message.toString());
            httpSmServiceResponse = executeServiceMethod(httpMethod);
            smResponseBody = httpSmServiceResponse.getResponseBody();
            smService.saveSmResponse(taskId, smResponseBody);
            if (message.getCommentId() != 0) {
                processSmCommentForAttachments(smResponseBody, message.getJsonData());
            }
        } catch (IOException ioex) {
            smMessagesLogging.logJiraToSmMessage("Some error with SM message sending or connection: ", ioex.getMessage());
            return SmResponseStatus.SM_SERVICE_CONNECTIVITY_ERROR;
        }
        smMessagesLogging.logJiraToSmMessage("SM service response is: ", httpSmServiceResponse.getResponseBody()
                + "; Response code: " +  httpSmServiceResponse.getResponseCode());

        if (Strings.isNullOrEmpty(httpSmServiceResponse.getResponseBody())) {
            smMessagesLogging.logJiraToSmMessage("Can't parse response from HP SM: ", httpSmServiceResponse.getResponseBody());
            return SmResponseStatus.SM_SERVICE_FAILURE;
        }

        SmServiceResponse structuredSmServiceResponse = parseHttpSmServiceResponse(httpSmServiceResponse, smIssueType);

        int returnCode = 0;
        if (structuredSmServiceResponse != null) {
            returnCode = structuredSmServiceResponse.getReturnCode();
        }

        if (httpSmServiceResponse.getResponseCode() >= 300) {
            if (returnCode == 70) {
                return SmResponseStatus.SM_ISSUE_ALREADY_RESOLVED;
            } else if (httpSmServiceResponse.getResponseCode() == 500) {
                addSmDeliveryStatusMessageIfComment(syncUser, message, false);
                return SmResponseStatus.SM_SERVICE_FAILURE;
            } else {
                addSmDeliveryStatusMessageIfComment(syncUser, message, false);
                return SmResponseStatus.SM_UNKNOWN_ERROR;
            }
        } else {
            if (message.mustAddCommentInIssue()) {
                addResolvedMessageInComment(message.getLinkedJiraIssue(), syncUser);
            } else {
                addSmDeliveryStatusMessageIfComment(syncUser, message, true);
            }
        }
        return SmResponseStatus.SM_ISSUE_UPDATE_SUCCESSFULLY;
    }

    private HttpServiceResponse executeServiceMethod(HttpMethod method) throws IOException {
        // TODO: Добавить блок try catch и запись ошибки по тайм ауту в лог
        HttpClient client = httpClientBuilder.buildHttpClient();
        client.getParams().setSoTimeout(120000);
        int responseCode = client.executeMethod(method);
        String responseBody = method.getResponseBodyAsString().replaceAll("; Response code: \\d*", "");
        return new HttpServiceResponse(responseCode, responseBody);
    }

    private SmServiceResponse parseHttpSmServiceResponse(HttpServiceResponse serviceResponse, SmIssueType issueType) {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
        try {
            return issueType == SmIssueType.INCIDENT
                    ? gson.fromJson(serviceResponse.getResponseBody(), SmRBprobsummaryModel.class)  // Если отправляли данные в инцидент
                    : gson.fromJson(serviceResponse.getResponseBody(), SmRBrequestTaskModel.class); // Если отправляли данные в наряд
        } catch (JsonParseException ignore) {
            return null;
        }
    }

    private void processSmCommentForAttachments(String smResponseBodyFromProtocolRecord, String requestJsonData) {
        try {
            JsonObject jsonSmResponseBody = new JsonParser().parse(smResponseBodyFromProtocolRecord).getAsJsonObject();
            String protocolRecordId = jsonSmResponseBody.getAsJsonObject("RBprotocolSendNewMsg").get("ID").getAsString();
            smAttachmentSender.sendAttachmentToSm(protocolRecordId, requestJsonData);
        } catch (Exception e) {
            log.error("Some error in processSmCommentAttachments method: ", e);
        }
    }
}
