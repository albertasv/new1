package ru.rosbank.jira.sm;

public enum SMEntityType {
    IM, SD, RFT
}
