package ru.rosbank.jira.sm.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "reasonResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class SmReasonResultModel {
    private List<SmReasonModel> items;
    private int total;

    public SmReasonResultModel() {
    }

    public SmReasonResultModel(List<SmReasonModel> items, int total) {
        this.items = items;
        this.total = total;
    }

    public List<SmReasonModel> getItems() {
        return items;
    }

    public void setItems(List<SmReasonModel> items) {
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
