package ru.rosbank.jira.sm.connector.exception;

public class SmSendingTaskRestorationException extends Exception {
}
