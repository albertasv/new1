package ru.rosbank.jira.sm.model;

import javax.xml.bind.annotation.*;

@XmlRootElement(name = "createIssueResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class SmCreateIssueResultModel {

    private Long issueId;
    private String issueKey;
    private String message;

    public SmCreateIssueResultModel() {
    }

    public Long getIssueId() {
        return issueId;
    }

    public void setIssueId(Long issueId) {
        this.issueId = issueId;
    }

    public String getIssueKey() {
        return issueKey;
    }

    public void setIssueKey(String issueKey) {
        this.issueKey = issueKey;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}