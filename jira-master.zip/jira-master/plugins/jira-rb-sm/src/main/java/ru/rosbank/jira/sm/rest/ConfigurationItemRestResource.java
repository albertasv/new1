package ru.rosbank.jira.sm.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.sm.ao.ConfigurationItem;
import ru.rosbank.jira.sm.api.ConfigurationItemService;
import ru.rosbank.jira.sm.api.SmService;
import ru.rosbank.jira.sm.model.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * REST API класс для обновления справочника ИТ-систем. Так как мастер справочник ИТ-систем находится в SM, то при его
 * обновлении SM отсылает обновлённые данные в наш справочник.
 */
@Path("/ci")
public class ConfigurationItemRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationItemRestResource.class);
    private static final int PAGE_MAX = 10;

    private final ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final JiraAuthenticationContext authenticationContext;
    private final ConfigLoader config;
    private ConfigurationItemService ciService;
    private SmService smService;

    public ConfigurationItemRestResource(
            @ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider, @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport ConfigLoader config,
            ConfigurationItemService ciService,
            SmService smService) {
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
        this.authenticationContext = checkNotNull(authenticationContext);
        this.config = checkNotNull(config);
        this.ciService = ciService;
        this.smService = smService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/search/{type}")
    public Response search(
            @PathParam("type") String type,
            @QueryParam("q") String query,
            @QueryParam("all") Boolean all,
            @QueryParam("project") Long project,
            @QueryParam("page") int page) {
        List<ConfigurationItemModel> res = new ArrayList<>();
        ConfigurationItemType ciType = ConfigurationItemType.getType(type);
        if (ciType != null) {
            for (ConfigurationItem ci : ciService.search(type, query, project, Boolean.TRUE.equals(all),
                    PAGE_MAX, (page - 1) * PAGE_MAX)) {
                res.add(ConfigurationItemModel.convert(ci));
            }
            int total = ciService.total(type, query, project, Boolean.TRUE.equals(all));
            return Response.ok(new ConfigurationItemResultModel(res, total)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/search2/{type}")
    public Response search2(
            @PathParam("type") String type,
            @QueryParam("q") String query,
            @QueryParam("page") int page) {
        if (type != null) {
            switch (type) {
                case "reason":
                    List<SmReasonModel> res = smService.searchReason(query, PAGE_MAX, (page - 1) * PAGE_MAX)
                            .stream().map(SmReasonModel::convert).collect(Collectors.toList());
                    int total = smService.totalReason(query);
                    return Response.ok(new SmReasonResultModel(res, total)).build();
            }
        }

        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/search/{type}/{code}")
    public Response search(
            @PathParam("type") String type,
            @PathParam("code") String code
    ) {
        ConfigurationItemType ciType = ConfigurationItemType.getType(type);
        if (ciType != null) {
            ConfigurationItem ci = ciService.getByCode(code);
            if (ci != null) {
                ConfigurationItemModel ciModel = ConfigurationItemModel.convert(ci);

                ciModel.setDomain(ci.getDomain());
                ciModel.setOwner(ci.getOwner());
                ciModel.setOwnerResponsible(ci.getOwnerResponsible());
                ciModel.setTeam(ci.getTeam());
                ciModel.setTeamResponsible(ci.getTeamResponsible());
                ciModel.setManager(ci.getManager());
                ciModel.setIsOfficer(ci.getIsOfficer());

                ciModel.setRegisterDate(ci.getRegisterDate());
                ciModel.setStartDevDate(ci.getStartDevDate());
                ciModel.setStartOperationDate(ci.getStartOperationDate());
                ciModel.setStartOutOfService(ci.getStartOutOfService());
                ciModel.setOutOfServiceDate(ci.getOutOfServiceDate());

                ciModel.setComment(ci.getComment());
                ciModel.setLastUpdateDate(ci.getLastUpdateDate());
                ciModel.setLastSyncDate(ci.getLastSyncDate());
                ciModel.setSensitivity(ci.getSensitivity());
                ciModel.setActualRpo(ci.getActualRpo());
                ciModel.setActualRto(ci.getActualRto());
                ciModel.setProcessCriticality(ci.getProcessCriticality());
                return Response.ok(ciModel).build();
            }
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/{type}")
    public Response update(@PathParam("type") String type, List<ConfigurationItemModel> cis) {
        StringBuilder errorLog = new StringBuilder();
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        if (!config.getJiraSmUser().equalsIgnoreCase(loggedInUser.getUsername())) {
            externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_IT_SYSTEMS_UPDATER
                    , Statuses.FAILED
                    , Response.Status.FORBIDDEN.getReasonPhrase()
                    , new Date());
            return Response.status(Response.Status.FORBIDDEN).build();
        }

        ConfigurationItemType ciType = ConfigurationItemType.getType(type);
        for (ConfigurationItemModel ci : cis) {
            switch (ciType) {
                case SYSTEM:
                case SERVICE:
                    String error = update(ciType, ci);
                    if (!Strings.isNullOrEmpty(error)) {
                        errorLog.append(error).append(";\n");
                    }
                    break;
                default:
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
            }
        }
        if (!Strings.isNullOrEmpty(errorLog.toString())) {
            externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_IT_SYSTEMS_UPDATER
                    , Statuses.UPDATED_WITH_ERRORS
                    , errorLog.toString()
                    , new Date());
            return Response.ok("Errors during CI's updating").build();
        }
        externalServiceSyncStatusProvider.writeStatus(ServiceNames.SM_IT_SYSTEMS_UPDATER
                , Statuses.UPDATED
                , Statuses.UPDATED.getMessage()
                , new Date());
        return Response.ok(Response.Status.OK).build();
    }

    private String update(ConfigurationItemType type, ConfigurationItemModel ciModel) {
        ConfigurationItem ci = ciService.getByCode(ciModel.getCode());
        if (ci == null) {
            // add
            return ciService.add(type, ciModel);
        }
        // update
        return ciService.update(ciModel);
    }
}