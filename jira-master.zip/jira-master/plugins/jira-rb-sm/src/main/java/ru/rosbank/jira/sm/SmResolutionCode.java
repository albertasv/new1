package ru.rosbank.jira.sm;

/**
 * Набор кодов закрытия нарядов в HP SM.
 *
 * @see <a href="https://kb.rosbank.rus.socgen/pages/viewpage.action?pageId=404096112">Интеграция JIRA-HPSM. Описание веб-сервисов v.2.0</a>
 */
public enum SmResolutionCode {

    COMPLETED_SUCCESSFULLY(10),
    COMPLETED_SUCCESSFULLY_WITH_COMMENT(50),
    CANT_BE_DONE(20),
    NOT_ACTUAL(30),
    ROLLED_BACK(40),
    INSUFFICIENT_INFORMATION(60),
    INCORRECT_ROUTING(70);

    private final int code;

    SmResolutionCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

}
