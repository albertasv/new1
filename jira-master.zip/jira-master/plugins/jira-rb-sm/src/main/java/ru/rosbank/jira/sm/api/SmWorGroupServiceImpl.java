package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.common.exceptions.SmWorkGroupCreationException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupSearchingException;
import ru.rosbank.jira.common.exceptions.SmWorkGroupUpdatingException;
import ru.rosbank.jira.sm.ao.SmWorkGroup;
import ru.rosbank.jira.sm.model.SmWorkGroupModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * DAO класс для работы с таблицей, в которой хранятся рабочие группы из SM
 */

@Named("smWorGroupService")
public class SmWorGroupServiceImpl implements SmWorGroupService {

    ActiveObjects ao;

    @Inject
    public SmWorGroupServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = ao;
    }

    @Override
    public List<SmWorkGroup> search(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupSearchingException {
        try {
        return Arrays.stream(ao.find(SmWorkGroup.class,
                Query.select().where("CODE = ?", smWorkGroupModel.getCode()))).collect(Collectors.toList());
        } catch (Exception e) {
            throw new SmWorkGroupSearchingException(e.getMessage(), e.getStackTrace());
        }
    }

    public List<SmWorkGroup> search(String query) {
            return Arrays.asList(ao.find(SmWorkGroup.class, Query.select().where("LOWER(\"NAME\") LIKE LOWER(?) OR LOWER(\"CODE\") LIKE LOWER(?)",
                    "%" + query + "%",  "%" + query + "%")));
    }

    @Override
    public List<SmWorkGroup> searchAll() {
        return Arrays.asList(ao.find(SmWorkGroup.class, Query.select()
                .where("\"BLOCKED\" = ? " +
                "AND \"WORK_IM\" = ?", false, true)));
    }

    @Override
    public List<SmWorkGroup> search(int limit, int offset) {
        return Arrays.asList(ao.find(SmWorkGroup.class, Query.select()
                .where("\"BLOCKED\" = ? " +
                "AND \"WORK_IM\" = ?", false, true)
                .limit(limit)
                .offset(offset)));
    }


    @Override
    public void update(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupUpdatingException {
        try {
            SmWorkGroup smWorkGroup = getByCode(smWorkGroupModel.getCode());
            smWorkGroup.setCode(smWorkGroupModel.getCode());
            smWorkGroup.setName(smWorkGroupModel.getName());
            smWorkGroup.setManagerLogin(smWorkGroupModel.getManagerLogin());
            smWorkGroup.setWorkIm(smWorkGroupModel.isWorkIm());
            smWorkGroup.setWorkRft(smWorkGroupModel.isWorkRft());
            smWorkGroup.setBlocked(smWorkGroupModel.isBlocked());
            smWorkGroup.setLastSyncDate(new Date());
            smWorkGroup.save();
        } catch (Exception e) {
            throw new SmWorkGroupUpdatingException(e.getMessage(), e.getStackTrace());
        }
    }

    @Override
    public void create(SmWorkGroupModel smWorkGroupModel) throws SmWorkGroupCreationException {
        try {
            ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                    .put("CODE", smWorkGroupModel.getCode())
                    .put("NAME", smWorkGroupModel.getName())
                    .put("MANAGER_LOGIN", smWorkGroupModel.getManagerLogin())
                    .put("WORK_IM", smWorkGroupModel.isWorkIm())
                    .put("WORK_RFT", smWorkGroupModel.isWorkRft())
                    .put("BLOCKED", smWorkGroupModel.isBlocked())
                    .put("LAST_SYNC_DATE", new Date());
            ao.create(SmWorkGroup.class, mapBuilder.build());
        } catch (Exception e) {
            throw new SmWorkGroupCreationException(e.getMessage(), e.getStackTrace());
        }
    }


    @Override
    public SmWorkGroup getByCode(String code) {
        SmWorkGroup[] smWorkGroup = ao.find(SmWorkGroup.class, Query.select().where("\"CODE\" = ?",code));
            if (smWorkGroup.length >= 1) {
                return smWorkGroup[0];
            }
            return null;
    }

    @Override
    public SmWorkGroup getByName(String name) {
        SmWorkGroup[] smWorkGroup = ao.find(SmWorkGroup.class, Query.select().where("\"NAME\" = ?",name));
        if (smWorkGroup.length >= 1) {
            return smWorkGroup[0];
        }
        return null;
    }

    @Override
    public int total() {
        return ao.count(SmWorkGroup.class, Query.select().where("\"WORK_IM\" = ?", true));
    }
}
