package ru.rosbank.jira.sm.api;

import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.comments.Comment;
import com.atlassian.jira.user.ApplicationUser;
import ru.rosbank.jira.sm.ao.SmReason;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.queue.SmMessageSendingTaskModel;
import ru.rosbank.jira.sm.model.HttpServiceResponse;

import java.util.Date;
import java.util.List;

public interface SmService {

    void updateDueDate(Issue issue, String smNumber, Date due, IssueEvent issueEvent);

    void updateResolveRegistrar(Issue issue, String smNumber, boolean canBeResolved);

    String getSmNumber(Issue issue);

    boolean isSmIssueSource(Issue issue);

    SmReason getReasonByCode(String code);

    List<SmReason> searchReason(String query, int pageMax, int offset);

    int totalReason(String query);

    void saveSmMessage(SmMessage message);

    List<SmMessageSendingTaskModel> getSavedSendingSmTasks();

    void markAsSent(SmMessageSendingTaskModel sendingTask);

    void saveSmResponse(int sendingTaskId, String smResponseBody);

    void addSmSyncComment(ApplicationUser author, Issue issue, String smNumber, Comment comment, IssueEvent issueEvent);

}
