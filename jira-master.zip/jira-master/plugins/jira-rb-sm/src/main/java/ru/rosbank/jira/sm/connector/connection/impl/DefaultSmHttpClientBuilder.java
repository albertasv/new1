package ru.rosbank.jira.sm.connector.connection.impl;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.sm.connector.connection.SmHttpClientBuilder;

/**
 * Обертка используется для предоставления возможности тестирования SmConnector-а.
 */
@Component
public class DefaultSmHttpClientBuilder implements SmHttpClientBuilder {
    @Override
    public HttpClient buildHttpClient() {
        float timeoutInSeconds = 10000f;

        HttpClientParams clientParams = new HttpClientParams();
        clientParams.setParameter(HttpClientParams.SO_TIMEOUT, (int) timeoutInSeconds);

        HttpClient httpClient = new HttpClient();
        httpClient.setParams(clientParams);

        return httpClient;
    }
}
