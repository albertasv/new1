package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ProjectPropertyModel;
import ru.rosbank.jira.common.api.ProjectPropertyService;
import ru.rosbank.jira.sm.ao.ConfigurationItem;
import ru.rosbank.jira.sm.model.ConfigurationItemModel;
import ru.rosbank.jira.sm.model.ConfigurationItemType;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;
import static ru.rosbank.jira.common.api.ProjectPropertyConstants.SYSTEMS_CONTEXT;

@ExportAsService
@Named("configurationItemService")
public class ConfigurationItemServiceImpl implements ConfigurationItemService {
    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationItemServiceImpl.class);
    private final ActiveObjects ao;
    private final ProjectPropertyService projectPropertyService;

    private String error;

    @Inject
    public ConfigurationItemServiceImpl(
            @ComponentImport ActiveObjects ao,
            @ComponentImport ProjectPropertyService projectPropertyService) {
        this.ao = checkNotNull(ao);
        this.projectPropertyService = projectPropertyService;
    }

    @Override
    public String add(ConfigurationItemType type, ConfigurationItemModel ciModel) {
        try {
            final ConfigurationItem todo = ao.create(ConfigurationItem.class,
                    ImmutableMap.<String, Object>of(
                            "TYPE", type.getType(),
                            "CODE", ciModel.getCode(),
                            "NAME", ciModel.getName(),
                            "STATUS", ciModel.getStatusCode(),
                            "LAST_SYNC_DATE", new Date()
                    ));
            if (type.equals("system")) {
                ConfigurationItem ci = getByCode(ciModel.getCode());
                ci.setSensitivity(ciModel.getSensitivity());
                ci.setActualRto(ciModel.getActualRto());
                ci.setActualRpo(ciModel.getActualRpo());
                ci.setProcessCriticality(ciModel.getProcessCriticality());
                ci.save();
            }
        } catch (Exception e) {
            error = String.format("Add CI exception. CI code: %s. Stack trace: %s", ciModel.getCode(), e);
            LOG.error("CI adding exception: ", e);
            return error;
        }
        return "";

    }

    @Override
    public List<ConfigurationItem> all() {
        return newArrayList(ao.find(ConfigurationItem.class, Query.select()));
    }

    @Override
    public int total() {
        return ao.count(ConfigurationItem.class, Query.select());
    }

    @Override
    public ConfigurationItem getByCode(String code) {
        ConfigurationItem[] systems = ao.find(ConfigurationItem.class, Query.select().where("\"CODE\" = ?", code));
        if (systems.length == 1) {
            return systems[0];
        }
        return null;
    }

    private static String SEARCH_QUERY = "\"TYPE\" = ? AND (LOWER(\"CODE\" COLLATE \"en_US\") LIKE ? OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ?) AND \"STATUS\" <> '80'";
    private static String SEARCH_ORDER = "\"STATUS\" > '40', \"NAME\"";

    @Override
    public List<ConfigurationItem> search(String type, String query, Long project, boolean all, int limit, int offset) {

        if (!all && project != null) {
            ProjectPropertyModel prop = projectPropertyService.search(project, SYSTEMS_CONTEXT);
            String codes = prop.getValue();
            if (prop != null && !Strings.isNullOrEmpty(codes)) {
                String queryToLower = Strings.nullToEmpty(query).toLowerCase();
                return Arrays.stream(codes.split(","))
                        .map(code -> getByCode(code.trim()))
                        .filter(system -> {
                            if(system == null) {
                                return false;
                            }
                            return system.getCode().toLowerCase().contains(queryToLower) || system.getName().toLowerCase().contains(queryToLower);
                        })
                        .collect(Collectors.toList());
            }
        }

        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(ConfigurationItem.class,
                    Query.select()
                            .where("\"TYPE\" = ? AND \"STATUS\" <> \'80\'", type)
                            .order(SEARCH_ORDER)
                            .limit(limit)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(ConfigurationItem.class, Query.select()
                .where(SEARCH_QUERY, type, likeQuery, likeQuery)
                .order(SEARCH_ORDER)
                .limit(limit)
                .offset(offset)
        ));
    }

    @Override
    public int total(String type, String query, Long project, boolean all) {
        if (!all && project != null) {
            ProjectPropertyModel prop = projectPropertyService.search(project, SYSTEMS_CONTEXT);
            if (prop != null && !Strings.isNullOrEmpty(prop.getValue())) {
                String queryToLower = Strings.nullToEmpty(query).toLowerCase();
                return Arrays.stream(prop.getValue().split(",")).map(code -> getByCode(code.trim()))
                        .filter(system -> {
                            if(system == null) {
                                return false;
                            }
                            return system.getCode().toLowerCase().contains(queryToLower) || system.getName().toLowerCase().contains(queryToLower);
                        }).mapToInt(system -> 1).sum();
            }
        }

        if (Strings.isNullOrEmpty(query)) {
            return total();
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(ConfigurationItem.class, Query.select()
                .where(SEARCH_QUERY, type, likeQuery, likeQuery));
    }

    @Override
    public String update(ConfigurationItemModel ciModel) {
        ConfigurationItem ci = getByCode(ciModel.getCode());
        if (ci != null) {
            ci.setName(ciModel.getName());
            ci.setStatus(ciModel.getStatusCode());
            ci.setDomain(ciModel.getDomain());
            ci.setOwner(ciModel.getOwner());
            ci.setOwnerResponsible(ciModel.getOwnerResponsible());
            ci.setTeam(ciModel.getTeam());
            ci.setTeamResponsible(ciModel.getTeamResponsible());
            ci.setManager(ciModel.getManager());
            ci.setIsOfficer(ciModel.getIsOfficer());
            ci.setRegisterDate(ciModel.getRegisterDate());
            ci.setStartDevDate(ciModel.getStartDevDate());
            ci.setStartOperationDate(ciModel.getStartOperationDate());
            ci.setStartOutOfService(ciModel.getStartOutOfService());
            ci.setOutOfServiceDate(ciModel.getOutOfServiceDate());
            ci.setComment(ciModel.getComment());
            ci.setLastUpdateDate(ciModel.getLastUpdateDate());
            ci.setLastSyncDate(new Date());
            ci.setSensitivity(ciModel.getSensitivity());
            ci.setActualRto(ciModel.getActualRto());
            ci.setActualRpo(ciModel.getActualRpo());
            ci.setProcessCriticality(ciModel.getProcessCriticality());
            ci.save();
        } else {
            error = String.format("Update CI error - incorrect input data. Code: %s", ci.getCode());
            LOG.error(error);
            return error;
        }
        return "";
    }
}
