package ru.rosbank.jira.sm.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.sm.connector.ao.SmMessageSendingTaskEntity;

import javax.inject.Inject;
import javax.inject.Named;

@Named("smMessageQueueCleanerService")
public class SmMessageQueueCleanerServiceImpl implements SmMessageQueueCleanerService {

    private static final Logger LOG = LoggerFactory.getLogger(SmMessageQueueCleanerServiceImpl.class);

    private final ActiveObjects ao;

    @Inject
    public SmMessageQueueCleanerServiceImpl(@ComponentImport ActiveObjects ao){
        this.ao = ao;
    }

    @Override
    public void cleanSmMessageQueue() {
        SmMessageSendingTaskEntity[] taskEntities = ao.find(SmMessageSendingTaskEntity.class, "\"TASK_CREATED_TIME\" < (current_timestamp - interval '1 month')");
        if (taskEntities.length != 0 && taskEntities != null) {
            LOG.debug("Deleting SM messages...");
            for (SmMessageSendingTaskEntity entity : taskEntities) {
                ao.delete(entity);
            }
        }
    }
}
