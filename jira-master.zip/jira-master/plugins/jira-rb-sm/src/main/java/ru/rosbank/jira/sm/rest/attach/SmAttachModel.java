package ru.rosbank.jira.sm.rest.attach;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class SmAttachModel implements Serializable {

    private String href;
    private String name;
    private String type;
    @SerializedName("xmime:contentType")
    private String mineType;

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getCid() {
        if (href.startsWith("cid:")) {
            return href.substring(4);
        }
        return href;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMineType() {
        return mineType;
    }

    public void setMineType(String mineType) {
        this.mineType = mineType;
    }
}
