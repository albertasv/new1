package ru.rosbank.jira.sm.ao;


import net.java.ao.schema.StringLength;


/**
 * Интерфейс для ORM Active Object, чтобы осуществлять маппинг Java объект и таблицу-справочник БД с рабочими группами из SM
 */

public interface SmWorkGroup extends SmDictionary{

    boolean getWorkIm();

    void setWorkIm(boolean state);

    boolean getWorkRft();

    void setWorkRft(boolean state);

    boolean getBlocked();

    void setBlocked(boolean state);

    @StringLength(StringLength.UNLIMITED)
    String getManagerLogin();

    @StringLength(StringLength.UNLIMITED)
    void setManagerLogin(String managerLogin);



}
