INSERT INTO "AO_D46467_PROJECT_PROPERTY"
SELECT nextval('"AO_D46467_PROJECT_PROPERTY_ID_seq"'), 'sm.resolution.done.action' "KEY", id "PROJECT", 'reassign' "VALUE"
FROM project
WHERE pkey IN
      ('CPR', 'AGG', 'AGP', 'USC', 'RPA', 'ATMRD', 'PHUB', 'NCM', 'WP');