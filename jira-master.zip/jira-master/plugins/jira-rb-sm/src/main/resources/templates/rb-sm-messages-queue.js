AJS.$(document).ready(function () {
    AJS.$("title").text("SM Messages Queue");
});