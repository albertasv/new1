AJS.$(document).ready(function () {
    const $issueWindow = AJS.$('.mod-footer').children('.ops');
    if ($issueWindow !== null) {
        const issueKey = AJS.$('#key-val').text();
        if (issueKey !== null || issueKey !== "") {
            AJS.$.get( "/rest/sm/1.0/issue/issuesource/" + issueKey)
                .success(function (data) {
                    if (data.issueSource !== null && data.issueSource === "SM") {
                        $issueWindow
                            .append('<li><span>&nbsp</span></li>')
                            .append('<li><a href="#" id="footer-sm-comment-button" name="add-comment" class="aui-button" resolved=""><span class="aui-icon aui-icon-small aui-iconfont-comment icon-comment"></span><span>Add comment to SM</span></a></li>');
                        AJS.$('#footer-sm-comment-button').on("click", function () {
                            AJS.$('#footer-comment-button').trigger("click");
                            setTimeout(function () {
                                const $comment = AJS.$('#comment');
                                if ($comment.exists()) {
                                    $comment.val("[~smsync]&nbsp;");
                                }
                            }, 500);
                            setTimeout(function (){
                                AJS.$('#issue-comment-add-submit').trigger("focus");
                            }, 1000)
                        });
                    }
                });
        }
    }
})