package ut.ru.rosbank.jira.sm.test.api.connector;

import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.message.SmMessage;

import java.util.List;

/**
 * Простой обработчик ответов от SM, который записывает полученный статус в список.
 * ВНИМАНИЕ! Добавлять поля с данными в обработчик ответов SM - плохая практика, т.к. в нормальном сценарии объект этого
 * класса будет конструироваться с помощью контейнера DI. Для сохранения/передачи каких-либо данных (настроек и т.п.)
 * стоит воспользоваться каким-либо сервисом (например {@link ru.rosbank.jira.common.api.ConfigLoader}).
 */
public class SaveResponseToListResponseProcessor {

    private final List<SmResponseStatus> savedResponses;

    public SaveResponseToListResponseProcessor(List<SmResponseStatus> savedResponses) {
        this.savedResponses = savedResponses;
    }


    public void processSmResponse(SmMessage message, SmResponseStatus responseStatus) {
        savedResponses.add(responseStatus);
    }

}
