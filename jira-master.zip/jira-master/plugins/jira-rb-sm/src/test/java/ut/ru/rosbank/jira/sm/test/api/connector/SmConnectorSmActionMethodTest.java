package ut.ru.rosbank.jira.sm.test.api.connector;

import com.atlassian.jira.issue.Issue;
import org.junit.Before;
import ru.rosbank.jira.sm.connector.SmResponseStatus;
import ru.rosbank.jira.sm.connector.connection.HttpSmConnector;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

public class SmConnectorSmActionMethodTest {

    // Параметры для вызова метода SmConnector::smActionMethod
    // Значения по умолчанию выставляются в методе setDefaultValuesForConnectorArgs
    // Если значения по умолчанию не подходят - нужно установить в подходящее перед выполнением executeSmAction()
    private String targetUrl;
    private Issue issue;
    private String sendData;
    private SmActionMethod requestMethodType;
    private boolean mustAddCommentToIssue;

    @Before
    public void setDefaultValuesForConnectorArgs() {
        targetUrl = "";
        issue = mock(Issue.class);
        sendData = "";
        requestMethodType = SmActionMethod.POST;
        mustAddCommentToIssue = false;
    }

    private SmResponseStatus sendMessageToSmViaConnector(HttpSmConnector smConnector) {
        SmMessage smMessage = new SmMessageBuilder()
                .toEndpoint(targetUrl)
                .withData(sendData)
                .linkedJiraIssue(issue)
                .usingMethod(requestMethodType)
                .mustAddCommentInIssue(mustAddCommentToIssue)
                .build();
        return smConnector.sendMessage(0, smMessage);
    }

    /**
     * Тестируем случай, когда HP SM вернул ответ с http-статусом = 500 и "неправильный" JSON в теле ответа
     */
    /*
    @Test
    public void addNewSmMessage_whenInternalServerErrorResponse_whenResponseBodyIsInvalidJson() {

        SmConnectorBuilder smConnectorBuilder = new SmConnectorBuilder();
        smConnectorBuilder.httpClientConfig()
                .withResponseStatus(500);
        smConnectorBuilder.httpMethodConfig()
                .withResponseBody("some non-JSON text");

        HttpSmConnector smConnector = smConnectorBuilder.build();
        SmResponseStatus actualServiceResponseStatus = sendMessageToSmViaConnector(smConnector);

        SmResponseStatus expectedServiceResponseStatus = SmResponseStatus.SM_SERVICE_FAILURE;
        assertEquals(expectedServiceResponseStatus, actualServiceResponseStatus);
    }

    /**
     * Тестируем случай, когда HP SM вернул ответ с http-статусом = 500 и без тела ответа
     */
    /*
    @Test
    public void addNewSmMessage_whenInternalServerErrorResponse_whenResponseBodyIsEmpty() {

        SmConnectorBuilder smConnectorBuilder = new SmConnectorBuilder();
        smConnectorBuilder.httpClientConfig()
                .withResponseStatus(500);
        smConnectorBuilder.httpMethodConfig();

        HttpSmConnector smConnector = smConnectorBuilder.build();
        SmResponseStatus actualServiceResponseStatus = sendMessageToSmViaConnector(smConnector);

        SmResponseStatus expectedServiceResponseStatus = SmResponseStatus.SM_SERVICE_FAILURE;
        assertEquals(expectedServiceResponseStatus, actualServiceResponseStatus);
    }

    /**
     * Тестируем случай, когда HP SM вернул ответ с http-статусом = 500 и пустым телом ответа
     */
    /*
    @Test
    public void addNewSmMessage_whenInternalServerErrorResponse_whenResponseIsEmptyString() {

        SmConnectorBuilder smConnectorBuilder = new SmConnectorBuilder();
        smConnectorBuilder.httpClientConfig()
                .withResponseStatus(500);
        smConnectorBuilder.httpMethodConfig()
                .withResponseBody("");

        HttpSmConnector smConnector = smConnectorBuilder.build();
        SmResponseStatus actualServiceResponseStatus = sendMessageToSmViaConnector(smConnector);

        SmResponseStatus expectedServiceResponseStatus = SmResponseStatus.SM_SERVICE_FAILURE;
        assertEquals(expectedServiceResponseStatus, actualServiceResponseStatus);
    }

    /**
     * Тестируем случай, когда связанная задача SM уже закрыта - http-статус > 300 и поле ReturnCode тела ответа = 70.
     * Здесь нужно уточнить какой именно http-статус возвращает сервис в тестируемом случае.
     */
    /*
    @Test
    public void addNewSmMessage_whenRequestedSmIssueAlreadyResolved() {

        String onCommentInClosedSmIssueResponseData = "{\"ReturnCode\":70,\"Messages\":[\"Issue already resolved\"]}";

        SmConnectorBuilder smConnectorBuilder = new SmConnectorBuilder();
        smConnectorBuilder.httpClientConfig()
                .withResponseStatus(400);
        smConnectorBuilder.httpMethodConfig()
                .withResponseBody(onCommentInClosedSmIssueResponseData);

        HttpSmConnector smConnector = smConnectorBuilder.build();
        SmResponseStatus actualServiceResponseStatus = sendMessageToSmViaConnector(smConnector);

        SmResponseStatus expectedServiceResponseStatus = SmResponseStatus.SM_ISSUE_ALREADY_RESOLVED;
        assertEquals(expectedServiceResponseStatus, actualServiceResponseStatus);
    }

     */

}
