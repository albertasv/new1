package ut.ru.rosbank.jira.sm.support.api.connector;

import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import ru.rosbank.jira.sm.connector.connection.HttpMethodBuilder;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MockedHttpMethodBuilder implements HttpMethodBuilder {

    private String withResponseBody;

    @Override
    public HttpMethod buildMethod(SmActionMethod methodType, String url, String data) {
        HttpMethod generatedHttpMethod;

        switch (methodType) {
            case POST:
                generatedHttpMethod = mock(PostMethod.class);
                break;
            case PUT:
                generatedHttpMethod = mock(PutMethod.class);
                break;
            default:
                generatedHttpMethod = null;
        }

        mockResponseBodyStream(generatedHttpMethod);
        mockGetResponseBodyAsString(generatedHttpMethod);

        return generatedHttpMethod;
    }

    public MockedHttpMethodBuilder withResponseBody(String responseBody) {
        this.withResponseBody = responseBody;
        return this;
    }

    private void mockResponseBodyStream(HttpMethod httpMethod) {
        try {
            if (withResponseBody == null) {
                when(httpMethod.getResponseBodyAsStream())
                        .thenReturn(null);
            } else {
                when(httpMethod.getResponseBodyAsStream())
                        .thenReturn(new ByteArrayInputStream(withResponseBody.getBytes(StandardCharsets.UTF_8)));
            }
        } catch (IOException ignore) {
        }
    }

    private void mockGetResponseBodyAsString(HttpMethod httpMethod) {
        try {
            when(httpMethod.getResponseBodyAsString())
                    .thenReturn(withResponseBody);
        } catch (IOException ignore) {
        }
    }

}
