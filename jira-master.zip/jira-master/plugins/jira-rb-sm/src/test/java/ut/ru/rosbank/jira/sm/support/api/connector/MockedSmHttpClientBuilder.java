package ut.ru.rosbank.jira.sm.support.api.connector;

import org.apache.commons.httpclient.HttpClient;
import ru.rosbank.jira.sm.connector.connection.SmHttpClientBuilder;

import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MockedSmHttpClientBuilder implements SmHttpClientBuilder {

    private Integer withResponseStatus;

    @Override
    public HttpClient buildHttpClient() {
        HttpClient mockedHttpClient = mock(HttpClient.class);

        if (withResponseStatus != null) {
            try {
                when(mockedHttpClient.executeMethod(any())).thenReturn(withResponseStatus);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return mockedHttpClient;
    }

    public MockedSmHttpClientBuilder withResponseStatus(int responseStatus) {
        this.withResponseStatus = responseStatus;
        return this;
    }

}
