package ut.ru.rosbank.jira.sm.test.api.connector.message.builder;

import com.atlassian.jira.issue.Issue;
import org.junit.Before;
import org.junit.Test;
import ru.rosbank.jira.sm.connector.message.SmActionMethod;
import ru.rosbank.jira.sm.connector.message.SmMessage;
import ru.rosbank.jira.sm.connector.message.SmMessageBuilder;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

public class SmMessageBuilderTest {

    private SmMessageBuilder smMessageBuilder;

    @Before
    public void initMessageBuilder() {
        smMessageBuilder = new SmMessageBuilder();
    }

    /**
     * Пример использования SmMessageBuilder-а.
     */
    @Test
    public void normalMessageBuildingTest() {

        String targetEndpoint = "";
        String jsonData = "";
        SmActionMethod actionMethod = SmActionMethod.POST;
        Issue linkedJiraIssue = mock(Issue.class);
        boolean mustAddCommentInIssue = false;

        SmMessage message = smMessageBuilder
                .toEndpoint(targetEndpoint)
                .withData(jsonData)
                .usingMethod(actionMethod)
                .linkedJiraIssue(linkedJiraIssue)
                .mustAddCommentInIssue(mustAddCommentInIssue)
                .build();

        assertEquals(targetEndpoint, message.getTargetEndpoint());
        assertEquals(jsonData, message.getJsonData());
        assertEquals(actionMethod, message.getActionMethod());
        assertEquals(linkedJiraIssue, message.getLinkedJiraIssue());
        assertEquals(mustAddCommentInIssue, message.mustAddCommentInIssue());
    }
}
