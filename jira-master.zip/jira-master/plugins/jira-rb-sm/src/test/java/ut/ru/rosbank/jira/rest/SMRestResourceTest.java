package ut.ru.rosbank.jira.rest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SMRestResourceTest {

    @Before
    public void setup() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void messageIsValid() {
        // TODO
        // SMRestResource resource = new SMRestResource();
        // final SMRestResourceModel message = (SMRestResourceModel) response.getEntity();
        // assertEquals("wrong message","Hello World",message.getMessage());
    }

    @Test
    public void loadITSystem() {
        // TODO
        // ITSystemUploadTask task = new ITSystemUploadTask();
        // task.loadITSystemFile();
    }
}
