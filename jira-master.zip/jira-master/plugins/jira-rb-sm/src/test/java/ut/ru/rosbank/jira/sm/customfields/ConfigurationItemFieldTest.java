package ut.ru.rosbank.jira.sm.customfields;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @since 3.5
 */
public class ConfigurationItemFieldTest {

    @Before
    public void setup() {

    }

    @After
    public void tearDown() {

    }

    @Test(expected = Exception.class)
    public void testSomething() throws Exception {

        //ITSystemField testClass = new ITSystemField();

        throw new Exception("ITSystemField has no tests!");

    }

}
