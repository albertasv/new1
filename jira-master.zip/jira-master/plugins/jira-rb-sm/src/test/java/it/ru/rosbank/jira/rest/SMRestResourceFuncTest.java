package it.ru.rosbank.jira.rest;

import org.junit.Test;
import org.junit.After;
import org.junit.Before;

public class SMRestResourceFuncTest {

    @Before
    public void setup() {

    }

    @After
    public void tearDown() {

    }

    @Test
    public void messageIsValid() {
        String baseUrl = System.getProperty("baseurl");
        String resourceUrl = baseUrl + "/rest/sm/1.0/issue/create";

        // TODO
        // RestClient client = new RestClient();
        // Resource resource = client.resource(resourceUrl);
        // SMRestResourceModel message = resource.get(SMRestResourceModel.class);
        // assertEquals("wrong message", "Hello World", message.getMessage());
    }
}
