package ru.rosbank.jira.misc.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.StringLength;


@Preload
public interface ProjectProperty extends Entity {

    @NotNull
    Long getProject();

    @NotNull
    void setProject(Long project);

    @NotNull
    String getKey();

    @NotNull
    void setKey(String key);

    @NotNull
    @StringLength(StringLength.UNLIMITED)
    String getValue();

    @NotNull
    void setValue(String value);
}
