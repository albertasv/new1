package ru.rosbank.jira.misc.service;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.pico.ComponentManager;
import com.atlassian.jira.issue.RendererManager;
import com.atlassian.jira.issue.fields.renderer.JiraRendererPlugin;
import com.atlassian.jira.issue.fields.renderer.wiki.AtlassianWikiRenderer;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.misc.ao.News;
import ru.rosbank.jira.misc.ao.UserInfo;
import ru.rosbank.jira.misc.model.NewsModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Named
public class NewsServiceImpl implements NewsService {

    private final ActiveObjects ao;
    private final JiraAuthenticationContext authContext;
    private final ConfigLoader configLoader;

    @Inject
    public NewsServiceImpl(@ComponentImport ActiveObjects ao,
                           @ComponentImport JiraAuthenticationContext authContext,
                           ConfigLoader configLoader) {
        this.ao = ao;
        this.authContext = authContext;
        this.configLoader = configLoader;

    }

    @Override
    public String getNewsForCurrentUser() {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        JiraRendererPlugin renderer = getRenderer();
        if (loggedInUser != null) {
            UserInfo[] uis = ao.find(UserInfo.class, "\"USERNAME\" = ?", loggedInUser.getUsername());
            if (uis != null && uis.length > 0) {
                UserInfo ui = uis[0];
                if (ui.getNewsId() != null && ui.getNewsId() != -1) {
                    News[] news = ao.find(News.class,
                            Query.select().where("ID > ?", ui.getNewsId()).order("ID DESC"));
                    if (news != null && news.length > 0) {
                        return renderer.render(news[0].getNews(), null);
                    }
                }
            }
        }
        return null;
    }

    public News[] getNewsByUser() {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        if (loggedInUser != null) {
            UserInfo[] uis = ao.find(UserInfo.class, "\"USERNAME\" = ?", loggedInUser.getUsername());
            if (uis != null && uis.length > 0) {
                UserInfo ui = uis[0];
                if (ui.getNewsId() != null && ui.getNewsId() != -1) {
                    News[] news = ao.find(News.class,
                            Query.select().where("ID > ?", ui.getNewsId()).order("ID DESC"));

                    return news;

                }
            }
        }
        return null;
    }

    @Override
    public String getCountNewsForCurrentUser() {
        News[] news = getNewsByUser();
        if (news != null && news.length > 0) {
            return ""+news.length;
        }
        return "0";
    }

    @Override
    public void hideNewsForCurrentUser() {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        if (loggedInUser != null) {
            UserInfo[] uis = ao.find(UserInfo.class, "\"USERNAME\" = ?", loggedInUser.getUsername());
            if (uis != null && uis.length > 0) {
                UserInfo ui = uis[0];
                if (ui.getNewsId() != null && ui.getNewsId() != -1) {
                    News[] news = ao.find(News.class,
                            Query.select().where("ID > ?", ui.getNewsId()).order("ID DESC"));
                    if (news != null && news.length > 0) {
                        ui.setNewsId(news[0].getID());
                        ui.save();
                    }
                }
            }
        }
    }

    @Override
    public void hideAllNewsForCurrentUser() {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        if (loggedInUser != null) {
            UserInfo[] uis = ao.find(UserInfo.class, "\"USERNAME\" = ?", loggedInUser.getUsername());
            if (uis != null && uis.length > 0) {
                UserInfo ui = uis[0];
                ui.setNewsId(-1);
                ui.save();
            }
        }
    }

    @Override
    public List<NewsModel> getNews() {
        JiraRendererPlugin renderer = getRenderer();
        News[] news = ao.find(News.class,
                Query.select().order("ID DESC").limit(10));
        if (news != null) {
            return Arrays.stream(news).map(news1 -> {
                NewsModel nm = NewsModel.convert(news1);
                nm.setNews(renderer.render(nm.getNews(), null));
                return nm;
            }).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @Override
    public NewsModel findNews(int newsId) {
        News[] news = ao.find(News.class,
                Query.select().where("ID = ?", newsId).limit(10));
        if (news != null & news.length > 0) {
            return NewsModel.convert(news[0]);
        }
        return null;
    }

    @Override
    public NewsModel saveNews(Integer newsId, String newsText) {
        if (newsId != null) {
            News[] nn = ao.find(News.class,
                    Query.select().where("ID = ?", newsId).limit(1));
            if (nn != null & nn.length > 0) {
                nn[0].setNews(newsText);
                nn[0].setLastUpdateDate(new Date());
                nn[0].save();
                return NewsModel.convert(nn[0]);
            }
        }

        if (!Strings.isNullOrEmpty(newsText)) {
            ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                    .put("NEWS", newsText)
                    .put("LAST_UPDATE_DATE", new Date());
            return NewsModel.convert(ao.create(News.class, mapBuilder.build()));
        }
        return new NewsModel();
    }

    @Override
    public void deleteNews(Integer newsId) {
        if (newsId != null) {
            News[] nn = ao.find(News.class,
                    Query.select().where("ID = ?", newsId).limit(1));
            if (nn != null & nn.length > 0) {
                ao.delete(nn[0]);
            }
        }
    }

    //JIRA-7704 Вынес инициализацию рендерера в отдельный метод, так как инициализация в конструкторе не работает
    private JiraRendererPlugin  getRenderer() {
        return ComponentManager.getInstance().getComponent(RendererManager.class)
                .getRendererForType(AtlassianWikiRenderer.RENDERER_TYPE);
    }
}