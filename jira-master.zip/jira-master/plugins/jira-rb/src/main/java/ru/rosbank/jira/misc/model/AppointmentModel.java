package ru.rosbank.jira.misc.model;

import com.google.common.base.Strings;
import microsoft.exchange.webservices.data.core.exception.service.local.ServiceLocalException;
import microsoft.exchange.webservices.data.core.service.item.Appointment;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.time.ZoneId;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppointmentModel {

    private static final Logger LOG = LoggerFactory.getLogger(AppointmentModel.class);

    private String iCalUid;
    private String uniqueId;

    private String tempoId;
    private String subject;
    private TimeZone timeZone;
    private Date start;
    private Date end;
    private Set<String> categories = new HashSet<>();

    public AppointmentModel() {
    }

    public AppointmentModel(String iCalUid, String subject, Date start, Date end) {
        this.iCalUid = iCalUid;
        this.subject = subject;
        this.start = start;
        this.end = end;
    }

    public String getICalUid() {
        return iCalUid;
    }

    public void setICalUid(String iCalUid) {
        this.iCalUid = iCalUid;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getTempoId() {
        return tempoId;
    }

    public void setTempoId(String tempoId) {
        this.tempoId = tempoId;
    }

    public String getSubject() {
        if (!Strings.isNullOrEmpty(subject)) {
            return subject;
        }
        return "";
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public TimeZone getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(TimeZone timeZone) {
        this.timeZone = timeZone;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public Set<String> getCategories() {
        return categories;
    }

    public void setCategories(Set<String> categories) {
        this.categories = categories;
    }

    public static AppointmentModel convert(Appointment appointment) {
        AppointmentModel res = new AppointmentModel();
        try {
            res.setICalUid(appointment.getICalUid());
            res.setUniqueId(appointment.getId().getUniqueId());
            res.setSubject(appointment.getSubject());

            String appointmentTimeZone = appointment.getTimeZone();
            if (!Strings.isNullOrEmpty(appointmentTimeZone)) {
                try {
                    String regex = "[+-][0-9]{2}:[0-9]{2}";
                    Matcher m = Pattern.compile(regex).matcher(appointmentTimeZone);
                    String timeZone = m.find() ? "GMT" + m.group() : null;
                    if (timeZone != null) {
                        ZoneId zoneId = ZoneId.of(timeZone);
                        if (zoneId != null) {
                            res.setTimeZone(TimeZone.getTimeZone(zoneId));
                        }
                    }
                } catch (Exception ex) {
                    LOG.error("Getting appointment time zone exception", ex);
                }
            }

            res.setStart(appointment.getStart());
            res.setEnd(appointment.getEnd());
            Iterator<String> categories = appointment.getCategories().getIterator();
            while (categories.hasNext()) {
                res.getCategories().add(categories.next());
            }
        } catch (ServiceLocalException e) {

        }
        return res;
    }
}
