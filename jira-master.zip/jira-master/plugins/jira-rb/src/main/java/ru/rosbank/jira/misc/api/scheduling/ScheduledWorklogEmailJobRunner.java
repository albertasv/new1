package ru.rosbank.jira.misc.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.service.TempoService;

import javax.annotation.Nullable;
import javax.inject.Named;

@Named("workflowEmailJobRunner")
public class ScheduledWorklogEmailJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledWorklogEmailJobRunner.class);

    private final TempoService tempoService;

    public ScheduledWorklogEmailJobRunner(TempoService tempoService) {
        this.tempoService = tempoService;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(JobRunnerRequest jobRunnerRequest) {
        LOG.info("Executing a worklog sending scheduled job");
        if (tempoService != null) {
            tempoService.sendWorklogEmails();
        }
        return JobRunnerResponse.success();
    }
}