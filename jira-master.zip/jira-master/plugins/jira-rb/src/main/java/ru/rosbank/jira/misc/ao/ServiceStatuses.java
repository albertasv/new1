package ru.rosbank.jira.misc.ao;


import net.java.ao.Entity;
import net.java.ao.schema.StringLength;

import java.util.Date;

public interface ServiceStatuses extends Entity {

    String getServiceName();

    void setServiceName(String name);

    @StringLength(StringLength.UNLIMITED)
    String getMessage();

    void setMessage(String message);

    Date getLastUpdateDate();

    void setLastUpdateDate(Date dateTime);

    String getStatus();

    void setStatus(String status);
}
