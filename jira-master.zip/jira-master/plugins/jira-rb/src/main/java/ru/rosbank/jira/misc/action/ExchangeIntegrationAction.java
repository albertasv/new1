package ru.rosbank.jira.misc.action;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;

import javax.inject.Inject;

public class ExchangeIntegrationAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(ExchangeIntegrationAction.class);

    private final JiraAuthenticationContext authenticationContext;

    private UserInfoModel loggedInUserInfo;

    @Inject
    public ExchangeIntegrationAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            UserInfoService userInfoService) {
        this.authenticationContext = authenticationContext;
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        this.loggedInUserInfo = userInfoService.getUserInfo(loggedInUser.getUsername());
    }

    @Override
    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public UserInfoModel getLoggedInUserInfo() {
        return loggedInUserInfo;
    }
}