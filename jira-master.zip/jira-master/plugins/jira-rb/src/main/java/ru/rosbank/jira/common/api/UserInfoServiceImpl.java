package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.UserUtils;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.misc.ao.UserInfo;
import ru.rosbank.jira.misc.service.ExchangeService;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;


@ExportAsService({UserInfoService.class})
@Service
public class UserInfoServiceImpl implements UserInfoService {

    private static final Logger LOG = LoggerFactory.getLogger(UserInfoServiceImpl.class);
    private static final long OOF_HOURS_BEFORE_LAST_UPDATE = 8;

    @ComponentImport
    private final ActiveObjects ao;

    private final ExchangeService exchangeService;
    private final UserManager userManager;

    @Inject
    public UserInfoServiceImpl(ActiveObjects ao,
                               ExchangeService exchangeService) {
        this.ao = checkNotNull(ao);
        this.exchangeService = exchangeService;
        this.userManager = ComponentAccessor.getUserManager();
    }

    @Override
    public UserInfoModel add(UserInfoModel uim) {
        if (uim.getUsername() != null) {
            ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                    .put("USERNAME", uim.getUsername())
                    .put("LAST_UPDATE_DATE", new Date());
            UserInfo ui = ao.create(UserInfo.class, mapBuilder.build());
            return updateOptional(ui, uim);
        }
        return null;
    }

    @Override
    public UserInfoModel update(UserInfoModel uim) {
        UserInfo ui = getUserInfoAO(uim.getUsername());
        if (ui == null) {
            return add(uim);
        }
        return updateOptional(ui, uim);
    }

    private UserInfoModel updateOptional(UserInfo ui, UserInfoModel uim) {
        ui.setExchangeIntegration(uim.getExchangeIntegration());
        ui.setOofEnabled(uim.getOof());

        if (!Strings.isNullOrEmpty(uim.getOofMessage())) {
            ui.setOofMessage(uim.getOofMessage());
        }

        if (uim.getTeamId() != null) {
            ui.setTeamId(uim.getTeamId());
        }

        if (uim.getTeamRole() != null) {
            ui.setTeamRole(uim.getTeamRole());
        }

        if (uim.getCalendarSync() != null) {
            ui.setCalendarSync(uim.getCalendarSync());
        }

        if (uim.getPlanningIssue() != null) {
            ui.setPlanningIssue(uim.getPlanningIssue().trim());
        }

        ui.setPriorityPlanningIssue(uim.getPriorityPlanningIssue());

        if (uim.getExcludedCategory() != null) {
            ui.setExcludedCategory(uim.getExcludedCategory());
        }

        ui.setLastUpdateDate(new Date());
        ui.save();
        return convert(ui);
    }

    @Override
    public UserInfoModel getUserInfo(String username) {
        return getUserInfo(username, true);
    }

    @Override
    public UserInfoModel getUserInfo(String username, boolean withCache) {
        UserInfo user = getUserInfoAO(username);
        boolean isNew = false;
        if (user == null) {
            add(new UserInfoModelImpl(username));
            user = getUserInfoAO(username);
            isNew = true;
        }

        if (user != null) {
            if (Boolean.TRUE.equals(user.getExchangeIntegration())) {
                Date lastUpdateDate = user.getLastUpdateDate();
                LOG.debug("Username: {}, isNew {}, nowDate: {}, lastUpdateDate: {}, update: {}, withCache: {}",
                        username, isNew, new Date(), lastUpdateDate,
                        ((new Date().getTime() - lastUpdateDate.getTime()) >= OOF_HOURS_BEFORE_LAST_UPDATE * 1000 * 60), withCache);
                if (!withCache
                        || isNew
                        || ((new Date().getTime() - lastUpdateDate.getTime()) >= OOF_HOURS_BEFORE_LAST_UPDATE * 1000 * 60)) {
                    ApplicationUser appUser = userManager.getUserByName(username);
                    if (appUser != null && appUser.isActive()) {
                        String message = exchangeService.exchangeOof(appUser.getEmailAddress());
                        if (Strings.isNullOrEmpty(message)) {
                            user.setOofEnabled(false);
                        } else {
                            user.setOofEnabled(true);
                            user.setOofMessage(message);
                        }
                        user.setLastUpdateDate(new Date());
                        user.save();
                    }
                }
            }
            return convert(user);
        }
        return null;
    }

    @Override
    public List<UserInfoModel> getUserInfo(List<String> usernames) {
        UserInfo[] users = ao.find(UserInfo.class, "\"USERNAMES\" IN (?)",
                usernames.stream().collect(Collectors.joining(", ")));
        return Arrays.asList(users).stream().map(UserInfoServiceImpl::convert).collect(Collectors.toList());
    }

    @Override
    public List<UserInfoModel> getUserInfoByOofStatus() {
        return Arrays.stream(ao.find(UserInfo.class, "\"OOF_ENABLED\" = ?", true)).map(UserInfoServiceImpl::convert)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserInfoModel> getUserInfoByTeam(int teamId) {
        UserInfo[] users = ao.find(UserInfo.class, "\"TEAM_ID\" = ?", teamId);
        return Arrays.asList(users).stream().map(UserInfoServiceImpl::convert).collect(Collectors.toList());
    }

    @Override
    public List<UserInfoModel> getUserInfoByCalendarSync(boolean calendarSync) {
        UserInfo[] users = ao.find(UserInfo.class, "\"CALENDAR_SYNC\" = ?", calendarSync);
        return Arrays.asList(users).stream().map(UserInfoServiceImpl::convert).collect(Collectors.toList());
    }

    @Override
    public void resetTeamMembers(int teamId) {
        Arrays.asList(ao.find(UserInfo.class, "\"TEAM_ID\" = ?", teamId))
                .stream().forEach(userInfo -> {
            userInfo.setTeamId(null);
            userInfo.save();
        });
    }

    @Override
    public UserInfoModel updateTeamMember(int teamId, String email, String role) {
        ApplicationUser au = UserUtils.getUsersByEmail(email).stream().filter(
                user ->
                        user.isActive() &&
                                user.getUsername().toLowerCase().matches("^(rb[0-9]|rbxmos[0-9]).*$"))
                .findAny().orElse(null);
        if (au == null) {
            au = UserUtils.getUsersByEmail(email).stream().findAny().orElse(null);
        }

        if (au == null) {
            au = userManager.getUserByName(email);
        }
        // Проверка факта изменения digital роли сотрудника. Если роль обновилась\не изменилась и роль имеет приписку Change\change,
        // то у таких пользователей проставляем 1 в атрибуте worklogEmail, чтобы пользователю уходила рассылка трудозатрат
        // по почте. Иначе наоборот, вместо 1 ставим 0, следовательно рассылка пользователю уходить не будет
        if (au != null) {
            UserInfo[] userInfos = ao.find(UserInfo.class, "\"USERNAME\" = ?", au.getUsername());
            if (userInfos != null && userInfos.length > 0) {
                UserInfo ui = userInfos[0];
                ui.setTeamId(teamId);
                ui.setTeamRole(role);
                if (!Strings.isNullOrEmpty(role)
                        && role.toLowerCase().contains("change")
                        && ui.getWorklogEmail() != null
                        && ui.getWorklogEmail() == 0) {
                    ui.setWorklogEmail(1);
                }
                if ((Strings.isNullOrEmpty(role)
                        || !role.toLowerCase().contains("change"))
                        && ui.getWorklogEmail() == 1) {
                    ui.setWorklogEmail(0);
                }
                ui.setLastUpdateDate(new Date());
                ui.save();
                return convert(ui);
            } else {
                UserInfoModelImpl uim = new UserInfoModelImpl();
                uim.setUsername(au.getUsername());
                uim.setTeamId(teamId);
                uim.setTeamRole(role);
                return add(uim);
            }
        } else {
            LOG.debug("Not found application user for {}", email);
        }
        return null;
    }

    private static UserInfoModel convert(UserInfo ui) {
        UserInfoModel res = new UserInfoModelImpl();
        res.setUsername(ui.getUsername());
        res.setTeamId(ui.getTeamId());
        res.setTeamRole(ui.getTeamRole());

        res.setExchangeIntegration(Boolean.TRUE.equals(ui.getExchangeIntegration()));
        res.setOof(ui.getOofEnabled());
        res.setOofMessage(ui.getOofMessage());
        res.setCalendarSync(Boolean.TRUE.equals(ui.getCalendarSync()));
        res.setPlanningIssue(ui.getPlanningIssue());
        res.setPriorityPlanningIssue(ui.getPriorityPlanningIssue());
        res.setExcludedCategory(ui.getExcludedCategory());
        return res;
    }

    private UserInfo getUserInfoAO(String username) {
        UserInfo[] users = ao.find(UserInfo.class, "\"USERNAME\" = ?", username);
        if (users.length > 0) {
            return users[0];
        }
        return null;
    }
}
