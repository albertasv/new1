package ru.rosbank.jira.misc.action;

import com.atlassian.jira.security.xsrf.RequiresXsrfCheck;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.model.NewsModel;
import ru.rosbank.jira.misc.service.NewsService;

import javax.inject.Inject;

public class NewsEditAction extends RbMiscAction {

    private static final Logger LOG = LoggerFactory.getLogger(NewsEditAction.class);

    private NewsService newsService;

    private Integer newsId;
    private String newsText;

    @Inject
    public NewsEditAction(NewsService newsService) {
        this.newsService = newsService;

        String newsIdParam = getHttpRequest().getParameter("id");
        if (!Strings.isNullOrEmpty(newsIdParam)) {
            try {
                NewsModel news = newsService.findNews(Integer.parseInt(newsIdParam));
                if (news != null) {
                    newsId = news.getId();
                    newsText = news.getNews();
                }
            } catch (NumberFormatException nfe) {
            }
        }
    }

    @Override
    protected void doValidation() {
        if (isAdmin()) {
            return;
        } else {
            addErrorMessage("You don't have permission to view this issue.");
        }
        addErrorMessage("You don't have permission to view this issue or it wasn't found.");
    }

    @Override
    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    @RequiresXsrfCheck
    public String doSave() {
        if (!isAdmin()) {
            return PERMISSION_VIOLATION_RESULT;
        }

        NewsModel newsModel = newsService.saveNews(newsId, newsText);
        newsId = newsModel.getId();
        newsText = newsModel.getNews();
        return SUCCESS;
    }

    public Integer getNewsId() {
        return newsId;
    }

    public void setNewsId(Integer newsId) {
        this.newsId = newsId;
    }

    public String getNewsText() {
        return newsText;
    }

    public void setNewsText(String newsText) {
        this.newsText = newsText;
    }
}