package ru.rosbank.jira.misc.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;

public abstract class RbMiscAction extends JiraWebActionSupport {

    public boolean isAdmin() {
        ApplicationUser loggedInUser = getLoggedInUser();
        if (loggedInUser != null) {
            return ComponentAccessor.getGlobalPermissionManager().hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser);
        }
        return false;
    }

}
