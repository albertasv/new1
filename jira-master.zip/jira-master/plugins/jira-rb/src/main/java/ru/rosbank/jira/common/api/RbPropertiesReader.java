package ru.rosbank.jira.common.api;

import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Инкапсулирует логику загрузки файла конфигурации плагинов RB.
 * Должен использоваться только из реализации ConfigLoader-а.
 */
@Component
class RbPropertiesReader {

    private static final Logger LOG = LoggerFactory.getLogger(RbPropertiesReader.class);

    private final JiraHome jiraHome;

    @Autowired
    RbPropertiesReader(@ComponentImport JiraHome jiraHome) {
        this.jiraHome = jiraHome;
    }

    /**
     * Загружает свойства из указанного файла. Путь к файлу высчитывается относительно каталога JIRA_HOME.
     *
     * @param propertiesFileName относительный путь к файлу свойств
     */
    public Properties loadPropertiesFrom(String propertiesFileName) {

        String propertiesFileAbsolutePath = jiraHome.getHomePath() + "/" + propertiesFileName;
        Properties loadedProperties = new Properties();

        try (InputStream propertiesFileStream = new FileInputStream(propertiesFileAbsolutePath)) {
            loadedProperties.load(propertiesFileStream);
            return loadedProperties;
        } catch (IOException e) {
            LOG.error("Required configuration file not found: {}", propertiesFileAbsolutePath);
            loadedProperties.clear();
            return loadedProperties;
        }

    }

}
