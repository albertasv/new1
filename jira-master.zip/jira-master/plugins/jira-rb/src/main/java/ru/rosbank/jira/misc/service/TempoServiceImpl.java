package ru.rosbank.jira.misc.service;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.timezone.TimeZoneManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.mail.Email;
import com.atlassian.mail.MailException;
import com.atlassian.mail.server.MailServerManager;
import com.atlassian.mail.server.SMTPMailServer;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.message.I18nResolver;
import com.atlassian.velocity.VelocityManager;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import org.ofbiz.core.entity.GenericDataSourceException;
import ru.rosbank.jira.common.exceptions.LoadPlanCalendarException;
import ru.rosbank.jira.common.exceptions.LoadingAppointmentsException;
import net.java.ao.Query;
import org.apache.velocity.tools.generic.NumberTool;
import org.joda.time.DateTimeComparator;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.RosbankUtil;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.misc.model.PlanAllocationModel;
import ru.rosbank.jira.misc.ao.TempoAppointment;
import ru.rosbank.jira.misc.model.AppointmentModel;
import ru.rosbank.jira.misc.model.MessageModel;
import ru.rosbank.jira.misc.model.PlanActivityModel;
import ru.rosbank.jira.misc.model.WorklogEmailModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static ru.rosbank.jira.common.api.PriorityPlanningIssue.KEY_FROM_SUBJECT_FIRST;
import static ru.rosbank.jira.common.api.PriorityPlanningIssue.getPriorityPlanningIssue;
import static ru.rosbank.jira.misc.service.OsgiHacks.getBundleForPlugin;
import static ru.rosbank.jira.misc.service.OsgiHacks.withApplicationContext;
import static ru.rosbank.jira.misc.service.ReflectionHacks.*;

@Service
@Named
public class TempoServiceImpl implements TempoService {
    private static final Logger LOG = LoggerFactory.getLogger(TempoServiceImpl.class);

    private static final String TEMPO_DATE_FORMAT = "yyyy-MM-dd";
    private static final String TEMPO_PLUGIN_KEY = "is.origo.jira.tempo-plugin";
    private static final String TEMPO_PLAN_CORE_PLUGIN_KEY = "com.tempoplugin.tempo-plan-core";
    private static final String TEMPO_CORE_PLUGIN_KEY = "com.tempoplugin.tempo-core";

    private static final String WORKLOG_EMAIL_QUERY = "select username," +
            " display_name," +
            " email," +
            " team_role," +
            " team_name," +
            " worklog_month," +
            " plan_month," +
            " worklog_week," +
            " plan_week," +
            " worklog_email" +
            " from rb_worklog_email_v";
    private static final String PLAN_ACTIVITIES_QUERY = "select plan_id, plan_user_name, plan_start_date, plan_start_clock," +
            " plan_end_date, plan_comment, plan_issue_id, plan_seconds, worklog_id" +
            " from rb_plan_activity_v where plan_start_date BETWEEN '%s' AND '%s' and plan_user_name = '%s'";

    private static final String USERNAME_FIELD = "username";
    private static final String DISPLAY_NAME_FIELD = "display_name";
    private static final String EMAIL_FIELD = "email";
    private static final String TEAM_ROLE_FIELD = "team_role";
    private static final String TEAM_NAME_FIELD = "team_name";
    private static final String WORKLOG_MONTH_FIELD = "worklog_month";
    private static final String PLAN_MONTH_FIELD = "plan_month";
    private static final String WORKLOG_WEEK_FIELD = "worklog_week";
    private static final String PLAN_WEEK_FIELD = "plan_week";
    private static final String WORKLOG_EMAIL_FIELD = "worklog_email";

    private static final String TEMPLATES_DIRECTORY = "/templates/worklog/";
    private static final String WORKLOG_EMAIL_TEMPLATE = "worklogEmailTemplate.vm";

    private final UserInfoService userInfoService;
    private final ExchangeService exchangeService;
    private final IssueManager issueManager;
    private final UserManager userManager;
    private final VelocityManager velocityManager;
    private final MailServerManager mailServerManager;
    private final TimeZoneManager timeZoneManager;
    private final NumberTool numberTool;

    private final I18nResolver i18nResolver;
    private final ActiveObjects ao;
    private final BundleContext bundleCtx;

    private Object planningService;
    private Object tempoCorePlanningService;
    private Object worklogService;
    private Object inputWorklogsFactory;
    private Object activitySourceService;
    private Class<?> allocationBuilderClass;
    private Class<?> worklogBeanBuilderClass;
    private Class<?> inputWorklogsClass;
    private Class<?> activitySourceBuilderClass;
    private Class<?> tempoDateClass;
    private Object assigneeTypeUser;
    private Object scopeTypeNone;
    private Object planItemTypeIssue;
    private Object activitySource_TargetWorklog;
    private Object activitySource_SourcePlan;

    @Inject
    public TempoServiceImpl(@ComponentImport I18nResolver i18nResolver,
                            @ComponentImport ActiveObjects ao,
                            UserInfoService userInfoService,
                            ExchangeService exchangeService,
                            BundleContext bundleCtx) {
        this.i18nResolver = checkNotNull(i18nResolver);
        this.ao = checkNotNull(ao);
        this.userInfoService = userInfoService;
        this.exchangeService = exchangeService;
        this.bundleCtx = bundleCtx;
        this.issueManager = ComponentAccessor.getIssueManager();
        this.userManager = ComponentAccessor.getUserManager();
        this.velocityManager = ComponentAccessor.getVelocityManager();
        this.mailServerManager = ComponentAccessor.getMailServerManager();
        this.timeZoneManager = ComponentAccessor.getComponent(TimeZoneManager.class);
        this.numberTool = new NumberTool();

        try {
            this.planningService = withApplicationContext(this.bundleCtx, TEMPO_PLUGIN_KEY,
                    (appCtx, bundle) -> getServiceBean(appCtx, bundle, "com.tempoplugin.planning.PlanningService"));

            this.tempoCorePlanningService = withApplicationContext(this.bundleCtx, TEMPO_PLAN_CORE_PLUGIN_KEY,
                    (appCtx, bundle) -> getServiceBean(appCtx, bundle, "com.tempoplugin.jira.plan.core.api.PlanningService"));

            this.worklogService = withApplicationContext(this.bundleCtx, TEMPO_PLUGIN_KEY,
                    (appCtx, bundle) -> getServiceBean(appCtx, bundle, "com.tempoplugin.worklog.v4.services.WorklogService"));

            this.inputWorklogsFactory = withApplicationContext(this.bundleCtx, TEMPO_PLUGIN_KEY,
                    (appCtx, bundle) -> getServiceBean(appCtx, bundle, "com.tempoplugin.worklog.v4.rest.InputWorklogsFactory"));

            this.activitySourceService = withApplicationContext(this.bundleCtx, TEMPO_PLUGIN_KEY,
                    (appCtx, bundle) -> getServiceBean(appCtx, bundle, "com.tempoplugin.core.activitysource.service.ActivitySourceService"));

            Bundle tempoBundle = getBundleForPlugin(bundleCtx, TEMPO_PLUGIN_KEY);
            this.allocationBuilderClass = tempoBundle.loadClass("com.tempoplugin.jira.plan.core.api.Allocation$AllocationBuilder");
            this.worklogBeanBuilderClass = tempoBundle.loadClass("com.tempoplugin.worklog.v4.rest.TimesheetWorklogBean$Builder");
            this.inputWorklogsClass = tempoBundle.loadClass("com.tempoplugin.worklog.v4.model.InputWorklogs");

            this.assigneeTypeUser = getEnumValue(tempoBundle, "com.tempoplugin.jira.plan.core.api.AssigneeType", "USER");
            this.scopeTypeNone = getEnumValue(tempoBundle, "com.tempoplugin.jira.plan.core.api.ScopeType", "NONE");
            this.planItemTypeIssue = getEnumValue(tempoBundle, "com.tempoplugin.jira.plan.core.api.PlanItemType", "ISSUE");

            Bundle tempoCoreBundle = getBundleForPlugin(bundleCtx, TEMPO_CORE_PLUGIN_KEY);
            this.tempoDateClass = tempoCoreBundle.loadClass("com.tempoplugin.core.datetime.api.TempoDate");
            this.activitySourceBuilderClass = tempoCoreBundle.loadClass("com.tempoplugin.core.activitysource.model.ActivitySource$Builder");
            this.activitySource_TargetWorklog = getEnumValue(tempoCoreBundle, "com.tempoplugin.core.activitysource.model.ActivitySource$TargetType", "WORKLOG");
            this.activitySource_SourcePlan = getEnumValue(tempoCoreBundle, "com.tempoplugin.core.activitysource.model.ActivitySource$SourceType", "PLAN");
        } catch (Exception ex) {
            LOG.error("TempoServiceImpl initialization error", ex);
        }
    }

    @Override
    public TreeMap<String, String> loadAllCalendars() {
        List<UserInfoModel> users = getActiveUsersWithCalendarSync();
        TreeMap<String, String> errorLog = new TreeMap<>();
        LOG.debug("Starting of all calendars loading...");
        for (UserInfoModel user : users) {
            try {
                ApplicationUser appUser = userManager.getUserByName(user.getUsername());
                ComponentAccessor.getJiraAuthenticationContext().setLoggedInUser(appUser);
                LOG.debug("Load calendar for user: {}", user.getUsername());
                loadPlanCalendar(appUser);
                ComponentAccessor.getJiraAuthenticationContext().clearLoggedInUser();
            } catch (LoadPlanCalendarException lex) {
                LOG.debug("Loading calendar exception for user: {}", user.getUsername());
                errorLog.put(user.getUsername(), ErrorStackTracer.getStackTrace(lex));
            } catch (Exception ex) {
                LOG.debug("Exception in loadAllCalendars() method", ex);
            }
        }
        return errorLog;
    }

    @Override
    public List<UserInfoModel> getActiveUsersWithCalendarSync() {
        List<UserInfoModel> usersWithCalendarSyncList = userInfoService.getUserInfoByCalendarSync(true);
        List<UserInfoModel> inactiveUsersFromCalendarSyncList = new ArrayList<>();
        Set<ApplicationUser> allUsers = userManager.getAllUsers();
        for (ApplicationUser applicationUser : allUsers) {
            if (!applicationUser.isActive()) {
                for (UserInfoModel userWithCalendarSync : usersWithCalendarSyncList) {
                    if (userWithCalendarSync.getUsername().equals(applicationUser.getUsername())) {
                        inactiveUsersFromCalendarSyncList.add(userWithCalendarSync);
                    }
                }
            }
        }
        usersWithCalendarSyncList.removeAll(inactiveUsersFromCalendarSyncList);
        usersWithCalendarSyncList.forEach(user -> LOG.debug("CalendarSyncUser after updating is: {}", user.getUsername()));
        return usersWithCalendarSyncList;
    }

    @Override
    public List<AppointmentModel> loadPlanCalendar(ApplicationUser appUser) throws LoadPlanCalendarException {
        return loadPlanCalendar(appUser, null, null);
    }

    @Override
    public List<AppointmentModel> loadPlanCalendar(ApplicationUser appUser, Date from, Date to) throws LoadPlanCalendarException {

        UserInfoModel userInfo = userInfoService.getUserInfo(appUser.getUsername());
        if (userInfo != null) {

            String defaultPlanningIssueKey = userInfo.getPlanningIssue().toUpperCase();
            String excludedCategory = userInfo.getExcludedCategory();

            Issue defaultPlanningIssue = null;
            if (!Strings.isNullOrEmpty(defaultPlanningIssueKey)) {
                defaultPlanningIssue = issueManager.getIssueObject(defaultPlanningIssueKey);
            }
            if (defaultPlanningIssue != null) {
                from = getFirstDayOfWeekOrDefault(from);
                to = getLastDayOfWeekOrDefault(to);

                LOG.debug("Load appointments for {} fromCalendar {} toCalendar {}. Planning Issue {}", appUser.getUsername(), from, to);
                List<PlanActivityModel> existedPlanActivities = getPlanActivities(appUser.getUsername(), from, to, true);
                // Map<Integer, PlanActivityModel> existedPlanActivitiesMap = existedPlanActivities.stream().collect(Collectors.toMap(m -> m.getPlanId(), m -> m)); -
                // закомментировал, так как при использовании данной конструкции возникает ошибка обновления календаря со встречами в плагине Tempo.
                Map<Integer, PlanActivityModel> existedPlanActivitiesMap = new HashMap<>();
                for (PlanActivityModel existedPlanActivity : existedPlanActivities) {
                    existedPlanActivitiesMap.put(existedPlanActivity.getPlanId(), existedPlanActivity);
                }

                List<AppointmentModel> appointments = new ArrayList<>();
                try {
                    appointments = exchangeService.getAppointments(appUser.getEmailAddress(), from, to);

                    // Update received appointments
                    for (AppointmentModel appointment : appointments) {
                            //region JIRA-3471 Реализовать возможность добавления категории в исключения из загрузки
                            boolean hasExcludedCategory = false;
                            if (appointment.getCategories() != null && !Strings.isNullOrEmpty(excludedCategory) && excludedCategory.length() >= 3) {
                                for (String category : appointment.getCategories()) {
                                    if (category.contains(excludedCategory)) {
                                        hasExcludedCategory = true;
                                        break;
                                    }
                                }
                            }
                            if (hasExcludedCategory) continue;
                            //endregion

                            Issue subjectPlanningJiraIssue = null;
                            Issue categoryPlanningJiraIssue = null;
                            try {
                                //region Subject Issue
                                String subjectJiraKey = RosbankUtil.getJiraKey(appointment.getSubject());
                                if (subjectJiraKey != null) {
                                    subjectPlanningJiraIssue = issueManager.getIssueObject(subjectJiraKey);
                                }
                                //endregion

                                //region Category Issue
                                if (appointment.getCategories() != null) {
                                    for (String category : appointment.getCategories()) {
                                        String categoryJiraKey = RosbankUtil.getJiraKey(category);
                                        if (categoryJiraKey != null) {
                                            categoryPlanningJiraIssue = issueManager.getIssueObject(categoryJiraKey);
                                            if (categoryPlanningJiraIssue != null) break;
                                        }
                                    }
                                }
                                //endregion
                            } catch (Exception pasex) {
                                LOG.debug("Parsing appointment subject exception", pasex);
                                throw new LoadPlanCalendarException(pasex.getMessage(), pasex.getStackTrace());
                            }

                            Issue planningIssue;
                            if (getPriorityPlanningIssue(userInfo.getPriorityPlanningIssue()) == KEY_FROM_SUBJECT_FIRST) {
                                LOG.debug("Priority planning issue - KEY_FROM_SUBJECT_FIRST");
                                planningIssue = subjectPlanningJiraIssue != null ? subjectPlanningJiraIssue : categoryPlanningJiraIssue;
                            } else {
                                LOG.debug("Priority planning issue - KEY_FROM_CATEGORY_FIRST");
                                planningIssue = categoryPlanningJiraIssue != null ? categoryPlanningJiraIssue : subjectPlanningJiraIssue;
                            }
                            planningIssue = planningIssue == null ? defaultPlanningIssue : planningIssue;
                            TimeZone appUserTimeZone = timeZoneManager.getTimeZoneforUser(appUser);
                            addOrUpdatePlan(appointment, appUser, appUserTimeZone, planningIssue, existedPlanActivitiesMap);
                    }
                } catch (LoadingAppointmentsException loax) {
                    LOG.error("Parsing appointment exception in loadPlanCalendar() method", loax);
                    throw new LoadPlanCalendarException(loax.getMessage(), loax.getStackTrace());
                } catch (Exception ex) {
                    LOG.error("Exception in loadPlanCalendar() method", ex);
                    throw new LoadPlanCalendarException(ex.getMessage(), ex.getStackTrace());
                }
                // Delete appointments that not in received appointments and exists in database (added previously and removed from outlook calendar now)
                Set<String> appointmentsCurrentSet = appointments.stream().map(app -> app.getUniqueId()).collect(Collectors.toSet());
                List<TempoAppointment> appointmentMappingList = getTempoAppointments(appUser.getUsername(), from, to);
                for (TempoAppointment appointmentMapping : appointmentMappingList) {
                    if (!appointmentsCurrentSet.contains(appointmentMapping.getExchangeId())) {
                        deletePlan(appointmentMapping.getTempoId());
                    }
                }
                deleteDuplicatedTempoAppointments(appUser.getKey());
                return appointments;
            } else {
                LOG.debug("Planning Issue not found");
            }
        }
        return Collections.emptyList();
    }

    @Override
    public MessageModel statusPlanCalendar(ApplicationUser loggedInUser, Date from, Date to) {
        from = getFirstDayOfPreviousWeekOrDefault(from);
        to = getLastDayOfWeekOrDefault(to);
        LOG.info("Get status plan calendar for period {} - {}", from, to);
        SimpleDateFormat sdf = new SimpleDateFormat(TEMPO_DATE_FORMAT);
        List<PlanActivityModel> planActivities = getPlanActivities(loggedInUser.getUsername(), from, to, false);
        int count = planActivities.size();
        if (count == 0) {
            MessageModel res = new MessageModel(i18nResolver.getText("rb-tempo.worklog.load.no-plan"));
            res.setData(count);
            return res;
        }
        MessageModel res = new MessageModel(i18nResolver.getText("rb-tempo.worklog.load.confirmation",
                sdf.format(getFirstDayOfWeekOrDefault(from)),
                sdf.format(getLastDayOfWeekOrDefault(to)),
                String.valueOf(count)));
        res.setData(count);
        return res;
    }

    @Override
    public MessageModel loadWorklogCalendar(ApplicationUser loggedInUser, Date from, Date to) {
        from = getFirstDayOfPreviousWeekOrDefault(from);
        to = getLastDayOfWeekOrDefault(to);
        LOG.info("Convert plan to worklog for period {} - {}", from, to);
        SimpleDateFormat sdf = new SimpleDateFormat(TEMPO_DATE_FORMAT);
        List<PlanActivityModel> planActivities = getPlanActivities(loggedInUser.getUsername(), from, to, false);
        List<Long> worklogIds = new ArrayList<>();
        for (int i = 0; i < planActivities.size(); i++) {
            PlanActivityModel planActivity = planActivities.get(i);
            LOG.info("Trying to convert plan with id {}", planActivity.getPlanId());
            try {
                Object worklogBeanBuilder = ReflectionHacks.instantiate(worklogBeanBuilderClass);
                callMethod(worklogBeanBuilder, "issueIdOrKey", String.class, String.valueOf(planActivity.getIssueId()));
                String comment = planActivity.getComment();
                comment = Strings.isNullOrEmpty(comment) ? "Auto-created worklog" : ("Auto-created worklog: " + comment);
                callMethod(worklogBeanBuilder, "comment", String.class, comment);
                callMethod(worklogBeanBuilder, "startDate", String.class, sdf.format(planActivity.getStartDate()));
                callMethod(worklogBeanBuilder, "workerKey", String.class, loggedInUser.getKey());
                callMethod(worklogBeanBuilder, "timeSpentSeconds", Long.class, planActivity.getTimeSpentSeconds());
                callMethod(worklogBeanBuilder, "remainingEstimate", Long.class, 0l);
                Object worklogBean = callMethod(worklogBeanBuilder, "build");

                Object inputWorklogs = callMethod(inputWorklogsFactory, "buildForCreate", worklogBean.getClass(), worklogBean);
                List worklogs = (List) callMethod(worklogService, "createTempoWorklogs", inputWorklogsClass, inputWorklogs);
                long worklogId = (Long) callMethod(worklogs.get(0), "getId");

                Object tempoDate = callClassMethod(tempoDateClass, "ofDeprecatedDate", Date.class, planActivity.getStartDate());

                Object activitySourceBuilder = ReflectionHacks.instantiate(activitySourceBuilderClass,
                        activitySource_TargetWorklog, String.valueOf(worklogId),
                        activitySource_SourcePlan, String.valueOf(planActivity.getPlanId()),
                        tempoDate);
                Object activitySourceCreate = callMethod(activitySourceBuilder, "build");
                Object activitySource = callMethod(activitySourceService, "create", activitySourceCreate.getClass(), activitySourceCreate);
                worklogIds.add(worklogId);
                LOG.info("Successfully converted plan with id {} to worklog", planActivity.getPlanId(), worklogId);
            } catch (Exception ex) {
                LOG.error("Convert plan to worklog exception", ex);
            }
        }

        MessageModel res = new MessageModel(i18nResolver.getText("rb-tempo.worklog.load.success", planActivities.size(), worklogIds.size()));
        return res;
    }

    @Override
    public List<WorklogEmailModel> getWorklogEmails(boolean onlyWorklogEmail) {
        if (onlyWorklogEmail) {
            String where = "where worklog_email = 1";
            return getWorklogEmails(where);
        }
        return Collections.emptyList();
    }

    @Override
    public WorklogEmailModel getWorklogEmail(String username) {
        UserInfoModel ui = userInfoService.getUserInfo(username);
        if (ui == null) {
            return WorklogEmailModel.defaultWorklog();
        }
        List<WorklogEmailModel> worklogs = getWorklogEmails("where username = '" + ui.getUsername() + "'");
        return worklogs.isEmpty() ? WorklogEmailModel.defaultWorklog() : worklogs.get(0);
    }

    @Override
    public void sendWorklogEmails() {
        List<WorklogEmailModel> worklogs = getWorklogEmails(true);
        SMTPMailServer mailServer = mailServerManager.getDefaultSMTPMailServer();
        for (WorklogEmailModel worklog : worklogs) {
            if (worklog.getEmail() == null) {
                LOG.error("There is no email for {}", worklog.getUsername());
                continue;
            }
            if (worklog.getWorklogWeek() >= worklog.getPlanWeek()) {
                LOG.info("Correctly: Worklog week >= than planned worklog week. E-mail won't be sent for " + worklog.getUsername());
                continue;
            }
            try {
                sendWorklogEmail(mailServer, worklog);
                LOG.info("Correctly: Worklog week < than planned worklog week. E-mail was sent for " + worklog.getUsername());
            } catch (Exception ex) {
                LOG.error("Cannot send email", ex);
            }
        }
    }

    @Override
    public void sendWorklogEmail(String username) {
        WorklogEmailModel worklog = getWorklogEmail(username);
        SMTPMailServer mailServer = mailServerManager.getDefaultSMTPMailServer();
        if (worklog.getEmail() == null) {
            LOG.error("There is no email for {}", worklog.getUsername());
            return;
        }
        try {
            sendWorklogEmail(mailServer, worklog);
        } catch (Exception ex) {
            LOG.error("Cannot send email", ex);
        }
    }

    private void sendWorklogEmail(SMTPMailServer mailServer, WorklogEmailModel worklog) throws MailException {
        Map<String, Object> context = new HashMap<>();
        context.put("worklog", worklog);
        context.put("numberTool", numberTool);

        String body = velocityManager.getEncodedBody(TEMPLATES_DIRECTORY, WORKLOG_EMAIL_TEMPLATE, "UTF-8", context);
        Email email = new Email(worklog.getEmail());
        email.setTo(worklog.getEmail());
        email.setMimeType("text/html");
        email.setSubject("Tempo - Уведомление о списаниях трудозатрат");
        email.setBody(body);
        mailServer.send(email);
    }

    private int addOrUpdatePlan(AppointmentModel appointment, ApplicationUser appUser, TimeZone appUserTimeZone, Issue issue, Map<Integer, PlanActivityModel> existedPlanActivitiesMap) throws Exception {
        try {
            String subject = appointment.getSubject();
            Date startDate = appointment.getStart();
            Date endDate = appointment.getEnd();

            long secondsPerDay = (endDate.getTime() - startDate.getTime()) / 1000l;
            if (secondsPerDay > 24 * 60 * 60) {
                LOG.error("Trying add plan item with duration more than 1 day");
                return -1;
            }

            TempoAppointment tempoAppointment = getTempoAppointment(appointment.getUniqueId());

            LocalDate startLocalDate = new LocalDate(startDate);
            LocalTime startLocalTime;
            if (appUserTimeZone != null) {
                DateTimeZone dateTimeZone = DateTimeZone.forTimeZone(appUserTimeZone);
                startLocalTime = new LocalTime(startDate, dateTimeZone);
            } else {
                startLocalTime = new LocalTime(startDate);
            }
            LocalDate endLocalDate = startLocalDate.plusDays(1);

            // for new appointment - tempoId is null
            Integer tempoId = null;
            if (tempoAppointment != null) {
                Integer existedTempoAppointmentId = tempoAppointment.getTempoId();
                if (existedPlanActivitiesMap.containsKey(existedTempoAppointmentId)) {
                    tempoId = existedTempoAppointmentId;
                    PlanActivityModel planActivityModel = existedPlanActivitiesMap.get(tempoId);
                    if (planActivityModel.getWorklogId() != null ||
                            subject.equals(planActivityModel.getComment()) &&
                                    issue.getId() != null && issue.getId().equals(planActivityModel.getIssueId()) &&
                                    DateTimeComparator.getDateOnlyInstance().compare(startDate, planActivityModel.getStartDate()) == 0 &&
                                    secondsPerDay == planActivityModel.getTimeSpentSeconds())
                        return tempoId;
                }
            }

            Object allocationBuilder = ReflectionHacks.instantiate(allocationBuilderClass);
            callMethod(allocationBuilder, "scopeType", scopeTypeNone.getClass(), scopeTypeNone);
            callMethod(allocationBuilder, "assigneeType", assigneeTypeUser.getClass(), assigneeTypeUser);
            callMethod(allocationBuilder, "assigneeKey", String.class, appUser.getKey());
            callMethod(allocationBuilder, "planItemId", long.class, issue.getId());
            callMethod(allocationBuilder, "planItemType", planItemTypeIssue.getClass(), planItemTypeIssue);

            callMethod(allocationBuilder, "startDate", LocalDate.class, startLocalDate);
            callMethod(allocationBuilder, "endDate", LocalDate.class, endLocalDate);
            callMethod(allocationBuilder, "startTimePerDay", LocalTime.class, startLocalTime);
            callMethod(allocationBuilder, "secondsPerDay", Long.class, secondsPerDay);
            callMethod(allocationBuilder, "description", String.class, subject);
            if (tempoId != null) {
                callMethod(allocationBuilder, "id", int.class, tempoId);
            }
            Object allocation = callMethod(allocationBuilder, "build");

            if (allocation != null) {
                if (tempoId == null) {
                    Object plan = callMethod(tempoCorePlanningService, "createPlan", allocation.getClass(), allocation);
                    tempoId = (Integer) callMethod(plan, "getId");
                } else {
                    Object plan = callMethod(tempoCorePlanningService, "updateAllocation", allocation.getClass(), allocation);
                }
                addOrUpdateTempoAppointment(appUser.getUsername(), appointment.getUniqueId(), appointment.getICalUid(), tempoId, startDate);
            } else {
                LOG.error("Error while adding / updating tempo plan for user {}, issue: {}, startDate: {} endDate: {}, secondsPerDay: {}", appUser.getUsername(), issue.getKey(), startDate, endDate, secondsPerDay);
            }

        } catch (Exception ex) {
            LOG.error("TempoServiceImpl add / update plan exception", ex);
            throw ex;
        }
        return -1;
    }

    private void addOrUpdateTempoAppointment(String username, String uniqueId, String iCalUid, Integer tempoId, Date startDate) {
        TempoAppointment[] appointments = ao.find(TempoAppointment.class,
                Query.select().where("\"TEMPO_ID\" = ?", tempoId));
        if (appointments != null && appointments.length > 0) {
            for (TempoAppointment app : appointments) {
                app.setICalUid(iCalUid);
                app.setTempoId(tempoId);
                app.setStartDate(startDate);
                app.setLastUpdatedBy(username);
                app.setLastUpdateDate(new Date());
                app.save();
            }
        } else {
            ao.create(TempoAppointment.class,
                    ImmutableMap.<String, Object>builder()
                            .put("TEMPO_ID", tempoId)
                            .put("START_DATE", startDate)
                            .put("EXCHANGE_ID", uniqueId)
                            .put("ICAL_UID", iCalUid)
                            .put("LAST_UPDATED_BY", username)
                            .put("LAST_UPDATE_DATE", new Date())
                            .build()
            );
        }
    }

    private void deletePlan(int tempoId) {
        try {
            LOG.debug("Delete tempo plan {}", tempoId);
            callMethod(planningService, "delete", int.class, tempoId);
            LOG.debug("Delete tempo plan mapping {}", tempoId);
            TempoAppointment[] ta = ao.find(TempoAppointment.class,
                    Query.select().where("\"TEMPO_ID\" = ?", tempoId).limit(1));
            if (ta != null & ta.length > 0) {
                ao.delete(ta[0]);
            }
        } catch (Exception ex) {
            LOG.error("Delete tempo plan {} exception {}", tempoId, ex);
        }
    }

    /*При синхронизации с календарём MS Exchange иногда возникают дубликаты встреч в календаре Tempo. Причина
     возникновения дубликатов в коммерческом плагине Tempo не выяснена, поэтому для принудительного
     удаления дубликатов используется этот метод*/
    private void deleteDuplicatedTempoAppointments(String username) {
        LOG.debug("Deleting appointment duplicates...");
        SQLProcessor sqlProcessor = new SQLProcessor("defaultDS");
        List<PlanAllocationModel>planAllocationModelList = new ArrayList<>();
        try {
            ResultSet rs = sqlProcessor.executeQuery("SELECT plan.\"ID\", plan.\"ASSIGNEE_KEY\", plan.\"DESCRIPTION\"," +
                    " plan.\"PLAN_ITEM_ID\", plan.\"CREATED\", plan.\"SECONDS_PER_DAY\",\n" +
                    " plan.\"END_TIME\", activity.\"WORKLOG_ID\"\n" +
                    " FROM \"AO_2D3BEA_PLAN_ALLOCATION\" plan LEFT JOIN \"AO_013613_ACTIVITY_SOURCE\" activity\n" +
                    "        ON activity.\"SOURCE_ID\"::numeric=plan.\"ID\"\n" +
                    " WHERE \"ASSIGNEE_KEY\"=\'" + username + "\' ORDER BY \"ID\" DESC LIMIT(100);");
            while (rs.next()) {
                PlanAllocationModel planAllocationModel = new PlanAllocationModel();
                planAllocationModel.setId(rs.getInt("ID"));
                planAllocationModel.setAssigneeKey(rs.getString("ASSIGNEE_KEY"));
                planAllocationModel.setDescription(rs.getString("DESCRIPTION"));
                planAllocationModel.setIssueId(rs.getInt("PLAN_ITEM_ID"));
                planAllocationModel.setCreated(rs.getTimestamp("CREATED"));
                planAllocationModel.setSecondsPerDay(rs.getInt("SECONDS_PER_DAY"));
                planAllocationModel.setEndTime(rs.getTimestamp("END_TIME"));
                planAllocationModel.setWorklogId(rs.getInt("WORKLOG_ID"));
                planAllocationModelList.add(planAllocationModel);
            }
            Set<Integer> planAllocationsToDelete = new HashSet<>();
            for (int i = 0; i < planAllocationModelList.size() - 1; i++) {
                for (int j = i + 1; j < planAllocationModelList.size(); j++) {
                    if (planAllocationModelList.get(i).getAssigneeKey().equals(planAllocationModelList.get(j).getAssigneeKey())
                        && planAllocationModelList.get(i).getCreated().getTime() - planAllocationModelList.get(j).getCreated().getTime() < 1000
                        && planAllocationModelList.get(i).getEndTime().equals(planAllocationModelList.get(j).getEndTime())
                        && planAllocationModelList.get(i).getIssueId() == planAllocationModelList.get(j).getIssueId()
                        && planAllocationModelList.get(i).getSecondsPerDay() == planAllocationModelList.get(j).getSecondsPerDay()
                        && planAllocationModelList.get(i).getDescription().equals(planAllocationModelList.get(j).getDescription())) {
                        if (planAllocationModelList.get(i).getWorklogId() == 0) {
                            planAllocationsToDelete.add(planAllocationModelList.get(i).getId());
                        } else {
                            planAllocationsToDelete.add(planAllocationModelList.get(j).getId());
                        }
                    }
                }
            }

            if (!planAllocationsToDelete.isEmpty()) {
                planAllocationsToDelete.stream().forEach(planAllocation -> {
                    deletePlan(planAllocation);
                });
            }

            sqlProcessor.close();
        } catch (Exception ex) {
            try {
                sqlProcessor.close();
            } catch (GenericDataSourceException e) {
                throw new RuntimeException(e);
            }
            LOG.error("Duplicated Tempo Appointments deleting exception {}", ex.getMessage());
        }
    }

    /**
     * Два ID см. JIRA-3464 Дублируются встречи при загрузке
     *
     * @param uniqueId
     * @return
     */
    private TempoAppointment getTempoAppointment(String uniqueId) {
        TempoAppointment[] res = ao.find(TempoAppointment.class,
                Query.select()
                        .where("\"EXCHANGE_ID\" = ?", uniqueId)
                        .order("ID DESC")
        );
        if (res.length > 0) {
            return res[0];
        }
        return null;
    }

    private List<TempoAppointment> getTempoAppointments(String username, Date from, Date to) {
        TempoAppointment[] res = ao.find(TempoAppointment.class,
                Query.select().where("\"LAST_UPDATED_BY\" = ? AND \"START_DATE\" >= ? AND \"START_DATE\" <= ?", username, from, to));
        return Arrays.stream(res).collect(Collectors.toList());
    }

    private List<WorklogEmailModel> getWorklogEmails(String where) {
        List<WorklogEmailModel> worklogs = new ArrayList<>();
        SQLProcessor sqlProcessor = null;
        try {
            sqlProcessor = new SQLProcessor("defaultDS");
            ResultSet rs = sqlProcessor.executeQuery(WORKLOG_EMAIL_QUERY + " " + where);
            while (rs.next()) {
                WorklogEmailModel worklog = new WorklogEmailModel();
                worklog.setUsername(rs.getString(USERNAME_FIELD));
                worklog.setDisplayName(rs.getString(DISPLAY_NAME_FIELD));
                worklog.setEmail(rs.getString(EMAIL_FIELD));
                worklog.setTeamName(rs.getString(TEAM_NAME_FIELD));
                worklog.setTeamRole(rs.getString(TEAM_ROLE_FIELD));
                worklog.setWorklogMonth(rs.getDouble(WORKLOG_MONTH_FIELD));
                worklog.setPlanMonth(rs.getDouble(PLAN_MONTH_FIELD));
                worklog.setWorklogWeek(rs.getDouble(WORKLOG_WEEK_FIELD));
                worklog.setPlanWeek(rs.getDouble(PLAN_WEEK_FIELD));
                worklog.setWorklogEmail(rs.getInt(WORKLOG_EMAIL_FIELD));
                worklogs.add(worklog);
            }
        } catch (GenericEntityException | SQLException ex) {
            LOG.error("Get worklog data error: {}", ex);
        } finally {
            if (sqlProcessor != null) {
                try {
                    sqlProcessor.close();
                } catch (GenericEntityException e) {
                    LOG.error("Get worklog data sqlProcessor error: {}", e);
                }
            }
        }
        return worklogs;
    }

    /**
     * Plans with / without linked worklogs
     */
    private List<PlanActivityModel> getPlanActivities(String username, Date from, Date to, boolean withWorklog) {
        List<PlanActivityModel> res = new ArrayList<>();
        SQLProcessor sqlProcessor = null;
        try {
            sqlProcessor = new SQLProcessor("defaultDS");
            SimpleDateFormat sdf = new SimpleDateFormat(TEMPO_DATE_FORMAT);
            ResultSet rs = sqlProcessor.executeQuery(String.format(PLAN_ACTIVITIES_QUERY +
                            (withWorklog ? "" : " AND worklog_id is null")
                    , sdf.format(from), sdf.format(to), username));
            while (rs.next()) {
                PlanActivityModel plan = new PlanActivityModel();
                plan.setPlanId(rs.getInt("plan_id"));
                plan.setIssueId(rs.getLong("plan_issue_id"));
                plan.setWorkerKey(rs.getString("plan_user_name"));
                plan.setComment(rs.getString("plan_comment"));
                plan.setStartDate(rs.getDate("plan_start_date"));
                plan.setStartClock(rs.getString("plan_start_clock"));
                plan.setEndDate(rs.getDate("plan_end_date"));
                plan.setTimeSpentSeconds(rs.getLong("plan_seconds"));
                plan.setWorklogId(rs.getString("worklog_id"));
                res.add(plan);
            }
        } catch (GenericEntityException | SQLException ex) {
            LOG.error("Get plan activity data error: {}", ex);
        } finally {
            if (sqlProcessor != null) {
                try {
                    sqlProcessor.close();
                } catch (GenericEntityException e) {
                    LOG.error("Get plan activity data sqlProcessor error: {}", e);
                }
            }
        }
        return res;
    }

    private Date getFirstDayOfWeekOrDefault(Date date) {
        Calendar fromCalendar = Calendar.getInstance();
        if (date != null) {
            fromCalendar.setTime(date);
        } else {
            fromCalendar.set(Calendar.DAY_OF_WEEK, fromCalendar.getFirstDayOfWeek());
        }
        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
        fromCalendar.set(Calendar.MINUTE, 0);
        fromCalendar.set(Calendar.SECOND, 0);
        fromCalendar.set(Calendar.MILLISECOND, 0);
        return fromCalendar.getTime();
    }

    private Date getLastDayOfWeekOrDefault(Date date) {
        Calendar toCalendar = Calendar.getInstance();
        if (date != null) {
            toCalendar.setTime(date);
        } else {
            toCalendar.set(Calendar.DAY_OF_WEEK, toCalendar.getFirstDayOfWeek());
            toCalendar.add(Calendar.DAY_OF_WEEK, 6);
        }
        toCalendar.set(Calendar.HOUR_OF_DAY, 23);
        toCalendar.set(Calendar.MINUTE, 59);
        toCalendar.set(Calendar.SECOND, 59);
        toCalendar.set(Calendar.MILLISECOND, 999);
        return toCalendar.getTime();
    }

    // JIRA-3905 Для удобства пользователей запланированное время списывается за последние две недели, а не одну
    private Date getFirstDayOfPreviousWeekOrDefault(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date != null) {
            calendar.setTime(date);
        } else {
            calendar.add(Calendar.DAY_OF_WEEK, -7);
            calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());
        }
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
}
