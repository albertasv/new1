package ru.rosbank.jira.misc.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.user.ApplicationUser;
import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ClickLogService;

import javax.inject.Inject;
import java.util.Map;

public class RedirectAction extends RbMiscAction {

    private static final Logger LOG = LoggerFactory.getLogger(RedirectAction.class);

    private final ClickLogService clickLogService;
    // TODO Move to config or database
    private final Map<String, String> REDIRECT_MAP = ImmutableMap.<String, String>builder()
            .put("JIRA_KB", "https://kb.rosbank.rus.socgen/display/PAT")
            .put("JIRA_FAQ", "https://kb.rosbank.rus.socgen/x/uuOiG")
            .put("JIRA_NEW_ISSUE", "https://kb.rosbank.rus.socgen/display/PAT?newIssue=1")
            .put("JIRA_NEW_PROJECT", "https://support.rosbank.rus.socgen/calls/create/R1432?complete_user=1&%D0%A1%D0%B8%D1%81%D1%82%D0%B5%D0%BC%D0%B0=Jira&%D0%94%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D0%B8%D0%B5=%D0%A1%D0%BE%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5%20%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82%D0%BE%D0%B2")
            .put("MAINTAIN_RELEASE", "/secure/ReleaseDogCreateRelease.jspa")
            .put("ARCHIVED_ISSUES", "https://rbitdas00007.test.rus.socgen/issues/?jql=")
            .build();

    @Inject
    public RedirectAction(ClickLogService clickLogService) {
        this.clickLogService = clickLogService;
    }

    @Override
    public String execute() throws Exception {
        String redirect = getHttpRequest().getParameter("redirect");
        if (redirect == null || !REDIRECT_MAP.containsKey(redirect)) {
            return ISSUE_NOT_FOUND_RESULT;
        }

        // Enable logging redirect
        if (LOG.isInfoEnabled()) {
            clickLogService.addClickLog(redirect);
        }

        getRedirect(REDIRECT_MAP.get(redirect), true);
        return super.execute();
    }

    public boolean isAdmin() {
        ApplicationUser loggedInUser = getLoggedInUser();
        if (loggedInUser != null) {
            return ComponentAccessor.getGlobalPermissionManager().hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser);
        }
        return false;
    }
}
