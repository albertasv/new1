package ru.rosbank.jira.common.service;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.util.Base64;

public class CredentialUtil {
    public static String encrypt(String text, String key) {
        try {
            Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, aesKey);
            return new String(Base64.getEncoder().encode(cipher.doFinal(text.getBytes())));
        } catch (GeneralSecurityException ges) {
            throw new RuntimeException(ges);
        }
    }

    public static String decrypt(String text, String key) {
        try {
            Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, aesKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(text.getBytes())));
        } catch (GeneralSecurityException ges) {
            throw new RuntimeException(ges);
        }
    }
}
