package ru.rosbank.jira.common.api;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClickLogModelImpl implements ClickLogModel {

    private String username;
    private String topic;
    private Date lastUpdateDate;
    private int click;

    public ClickLogModelImpl() {
    }

    public ClickLogModelImpl(String username, String topic) {
        this.username = username;
        this.topic = topic;
        this.lastUpdateDate = new Date();
        this.click = 1;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    public void setTopic(String topic) {
        this.topic = topic;
    }

    @Override
    public int getClick() {
        return click;
    }

    @Override
    public void setClick(int i) {
        this.click = click;
    }

    @Override
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    @Override
    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }
}
