package ru.rosbank.jira.misc.service;

import com.google.common.primitives.Primitives;
import org.osgi.framework.Bundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ReflectionHacks {

    private static final Logger LOG = LoggerFactory.getLogger(ReflectionHacks.class);

    public static Object callClassMethod(Class clazz, String methodName) throws Exception {
        Method m = getClassMethod(clazz, methodName);
        return m.invoke(null);
    }

    public static Object callClassMethod(Class clazz, String methodName, Class argType, Object arg) throws Exception {
        Method m = getClassMethod(clazz, methodName, argType);
        return m.invoke(null, arg);
    }

    public static Object callMethod(Object object, String methodName) throws Exception {
        Method m = getMethod(object, methodName);
        return m.invoke(object);
    }

    public static Object callMethod(Object object, String methodName, Class argType, Object arg) throws Exception {
        Method m = getMethod(object, methodName, argType);
        return m.invoke(object, arg);
    }

    public static Object callMethod(Object object, String methodName, Class argType1, Object arg1, Class argType2, Object arg2) throws Exception {
        Method m = getMethod(object, methodName, argType1, argType2);
        Object invoke = null;
        try {
            invoke = m.invoke(object, arg1, arg2);
        } catch (Exception ex) {
            LOG.error("fail to invoke!", ex);
        }
        return invoke;
    }

    public static Object callMethod(Object object, String methodName, Class argType1, Object arg1,
                                    Class argType2, Object arg2, Class argType3, Object arg3) throws Exception {
        Method m = getMethod(object, methodName, argType1, argType2, argType3);
        Object invoke = null;
        try {
            invoke = m.invoke(object, arg1, arg2, arg3);
        } catch (Exception ex) {
            LOG.error("fail to invoke!", ex);
        }
        return invoke;
    }

    public static Method getMethod(Object object, String methodName, Class... argumentTypes) throws Exception {
        return getClassMethod(object.getClass(), methodName, argumentTypes);
    }

    public static Method getClassMethod(Class<?> cls, String methodName, Class... argumentTypes) throws Exception {
        Method m = null;
        NoSuchMethodException exception = null;
        while (cls != null) {
            try {
                m = cls.getDeclaredMethod(methodName, argumentTypes);
                break;
            } catch (NoSuchMethodException ex) {
                if (exception == null) {
                    exception = ex;
                }

                cls = cls.getSuperclass();
            }
        }
        if (m == null) {
            assert exception != null;
            throw exception;
        } else {
            m.setAccessible(true);
            return m;
        }
    }

    public static Object instantiate(Class<?> clazz, Object... args) throws Exception {
        Constructor<?>[] constructors = clazz.getConstructors();
        Constructor<?> suitableConstructor = null;
        Constructor[] obj = constructors;
        for (int i = 0; i < constructors.length; ++i) {
            Constructor<?> constructor = obj[i];
            if (checkConstructor(constructor, args)) {
                if (suitableConstructor != null) {
                    return null;
                }
                suitableConstructor = constructor;
            }
        }
        if (suitableConstructor == null) {
            return null;
        } else {
            return suitableConstructor.newInstance(args);
        }
    }

    private static boolean checkConstructor(Constructor<?> constructor, Object... args) {
        Class<?>[] types = constructor.getParameterTypes();
        if (types.length != args.length) {
            return false;
        } else {
            for (int i = 0; i < types.length; ++i) {
                if (args[i] != null) {
                    Class<?> wrappedType = Primitives.wrap(types[i]);
                    if (!wrappedType.isAssignableFrom(args[i].getClass())) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    public static Object getEnumValue(Bundle bundle, String enumClassName, String enumValueName) throws Exception {
        Class<?> enumClass = bundle.loadClass(enumClassName);
        for (Object enumValue : enumClass.getEnumConstants()) {
            if (enumValueName.equals(enumValue.toString())) {
                return enumValue;
            }
        }
        return null;
    }

    public static Object getServiceBean(ApplicationContext appCtx, Bundle bundle, String serviceClassName) {
        if (bundle == null) {
            return null;
        } else if (appCtx == null) {
            return null;
        } else {
            Class serviceClass;
            try {
                serviceClass = bundle.loadClass(serviceClassName);
            } catch (ClassNotFoundException var7) {
                return null;
            }

            Object service = appCtx.getBean(serviceClass);
            if (service == null) {
                return null;
            } else {
                return service;
            }
        }
    }
}
