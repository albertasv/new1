package ru.rosbank.jira.misc.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ClickLogService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import static com.google.common.base.Preconditions.checkNotNull;

@Component
@Path("/menu")
public class JiraMainMenuClickCounterRestResource {

    private final ClickLogService clickLogService;
    private static final Logger LOG = LoggerFactory.getLogger(JiraMainMenuClickCounterRestResource.class);

    @Inject
    public JiraMainMenuClickCounterRestResource(ClickLogService clickLogService) {
        this.clickLogService = checkNotNull(clickLogService);
    }

    //Логирование нажатий пользователей на кнопку Support (Поддержка) и на кнопку help
    @GET
    @Path("/click/support/{menuName}")
    public String clickSupportMenu(@PathParam("menuName") String menuName) {

        switch (menuName) {
           case "rb_jira_help_links_link":
               clickLogService.addClickLog("SUPPORT_MENU");
               break;
           case "qbr":
               clickLogService.addClickLog("QBR_STRUCTURE_VIEW");
               break;
           case "news_bell":
               clickLogService.addClickLog("NEWS_BELL");
               break;
           case "help_link0":
               clickLogService.addClickLog("HELP_LINK0");
               break;
           case "help_link1":
               clickLogService.addClickLog("HELP_LINK1");
               break;
           case "help_link2":
               clickLogService.addClickLog("HELP_LINK2");
               break;
           case "help_link3":
               clickLogService.addClickLog("HELP_LINK3");
               break;
           case "help_link4":
               clickLogService.addClickLog("HELP_LINK4");
               break;
           case "help_link5":
               clickLogService.addClickLog("HELP_LINK5");
               break;
           case "help_link6":
               clickLogService.addClickLog("HELP_LINK6");
               break;
           case "help_link7":
               clickLogService.addClickLog("HELP_LINK7");
               break;
           case "help_link8":
               clickLogService.addClickLog("HELP_LINK8");
               break;
           case "help_link9":
                clickLogService.addClickLog("HELP_LINK9");
                break;
            case "help_link10":
                clickLogService.addClickLog("HELP_LINK10");
                break;
           case "archived_issues_link":
               clickLogService.addClickLog("ARCHIVED_ISSUES_LINK");
               break;
        }
        return null;
    }
}
