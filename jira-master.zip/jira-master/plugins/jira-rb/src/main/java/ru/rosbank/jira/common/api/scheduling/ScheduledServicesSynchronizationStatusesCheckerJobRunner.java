package ru.rosbank.jira.common.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ServicesSynchronizationStatusesChecker;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Named;

/**
 * Класс, который запускает процесс по проверке ошибок при синхронизации справочников из RBStaff, SM и СБУ
 */
@Named("servicesSynchronizationStatusesCheckerJobRunner")
public class ScheduledServicesSynchronizationStatusesCheckerJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledServicesSynchronizationStatusesCheckerJobRunner.class);

    private final ServicesSynchronizationStatusesChecker servicesSynchronizationStatusesChecker;


    public ScheduledServicesSynchronizationStatusesCheckerJobRunner(
            ServicesSynchronizationStatusesChecker servicesSynchronizationStatusesChecker){
        this.servicesSynchronizationStatusesChecker = servicesSynchronizationStatusesChecker;
    }


    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest request) {
        LOG.info("Executing checking servicesSynchronizationStatusesChecker");
        try {
            servicesSynchronizationStatusesChecker.checkServicesSynchronizationStatuses();
        } catch (Exception e) {
            LOG.error("Some error with checking service's synchronization statuses: {}", ErrorStackTracer.getStackTrace(e));
        }
        return null;
    }
}
