package ru.rosbank.jira.misc.model;

import ru.rosbank.jira.misc.ao.ServiceStatuses;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExternalServiceStatusModel {

    private int id;

    private String serviceName;

    private String message;

    private String status;

    private Date lastUpdateDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public static List<ExternalServiceStatusModel> convert(ServiceStatuses[] items) {
        if (items == null) {
            return null;
        }
        List<ExternalServiceStatusModel> externalServiceStatusModelList = new ArrayList<>();
        for (int i = 0; i < items.length; i ++) {
            ExternalServiceStatusModel externalServiceStatusModel = new ExternalServiceStatusModel();
            externalServiceStatusModel.setId(items[i].getID());
            externalServiceStatusModel.setServiceName(items[i].getServiceName());
            externalServiceStatusModel.setMessage(items[i].getMessage());
            externalServiceStatusModel.setStatus(items[i].getStatus());
            externalServiceStatusModel.setLastUpdateDate(items[i].getLastUpdateDate());
            externalServiceStatusModelList.add(externalServiceStatusModel);
        }
        return externalServiceStatusModelList;
    }
}
