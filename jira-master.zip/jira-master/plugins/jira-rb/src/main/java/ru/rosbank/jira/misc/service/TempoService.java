package ru.rosbank.jira.misc.service;

import com.atlassian.jira.user.ApplicationUser;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.exceptions.LoadPlanCalendarException;
import ru.rosbank.jira.common.exceptions.LoadingAppointmentsException;
import ru.rosbank.jira.misc.model.AppointmentModel;
import ru.rosbank.jira.misc.model.MessageModel;
import ru.rosbank.jira.misc.model.WorklogEmailModel;

import java.util.Date;
import java.util.List;
import java.util.TreeMap;

public interface TempoService {
    TreeMap <String, String>  loadAllCalendars();

    List<AppointmentModel> loadPlanCalendar(ApplicationUser appUser) throws LoadPlanCalendarException, LoadingAppointmentsException;

    List<AppointmentModel> loadPlanCalendar(ApplicationUser appUser, Date from, Date to) throws LoadPlanCalendarException, LoadingAppointmentsException;

    MessageModel statusPlanCalendar(ApplicationUser loggedInUser, Date from, Date to);

    MessageModel loadWorklogCalendar(ApplicationUser loggedInUser, Date from, Date to);

    List<WorklogEmailModel> getWorklogEmails(boolean onlyWorklogEmail);

    WorklogEmailModel getWorklogEmail(String username);

    void sendWorklogEmails();

    void sendWorklogEmail(String username);

    List<UserInfoModel> getActiveUsersWithCalendarSync();
}
