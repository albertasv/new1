package ru.rosbank.jira.misc;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.parser.JqlParseException;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.permission.ProjectPermissions;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleActors;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugin.spring.scanner.annotation.imports.JiraImport;
import com.atlassian.plugin.web.ContextProvider;
import com.google.common.collect.Maps;
import org.apache.velocity.tools.generic.EscapeTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ProjectPropertyConstants;
import ru.rosbank.jira.common.api.ProjectPropertyModel;
import ru.rosbank.jira.common.api.ProjectPropertyService;

import javax.inject.Inject;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class ProjectInfoContextProvider implements ContextProvider {

    private final PermissionManager permissionManager;
    private final ProjectPropertyService projectPropertyService;

    private static final Logger LOG = LoggerFactory.getLogger(ProjectInfoContextProvider.class);

    @Inject
    public ProjectInfoContextProvider(@ComponentImport PermissionManager permissionManager,
                                      ProjectPropertyService projectPropertyService) {
        this.permissionManager = permissionManager;
        this.projectPropertyService = projectPropertyService;
    }

    public void init(Map params) throws PluginParseException {
    }

    /*
     * request
     * selectedQuery
     * projectKeyEncoded
     * settingsUrl
     * project
     * selectedBoardId
     * isSelectedBoardTypeScrum
     * projectKey
     * helper
     * queryEncodedProjectKey
     * noIssuesInProject
     * user
     * selectedBoard
     * pathEncodedProjectKey
     * username
     */

    public Map getContextMap(Map context) {
        ApplicationUser user = (ApplicationUser) context.get("user");
        if (user == null) {
            String username = (String) context.get("username");
            user = this.getUserManager().getUserByName(username);
        }

        Map<String, Object> ctx = Maps.newHashMap();
        Project project = (Project) context.get("project");

        if (project != null) {
            ctx.put("esc", new EscapeTool());
            
            ctx.put("project", project);
            ctx.put("administrators", this.getMembers(project, "Administrators"));

            ctx.put("permissionScheme", ComponentAccessor.getPermissionSchemeManager().getSchemeFor(project).getName());
            ctx.put("issueTypeScheme", ComponentAccessor.getIssueTypeSchemeManager().getConfigScheme(project).getName());
            ctx.put("workflowScheme", ComponentAccessor.getWorkflowSchemeManager().getWorkflowSchemeObj(project).getName());
            ctx.put("screenScheme", ComponentAccessor.getIssueTypeScreenSchemeManager().getIssueTypeScreenScheme(project).getName());

            List<ProjectPropertyModel> projectProperties = projectPropertyService.search(project.getId());
            if (!projectProperties.isEmpty()) {
                for (ProjectPropertyModel projectProperty : projectProperties) {
                    switch (projectProperty.getKey()) {
                        case ProjectPropertyConstants.AGILE_TEAM:
                            ctx.put("agileTeam", projectProperty.getValue());
                            break;
                        case ProjectPropertyConstants.SYSTEMS_CONTEXT:
                            ctx.put("systems", projectProperty.getValue());
                            break;
                        case ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION:
                            ctx.put("smDoneAction", projectProperty == null ? ProjectPropertyConstants.SM_RESOLUTION_DONE_ACTION_EXECUTE : projectProperty.getValue());
                            break;
                        case ProjectPropertyConstants.FAVORITE_SM_WORKGROUPS:
                            ctx.put("favoriteWorkgroups", projectProperty.getValue());
                            break;
                    }
                }
            }

            boolean isAdmin = permissionManager.hasPermission(ProjectPermissions.ADMINISTER_PROJECTS, project, user);
            ctx.put("isProjectAdmin", isAdmin);

            ctx.put("smIntegration", activeSmIntegration(project.getKey(), user));
        }
        return ctx;
    }

    private UserManager getUserManager() {
        return ComponentAccessor.getUserManager();
    }

    private List<ApplicationUser> getMembers(Project project, String role) {
        ProjectRole admRole = ComponentAccessor.getComponent(ProjectRoleManager.class).getProjectRole(role);
        ProjectRoleActors actors = ComponentAccessor.getComponent(ProjectRoleManager.class).getProjectRoleActors(admRole, project);
        return actors.getUsers().stream().sorted(Comparator.comparing(ApplicationUser::getDisplayName)).collect(Collectors.toList());
    }

    private boolean activeSmIntegration(String projectKey, ApplicationUser user) {
        String jqlTemplate = "project = '%s' AND 'Issue Source' ~ '%s'";
        String jql = String.format(jqlTemplate, projectKey, "SM");
        try {
            com.atlassian.query.Query query = ComponentAccessor.getComponent(JqlQueryParser.class).parseQuery(jql);
            SearchResults<Issue> searchResult = ComponentAccessor.getComponent(SearchService.class)
                    .search(user, query, PagerFilter.newPageAlignedFilter(0, 2));
            int total = searchResult.getTotal();
            if (total > 0) {
                return true;
            }
        } catch (JqlParseException | SearchException e) {
            LOG.error("Get portfolio issue exception {0}", e);
        }
        return false;
    }
}
