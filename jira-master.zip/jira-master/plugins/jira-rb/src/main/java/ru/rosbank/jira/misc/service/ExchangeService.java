package ru.rosbank.jira.misc.service;

import ru.rosbank.jira.common.exceptions.LoadingAppointmentsException;
import ru.rosbank.jira.misc.model.AppointmentModel;

import java.util.Date;
import java.util.List;

public interface ExchangeService {
    
    String exchangeOof(String email);

    List<AppointmentModel> getAppointments(String email, Date from, Date to) throws LoadingAppointmentsException;

}
