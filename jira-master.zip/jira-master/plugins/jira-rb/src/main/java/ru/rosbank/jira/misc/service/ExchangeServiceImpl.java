package ru.rosbank.jira.misc.service;

import com.google.common.base.Strings;
import ru.rosbank.jira.common.exceptions.LoadingAppointmentsException;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.MeetingResponseType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.exception.service.local.ServiceLocalException;
import microsoft.exchange.webservices.data.core.service.folder.CalendarFolder;
import microsoft.exchange.webservices.data.core.service.item.Appointment;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.property.complex.Mailbox;
import microsoft.exchange.webservices.data.search.CalendarView;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.misc.model.AppointmentModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

@Service
@Named
public class ExchangeServiceImpl implements ExchangeService {

    private static final Logger LOG = LoggerFactory.getLogger(ExchangeServiceImpl.class);
    private static final String EWS_URL = "https://owa.rosbank.ru/EWS/Exchange.asmx";
    private static final String EWS_DOMAIN = "rosbank";
    private static final int EWS_TIMEOUT = 100000;

    private final ConfigLoader configLoader;

    @Inject
    public ExchangeServiceImpl(ConfigLoader configLoader) {
        this.configLoader = checkNotNull(configLoader);
    }

    @Override
    public String exchangeOof(String email) {
        LOG.debug("Trying to get exchange tip for {}", email);

        String result = null;

        String ewsLogin = configLoader.getEwsLogin();
        String ewsPassword = configLoader.getEwsPassword();

        if (!Strings.isNullOrEmpty(ewsLogin) && !Strings.isNullOrEmpty(ewsPassword)) {
            HttpPost httpPost = new HttpPost(EWS_URL);

            httpPost.addHeader("Content-type", "text/xml; charset=utf-8");
            httpPost.addHeader("Keep-Alive", "300");
            httpPost.addHeader("Connection", "Keep-Alive");

            RequestConfig.Builder requestConfigBuilder =
                    RequestConfig.custom().setAuthenticationEnabled(true)
                            .setConnectionRequestTimeout(EWS_TIMEOUT)
                            .setConnectTimeout(EWS_TIMEOUT)
                            .setRedirectsEnabled(true)
                            .setSocketTimeout(EWS_TIMEOUT)
                            .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                            .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC));

            CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
            NTCredentials webServiceCredentials = new NTCredentials(
                    ewsLogin,
                    ewsPassword,
                    "", EWS_DOMAIN);
            credentialsProvider.setCredentials(new AuthScope(AuthScope.ANY), webServiceCredentials);
            httpPost.setConfig(requestConfigBuilder.build());

            StringBuilder requestData = new StringBuilder();
            requestData.append("<soap:Envelope ")
                    .append("xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" ")
                    .append("xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">")
                    .append("<soap:Header>")
                    .append("<t:RequestServerVersion Version=\"Exchange2010\"/></soap:Header><soap:Body>")
                    .append("<GetMailTips xmlns=\"http://schemas.microsoft.com/exchange/services/2006/messages\">")
                    .append("<SendingAs>")
                    .append("<t:EmailAddress>")
                    .append(email)
                    .append("</t:EmailAddress>")
                    .append("<t:RoutingType>SMTP</t:RoutingType>")
                    .append("</SendingAs>")
                    .append("<Recipients><t:Mailbox>")
                    .append("<t:EmailAddress>")
                    .append(email)
                    .append("</t:EmailAddress>")
                    .append("<t:RoutingType>SMTP</t:RoutingType>")
                    .append("</t:Mailbox></Recipients>")
                    .append("<MailTipsRequested>OutOfOfficeMessage</MailTipsRequested></GetMailTips>")
                    .append("</soap:Body></soap:Envelope>");

            try {
                httpPost.setEntity(new StringEntity(requestData.toString()));
            } catch (UnsupportedEncodingException ueex) {
                LOG.error("UnsupportedEncodingException for {}", email, ueex);
                return null;
            }

            try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build()) {

                String responseData;
                try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                    responseData = EntityUtils.toString(response.getEntity());
                    LOG.debug("MailTipsRequested request status {}", response.getStatusLine());
                }

                if (responseData != null) {
                    Document responseDoc = Jsoup.parse(responseData, "", Parser.xmlParser());
                    for (Element responseDocEl : responseDoc.select("t|ReplyBody > t|Message")) {
                        String message = responseDocEl.text();
                        if (!Strings.isNullOrEmpty(message)) {
                            result = Jsoup.parse(StringEscapeUtils.unescapeHtml(message)).text();
                            break;
                        }
                    }
                    // TODO Duration
                    // Example <t:Duration><t:StartTime>2021-09-13T06:00:00Z</t:StartTime><t:EndTime>2021-09-28T03:00:00Z</t:EndTime></t:Duration>
                }

                LOG.debug("Trying to get exchange tip - OK");
            } catch (IOException ioex) {
                LOG.error("Some unrecognized input output exception", ioex);
            }
        }
        return result;
    }

    @Override
    public List<AppointmentModel> getAppointments(String email, Date from, Date to) throws LoadingAppointmentsException {
        microsoft.exchange.webservices.data.core.ExchangeService exchangeService = null;
        try {
            String ewsLogin = configLoader.getEwsLogin();
            String ewsPassword = configLoader.getEwsPassword();

            ExchangeCredentials userCredential = new WebCredentials(ewsLogin, ewsPassword, EWS_DOMAIN);
            exchangeService = new microsoft.exchange.webservices.data.core.ExchangeService(ExchangeVersion.Exchange2010_SP1);
            exchangeService.setCredentials(userCredential);
            exchangeService.setUrl(new URI(EWS_URL));

            FolderId targetUserCalendarId = new FolderId(WellKnownFolderName.Calendar, Mailbox.getMailboxFromString(email));
            CalendarFolder calendarFolder = CalendarFolder.bind(exchangeService, targetUserCalendarId);

            FindItemsResults<Appointment> findResults = calendarFolder.findAppointments(new CalendarView(from, to));
            return findResults.getItems().stream()
                    .filter(app -> {
                        try {
                            // Appointment State is bitwise combination: 1 - Meeting, 2 - Received, 4 - Cancelled
                            return (app.getAppointmentState() == null || app.getAppointmentState() < 4) &&
                                    app.getMyResponseType() != MeetingResponseType.Decline &&
                                    // JIRA-3654 Bug MeetingResponseType.NoResponseReceived for Accepted appointments
                                    (Set.of("guzel.valieva@rosbank.ru").contains(email.toLowerCase())
                                            || app.getMyResponseType() != MeetingResponseType.NoResponseReceived);
                        } catch (ServiceLocalException sle) {
                            LOG.debug("Get appointment's status exception", sle);
                        }
                        return true;
                    })
                    .map(AppointmentModel::convert).collect(Collectors.toList());
        } catch (Exception ex) {
            LOG.error("Loading appointments errors", ex);
            throw new LoadingAppointmentsException(ex.getMessage(), ex.getStackTrace());
        } finally {
            if (exchangeService != null) {
                exchangeService.close();
            }
        }
    }
}
