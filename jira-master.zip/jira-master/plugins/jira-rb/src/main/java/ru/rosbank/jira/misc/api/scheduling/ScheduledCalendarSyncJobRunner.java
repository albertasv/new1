package ru.rosbank.jira.misc.api.scheduling;

import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.misc.service.TempoService;

import javax.annotation.Nullable;
import javax.inject.Named;
import java.util.Date;
import java.util.TreeMap;

@Named("calendarSyncJobRunner")
public class ScheduledCalendarSyncJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledCalendarSyncJobRunner.class);

    private final TempoService tempoService;

    private ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final ServiceNames serviceName = ServiceNames.CALENDAR_UPDATER;


    public ScheduledCalendarSyncJobRunner(ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                          TempoService tempoService) {
        this.tempoService = tempoService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(JobRunnerRequest jobRunnerRequest) {
        try {
            LOG.info("Executing calendar sync scheduled job");
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
                    new Date());
            if (tempoService != null) {
                TreeMap<String, String> errorLog = tempoService.loadAllCalendars();
                if (!errorLog.isEmpty()) {
                    StringBuilder stackTrace = new StringBuilder();
                    errorLog.forEach((user, error) -> stackTrace.append("User: " + user + " :\n " + error + "\n"));
                    externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED_WITH_ERRORS, stackTrace.toString(), new Date());
                } else {
                    externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(), new Date());
                }
            }
        } catch (Exception ex) {
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(ex),
                new Date());
            LOG.error("Exception because of " + ex.getMessage() + " {}", ErrorStackTracer.getStackTrace(ex));
        }
        return JobRunnerResponse.success();
    }
}