package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.ao.ServiceStatuses;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

/**
 * Класс, который записывает в базу данных ответы от внешних систем, интегрированных с Jira.
 */
@ExportAsService
@Named("externalServiceSyncStatusProvider")
public class ExternalServiceSyncStatusProviderImpl implements ExternalServiceSyncStatusProvider {

    private static final Logger LOG = LoggerFactory.getLogger(ExternalServiceSyncStatusProviderImpl.class);
    private final ActiveObjects ao;

    @Inject
    public ExternalServiceSyncStatusProviderImpl(@ComponentImport ActiveObjects ao) {
        this.ao = ao;
    }

    @Override
    public void writeStatus(ServiceNames serviceName, Statuses status, String message, Date dateTime){

        String nameOfServiceName = serviceName.name();
        String nameOfStatus = status.name();

        try {
            ServiceStatuses[] statuses = ao.find(ServiceStatuses.class, Query.select().where("SERVICE_NAME = ?", nameOfServiceName));

                if (statuses != null && statuses.length > 0) {
                    ServiceStatuses statusNote = statuses[0];
                    statusNote.setStatus(nameOfStatus);
                    statusNote.setMessage(message);
                    statusNote.setLastUpdateDate(dateTime);
                    statusNote.save();
                } else {
                    ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                            .put("SERVICE_NAME", nameOfServiceName)
                            .put("STATUS", nameOfStatus)
                            .put("MESSAGE", message)
                            .put("LAST_UPDATE_DATE", dateTime);
                    ao.create(ServiceStatuses.class, mapBuilder.build());
                }
        } catch (Exception ex){
            LOG.error("Can not write status of " + serviceName + " synchronization because of: ", ex);
        }
    }
}
