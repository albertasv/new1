package ru.rosbank.jira.misc.rest;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Map;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class IssueTypeResultModel {
    private String issueTypeInfo;
    private Map<String, Object> fields;

    public String getIssueTypeInfo() {
        return issueTypeInfo;
    }

    public void setIssueTypeInfo(String issueTypeInfo) {
        this.issueTypeInfo = issueTypeInfo;
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public void setFields(Map<String, Object> fields) {
        this.fields = fields;
    }
}
