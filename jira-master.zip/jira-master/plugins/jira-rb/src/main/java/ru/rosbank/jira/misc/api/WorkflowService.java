package ru.rosbank.jira.misc.api;

import com.atlassian.jira.user.ApplicationUser;

public interface WorkflowService {

    String transition(ApplicationUser appUser, String issueKey, String newStatus, String comment);

    ApplicationUser getActiveUser(String nameOrEmail);
}
