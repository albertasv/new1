package ru.rosbank.jira.common.action;

import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.GlobalPermissionManager;
import com.atlassian.jira.security.xsrf.RequiresXsrfCheck;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.service.CredentialProviderService;

import javax.inject.Inject;
import java.util.HashMap;

public class CredentialSettingsActionImpl extends JiraWebActionSupport implements CredentialSettingsAction {

    private static final Logger LOG = LoggerFactory.getLogger(CredentialSettingsAction.class);
    @ComponentImport
    private final GlobalPermissionManager globalPermissionManager;
    private final CredentialProviderService credentialSettings;

    private String sbuLogin;
    private String sbuPassword;
    private String smLogin;
    private String smPassword;
    private String ewsLogin;
    private String ewsPassword;
    private String rbStaffLogin;
    private String rbStaffPassword;

    //TODO: refactor methods
    @Inject
    public CredentialSettingsActionImpl(CredentialProviderService credentialSettings,
                                        GlobalPermissionManager globalPermissionManager) {
        this.credentialSettings = credentialSettings;
        this.globalPermissionManager = globalPermissionManager;
    }

    @Override
    public String doDefault() {
        if (!hasAdminPermission()) {
            return PERMISSION_VIOLATION_RESULT;
        }
        HashMap<String, HashMap<String, String>> result = credentialSettings.loadCredentials();
        this.sbuLogin = nullSafeValue(result.get("SBU")).get("login");
        this.sbuPassword = nullSafeValue(result.get("SBU")).get("password");
        this.smLogin = nullSafeValue(result.get("SM")).get("login");
        this.smPassword = nullSafeValue(result.get("SM")).get("password");
        this.ewsLogin = nullSafeValue(result.get("EWS")).get("login");
        this.ewsPassword = nullSafeValue(result.get("EWS")).get("password");
        this.rbStaffLogin = nullSafeValue(result.get("RBSTAFF")).get("login");
        this.rbStaffPassword = nullSafeValue(result.get("RBSTAFF")).get("password");
        return INPUT;
    }

    @Override
    public boolean hasAdminPermission() {
        ApplicationUser user = getLoggedInUser();
        if (user == null) {
            return false;
        }
        return globalPermissionManager.hasPermission(GlobalPermissionKey.ADMINISTER, user);
    }

    @Override
    @RequiresXsrfCheck
    public String doSave() {
        if (!hasAdminPermission()) {
            return PERMISSION_VIOLATION_RESULT;
        }
        HashMap<String, HashMap<String, String>> payload = new HashMap<>();

        payload.put("SBU", new HashMap<>() {{
            put("login", sbuLogin);
            put("password", sbuPassword);
        }});
        payload.put("SM", new HashMap<>() {{
            put("login", smLogin);
            put("password", smPassword);
        }});
        payload.put("EWS", new HashMap<>() {{
            put("login", ewsLogin);
            put("password", ewsPassword);
        }});
        payload.put("RBSTAFF", new HashMap<>() {{
            put("login", rbStaffLogin);
            put("password", rbStaffPassword);
        }});
        credentialSettings.saveCredentials(payload);
        return SUCCESS;
    }

    public String getSbuLogin() {
        return sbuLogin;
    }

    public void setSbuLogin(String sbuLogin) {
        this.sbuLogin = sbuLogin;
    }

    public String getSbuPassword() {
        return sbuPassword;
    }

    public void setSbuPassword(String sbuPassword) {
        this.sbuPassword = sbuPassword;
    }

    public String getSmLogin() {
        return smLogin;
    }

    public void setSmLogin(String smLogin) {
        this.smLogin = smLogin;
    }

    public String getSmPassword() {
        return smPassword;
    }

    public void setSmPassword(String smPassword) {
        this.smPassword = smPassword;
    }

    public String getEwsLogin() {
        return ewsLogin;
    }

    public void setEwsLogin(String ewsLogin) {
        this.ewsLogin = ewsLogin;
    }

    public String getEwsPassword() {
        return ewsPassword;
    }

    public void setEwsPassword(String ewsPassword) {
        this.ewsPassword = ewsPassword;
    }

    public String getRbStaffLogin() {
        return rbStaffLogin;
    }

    public void setRbStaffLogin(String rbStaffLogin) {
        this.rbStaffLogin = rbStaffLogin;
    }

    public String getRbStaffPassword() {
        return rbStaffPassword;
    }
    
    public void setRbStaffPassword(String rbStaffPassword) {
        this.rbStaffPassword = rbStaffPassword;
    }

    private HashMap<String, String> nullSafeValue(HashMap<String, String> value) {
        if (value == null) {
            return new HashMap<>() {{
                put("login", "");
                put("password", "");
            }};
        }
        return value;
    }
}
