package ru.rosbank.jira.misc.action;

import com.google.common.base.Strings;
import org.apache.velocity.tools.generic.NumberTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.model.WorklogEmailModel;
import ru.rosbank.jira.misc.service.TempoService;

import javax.inject.Inject;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class WorklogEmailAction extends RbMiscAction {

    private static final Logger LOG = LoggerFactory.getLogger(WorklogEmailAction.class);

    private final TempoService tempoService;
    private final DateFormat dateFormat;
    private WorklogEmailModel worklog;
    private String username;
    private NumberTool numberTool;

    @Inject
    public WorklogEmailAction(TempoService tempoService) {
        this.tempoService = tempoService;
        this.numberTool = new NumberTool();
        this.dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    }

    @Override
    public String execute() throws Exception {
        if (!isAdmin()) {
            return PERMISSION_VIOLATION_RESULT;
        }
        initWorklog();
        return super.execute();
    }

    public WorklogEmailModel getWorklog() {
        return this.worklog;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public NumberTool getNumberTool() {
        return numberTool;
    }

    private void initWorklog() {
        if (Strings.isNullOrEmpty(username)) {
            this.worklog = tempoService.getWorklogEmail(getLoggedInUser().getUsername());
        } else {
            this.worklog = tempoService.getWorklogEmail(username);
        }

        tempoService.sendWorklogEmail(worklog.getUsername());
    }
}