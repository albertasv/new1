package ru.rosbank.jira.common.service;

import java.util.HashMap;

public interface CredentialProviderService {

    String getCredential(String target);

    String getFormattedCredential(String target, String format);

    String getBase64Credential(String target);

    String getLogin(String target);

    String getPassword(String target);

    void saveCredentials(HashMap<String, HashMap<String, String>> credentialMap);

    HashMap<String, HashMap<String, String>> loadCredentials();
}
