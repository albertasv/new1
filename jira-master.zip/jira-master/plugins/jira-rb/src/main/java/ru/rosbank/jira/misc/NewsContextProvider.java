package ru.rosbank.jira.misc;

import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.web.ContextProvider;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.service.NewsService;
import javax.inject.Inject;
import java.util.Map;


public class NewsContextProvider implements ContextProvider {

    private static final Logger LOG = LoggerFactory.getLogger(NewsContextProvider.class);

    private NewsService newsService;

    @Inject
    public NewsContextProvider( NewsService newsService) {
        this.newsService = newsService;
    }

    public void init(Map params) throws PluginParseException {   }


    public Map getContextMap(Map context) {
        Map<String, Object> ctx = Maps.newHashMap();
        ctx.put("news", newsService.getCountNewsForCurrentUser());
        return ctx;
    }

}
