package ru.rosbank.jira.common.model;

import net.java.ao.EntityManager;
import net.java.ao.RawEntity;
import ru.rosbank.jira.misc.ao.Credential;

import java.beans.PropertyChangeListener;

public class FakeCredential implements Credential {
    @Override
    public String getTarget() {
        return "";
    }

    @Override
    public void setTarget(String target) {

    }

    @Override
    public String getLogin() {
        return "";
    }

    @Override
    public void setLogin(String login) {

    }

    @Override
    public String getEncryptedPass() {
        return "";
    }

    @Override
    public void setEncryptedPass(String encryptedPass) {

    }

    @Override
    public int getID() {
        return 0;
    }

    @Override
    public void init() {

    }

    @Override
    public void save() {

    }

    @Override
    public EntityManager getEntityManager() {
        return null;
    }

    @Override
    public <X extends RawEntity<Integer>> Class<X> getEntityType() {
        return null;
    }

    @Override
    public void addPropertyChangeListener(PropertyChangeListener propertyChangeListener) {

    }

    @Override
    public void removePropertyChangeListener(PropertyChangeListener propertyChangeListener) {

    }
}
