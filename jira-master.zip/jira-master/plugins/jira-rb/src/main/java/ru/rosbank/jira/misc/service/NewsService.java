package ru.rosbank.jira.misc.service;

import ru.rosbank.jira.misc.model.NewsModel;

import java.util.List;

public interface NewsService {

    String getNewsForCurrentUser();

    void hideNewsForCurrentUser();

    String getCountNewsForCurrentUser();

    void hideAllNewsForCurrentUser();
    
    List<NewsModel> getNews();

    NewsModel findNews(int newsId);

    NewsModel saveNews(Integer newsId, String news);

    void deleteNews(Integer newsId);
}
