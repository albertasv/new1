package ru.rosbank.jira.common.api;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfoModelImpl implements UserInfoModel {

    public static final String DEFAULT_OOF_MESSAGE = "";

    private String username;
    private String displayName;
    private String email;
    private String phone;
    private String internalPhone;

    private boolean exchangeIntegration = true;
    private boolean oof = false;
    private String oofMessage = DEFAULT_OOF_MESSAGE;

    private Integer teamId;
    private String team;
    private String teamRole;

    private String employeeId;
    private String staffId;
    private String planningIssue;
    private int priorityPlanningIssue;
    private String excludedCategory;
    private boolean calendarSync;

    private String news;

    public UserInfoModelImpl() {
    }

    public UserInfoModelImpl(String username) {
        this.username = username;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getPhone() {
        return phone;
    }

    @Override
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String getInternalPhone() {
        return internalPhone;
    }

    @Override
    public void setInternalPhone(String internalPhone) {
        this.internalPhone = internalPhone;
    }

    @Override
    public Boolean getExchangeIntegration() {
        return exchangeIntegration;
    }

    @Override
    public void setExchangeIntegration(Boolean exchangeIntegration) {
        this.exchangeIntegration = exchangeIntegration;
    }

    @Override
    public Boolean getOof() {
        return oof;
    }

    @Override
    public void setOof(Boolean oof) {
        this.oof = oof;
    }

    @Override
    public String getOofMessage() {
        return oofMessage;
    }

    @Override
    public void setOofMessage(String oofMessage) {
        this.oofMessage = oofMessage;
    }

    @Override
    public Integer getTeamId() {
        return teamId;
    }

    @Override
    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }

    @Override
    public String getTeam() {
        return team;
    }

    @Override
    public void setTeam(String team) {
        this.team = team;
    }

    @Override
    public String getTeamRole() {
        return teamRole;
    }

    @Override
    public void setTeamRole(String teamRole) {
        this.teamRole = teamRole;
    }

    @Override
    public String getEmployeeId() {
        return employeeId;
    }

    @Override
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    @Override
    public String getStaffId() {
        return staffId;
    }

    @Override
    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    @Override
    public Boolean getCalendarSync() {
        return calendarSync;
    }

    @Override
    public void setCalendarSync(Boolean calendarSync) {
        this.calendarSync = calendarSync;
    }

    @Override
    public String getPlanningIssue() {
        return planningIssue;
    }

    @Override
    public void setPlanningIssue(String planningIssue) {
        this.planningIssue = planningIssue;
    }

    @Override
    public int getPriorityPlanningIssue() {
        return priorityPlanningIssue;
    }

    @Override
    public void setPriorityPlanningIssue(int priorityIssue) {
        this.priorityPlanningIssue = priorityIssue;
    }

    @Override
    public String getExcludedCategory() {
        return excludedCategory;
    }

    @Override
    public void setExcludedCategory(String excludeCategory) {
        this.excludedCategory = excludeCategory;
    }

    @Override
    public String getNews() {
        return news;
    }

    @Override
    public void setNews(String news) {
        this.news = news;
    }
}
