package ru.rosbank.jira.misc.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.Unique;

import java.util.Date;


@Preload
public interface TempoAppointment extends Entity {
    @NotNull
    @Unique
    Integer getTempoId();

    @NotNull
    void setTempoId(Integer tempoId);

    @NotNull
    String getExchangeId();

    @NotNull
    void setExchangeId(String exchangeId);

    @NotNull
    String getICalUid();

    @NotNull
    void setICalUid(String iCalUid);

    Date getStartDate();

    void setStartDate(Date startDate);

    @NotNull
    Date getLastUpdateDate();

    @NotNull
    void setLastUpdateDate(Date lastUpdateDate);

    @NotNull
    String getLastUpdatedBy();

    @NotNull
    void setLastUpdatedBy(String lastUpdateBy);
}
