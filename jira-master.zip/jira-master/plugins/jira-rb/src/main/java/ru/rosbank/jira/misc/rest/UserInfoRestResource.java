package ru.rosbank.jira.misc.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.jira.component.ComponentAccessor;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoModelImpl;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.misc.service.NewsService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

@Component
@Path("/userInfo")
public class UserInfoRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(UserInfoRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final UserInfoService userInfoService;
    private final NewsService newsService;
    private final UserManager userManager;

    @Inject
    public UserInfoRestResource(@ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
                                NewsService newsService,
                                UserInfoService userInfoService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.userManager = ComponentAccessor.getUserManager();
        this.newsService = newsService;
        this.userInfoService = userInfoService;

    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/status")
    public Response status(@RequestParam("users") List<String> usernames) {
        List<UserInfoModel> users = new ArrayList<>();

        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            String loggedInUsername = loggedInUser.getUsername();
            UserInfoModel loggedInUserModel = getOof(loggedInUsername, true);

            // Add news
            loggedInUserModel.setNews(newsService.getNewsForCurrentUser());

            users.add(loggedInUserModel);
            if (usernames != null) {
                Set<String> processingUsernames = new HashSet<>();
                for (String username : usernames) {
                    // only rb000000 and rbxmos000000 users
                    if (!username.equalsIgnoreCase(loggedInUsername)
                            && username.toLowerCase().matches("^(rb[0-9]|rbxmos[0-9]).*$")) {
                        ApplicationUser user = userManager.getUserByName(username);
                        if (user != null && user.isActive()) {
                            processingUsernames.add(username);
                        }
                    }
                }
                users.addAll(getOof(Lists.newArrayList(processingUsernames)));
            }
            return Response.ok(users).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/status")
    public Response status() {
        return status(Collections.emptyList());
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/status/update")
    public Response updateStatus(UserInfoModelImpl user) {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            String loggedInUsername = loggedInUser.getUsername();
            user.setUsername(loggedInUsername);
            return Response.ok(userInfoService.update(user)).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/status/{username}")
    public Response userStatus(@PathParam("username") String username) {
        return Response.ok(getOof(username, false)).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/hideNews")
    public Response hideNews() {
        newsService.hideNewsForCurrentUser();
        return Response.ok().build();
    }


    private UserInfoModel getOof(String username, boolean cache) {
        return userInfoService.getUserInfo(username, cache);
    }

    private List<UserInfoModel> getOof(List<String> usernames) {
        List<UserInfoModel> res = new ArrayList<>();

        // TODO Replace with bulk fetch
        // res = userInfoService.getUserInfo(usernames);

        for (String username : usernames) {
            res.add(getOof(username, true));
        }
        return res;
    }
}