package ru.rosbank.jira.misc.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.StringLength;
import net.java.ao.schema.Unique;

import java.util.Date;


@Preload
public interface UserInfo extends Entity {

    @NotNull
    @Unique
    String getUsername();

    @NotNull
    void setUsername(String username);

    Boolean getExchangeIntegration();

    void setExchangeIntegration(boolean exchangeIntegration);

    Boolean getOofEnabled();

    void setOofEnabled(boolean oofEnabled);

    @StringLength(StringLength.UNLIMITED)
    String getOofMessage();

    void setOofMessage(String oofMessage);

    Date getLastUpdateDate();

    void setLastUpdateDate(Date lastUpdateDate);

    Integer getTeamId();

    void setTeamId(Integer teamId);

    String getTeamRole();

    void setTeamRole(String role);

    Boolean getCalendarSync();

    void setCalendarSync(boolean calendarSync);

    String getPlanningIssue();

    void setPlanningIssue(String planningIssue);

    int getPriorityPlanningIssue();

    void setPriorityPlanningIssue(int priorityPlanningIssue);

    String getExcludedCategory();

    void setExcludedCategory(String excludedCategory);

    Integer getNewsId();

    void setNewsId(int newsId);

    Integer getWorklogEmail();

    void setWorklogEmail(int worklogEmail);

    String getDepart1();

    void setDepart1(String depart1);

    String getDepart2();

    void setDepart2(String depart2);

    String getDepart3();

    void setDepart3(String depart3);

    String getDepart4();

    void setDepart4(String depart4);

    String getDepart5();

    void setDepart5(String depart5);

    String getDepart6();

    void setDepart6(String depart6);
  
  	String getDepart7();

    void setDepart7(String depart7);
}

