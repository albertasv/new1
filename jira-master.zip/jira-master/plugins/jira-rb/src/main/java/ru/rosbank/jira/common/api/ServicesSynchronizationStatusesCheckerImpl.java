package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.mail.Email;
import com.atlassian.mail.MailException;
import com.atlassian.mail.server.SMTPMailServer;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.misc.ao.ServiceStatuses;

import java.util.Date;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Класс, который проверяет наличие ошибок при обновлении справочников из RBStaff, SM и СБУ
 */

@Component
public class ServicesSynchronizationStatusesCheckerImpl implements ServicesSynchronizationStatusesChecker {

    private static final Logger LOG = LoggerFactory.getLogger(ServicesSynchronizationStatusesCheckerImpl.class);


    private final ActiveObjects ao;

    public ServicesSynchronizationStatusesCheckerImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }


    public void checkServicesSynchronizationStatuses() {
        final String status = "FAILED";
        ServiceStatuses[] serviceStatuses = ao.find(ServiceStatuses.class, Query.select()
                .where("\"STATUS\" = ?", status));
        if (serviceStatuses.length > 0) {
            for (ServiceStatuses serviceStatus : serviceStatuses) {
                notifyJiraAdmins(serviceStatus);
            }
        }
    }

    public void notifyJiraAdmins(ServiceStatuses serviceStatus) {
        final String serviceName = serviceStatus.getServiceName();
        final Date lastUpdateDate = serviceStatus.getLastUpdateDate();
        final String subject = "Ошибка обновления справочника сервиса " + serviceName;
        SMTPMailServer mailServer = ComponentAccessor.getMailServerManager().getDefaultSMTPMailServer();
        ApplicationUser jiraAdmin = ComponentAccessor.getUserManager().getUserByName("ppmsync");
        Email email = new Email(jiraAdmin.getEmailAddress());
        email.setMimeType("text/plain");
        email.setSubject(subject);
        email.setBody("Возникла ошибка при обновлении справочника " + serviceName + " от " + lastUpdateDate + ". Справочник не обновлён." +
                " Обратитесь к администратору Jira");
        try {
            mailServer.send(email);
        } catch (MailException e) {
            LOG.error("Exception in ServicesSynchronizationStatusesCheckerImpl.notifyJiraAdmins() method: {}", e);
        }
    }
}