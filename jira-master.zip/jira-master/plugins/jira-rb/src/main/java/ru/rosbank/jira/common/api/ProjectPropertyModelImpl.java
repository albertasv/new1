package ru.rosbank.jira.common.api;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectPropertyModelImpl implements ProjectPropertyModel {

    private int id;
    private Long project;
    private String key;
    private String value;

    public ProjectPropertyModelImpl() {
    }

    public ProjectPropertyModelImpl(int id, Long project, String key, String value) {
        this.id = id;
        this.project = project;
        this.key = key;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Long getProject() {
        return project;
    }

    public void setProject(Long project) {
        this.project = project;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "PropertyAddModel{" +
                "project=" + project +
                ", key='" + key + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
