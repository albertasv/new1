package ru.rosbank.jira.common.api;

import ru.rosbank.jira.misc.ao.ServiceStatuses;

import java.util.Date;

public interface ServicesSynchronizationStatusesChecker {

    void checkServicesSynchronizationStatuses();

    void notifyJiraAdmins(ServiceStatuses serviceStatus);
}
