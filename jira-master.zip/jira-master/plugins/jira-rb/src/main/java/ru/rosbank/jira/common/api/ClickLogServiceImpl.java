package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.misc.ao.ClickLog;

import javax.inject.Inject;
import java.util.Date;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService({ClickLogService.class})
@Component
public class ClickLogServiceImpl implements ClickLogService {

    private static final Logger LOG = LoggerFactory.getLogger(ClickLogServiceImpl.class);

    private final JiraAuthenticationContext authContext;
    private final ActiveObjects ao;

    @Inject
    public ClickLogServiceImpl(
            @ComponentImport JiraAuthenticationContext authContext,
            @ComponentImport ActiveObjects ao) {
        this.authContext = authContext;
        this.ao = checkNotNull(ao);

    }

    @Override
    public void addClickLog(String username, String topic) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("USERNAME", username)
                .put("TOPIC", topic)
                .put("CLICK", 1)
                .put("LAST_UPDATE_DATE", new Date());
        ao.create(ClickLog.class, mapBuilder.build());

    }

    @Override
    public void addClickLog(String topic) {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        if (loggedInUser != null) {
            addClickLog(loggedInUser.getUsername(), topic);
        } else {
            addClickLog("anonymous", topic);
        }
    }
}