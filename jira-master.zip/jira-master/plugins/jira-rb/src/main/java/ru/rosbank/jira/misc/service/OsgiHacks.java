package ru.rosbank.jira.misc.service;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.springframework.context.ApplicationContext;

import java.util.Arrays;
import java.util.function.BiFunction;
import java.util.stream.Stream;

public class OsgiHacks {
    public static <R, E extends Exception> R withApplicationContext(BundleContext context, String pluginKey, BiFunction<? super ApplicationContext, ? super Bundle, ? extends R> code) throws E {
        return withService(context, pluginKey, ApplicationContext.class, code);
    }

    public static <S, R, E extends Exception> R withService(BundleContext context, String pluginKey, Class<S> serviceClass, BiFunction<? super S, ? super Bundle, ? extends R> code) throws E {
        Bundle bundle = getBundleForPlugin(context, pluginKey);
        if (bundle != null) {
            ServiceReference<?> reference = getServiceReference(bundle, serviceClass.getName());
            if (reference != null) {
                return withService(context, reference, (o, b) -> code.apply(serviceClass.isInstance(o) ? serviceClass.cast(o) : null, b));
            }
        }
        return code.apply(null, bundle);
    }

    public static Bundle getBundleForPlugin(BundleContext context, String pluginKey) {
        return Arrays.stream(context.getBundles()).filter((b) -> pluginKey.equals(b.getHeaders().get("Atlassian-Plugin-Key"))).findAny().orElse(null);
    }

    private static ServiceReference<?> getServiceReference(Bundle bundle, String className) {
        // TODO: Написать тест для сервиса, так как он возвращает nullpointerexception при старте Jira
        return Arrays.stream(bundle.getRegisteredServices()).filter((r) -> hasObjectClass(r, className)).findAny().orElse(null);
    }

    private static boolean hasObjectClass(ServiceReference<?> reference, String className) {
        Object objectClass = reference.getProperty("objectClass");
        if (objectClass instanceof String[]) {
            Stream classes = Arrays.stream((String[]) objectClass);
            if (classes.anyMatch(className::equals)) {
                return true;
            }
        }
        return false;
    }

    private static <R, E extends Exception> R withService(BundleContext context, ServiceReference<?> reference, BiFunction<Object, ? super Bundle, ? extends R> code) throws E {
        Object service = context.getService(reference);
        R obj;
        try {
            obj = code.apply(service, reference.getBundle());
        } finally {
            context.ungetService(reference);
        }
        return obj;
    }
}
