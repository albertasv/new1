package ru.rosbank.jira.misc.rest;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import ru.rosbank.jira.common.exceptions.LoadPlanCalendarException;
import ru.rosbank.jira.common.exceptions.LoadingAppointmentsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.*;
import ru.rosbank.jira.misc.model.AppointmentModel;
import ru.rosbank.jira.misc.model.MessageModel;
import ru.rosbank.jira.misc.service.ExchangeService;
import ru.rosbank.jira.misc.service.TempoService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
@Path("/calendar")
public class CalendarRestResource {
    private static final Logger LOG = LoggerFactory.getLogger(CalendarRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;

    private final UserInfoService userInfoService;

    private final ExchangeService exchangeService;

    private final TempoService tempoService;

    private final IssueManager issueManager;

    private ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;


    @Inject
    public CalendarRestResource(@ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
                                UserInfoService userInfoService,
                                ExchangeService exchangeService,
                                ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                TempoService tempoService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.userInfoService = userInfoService;
        this.exchangeService = exchangeService;
        this.tempoService = tempoService;
        this.issueManager = ComponentAccessor.getIssueManager();
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/exchange/status")
    public Response status(@QueryParam("from") String fromParam, @QueryParam("to") String toParam) {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            UserInfoModel userInfo = userInfoService.getUserInfo(loggedInUser.getUsername());
            if (userInfo != null) {
                String planningIssue = userInfo.getPlanningIssue();
                Issue issue = null;
                if (!Strings.isNullOrEmpty(planningIssue)) {
                    issue = issueManager.getIssueObject(planningIssue);
                }
                if (issue != null) {
                    Calendar from = Calendar.getInstance();
                    from.add(Calendar.DAY_OF_WEEK, from.getFirstDayOfWeek() - from.get(Calendar.DAY_OF_WEEK));
                    from.set(Calendar.HOUR_OF_DAY, 0);
                    from.set(Calendar.MINUTE, 0);
                    from.set(Calendar.SECOND, 0);
                    from.set(Calendar.MILLISECOND, 0);

                    Calendar to = (Calendar) from.clone();
                    to.add(Calendar.DAY_OF_YEAR, 6);
                    to.set(Calendar.HOUR_OF_DAY, 23);
                    to.set(Calendar.MINUTE, 59);
                    to.set(Calendar.SECOND, 59);
                    to.set(Calendar.MILLISECOND, 59);

                    LOG.debug("Load appointments for {} from {} to {}. Planning Issue {}", loggedInUser.getUsername(), from, to);
                    try {
                        List<AppointmentModel> appointments = exchangeService.getAppointments(loggedInUser.getEmailAddress(),
                                from.getTime(), to.getTime());
                        return Response.ok(appointments).build();
                    } catch (LoadingAppointmentsException loax) {
                        String errorMessage = "Loading appointments errors";
                        LOG.info(errorMessage, loax);
                        return Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
                    }
                } else {
                    LOG.debug("Planning Issue not found");
                }
            } else {
                LOG.debug("Calendar synchronization is turned off");
                return Response.ok(Collections.emptyList()).build();
            }
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/plan/load")
    public Response planLoad(@QueryParam("from") String fromParam, @QueryParam("to") String toParam) {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            try {
                return Response.ok(tempoService.loadPlanCalendar(loggedInUser, parseDate(fromParam), parseDate(toParam))).build();
            } catch (LoadPlanCalendarException | LoadingAppointmentsException lex) {
                LOG.debug("Can not load calendar for user via REST, because of " + lex.getMessage() + "{}", ErrorStackTracer.getStackTrace(lex));
                return Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
            }
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/plan/status")
    public Response planStatus(@QueryParam("from") String fromParam, @QueryParam("to") String toParam) {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            return Response.ok(tempoService.statusPlanCalendar(loggedInUser, parseDate(fromParam), parseDate(toParam))).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/worklog/load")
    public Response worklogLoad(@QueryParam("from") String fromParam, @QueryParam("to") String toParam) {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            return Response.ok(tempoService.loadWorklogCalendar(loggedInUser, parseDate(fromParam), parseDate(toParam))).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/loadallcalendars")
    public Response loadAllCalendars() {
        final ServiceNames serviceName = ServiceNames.CALENDAR_UPDATER;
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
                    new Date());
        try {
            ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
            if (loggedInUser != null) {
                TreeMap<String, String> errorLog = tempoService.loadAllCalendars();
                if (errorLog.size() > 0) {
                    StringBuilder stackTraceFromErrorLog = new StringBuilder();
                    errorLog.forEach((user, error) -> stackTraceFromErrorLog.append("User: " + user + " :\n " + error + "\n"));
                    externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED_WITH_ERRORS, stackTraceFromErrorLog.toString(),
                        new Date());
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                            .entity(new MessageModel("Errors with calendars loading")).build();
                }
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                        new Date());
                return Response.status(Response.Status.OK).entity(new MessageModel("OK")).build();
            }
            return Response.status(Response.Status.UNAUTHORIZED).build();
        } catch (Exception ex) {
            LOG.debug("Exception in CalendarRestResource" +
                    " because of " + ex.getMessage() + " {}", ErrorStackTracer.getStackTrace(ex));
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(ex),
                    new Date());
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
    }


    private Date parseDate(String date) {
        Date res = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            res = sdf.parse(date);
        } catch (Exception ex) {
            LOG.debug("Cannot parse date parameters - {}", date);
        }
        return res;
    }
}