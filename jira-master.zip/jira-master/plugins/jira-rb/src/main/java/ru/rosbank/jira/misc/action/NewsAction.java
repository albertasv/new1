package ru.rosbank.jira.misc.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.permission.GlobalPermissionKey;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.misc.model.NewsModel;
import ru.rosbank.jira.misc.service.NewsService;

import javax.inject.Inject;
import java.util.List;

public class NewsAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(NewsAction.class);

    private final JiraAuthenticationContext authContext;
    private NewsService newsService;

    @Inject
    public NewsAction(
            @ComponentImport JiraAuthenticationContext authContext,
            NewsService newsService,
            UserInfoService userInfoService) {
        this.authContext = authContext;
        this.newsService = newsService;
    }

    @Override
    public String execute() throws Exception {
        String deleteIdParam = getHttpRequest().getParameter("delete");
        if (!Strings.isNullOrEmpty(deleteIdParam)) {
            try {
                newsService.deleteNews(Integer.parseInt(deleteIdParam));
                forceRedirect("News.jspa");
            } catch (NumberFormatException nfe) {
            }
        }
        return super.execute(); //returns SUCCESS
    }

    public List<NewsModel> getNews() {
        return newsService.getNews();
    }

    public boolean isAdmin() {
        ApplicationUser loggedInUser = authContext.getLoggedInUser();
        if (loggedInUser != null) {
            return ComponentAccessor.getGlobalPermissionManager().hasPermission(GlobalPermissionKey.ADMINISTER, loggedInUser);
        }
        return false;
    }
}