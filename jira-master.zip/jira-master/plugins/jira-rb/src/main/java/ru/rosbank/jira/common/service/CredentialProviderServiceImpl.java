package ru.rosbank.jira.common.service;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.transaction.TransactionCallback;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.common.model.FakeCredential;
import ru.rosbank.jira.misc.ao.Credential;

import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CredentialProviderServiceImpl implements CredentialProviderService {

    private static final Logger LOG = LoggerFactory.getLogger(CredentialProviderService.class);

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final Map<String, Credential> cache;
    private final boolean encrypted;
    private final String credentialKey;

    @Inject
    public CredentialProviderServiceImpl(ActiveObjects activeObjects) throws IOException {
        this.activeObjects = activeObjects;
        this.cache = new ConcurrentHashMap<>();
        this.encrypted = true;
        this.credentialKey = new String(this.getClass().getResourceAsStream("credentialKey.txt").readAllBytes(), StandardCharsets.UTF_8);
    }

    @Override
    public String getCredential(String target) {
        Credential credential = getCredentialFromAO(target);
        return String.format("%s:%s", credential.getLogin(), decryptedPassword(credential.getEncryptedPass(), encrypted));
    }

    @Override
    public String getFormattedCredential(String target, String format) {
        Credential credential = getCredentialFromAO(target);
        return String.format(format, credential.getLogin(), decryptedPassword(credential.getEncryptedPass(), encrypted));
    }

    @Override
    public String getBase64Credential(String target) {
        return Base64.getEncoder().encodeToString(getCredential(target).getBytes());
    }

    @Override
    public String getLogin(String target) {
        Credential credential = getCredentialFromAO(target);
        return credential.getLogin();
    }

    public String getPassword(String target) {
        Credential credential = getCredentialFromAO(target);
        return decryptedPassword(credential.getEncryptedPass(), encrypted);
    }

    @Override
    public void saveCredentials(HashMap<String, HashMap<String, String>> credentialMap) {
        for (Map.Entry<String, HashMap<String, String>> entry : credentialMap.entrySet()) {
            Credential credential = activeObjects.executeInTransaction(() -> {
                final Credential[] credentials = activeObjects.find(Credential.class, Query.select().where("\"TARGET\" = ?", entry.getKey()));
                String pass = entry.getValue().get("password");
                String encryptedPass = encryptedPassword(pass, encrypted);
                if (credentials.length == 0) {
                    final Credential newCredential = activeObjects.create(Credential.class);
                    newCredential.setTarget(entry.getKey());
                    newCredential.setLogin(entry.getValue().get("login"));
                    newCredential.setEncryptedPass(encryptedPass);
                    newCredential.save();
                    return newCredential;
                }

                @NotNull String currentPass = credentials[0].getEncryptedPass();
                if (!pass.equals(currentPass) && !encryptedPass.equals(currentPass)) {
                    credentials[0].setTarget(entry.getKey());
                    credentials[0].setLogin(entry.getValue().get("login"));
                    credentials[0].setEncryptedPass(encryptedPass);
                    credentials[0].save();
                }
                return credentials[0];
            });
            updateCache(credential);
        }

    }

    @Override
    public HashMap<String, HashMap<String, String>> loadCredentials() {

        HashMap<String, HashMap<String, String>> result = new HashMap<>();
        Credential[] credentials = activeObjects.executeInTransaction(() -> activeObjects.find(Credential.class, Query.select()));

        for (Credential entry : credentials) {
            result.put(entry.getTarget(), new HashMap<>() {
                {
                    put("login", entry.getLogin());
                    put("password", decryptedPassword(entry.getEncryptedPass(), encrypted));
                }
            });
        }
        return result;
    }

    private String encryptedPassword(String input, boolean encrypted) {
        return encrypted ? CredentialUtil.encrypt(input, credentialKey) : input;
    }

    private String decryptedPassword(String input, boolean encrypted) {
        if (encrypted) {
            try {
                return CredentialUtil.decrypt(input, credentialKey);
            } catch (Exception ex) {
                // To support previous base64 encoding
                return new String(Base64.getDecoder().decode(input.getBytes()));
            }
        }
        return input;
    }

    private Credential getCredentialFromAO(String target) {
        Credential credential = cache.get(target);
        if (credential == null) {
            credential = activeObjects.executeInTransaction(new TransactionCallback<Credential>() {

                @Override
                public Credential doInTransaction() {
                    final Credential[] credentials = activeObjects.find(Credential.class, Query.select().where("\"TARGET\" = ?", target));
                    if (credentials.length == 0) {
                        return new FakeCredential();
                    }
                    updateCache(credentials[0]);
                    return credentials[0];
                }
            });
        }
        return credential;
    }

    private void updateCache(Credential credential) {
        if (cache.get(credential.getTarget()) != null) {
            cache.remove(credential.getTarget());
        }
        cache.put(credential.getTarget(), credential);
    }
}
