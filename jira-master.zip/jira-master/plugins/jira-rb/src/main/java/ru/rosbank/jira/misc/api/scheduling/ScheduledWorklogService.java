package ru.rosbank.jira.misc.api.scheduling;

import com.atlassian.beehive.ClusterLockService;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.scheduler.SchedulerService;
import com.atlassian.scheduler.SchedulerServiceException;
import com.atlassian.scheduler.config.*;
import com.atlassian.scheduler.status.JobDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.RbCommonScheduledService;

import javax.annotation.PreDestroy;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.concurrent.locks.Lock;

@ExportAsService
@Named("worklogScheduledService")
public class ScheduledWorklogService implements RbCommonScheduledService, LifecycleAware {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledWorklogService.class);

    private final String CRON_EXPRESSION_EMAIL_EVERY_WEEK;

    private final JobRunnerKey jobRunnerKey = JobRunnerKey.of(ScheduledWorklogService.class.getName() + ":instance-every_week");


    private final SchedulerService schedulerService;


    private final ScheduledWorklogEmailJobRunner scheduledWorklogEmailJobRunner;

    private static final String LOCK_NAME = ScheduledWorklogService.class.getName() + ".lockedTask";

    private final ClusterLockService clusterLockService;

    @Inject
    public ScheduledWorklogService(
            @ComponentImport SchedulerService schedulerService,
            @ComponentImport ClusterLockService clusterLockService,
            ConfigLoader configLoader,
            ScheduledWorklogEmailJobRunner scheduledWorklogEmailJobRunner) {
        this.schedulerService = schedulerService;
        this.scheduledWorklogEmailJobRunner = scheduledWorklogEmailJobRunner;
        this.CRON_EXPRESSION_EMAIL_EVERY_WEEK = configLoader.getWorklogScheduling();
        this.clusterLockService = clusterLockService;
    }

    @Override
    public void onStart() {
        reschedule();
    }

    @Override
    public void reschedule() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            LOG.info("Register scheduled worklog service");
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }

            schedulerService.registerJobRunner(jobRunnerKey, scheduledWorklogEmailJobRunner);
            JobConfig worklogEmailJobConfigEveryWeek = JobConfig.forJobRunnerKey(jobRunnerKey)
                    .withRunMode(RunMode.RUN_ONCE_PER_CLUSTER)
                    .withSchedule(Schedule.forCronExpression(CRON_EXPRESSION_EMAIL_EVERY_WEEK));
            try {
                schedulerService.scheduleJobWithGeneratedId(worklogEmailJobConfigEveryWeek);
            } catch (SchedulerServiceException ssex) {
                LOG.error("Unable to create worklog schedule task", ssex);
            }
        } finally {
            lock.unlock();
        }
    }

    @PreDestroy
    public void onStop() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }
        } finally {
            lock.unlock();
        }
    }
}