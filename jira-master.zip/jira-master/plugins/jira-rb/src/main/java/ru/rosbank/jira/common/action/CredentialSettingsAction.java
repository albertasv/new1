package ru.rosbank.jira.common.action;

public interface CredentialSettingsAction {
    String doDefault();
    public boolean hasAdminPermission();
    String doSave();

}
