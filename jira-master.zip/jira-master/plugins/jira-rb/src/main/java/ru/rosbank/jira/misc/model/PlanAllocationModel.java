package ru.rosbank.jira.misc.model;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * POJO для временного хранения данных о встречах из календаря плагина Tempo
 */

public class PlanAllocationModel {

    private int id;

    private String assigneeKey;

    private Timestamp created;

    private String description;

    private Timestamp endTime;

    private int issueId;

    private int secondsPerDay;

    private int worklogId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAssigneeKey() {
        return assigneeKey;
    }

    public void setAssigneeKey(String assigneeKey) {
        this.assigneeKey = assigneeKey;
    }

    public Timestamp getCreated() {
        return created;
    }

    public void setCreated(Timestamp created) {
        this.created = created;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public int getIssueId() {
        return issueId;
    }

    public void setIssueId(int issueId) {
        this.issueId = issueId;
    }

    public int getSecondsPerDay() {
        return secondsPerDay;
    }

    public void setSecondsPerDay(int secondPerDay) {
        this.secondsPerDay = secondPerDay;
    }

    public int getWorklogId() {
        return worklogId;
    }

    public void setWorklogId(int worklogId) {
        this.worklogId = worklogId;
    }

    @Override
    public String toString() {
        return  "PlanAllocation: " +
                "ID=" + id + "; " +
                "ASSIGNEE_KEY=" + assigneeKey + "; " +
                "DESCRIPTION=" + description + "; " +
                "ISSUE_ID=" + issueId + "; " +
                "CREATED=" + created + "; " +
                "SECONDS_PER_DAY=" + secondsPerDay + "; " +
                "END_TIME=" + endTime + "; ";
    }
}
