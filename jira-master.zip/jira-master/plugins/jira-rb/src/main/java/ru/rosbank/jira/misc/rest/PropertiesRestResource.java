package ru.rosbank.jira.misc.rest;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.component.pico.ComponentManager;
import com.atlassian.jira.config.IssueTypeManager;
import com.atlassian.jira.issue.RendererManager;
import com.atlassian.jira.issue.fields.renderer.JiraRendererPlugin;
import com.atlassian.jira.issue.fields.renderer.wiki.AtlassianWikiRenderer;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.permission.ProjectPermissions;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.plugin.spring.scanner.annotation.imports.JiraImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ProjectPropertyModel;
import ru.rosbank.jira.common.api.ProjectPropertyModelImpl;
import ru.rosbank.jira.common.api.ProjectPropertyService;
import ru.rosbank.jira.misc.model.MessageModel;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

@Component
@Path("/properties")
public class PropertiesRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesRestResource.class);

    @JiraImport
    private final JiraAuthenticationContext jiraAuthenticationContext;
    @JiraImport
    private final PermissionManager permissionManager;

    private final ProjectManager projectManager;
    private final IssueTypeManager issueTypeManager;
    private final ProjectPropertyService projectPropertyService;


    @Inject
    public PropertiesRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            @ComponentImport PermissionManager permissionManager,
            ProjectPropertyService projectPropertyService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.permissionManager = permissionManager;
        this.projectPropertyService = projectPropertyService;

        this.projectManager = ComponentAccessor.getProjectManager();
        this.issueTypeManager = ComponentAccessor.getComponent(IssueTypeManager.class);
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{projectId}")
    public Response properties(@PathParam("projectId") Long projectId) {
        Project projectObj = projectManager.getProjectObj(projectId);
        if (projectObj == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        List<ProjectPropertyModel> props = projectPropertyService.search(projectId);
        return Response.ok(props).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{projectId}/{id}")
    public Response getProperty(@PathParam("projectId") Long projectId,
                                @PathParam("id") int propId) {
        if (!isProjectAdmin(projectId)) {
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        ProjectPropertyModel property = projectPropertyService.search(propId);
        if (property == null) {
            return Response.status(Response.Status.NOT_FOUND).entity(new MessageModel("Property not found")).build();
        }
        return Response.ok(property).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/list/{projectId}")
    public Response addProperty(@PathParam("projectId") Long projectId,
                                List<ProjectPropertyModelImpl> props) {
        if (!isProjectAdmin(projectId)) {
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        List<ProjectPropertyModel> res = new ArrayList<>();
        for (ProjectPropertyModelImpl prop : props) {
            String key = prop.getKey();
            if (key == null) {
                return Response.status(Response.Status.BAD_REQUEST).entity(new MessageModel("Key required")).build();
            }
            String value = prop.getValue() == null ? "" : prop.getValue();

            ProjectPropertyModel property = projectPropertyService.add(
                    projectId,
                    key,
                    value);
            res.add(property);
        }
        return Response.ok(res).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/{projectId}")
    public Response addProperty(@PathParam("projectId") Long projectId,
                                ProjectPropertyModelImpl prop) {
        if (!isProjectAdmin(projectId)) {
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        String key = prop.getKey();
        if (key == null) {
            return Response.status(Response.Status.BAD_REQUEST).entity(new MessageModel("Key required")).build();
        }
        String value = prop.getValue() == null ? "" : prop.getValue();

        ProjectPropertyModel property = projectPropertyService.add(
                projectId,
                key,
                value);
        return Response.ok(property).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{projectId}/{id}")
    public Response deleteProperty(@PathParam("projectId") Long projectId,
                                   @PathParam("id") int propId) {
        if (!isProjectAdmin(projectId)) {
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        projectPropertyService.delete(propId);
        return Response.ok(new MessageModel("OK")).build();
    }

    private boolean isProjectAdmin(Long project) {
        return permissionManager.hasPermission(ProjectPermissions.ADMINISTER_PROJECTS,
                projectManager.getProjectObj(project),
                jiraAuthenticationContext.getLoggedInUser());
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{projectId}/issueType/{issueTypeId}")
    public Response properties(@PathParam("projectId") Long projectId,
                               @PathParam("issueTypeId") Long issueTypeId) {

        Project projectObj = projectManager.getProjectObj(projectId);
        IssueType issueType = issueTypeManager.getIssueType(String.valueOf(issueTypeId));
        if (projectObj == null || issueType == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        // Issue type info
        String info = getIssueTypeParameter(issueType, projectId, "info");
        String issueTypeInfo = info == null ? issueType.getDescription() : info;
        // Summary and description
        Map<String, Object> fields = new HashMap<>();
        String summary = getIssueTypeParameter(issueType, projectId, "summary");
        if (!Strings.isNullOrEmpty(summary)) {
            fields.put("summary", summary);
        }
        String description = getIssueTypeParameter(issueType, projectId, "description");
        if (!Strings.isNullOrEmpty(description)) {
            fields.put("description", description);
        }

        String itSystem = getIssueTypeParameter(issueType, projectId, "itSystem");
        if (!Strings.isNullOrEmpty(itSystem)) {
            fields.put("itSystem", itSystem);
        }

        String account = getIssueTypeParameter(issueType, projectId, "account");
        if (!Strings.isNullOrEmpty(account)) {
            fields.put("account", account);
        }

        String informationForDutyService = getIssueTypeParameter(issueType, projectId, "customfield_18801");
        if (!Strings.isNullOrEmpty(informationForDutyService)) {
            fields.put("customfield_18801", informationForDutyService);
        }

        IssueTypeResultModel res = new IssueTypeResultModel();
        JiraRendererPlugin renderer = ComponentManager.getInstance().getComponent(RendererManager.class)
                .getRendererForType(AtlassianWikiRenderer.RENDERER_TYPE);
        res.setIssueTypeInfo(renderer.render(issueTypeInfo, null));
        res.setFields(fields);

        return Response.ok(res).build();
    }

    private String getIssueTypeParameter(IssueType issueType, Long projectId, String parameter) {
        String result = null;
        String infoKey = issueType.getName() + "." + parameter;
        ProjectPropertyModel property = projectPropertyService.search(projectId, infoKey);
        if (property != null) {
            result = property.getValue();
        } else {
            infoKey = "*." + parameter;
            property = projectPropertyService.search(projectId, infoKey);
            if (property != null) {
                result = property.getValue();
            }
        }
        return result;
    }
}