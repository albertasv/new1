package ru.rosbank.jira.common.api;

public enum PriorityPlanningIssue {
    KEY_FROM_SUBJECT_FIRST,
    KEY_FROM_CATEGORY_FIRST;

    public static PriorityPlanningIssue getPriorityPlanningIssue(int index) {
        if (index < 0 && index >= PriorityPlanningIssue.values().length) return KEY_FROM_SUBJECT_FIRST;
        return PriorityPlanningIssue.values()[index];
    }
}
