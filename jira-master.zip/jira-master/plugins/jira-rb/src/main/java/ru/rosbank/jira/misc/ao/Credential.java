package ru.rosbank.jira.misc.ao;


import net.java.ao.Entity;

import javax.validation.constraints.NotNull;

public interface Credential extends Entity {

    @NotNull
    String getTarget();

    @NotNull
    void setTarget(String target);

    @NotNull
    String getLogin();

    @NotNull
    void setLogin(String login);

    @NotNull
    String getEncryptedPass();

    @NotNull
    void setEncryptedPass(String encryptedPass);
}
