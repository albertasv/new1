package ru.rosbank.jira.common.api.scheduling;

import com.atlassian.beehive.ClusterLockService;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.scheduler.SchedulerService;
import com.atlassian.scheduler.SchedulerServiceException;
import com.atlassian.scheduler.config.JobConfig;
import com.atlassian.scheduler.config.JobRunnerKey;
import com.atlassian.scheduler.config.RunMode;
import com.atlassian.scheduler.config.Schedule;
import com.atlassian.scheduler.status.JobDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.RbCommonScheduledService;

import javax.annotation.PreDestroy;
import javax.inject.Named;
import java.util.List;
import java.util.concurrent.locks.Lock;


/**
 * Класс, который регистрирует работу по рассписанию процесса проверки проверяет наличия
 * ошибок при обновлении справочников из RBStaff, SM и СБУ
 */

@ExportAsService
@Named("servicesSynchronizationStatusesCheckerSchedule")
public class ScheduledServicesSynchronizationStatusesChecker implements RbCommonScheduledService, LifecycleAware {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledServicesSynchronizationStatusesChecker.class);

    private final String CRON_EXPRESSION_EVERY_DAY;


    private final JobRunnerKey jobRunnerKey = JobRunnerKey.of(ScheduledServicesSynchronizationStatusesChecker.class.getName() +
            ":instance-every-day");

    private final SchedulerService schedulerService;

    private final ScheduledServicesSynchronizationStatusesCheckerJobRunner jobRunner;

    private static final String LOCK_NAME = ScheduledServicesSynchronizationStatusesChecker.class.getName() + ".lockedTask";

    private final ClusterLockService clusterLockService;

    @Autowired
    public ScheduledServicesSynchronizationStatusesChecker(
            @ComponentImport SchedulerService schedulerService,
            @ComponentImport ClusterLockService clusterLockService,
            ConfigLoader configLoader,
            ScheduledServicesSynchronizationStatusesCheckerJobRunner jobRunner) {
        this.schedulerService = schedulerService;
        this.jobRunner = jobRunner;
        this.CRON_EXPRESSION_EVERY_DAY = configLoader.getServicesSyncStatusesCheckerScheduling();
        this.clusterLockService = clusterLockService;
    }

    @Override
    public void onStart() {
        reschedule();
    }

    @Override
    public void reschedule() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        LOG.info("Register servicesSynchronizationStatusesChecker scheduled service");
        try {
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }
            schedulerService.registerJobRunner(jobRunnerKey, jobRunner);
            JobConfig servicesSynchronizationStatusesCheckerJobConfigEveryDay = JobConfig.forJobRunnerKey(jobRunnerKey)
                    .withRunMode(RunMode.RUN_ONCE_PER_CLUSTER)
                    .withSchedule(Schedule.forCronExpression(CRON_EXPRESSION_EVERY_DAY));
            try {
                schedulerService.scheduleJobWithGeneratedId(servicesSynchronizationStatusesCheckerJobConfigEveryDay);
            } catch (SchedulerServiceException ssex) {
                LOG.error("Unable to create servicesSynchronizationStatusesChecker schedule task", ssex);
            }
        } finally {
            lock.unlock();
        }
    }

    @PreDestroy
    public void onStop() {
        final Lock lock = clusterLockService.getLockForName(LOCK_NAME);
        lock.lock();
        try {
            List<JobDetails> jobsList = schedulerService.getJobsByJobRunnerKey(jobRunnerKey);
            if (!jobsList.isEmpty()) {
                for (JobDetails job : jobsList) {
                    schedulerService.unscheduleJob(job.getJobId());
                }
                schedulerService.unregisterJobRunner(jobRunnerKey);
            }
        } finally {
            lock.unlock();
        }
    }
}
