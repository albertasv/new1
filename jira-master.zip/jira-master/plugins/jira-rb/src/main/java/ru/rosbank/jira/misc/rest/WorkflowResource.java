package ru.rosbank.jira.misc.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.misc.api.WorkflowService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import java.net.URISyntaxException;

@Component
@Path("/workflow")
public class WorkflowResource {

    private static final Logger LOG = LoggerFactory.getLogger(WorkflowResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final WorkflowService workflowService;

    @Inject
    public WorkflowResource(@ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
                            WorkflowService workflowService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.workflowService = workflowService;
    }

    @GET
    @Path("/transition/{issueKey}/{newStatus}")
    public Response status(@PathParam("issueKey") String issueKey,
                           @PathParam("newStatus") String newStatus) throws URISyntaxException {
        ApplicationUser loggedInUser = jiraAuthenticationContext.getLoggedInUser();
        if (loggedInUser != null) {
            String result = workflowService.transition(loggedInUser, issueKey, newStatus, null);
            return Response.ok(result).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }


}