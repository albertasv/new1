package ru.rosbank.jira.common.api;

import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.service.CredentialProviderService;

import javax.inject.Inject;
import java.util.Properties;

@ExportAsService({ConfigLoader.class})
@Component
public class ConfigLoaderImpl implements ConfigLoader {

    private static final String MAIN_CONFIG_FILE_NAME = "config.properties";

    private final Properties properties;
    private final CredentialProviderService credentialProviderService;

    @Inject
    public ConfigLoaderImpl(CredentialProviderService credentialProviderService, RbPropertiesReader propertiesReader) {
        this.credentialProviderService = credentialProviderService;
        this.properties = propertiesReader.loadPropertiesFrom(MAIN_CONFIG_FILE_NAME);
    }

    @Override
    public String getJiraEnvironment() {
        return properties.getProperty("jira.server.environment");
    }

    @Override
    public String getPortfolioModelVersion() {
        return properties.getProperty("jira.portfolio.model.version");
    }

    @Override
    public String getJiraPpmSyncUser() {
        return properties.getProperty("jira.ppm.syncUser");
    }

    @Override
    public Long getPortfolioIssueFieldId() {
        return getLongProperty("jira.field.portfolioIssue.id");
    }

    @Override
    public String getPortfolioIssueFieldName() {
        return properties.getProperty("jira.field.portfolioIssue.name");
    }

    @Override
    public Long getPortfolioProjectFieldId() {
        return getLongProperty("jira.field.portfolioProject.id");
    }

    @Override
    public String getJiraCRSProject() {
        return properties.getProperty("jira.crs.project");
    }

    @Override
    public String getJiraPRJProject() {
        return properties.getProperty("jira.prj.project");
    }

    @Override
    public String getJiraPREProject() {
        return properties.getProperty("jira.pre.project");
    }

    @Override
    public String getJiraArchitectProject() {
        return properties.getProperty("jira.architect.project");
    }

    @Override
    public String getJiraISOfficeProject() {
        return properties.getProperty("jira.isOfficer.project");
    }

    @Override
    public String getJiraProblemProject() {
        return properties.getProperty("jira.problem.project");
    }

    @Override
    public Long getPpmCodeFieldId() {
        return getLongProperty("jira.field.ppmCode.id");
    }

    @Override
    public Long getDescriptionEnFieldId() {
        return getLongProperty("jira.field.descriptionEn.id");
    }

    @Override
    public Long getDomainFieldId() {
        return getLongProperty("jira.field.domain.id");
    }

    @Override
    public Long getCategoryFieldId() {
        return getLongProperty("jira.field.category.id");
    }

    @Override
    public Long getCostCenterFieldId() {
        return getLongProperty("jira.field.costCenter.id");
    }

    @Override
    public Long getManagerFieldId() {
        return getLongProperty("jira.field.manager.id");
    }

    @Override
    public Long getISOfficerFieldId() {
        return getLongProperty("jira.field.isOfficer.id");
    }

    @Override
    public Long getITArchitectFieldId() {
        return getLongProperty("jira.field.itArchitect.id");
    }

    @Override
    public String getITArchitectFieldName() {
        return properties.getProperty("jira.field.itArchitect.name");
    }

    @Override
    public Long getExecutionTeamsFieldId() {
        return getLongProperty("jira.field.executionTeams.id");
    }

    @Override
    public Long getItArchitectResolutionId() {
        return getLongProperty("jira.field.itArchitectResolution.id");
    }

    @Override
    public String getItArchitectResolutionName() {
        return properties.getProperty("jira.field.itArchitectResolution.name");
    }

    @Override
    public Long getIsOfficerResolutionId() {
        return getLongProperty("jira.field.isOfficerResolution.id");
    }

    @Override
    public Long getFinancialResolutionId() {
        return getLongProperty("jira.field.financialResolution.id");
    }

    @Override
    public Long getIsOfficerClosingId() {
        return getLongProperty("jira.field.isOfficerClosing.id");
    }

    /**
     * Start Date
     */
    @Override
    public Long getStartDateFieldId() {
        return getLongProperty("jira.field.startDate.id");
    }

    /**
     * Registration Date
     */
    @Override
    public Long getRegDateFieldId() {
        return getLongProperty("jira.field.regDate.id");
    }

    /**
     * End Initial Date
     */
    @Override
    public Long getEndInitialDateFieldId() {
        return getLongProperty("jira.field.endInitialDate.id");
    }

    /**
     * End Validated Date
     */
    @Override
    public Long getEndValidatedDateFieldId() {
        return getLongProperty("jira.field.endValidatedDate.id");
    }

    /**
     * End Actual Date
     */
    @Override
    public Long getEndActualDateFieldId() {
        return getLongProperty("jira.field.endActualDate.id");
    }

    /**
     * SteerCo Date
     */
    @Override
    public Long getSteerCoFieldId() {
        return getLongProperty("jira.field.steerCoDate.id");
    }

    @Override
    public Long getSplitIssueLinkType() {
        return getLongProperty("jira.issueLinkType.split");
    }

    @Override
    public Long getRelatesIssueLinkType() {
        return getLongProperty("jira.issueLinkType.relates");
    }

    @Override
    public Long getJiraIssueSourceFieldId() {
        return getLongProperty("jira.field.issueSource.id");
    }

    @Override
    public Long getJiraItSystemFieldId() {
        return getLongProperty("jira.field.itSystem.id");
    }

    @Override
    public Long getJiraImpactFieldId() {
        return getLongProperty("jira.field.impact.id");
    }

    @Override
    public Long getJiraSmNumberFieldId() {
        return getLongProperty("jira.field.smNumber.id");
    }

    @Override
    public Long getJiraServiceFieldId() {
        return getLongProperty("jira.field.service.id");
    }

    @Override
    public Long getJiraStartDateFieldId() {
        return getLongProperty("jira.field.startDate.id");
    }

    @Override
    public Long getJiraGroupFieldId() {
        return getLongProperty("jira.field.group.id");
    }

    @Override
    public Long getJiraSmCauseReasonFieldId() {
        return getLongProperty("jira.field.smCauseReason.id");
    }

    @Override
    public Long getJiraSmAmountLinkedSdFieldId() {
        return getLongProperty("jira.field.smAmountLinkedSd.id");
    }

    @Override
    public Long getEnvironmentFoundFieldId() {
        return getLongProperty("jira.field.environmentFound.id");
    }

    @Override
    public String getEnvironmentFoundProdOptionId() {
        return properties.getProperty("jira.field.environmentFound.PROD.id");
    }

    @Override
    public Long getJiraProblemSourceFieldId() {
        return getLongProperty("jira.field.problemSource.id");
    }

    @Override
    public Long getJiraProblemSourceFieldDefaultOptionId() {
        return getLongProperty("jira.field.problemSource.defaultOption.id");
    }

    @Override
    public Long getJiraChecklistsFieldId() {
        return getLongProperty("jira.field.checklists.id");
    }

    @Override
    public Long getJiraSolutionFieldId() {
        return getLongProperty("jira.field.solution.id");
    }

    @Override
    public Long getJiraSmDeadlineFieldId() {
        return getLongProperty("jira.field.smDeadline.id");
    }

    @Override
    public Long getJiraOrdinalPriorityFieldId() {
        return getLongProperty("jira.field.ordinalPriority.id");
    }

    @Override
    public Long getJiraThemesFieldId() {
        return getLongProperty("jira.field.themes.id");
    }

    @Override
    public Long getJiraVendorFieldId() {
        return getLongProperty("jira.field.vendor.id");
    }

    @Override
    public Long getJiraProjectAimsFieldId() {
        return getLongProperty("jira.field.projectAims.id");
    }

    @Override
    public Long getJiraProjectPerimeterFieldId() {
        return getLongProperty("jira.field.projectPerimeter.id");
    }

    @Override
    public Long getJiraReadinessCriteriaFieldId() {
        return getLongProperty("jira.field.readinessCriteria.id");
    }

    @Override

    public Long getSmWorkGroupFieldId() {
        return getLongProperty("jira.field.smWorkGroup.id");
    }
    public Long getSptTypeFieldId () {
            return getLongProperty("jira.field.sptType.id");
        }
    @Override
    public String getSptTypeProdOptionId () {
        return properties.getProperty("jira.field.sptTypeProd.id");
    }

    @Override
    public String getSbuWsLocation () {
        return properties.getProperty("sbu.wsLocation");
    }

    @Override
    public String getSbuLogin () {
        return credentialProviderService.getLogin("SBU");
    }

    @Override
    public String getSbuPassword () {
        return credentialProviderService.getPassword("SBU");
    }

    @Override
    public String getSmUrl () {
        return properties.getProperty("sm.url");
    }

    @Override
    public String getSmAuth () {
        return credentialProviderService.getBase64Credential("SM");
    }

    @Override
    public String getSmActionUrl () {
        return properties.getProperty("sm.action.url");
    }

    @Override
    public String getSmLogin () {
        return credentialProviderService.getLogin("SM");
    }

    @Override
    public String getSmPassword () {
        return credentialProviderService.getPassword("SM");
    }

    @Override
    public String getJiraSmUser () {
        return properties.getProperty("jira.sm.user");
    }

    @Override
    public String getEwsLogin () {
        return credentialProviderService.getLogin("EWS");
    }

    @Override
    public String getEwsPassword () {
        return credentialProviderService.getPassword("EWS");
    }

    @Override
    public String getRbStaffUrl () {
        return properties.getProperty("rbstaff.url");
    }

    @Override
    public String getRbStaffLogin () {
        return credentialProviderService.getLogin("RBSTAFF");
    }

    @Override
    public String getRbStaffLoginDomain () {
        return properties.getProperty("rbstaff.login.domain");
    }

    @Override
    public String getRbStaffPassword () {
        return credentialProviderService.getPassword("RBSTAFF");
    }

    private Long getLongProperty (String key){
        try {
            return Long.parseLong(properties.getProperty(key));
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public Long getSyncedWithSmStatusFieldId() {
        return getLongProperty("jira.field.sentToSm.id");
    }

    @Override
    public String getSyncedWithSmStatusFieldValue() {
        return properties.getProperty("jira.field.sentToSm.value");
    }

    @Override
    public String getSmReturnCode3Message() {
        return properties.getProperty("sm.response.code.3");
    }

    @Override
    public String getSmReturnCode51Message() {
        return properties.getProperty("sm.response.code.51");
    }

    @Override
    public String getSmReturnCode71Message() {
        return properties.getProperty("sm.response.code.71");
    }

    @Override
    public String getCalendarScheduling() {
        return properties.getProperty("scheduled.calendar.service");
    }

    @Override
    public String getWorklogScheduling() {
        return properties.getProperty("scheduled.worklog.service");
    }

    @Override
    public String getDauScheduling() {
        return properties.getProperty("scheduled.dau.service");
    }

    @Override
    public String getCurrentFinancialYearScheduling() {
        return properties.getProperty("scheduled.current.financial.year.service");
    }

    @Override
    public String getPreviousFinancialYearScheduling() {
        return properties.getProperty("scheduled.previous.financial.year.service");
    }

    @Override
    public String getRbStaffTeamsLoadingScheduling() {
        return properties.getProperty("scheduled.rbstaff.load.teams.service");
    }

    @Override
    public String getSmReasonsUpdaterScheduling() {
        return properties.getProperty("scheduled.sm.reasons.updating.service");
    }

    @Override
    public String getSmMessagesQueueCleanerScheduling() {
        return properties.getProperty("scheduled.sm.messages.queue.cleaner.service");
    }

    @Override
    public String getServicesSyncStatusesCheckerScheduling() {
        return properties.getProperty("scheduled.synchronization.statuses.checker.service");
    }

    @Override
    public Long getActivityTypeFieldId() {
        return getLongProperty("jira.field.activityType.id");
    }

    @Override
    public Long getTestEnvironmentFieldId() {
        return getLongProperty("jira.field.testEnvironment.id");
    }
}
