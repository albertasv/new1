package ru.rosbank.jira.misc.action;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.misc.api.WorkflowService;

import javax.inject.Inject;

public class WorkflowTransitionAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(WorkflowTransitionAction.class);

    private final JiraAuthenticationContext authenticationContext;
    private final UserInfoService userInfoService;
    private final WorkflowService workflowService;

    private UserInfoModel loggedInUserInfo;
    private String issueKey;
    private String workflowTransitionResult;

    @Inject
    public WorkflowTransitionAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            UserInfoService userInfoService,
            WorkflowService workflowService) {
        this.authenticationContext = authenticationContext;
        this.userInfoService = userInfoService;
        this.workflowService = workflowService;

        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        this.loggedInUserInfo = userInfoService.getUserInfo(loggedInUser.getUsername());
    }

    @Override
    public String execute() throws Exception {
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        issueKey = getHttpRequest().getParameter("issue");
        String newStatus = getHttpRequest().getParameter("status");

        if (loggedInUser != null) {
            workflowTransitionResult = workflowService.transition(loggedInUser, issueKey, newStatus, null);
        }
        return super.execute(); //returns SUCCESS
    }

    public UserInfoModel getLoggedInUserInfo() {
        return loggedInUserInfo;
    }

    public String getIssueKey() {
        return issueKey;
    }

    public String getWorkflowTransitionResult() {
        return workflowTransitionResult;
    }
}