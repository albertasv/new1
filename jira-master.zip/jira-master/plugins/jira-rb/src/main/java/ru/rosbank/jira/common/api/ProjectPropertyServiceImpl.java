package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.user.UserManager;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.springframework.stereotype.Service;
import ru.rosbank.jira.misc.ao.ProjectProperty;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService
@Service
public class ProjectPropertyServiceImpl implements ProjectPropertyService {

    @ComponentImport
    private final ActiveObjects ao;
    @ComponentImport
    private final UserManager userManager;

    @Inject
    public ProjectPropertyServiceImpl(ActiveObjects ao, UserManager userManager) {
        this.ao = checkNotNull(ao);
        this.userManager = checkNotNull(userManager);
    }

    @Override
    public ProjectPropertyModel search(int propId) {
        return convert(getProperty(propId));
    }

    @Override
    public List<ProjectPropertyModel> search(Long projectId) {
        return Arrays.asList(getProperties(projectId)).stream().map(pp -> convert(pp)).collect(Collectors.toList());
    }

    @Override
    public List<ProjectPropertyModel> search(String s) {
        return Arrays.asList(getProperties(s)).stream().map(pp -> convert(pp)).collect(Collectors.toList());
    }

    @Override
    public ProjectPropertyModel search(Long project, String key) {
        return convert(getProperty(project, key));
    }

    @Override
    public ProjectPropertyModel add(Long project, String key, String value) {
        ProjectPropertyModel property = update(project, key.toLowerCase(), value);
        if (property == null && project != null && !Strings.isNullOrEmpty(key) && !Strings.isNullOrEmpty(value)) {
            property = convert(ao.create(ProjectProperty.class,
                    ImmutableMap.of(
                            "PROJECT", project,
                            "KEY", key,
                            "VALUE", value)));
        }
        return property;
    }

    @Override
    public ProjectPropertyModel update(Long project, String key, String value) {
        ProjectProperty property = getProperty(project, key.toLowerCase());
        if (property != null) {
            property.setValue(value);
            property.save();
        }
        return convert(property);
    }

    @Override
    public void delete(int propId) {
        ProjectProperty propertyToDelete = getProperty(propId);
        if (propertyToDelete != null) {
            ao.delete(propertyToDelete);
        }
    }

    public static ProjectPropertyModel convert(ProjectProperty pp) {
        if (pp == null) {
            return null;
        }
        return new ProjectPropertyModelImpl(pp.getID(), pp.getProject(), pp.getKey(), pp.getValue());
    }

    private ProjectProperty getProperty(int projectId) {
        ProjectProperty[] props = ao.find(ProjectProperty.class,
                Query.select().where("ID = ?", projectId));
        if (props.length > 0) {
            return props[0];
        }
        return null;
    }

    private ProjectProperty getProperty(Long projectId, String key) {
        ProjectProperty[] props = ao.find(ProjectProperty.class,
                Query.select().where("PROJECT = ? AND LOWER(\"KEY\" COLLATE \"en_US\") LIKE ?", projectId, key.toLowerCase()));
        if (props.length > 0) {
            return props[0];
        }
        return null;
    }

    private ProjectProperty[] getProperties(Long projectId) {
        return ao.find(ProjectProperty.class,
                Query.select().where("PROJECT = ?", projectId));
    }

    private ProjectProperty[] getProperties(String key) {
        return ao.find(ProjectProperty.class,
                Query.select().where("LOWER(\"KEY\" COLLATE \"en_US\") LIKE ?", key.toLowerCase()));
    }
}
