package ru.rosbank.jira.misc.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import net.java.ao.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.misc.ao.ServiceStatuses;
import ru.rosbank.jira.misc.model.ExternalServiceStatusModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
@ExportAsService
@Named("GetExtServiceStatusesService")
public class GetExternalServicesStatusesServiceImpl implements GetExternalServicesStatusesService {

    private static final Logger LOG = LoggerFactory.getLogger(GetExternalServicesStatusesServiceImpl.class);
    private List<ExternalServiceStatusModel> externalServiceStatusModelList;
    private final ActiveObjects ao;

    @Inject
    public GetExternalServicesStatusesServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public List<ExternalServiceStatusModel> getAllExtServicesStatuses() {
        ServiceStatuses[] statuses = ao.find(ServiceStatuses.class, Query.select());
        LOG.debug("serviceStatusModelList is: {}", statuses);
        externalServiceStatusModelList = ExternalServiceStatusModel.convert(statuses);
        return externalServiceStatusModelList;
    }
}
