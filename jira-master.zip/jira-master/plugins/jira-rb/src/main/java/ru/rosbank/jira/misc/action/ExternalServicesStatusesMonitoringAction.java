package ru.rosbank.jira.misc.action;

import com.atlassian.jira.web.action.JiraWebActionSupport;
import ru.rosbank.jira.misc.api.GetExternalServicesStatusesService;
import ru.rosbank.jira.misc.model.ExternalServiceStatusModel;

import java.util.List;

public class ExternalServicesStatusesMonitoringAction extends JiraWebActionSupport {

    GetExternalServicesStatusesService getExternalServicesStatusesService;


    public ExternalServicesStatusesMonitoringAction(GetExternalServicesStatusesService getExternalServicesStatusesService) {
        this.getExternalServicesStatusesService = getExternalServicesStatusesService;
    }

    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public List<ExternalServiceStatusModel> getServices() {
        return getExternalServicesStatusesService.getAllExtServicesStatuses();
    }


}
