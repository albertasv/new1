package ru.rosbank.jira.misc.api;

import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.IssueInputParameters;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.status.Status;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.UserUtils;
import com.atlassian.jira.util.ErrorCollection;
import com.atlassian.jira.workflow.JiraWorkflow;
import com.atlassian.jira.workflow.TransitionOptions;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.opensymphony.workflow.loader.ActionDescriptor;
import com.opensymphony.workflow.loader.StepDescriptor;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@ExportAsService
@Named("workflowService")
public class WorkflowServiceImpl implements WorkflowService {

    private final IssueService issueService;

    @Inject
    public WorkflowServiceImpl(@ComponentImport IssueService issueService) {
        this.issueService = issueService;
    }

    @Override
    public String transition(ApplicationUser appUser, String issueKey, String newStatus, String comment) {
        MutableIssue issue = ComponentAccessor.getIssueManager().getIssueObject(issueKey);
        String errors = null;
        if (issue != null) {
            // Transition
            Status currentStatus = issue.getStatus();
            String currentStatusName = currentStatus.getName();
            if (!currentStatusName.equalsIgnoreCase(newStatus)) {
                JiraWorkflow jiraWorkflow = ComponentAccessor.getWorkflowManager().getWorkflow(issue);
                // Looking for common transition
                StepDescriptor oStep = jiraWorkflow.getLinkedStep(currentStatus);
                List<ActionDescriptor> oActions = (List<ActionDescriptor>) oStep.getActions();
                Optional<ActionDescriptor> anyAction = oActions.stream()
                        .filter(oAction -> oAction.getName().equalsIgnoreCase(newStatus))
                        .findAny();
                Integer actionId = null;
                if (anyAction.isPresent()) {
                    ActionDescriptor oAction = anyAction.get();
                    actionId = oAction.getId();
                } else {
                    // If there is no common action, looking for global
                    Optional<ActionDescriptor> anyGlobalAction = jiraWorkflow.getAllActions().stream().filter(oAction ->
                            jiraWorkflow.isGlobalAction(oAction) && (oAction.getName().equalsIgnoreCase(newStatus)))
                            .findAny();
                    if (anyGlobalAction.isPresent()) {
                        actionId = anyGlobalAction.get().getId();
                    }
                }

                if (actionId != null) {
                    IssueInputParameters issueInputParameters = issueService.newIssueInputParameters();
                    TransitionOptions transitionOptions = new TransitionOptions.Builder().skipConditions().build();
                    IssueService.TransitionValidationResult transitionValidationResult
                            = issueService.validateTransition(appUser,
                            issue.getId(),
                            actionId,
                            issueInputParameters, transitionOptions);
                    // Transition Validation errors
                    errors = errors(transitionValidationResult.getErrorCollection());
                    if (errors == null) {
                        IssueService.IssueResult transitionResult = issueService.transition(appUser, transitionValidationResult);
                        // Transition errors
                        errors = errors(transitionResult.getErrorCollection());

                        if (errors == null) {
                            if (!Strings.isNullOrEmpty(comment)) {
                                ComponentAccessor.getCommentManager().create(issue, appUser, comment, false);
                            }

                            // TO transition result HERE
                            return "Success: Issue " + issueKey + " was transitioned " +
                                    "from status " + currentStatusName +
                                    " to " + newStatus;
                        }
                    }
                } else {
                    errors = "Error: Issue " + issueKey + " status " + newStatus + " transition not found";
                }
            } else {
                errors = "Error: Issue " + issueKey + " is already in status " + newStatus;
            }
        } else {
            errors = "Error: Issue " + issueKey + " not found";
        }
        return errors;
    }

    private static String errors(ErrorCollection errorCollection) {
        if (errorCollection.hasAnyErrors()) {
            return errorCollection.getErrors()
                    .entrySet()
                    .stream()
                    .map(e -> e.getKey() + " -> " + e.getValue())
                    .collect(Collectors.joining(" | "));
        }
        return null;
    }

    @Override
    public ApplicationUser getActiveUser(String nameOrEmail) {
        ApplicationUser applicationUser;
        if (nameOrEmail != null && nameOrEmail.contains("@")) {

            // only rb000000 and rbxmos000000 users
            applicationUser = UserUtils.getUsersByEmail(nameOrEmail).stream().filter(
                    user ->
                            user.isActive() &&
                                    user.getUsername().toLowerCase().matches("^(rb[0-9]|rbxmos[0-9]).*$"))
                    .findAny().orElse(null);
            if (applicationUser != null) {
                return applicationUser;
            }
        }
        applicationUser = UserUtils.getUser(nameOrEmail);
        if (applicationUser != null && applicationUser.isActive()) {
            return applicationUser;
        }
        return null;
    }
}
