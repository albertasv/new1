package ru.rosbank.jira.misc.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.misc.ao.News;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NewsModel {

    private Integer id;
    private String news;
    private String newsRender;
    private Date lastUpdateDate;

    public NewsModel() {
    }

    public NewsModel(Integer id, String news) {
        this.id = id;
        this.news = news;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNews() {
        return news;
    }

    public void setNews(String news) {
        this.news = news;
    }

    public String getNewsRender() {
        return newsRender;
    }

    public void setNewsRender(String newsRender) {
        this.newsRender = newsRender;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public static NewsModel convert(News news) {
        NewsModel item = new NewsModel();
        item.setId(news.getID());
        item.setNews(news.getNews());
        item.setLastUpdateDate(news.getLastUpdateDate());
        return item;
    }
}
