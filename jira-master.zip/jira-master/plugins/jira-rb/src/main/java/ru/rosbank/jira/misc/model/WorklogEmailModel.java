package ru.rosbank.jira.misc.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class WorklogEmailModel {

    private String username;
    private String displayName;
    private String email;
    private String teamRole;
    private String teamName;
    private double worklogMonth;
    private double planMonth;
    private double worklogWeek;
    private double planWeek;
    private int worklogEmail;

    private final DateFormat dateFormat;

    public WorklogEmailModel() {
        this.dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTeamRole() {
        return teamRole;
    }

    public void setTeamRole(String teamRole) {
        this.teamRole = teamRole;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public double getWorklogMonth() {
        return worklogMonth;
    }

    public void setWorklogMonth(double worklogMonth) {
        this.worklogMonth = worklogMonth;
    }

    public double getPlanMonth() {
        return planMonth;
    }

    public void setPlanMonth(double planMonth) {
        this.planMonth = planMonth;
    }

    public double getStatusMonth() {
        return worklogMonth - planMonth;
    }

    public double getWorklogWeek() {
        return worklogWeek;
    }

    public void setWorklogWeek(double worklogWeek) {
        this.worklogWeek = worklogWeek;
    }

    public double getPlanWeek() {
        return planWeek;
    }

    public void setPlanWeek(double planWeek) {
        this.planWeek = planWeek;
    }

    public double getStatusWeek() {
        return worklogWeek - planWeek;
    }

    public int getWorklogEmail() {
        return worklogEmail;
    }

    public void setWorklogEmail(int worklogEmail) {
        this.worklogEmail = worklogEmail;
    }

    public String getCurrentDate() {
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }

    public String getCurrentWeek() {
        Calendar weekStart = Calendar.getInstance();
        weekStart.set(Calendar.DAY_OF_WEEK, 2);
        Calendar weekEnd = (Calendar) weekStart.clone();
        weekEnd.set(Calendar.DAY_OF_WEEK, 1);
        return "с " + dateFormat.format(weekStart.getTime()) + " по " + dateFormat.format(weekEnd.getTime());
    }

    public String getCurrentMonth() {
        Calendar monthStart = Calendar.getInstance();
        monthStart.set(Calendar.DAY_OF_MONTH, 1);
        Calendar monthEnd = (Calendar) monthStart.clone();
        monthEnd.set(Calendar.DAY_OF_MONTH, monthEnd.getActualMaximum(Calendar.DAY_OF_MONTH));
        return "с " + dateFormat.format(monthStart.getTime()) + " по " + dateFormat.format(monthEnd.getTime());
    }

    public static WorklogEmailModel defaultWorklog() {
        return new WorklogEmailModel();
    }
}
