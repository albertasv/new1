package ru.rosbank.jira.misc.ao;


import net.java.ao.Entity;

import javax.validation.constraints.NotNull;
import java.util.Date;

public interface ClickLog extends Entity {

    @NotNull
    String getUsername();

    @NotNull
    void setUsername(String username);

    @NotNull
    String getTopic();

    @NotNull
    void setTopic(String topic);

    int getClick();

    void setClick(int click);

    @NotNull
    Date getLastUpdateDate();

    @NotNull
    void setLastUpdateDate(Date lastUpdateDate);
}
