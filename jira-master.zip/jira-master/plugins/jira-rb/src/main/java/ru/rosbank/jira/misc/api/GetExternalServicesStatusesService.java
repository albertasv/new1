package ru.rosbank.jira.misc.api;

import ru.rosbank.jira.misc.model.ExternalServiceStatusModel;

import java.util.List;

public interface GetExternalServicesStatusesService {
    public List<ExternalServiceStatusModel> getAllExtServicesStatuses();
}
