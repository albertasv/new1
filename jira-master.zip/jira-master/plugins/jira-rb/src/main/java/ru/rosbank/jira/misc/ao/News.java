package ru.rosbank.jira.misc.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.StringLength;

import java.util.Date;


@Preload
public interface News extends Entity {

    @NotNull
    @StringLength(StringLength.UNLIMITED)
    String getNews();

    @NotNull
    void setNews(String news);

    @NotNull
    Date getLastUpdateDate();

    @NotNull
    void setLastUpdateDate(Date lastUpdateDate);

}
