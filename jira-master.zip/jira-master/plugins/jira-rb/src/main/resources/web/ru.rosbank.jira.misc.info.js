AJS.$(document).ready(function () {
    var tablePlaceholder = AJS.$("#project-properties");
    var projectId = tablePlaceholder.data("project");

    AJS.$("#rb-agile-team-select").select2({
        multiple: true,
        placeholder: 'Not selected',
        allowClear: true,
        containerCssClass: 'pitronote-select2',
        ajax: {
            url: '/rest/portfolio/1.0/dictionary/EXECUTION_TEAM.json',
            dataType: 'json',
            quietMillis: 250,
            data: function (term, page) {
                return {
                    q: 'agile_team#' + term,
                    all: true,
                    page: page
                };
            },
            results: function (data, page) {
                var more = page * 10 < data.total;
                data = AJS.$.map(data.items, function (val, i) {
                    return {
                        id: val.code,
                        name: val.name,
                        owner: val.ownerFullName,
                        type: val.type,
                        status: val.status
                    }
                });
                return {results: data, more: more};
            },
            allowClear: true,
            cache: true
        },
        initSelection: function (element, callback) {
            var data = [];
            AJS.$.each(AJS.$(element).data('code').split(','), function (index, code) {
                data.push({id: code, name: ' '});
            });
            callback(data);
        },
        formatResult: function (val) {
            return `<div class="dict-container">
                <span class="dict-code">[${val.id}]</span> ${val.name}</span><br/>
                <span class="et-type"><label>Type:</label> ${val.type}</span></span><br/>
                <span class="et-owner"><label>Owner:</label> ${val.owner || ''}</span>
                </div>`;
        },
        formatSelection: function (val) {
            return `<div class="et-container">
                <span class="et-code">[${val.id}]</span> ${val.name}<br/>
                </div>`;
        },
        escapeMarkup: function (m) {
            return m;
        }
    });

    AJS.$("#rb-systems-select").select2({
        multiple: true,
        placeholder: 'Not selected',
        allowClear: true,
        containerCssClass: 'pitronote-select2',
        ajax: {
            url: '/rest/sm/1.0/ci/search/system.json',
            dataType: 'json',
            quietMillis: 250,
            data: function (term, page) {
                return {
                    q: term,
                    all: true,
                    page: page
                };
            },
            results: function (data, page) {
                var more = page * 10 < data.total;
                data = AJS.$.map(data.items, function (val, i) {
                    return {
                        id: val.code,
                        name: val.name,
                        owner: val.ownerFullName,
                        type: val.type,
                        status: val.status
                    }
                });
                return {results: data, more: more};
            },
            allowClear: true,
            cache: true
        },
        initSelection: function (element, callback) {
            var data = [];
            AJS.$.each(AJS.$(element).data('code').split(','), function (index, code) {
                data.push({id: code, name: ''});
            });
            callback(data);
        },
        formatResult: function (val) {
            var status = ' ';
            if (val.status) {
                status += '<span class="sm-ci-status-' + val.status.code + '">(' + val.status.name + ')</span>';
            }
            return '<span class="sm-ci-code">'
                + ('[' + val.id + ']')
                + '</span> '
                + (val.name || '')
                + status;
        },
        formatSelection: function (val) {
            return `<div class="et-container">
                <span class="et-code">[${val.id}]</span> ${val.name}<br/>
                </div>`;
        },
        escapeMarkup: function (m) {
            return m;
        }
    });

   AJS.$("#sm-favorite-workgroups-select").select2({
        multiple: true,
        placeholder: 'Not selected',
        allowClear: true,
        containerCssClass: 'pitronote-select2',
        ajax: {
            url: '/rest/sm/1.0/workgroup/search',
            dataType: 'json',
            quietMillis: 250,
            data: function (term, page) {
                return {
                    q: term
                    ,page: page
                };
            },
            results: function (data, page) {
                var more = page * 10 < data.total;
                data = AJS.$.map(data.items, function (val, i) {
                    return {
                        id: val.ID,
                        name: val.Name,
                    }
                });
                return {results: data, more: more};
            },
            allowClear: true,
            cache: true
        },
        initSelection: function (element, callback) {
            var data = [];
            AJS.$.each(AJS.$(element).data('code').split(','), function (index, code) {
                data.push({id: code, name: ''});
            });
            callback(data);
        },
        formatResult: function (val) {
            return '<span class="sm-ci-code">'
                + ('[' + val.id + ']')
                + '</span> '
                + (val.name || '');
        },
        formatSelection: function (val) {
            return `<div class="et-container">
                <span class="et-code">[${val.id}]</span> ${val.name}</span><br/>
                </div>`;
        },
        escapeMarkup: function (m) {
            return m;
        }
    });

    AJS.$("#rb-agile-team-save").on('click', function (e) {
        e.preventDefault();
        AJS.$.ajax({
            type: "POST",
            url: "/rest/misc/1.0/properties/list/" + projectId,
            contentType: "application/json; charset=utf-8",
            dropdownAutoWidth: true,
            dataType: 'json',
            data: JSON.stringify([
                    {
                        'key': 'agile.team',
                        'value': AJS.$("#rb-agile-team-select").val()
                    }, {
                        'key': 'itSystems',
                        'value': AJS.$("#rb-systems-select").val()
                    }
                ]
            ),
            success: function (data) {
                window.alert("Properties saved successfully");
            }
        });
    });

    AJS.$("#rb-sm-save").on('click', function (e) {
        e.preventDefault();
        AJS.$.ajax({
            type: "POST",
            url: "/rest/misc/1.0/properties/list/" + projectId,
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            data: JSON.stringify([
                {
                    'key': 'sm.resolution.done.action',
                    'value': AJS.$("#sm-resolution-done-action").val()
                },
                {
                    'key': 'favorite.sm.workgroups',
                    'value': AJS.$("#sm-favorite-workgroups-select").val()
                }
            ]),
            success: function (data) {
                window.alert("Properties saved successfully");
            }
        });
    });

    // All properties table
    var initTable = function () {
        return new AJS.RestfulTable({
            el: tablePlaceholder,
            autoFocus: true,
            allowEdit: false,
            resources: {
                all: "/rest/misc/1.0/properties/" + projectId,
                self: "/rest/misc/1.0/properties/" + projectId
            },
            deleteConfirmationCallback: function (model) {
                AJS.$("#restful-table-model")[0].innerHTML = "<b>Key:</b> " + model.key;
                AJS.dialog2("#delete-confirmation-dialog").show();
                return new Promise(function (resolve, reject) {
                    AJS.$("#dialog-submit-button").on('click', function (e) {
                        resolve();
                        e.preventDefault();
                        AJS.dialog2("#delete-confirmation-dialog").hide();
                    });
                    AJS.$(".aui-close-button, #warning-dialog-cancel").on('click', function (e) {
                        reject();
                        e.preventDefault();
                        AJS.dialog2("#delete-confirmation-dialog").hide();
                    });
                });
            },
            columns: [
                {
                    id: "key",
                    header: "Key"
                },
                {
                    id: "value",
                    header: "Value",
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function (self) {
                            return jQuery("<textarea name='value' class='textarea long-field' rows='3' cols='50' name='description' aria-label='value'></textarea>")
                        }
                    })
                }
            ]
        });
    }
    var propsTable = initTable();
    AJS.$(document).bind(AJS.RestfulTable.Events.ROW_ADDED, function () {
        // TODO
        tablePlaceholder.empty();
        propsTable = initTable();
    });
    // !All properties table

    // Update Agile team info by code - name, owner
    var updateAgileTeamInfo = function () {
        var agileTeamEl = AJS.$("#rb-agile-team");
        var agileTeamCode = agileTeamEl.data("team");
        if (agileTeamCode) {
            AJS.$.get("/rest/portfolio/1.0/dictionary/EXECUTION_TEAM.json?q=" + agileTeamCode)
                .success(function (data) {
                    if (data && data.items && data.items.length > 0) {
                        var agileTeam = data.items[0];
                        agileTeamEl.append(`
                            <div>
                                <a href="/secure/AgileTeamInfo.jspa?code=${agileTeam.code}">${agileTeam.name} (${agileTeam.code})</a><br/>
                                Owner: <span><span class="user-hover" rel="${agileTeam.ownerUserName}">${agileTeam.ownerFullName}</span></span>
                            </div>`);

                        AJS.$('#s2id_rb-agile-team-select .et-container').html(`<div class="et-container">
                                <span class="et-code">[${agileTeam.code}]</span> ${agileTeam.name}</span><br/>
                            </div>`);
                    }
                });
        }
    }
    updateAgileTeamInfo();
    // !Update Agile team info by code
});


