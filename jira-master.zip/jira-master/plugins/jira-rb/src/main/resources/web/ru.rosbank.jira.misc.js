JIRA.bind(JIRA.Events.NEW_CONTENT_ADDED, function () {
    addOof();
    copyEpicNameSummary();
    issuesInEpicRenderer();
    //printHelpButton(); // Пока что отключил раскраску кнопки Support/Поддержка

    AJS.$("#tempo-bar-load-calendar").on('click', function (e) {
        e.preventDefault();
        AJS.$.get("/rest/misc/1.0/calendar/plan/load")
            .success(function () {
                window.alert('Данные календаря успешно загружены.');
                if (window.location.href.indexOf("Tempo.jspa") > -1) {
                    window.location.reload();
                }
            })
            .error(function () {
                window.alert('Во время загрузки календаря произошла ошибка. Обратитесь к администратору.');
            });
    });

    AJS.$("#tempo-bar-load-worklog").on('click', function (e) {
        e.preventDefault();
        AJS.$.get("/rest/misc/1.0/calendar/plan/status")
            .success(function (msg) {
                if (msg.data == 0) {
                    window.alert(msg.message)
                } else {
                    if (window.confirm(msg.message) == true) {
                        loadWorklog();
                    }
                }
            })
            .error(function () {
                window.alert('Во время загрузки календаря произошла ошибка. Обратитесь к администратору.');
            });
    });


    AJS.$("#maintain_release_links_link_lnk").attr("href", "/secure/Redirect.jspa?redirect=MAINTAIN_RELEASE");

    setTimeout(function () {
        $('nav.sc-CtfFt').prepend(
            `
        <div style="margin: 0 10px;">
        <input id="hide-issue-summary" class="checkbox" type="checkbox" onclick="$('.bLjFcC').each(function (i, el) {
        if ($(el).css('display') == 'none') {
            $(el).attr('style', 'display:block');
        } else {
            $(el).attr('style', 'display:none');
        }});">
        <label for="hide-issue-summary" title="Скрыть наименования задач в календа Tempo">Скрыть задачи</label>
        </div>
        `);
    }, 2000);

})

var TIMEOUT_DELAY = 500;

var addOof = function () {
    setTimeout(function () {
        var users = AJS.$('.user-hover:not([data-oof])').map(function (i, el) {
            return AJS.$(el).attr('rel');
        }).toArray().filter(function (itm, i, a) {
            return i == a.indexOf(itm);
        });
        if (loading() === 0 || (loading() === 2 && users.length > 0)) {
            // loading(1);
            AJS.$.ajax({
                type: "POST",
                url: "/rest/misc/1.0/userInfo/status",
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                data: JSON.stringify(users),
                success: function (data) {
                    if (data && data.length > 0) {
                        for (var i = 0; i < data.length; i++) {
                            // Banner
                            if (i == 0) {
                                // Out of Office banner
                                if (data[i]['oof'] && AJS.$('#announcement-banner-oof').length === 0) {
                                    AJS.$(`<div id='announcement-banner-oof' class='alertHeader'>
                                                                        <span class="out-of-office-banner">
                                                                                <span class="turned-on">Out of Office is turned on.</span>
                                                                        Manage settings <a href="/secure/ExchangeIntegration.jspa">here</a>.</span>
                                                                     </div>`)
                                        .insertBefore("#content");
                                }

                                // News dialog
                                if (data[i]['news'] && AJS.$('#announcement-banner-news').length === 0) {
                                    var news = data[i]['news'];
                                    AJS.$(`<div id='announcement-banner-news' class='alertHeader'>
                                                                            <div class="aui-message closeable aui-message-warning">
                                                                                ${news}
                                                                                <button type="button" class="aui-close-button" aria-label="Close" onclick="closeAnnouncementBannerNews()"></button>
                                                                            </div>
                                                                     </div>`)
                                        .insertBefore("#content");
                                }

                                // FIX scroll JIRA-2919
                                window.scrollTo(window.scrollX, window.scrollY + 1);
                                window.scrollTo(window.scrollX, window.scrollY - 1);
                            }

                            // OOF marker
                            if (data[i]['oof']) {
                                var username = data[i]['username'];
                                var message = data[i]['oofMessage'];
                                AJS.$('.user-hover[rel="' + username + '"]:not([data-oof])').each(function (i, u) {
                                    var userEl = AJS.$(u);
                                    userEl.attr('data-oof', '1');
                                    var oofEl = userEl.after(`
                        <span class="out-of-office-user"  title="${message}">[Out of Office]</span>
                        `);
                                });
                            }
                        }
                    }

                    // Mark other
                    AJS.$('.user-hover:not([data-oof])').each(function (i, u) {
                        var userEl = AJS.$(u);
                        userEl.attr('data-oof', '0');
                    });
                },

                complete: function () {
                    loading(2);
                }
            });
        }
    }, TIMEOUT_DELAY);
};

function copyEpicNameSummary() {
    AJS.$('#customfield_11005').focusout(function () {
        var epicNameVal = AJS.$(this).val();
        var summaryEl = $('#summary');
        if (epicNameVal && summaryEl && !summaryEl.val()) {
            summaryEl.val(epicNameVal);
        }
    });

    AJS.$('#summary').focusout(function () {
        var summaryVal = AJS.$(this).val();
        var epicNameEl = $('#customfield_11005');
        if (summaryVal && epicNameEl && !epicNameEl.val()) {
            epicNameEl.val(summaryVal);
        }
    });
}

function closeAnnouncementBannerNews() {
    AJS.$("#announcement-banner-news").addClass('hidden');
    AJS.$.get("/rest/misc/1.0/userInfo/hideNews").complete(function () {
        console.log("Last news has been hidden")
    });
}

function loading(status) {
    // 0 - init, 1 - loading, 2 - loaded
    if (status) {
        AJS.$('#jira').data('rb-misc', status);
        return status;
    }
    return AJS.$('#jira').data('rb-misc') || 0;
}

function loadWorklog() {
    loadingWorklogDialog(true);
    AJS.$.get("/rest/misc/1.0/calendar/worklog/load")
        .success(function (msg) {
            loadingWorklogDialog(false);
            setTimeout(function () {
                window.alert(msg.message);
                if (window.location.href.indexOf("Tempo.jspa") > -1) {
                    window.location.reload();
                }
            }, TIMEOUT_DELAY);
        })
        .error(function () {
            loadingWorklogDialog(false, 'Во время перевода плана в факт произошла ошибка. Обратитесь к администратору.');
        });
}

function loadingWorklogDialog(show) {
    var dialog = AJS.$('#loadingWorklogDialog');
    if (dialog.length == 0) {
        AJS.$('#page').after(
            `
            <section id="loadingWorklogDialog" class="aui-dialog2 aui-dialog2-small aui-layer" role="dialog" tabindex="-1" aria-labelledby="dialog-show-button--heading"
             data-aui-focus="false" data-aui-blanketed="true" style="z-index: 3000;" open="">
                <header class="aui-dialog2-header">
                    <h1 class="aui-dialog2-header-main" id="dialog-show-button--heading">Loading data ...</h1>
                    <button class="aui-close-button" type="button" aria-label="close" tabindex="0" onclick="loadingWorklogDialog(false)"></button>
                </header>
                <div class="aui-dialog2-content" style="margin: 0 auto; padding: 10px;">
                    <aui-spinner size="large" resolved="">
                        <div class="aui-spinner spinner">
                            <svg focusable="false" size="50" height="50" width="50" viewBox="0 0 50 50">
                                <circle cx="25" cy="25" r="22.5"></circle>
                             </svg>
                         </div>
                    </aui-spinner>
                </div>                
            </section>
            `
        );
        dialog = AJS.$('#loadingWorklogDialog');
    }

    if (show) {
        dialog.show();
    } else {
        dialog.hide();
    }
    return dialog;
}

// Красим кнопку Support
var printHelpButton = function () {
    let $supportButton = AJS.$("#rb-jira-help-links-link");
    $supportButton.css("background", "#0065ff");
}

//JIRA-5350 Адаптация вывода на экран панели Issues In Epic в эпике
var issuesInEpicRenderer = function () {
    var container = document.getElementsByClassName("mod-content");
    if (container !== null ) {
        for (var i = 0; i < container.length; i++) {
            container.item(i).classList.add("issues-in-epic-div");
        }
    }

    var issuesInEpicTable = document.getElementById("ghx-issues-in-epic-table");
    if (issuesInEpicTable !== null) {
        issuesInEpicTable.classList.add("issues-in-epic-table-new");
    }

    var issueKeyColumn = document.getElementsByClassName("nav ghx-minimal");
    if (issueKeyColumn !== null) {
        for (var k = 0; k < issueKeyColumn.length; k++) {
            issueKeyColumn.item(k).classList.add("issue-key-column-in-epic-table");
        }
    }

    var summaryColumn = document.getElementsByClassName("nav ghx-summary");
    if (summaryColumn !== null) {
        for (var j = 0; j < summaryColumn.length; j++) {
            summaryColumn.item(j).classList.add("issue-summary-column-in-epic-table");
        }
    }

    var issueTypeColumn = document.getElementsByClassName("nav status");
    if (issueTypeColumn !== null) {
        for (var m = 0; m < issueTypeColumn.length; m++) {
            issueTypeColumn.item(m).classList.add("issue-status-column-in-epic-table");
        }
    }
}



