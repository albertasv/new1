// JIRA-5620 Добавить логирование по клику кнопки "Rosbank Help"
AJS.$(document).on("click","#rb-jira-help-links-link",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/rb_jira_help_links_link");
});

AJS.$(document).on("click","#news-bell",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/news_bell");
});

// AJS.$(document).on("click","#help-link",function() {
//     AJS.$.get("/rest/misc/1.0/menu/click/support/help_link");
// });
AJS.$(document).on("click","#help-link0",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link0");
});
AJS.$(document).on("click","#help-link1",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link1");
});
AJS.$(document).on("click","#help-link2",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link2");
});
AJS.$(document).on("click","#help-link3",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link3");
});
AJS.$(document).on("click","#help-link4",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link4");
});
AJS.$(document).on("click","#help-link5",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link5");
});
AJS.$(document).on("click","#help-link6",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link6");
});
AJS.$(document).on("click","#help-link7",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link7");
});
AJS.$(document).on("click","#help-link8",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link8");
});
AJS.$(document).on("click","#help-link9",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link9");
});
AJS.$(document).on("click","#help-link10",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/help_link10");
});

AJS.$(document).on("click","#rb-jira-help-new-archived-issues-link_lnk",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/archived_issues_link");
});

AJS.$(document).on("auxclick","#rb-jira-help-new-archived-issues-link_lnk",function() {
    AJS.$.get("/rest/misc/1.0/menu/click/support/archived_issues_link");
});


// JIRA-5784 Выставить мониторинг выбора View в Structure "QBR Q2-Q3`23 Public view"
AJS.$(document).on("click", ".aui-button.aui-button-compact.aui-button-subtle.aui-dropdown2-trigger.s-ph-view-selector.s-ph-labeled.no-track-focus",
    function () {
        setTimeout(function () {
            let elements = document.getElementsByClassName("aui-dropdown2-radio");
            if (elements !== null) {
                for (let i = 0; i < elements.length; i++ ) {
                    AJS.$(elements[i]).off("click").on("click", function () {
                        if (elements[i].children.item(0).textContent === "QBR Q2-Q3`23 Public view") {
                            AJS.$.get("/rest/misc/1.0/menu/click/support/qbr");
                        }
                    });
                }
            }
        }, 1000);
    }
);