AJS.$(document).ready(function () {
    AJS.$("title").text("PPM Team News");
});


