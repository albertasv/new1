AJS.$(document).ready(function () {
    AJS.$("title").text("Jira Exchange Integration");

    AJS.$(document).on('click', '#tempo-load', function () {
        var planningIssue = AJS.$('#planning-issue').val();
        if (planningIssue) {
            var that = this;
            if (!that.isBusy()) {
                that.busy();
                var user = getUserFormData();
                AJS.$.ajax({
                    type: "POST",
                    url: "/rest/misc/1.0/userInfo/status/update",
                    contentType: "application/json; charset=utf-8",
                    dataType: 'json',
                    data: JSON.stringify(user),
                    success: function () {
                        AJS.$.get("/rest/misc/1.0/calendar/plan/load")
                            .success(function () {
                                window.alert('Данные календаря успешно загружены.');
                                that.idle();
                            })
                            .error(function () {
                                window.alert('Во время загрузки календаря произошла ошибка. Обратитесь к администратору.');
                                that.idle();
                            });
                    }
                });
            }
        } else {
            alert("Default issue is required");
        }
    });

    AJS.$(document).on('click', '#tempo-load-worklog', function (e) {
        e.preventDefault();
        AJS.$("#tempo-bar-load-worklog").click()
    });

    AJS.$('#oof-exchange').on('click', function (e) {
        var isExchange = AJS.$('#oof-exchange').is(":checked");
        AJS.$('#oof-enabled').attr('disabled', isExchange);
        AJS.$('#oof-message').attr('disabled', isExchange);
    });

    AJS.$('#oof-save1').on('click', saveSettings);
    AJS.$('#oof-save2').on('click', saveSettings);
});


var saveSettings = function (e) {
    var that = this;
    if (!that.isBusy()) {
        that.busy();
        var user = getUserFormData();
        AJS.$.ajax({
            type: "POST",
            url: "/rest/misc/1.0/userInfo/status/update",
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            data: JSON.stringify(user),
            success: function (data) {
                that.idle();
                window.alert("Настройки сохранены");
            }
        });
    }
    e.preventDefault();
};

var getUserFormData = function () {
    return {
        exchangeIntegration: AJS.$('#oof-exchange').is(":checked"),
        oof: AJS.$('#oof-enabled').is(":checked"),
        oofMessage: AJS.$('#oof-message').val(),
        calendarSync: AJS.$('#calendar-sync').is(":checked"),
        planningIssue: AJS.$('#planning-issue').val(),
        priorityPlanningIssue: AJS.$('#priority-issue').val(),
        excludedCategory: AJS.$('#excluded-category').val()
    };
};