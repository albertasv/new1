// Предзаполняет значения полей при создании задачи
JIRA.bind(JIRA.Events.NEW_CONTENT_ADDED, function () {

    const projectInput = getActualInputFieldSelector("#project");
    const typeInput = getActualInputFieldSelector("#issuetype");
    if (projectInput && typeInput) {
        appendInfo(projectInput, typeInput);
    }

    function appendInfo(projectInput, typeInput) {

        const projectId = getActualProjectId(projectInput);
        const typeId = getActualIssueTypeId(typeInput);

        if (projectId && typeId) {
            $.getJSON("/rest/misc/1.0/properties/" + projectId + '/issueType/' + typeId, function (projectProperties) {
                if (projectProperties) {
                    setIssueTypeInfo(projectProperties);

                    const fields = projectProperties['fields'];
                    if (fields) {
                        fillFieldValuesFromTemplate(fields);
                    }
                }
            });
        }
    }
})

// Возвращает идентификатор выбранного проекта для создания задачи
// В случае открытия страницы по прямому URL-у с предустановлленым идентификатором проекта
// определяет id проекта по значению параметра pid (регистрозависимая операция).
function getActualProjectId(projectInput) {
    const urlQueryParams = new URLSearchParams(window.location.search);
    return projectInput.val() || urlQueryParams.get('pid');
}

// Возвращает идентификатор выбранного типа (issue type) для создания задачи
// В случае открытия страницы по прямому URL-у с предустановлленым идентификатором типа
// определяет его id по значению параметра issuetype (регистрозависимая операция).
function getActualIssueTypeId(issueTypeInput) {
    const urlQueryParams = new URLSearchParams(window.location.search);
    return issueTypeInput.val() || urlQueryParams.get('issuetype');
}

function setIssueTypeInfo(projectProperties) {
    JIRA.Screen.IssueTypeInfoPanel.updateIssueTypeInfo(projectProperties['issueTypeInfo']);
}

function fillFieldValuesFromTemplate(templatedFieldValues) {
    fillSummaryFromTemplate(templatedFieldValues);
    fillDescriptionFromTemplate(templatedFieldValues);
    fillItSystemFromTemplate(templatedFieldValues);
    fillTempoAccountFromTemplate(templatedFieldValues);
    fillInformationForDutyServiceFromTemplate(templatedFieldValues);
}

function fillSummaryFromTemplate(templatedFieldValues) {
    const summary = templatedFieldValues['summary'] || '';
    const $summary = getActualInputFieldSelector("#summary");

    $summary.val(summary);
}

function fillDescriptionFromTemplate(templatedFieldValues) {
    const description = templatedFieldValues['description'] || '';
    const $description = getActualInputFieldSelector("#description");
    if ($description.exists()) {
        // таймаут нужен для того, чтобы успел загрузится и отрендерится RichEditor. Иначе установленное значение
        // будет отображаться только в режиме редактора "Text"
        setTimeout(function() {
            $description.val(description)
        }, TIMEOUT_DELAY);
    }
}

function fillItSystemFromTemplate(templatedFieldValues) {
    const itSystem = templatedFieldValues['itSystem'];
    if (itSystem) {
        $.getJSON('/rest/sm/1.0/ci/search/system.json?all=true&q=' + itSystem, function (itSystemItems) {
            if (itSystemItems && itSystemItems['items'] && itSystemItems['items'].length > 0) {
                const itSystemItem = itSystemItems['items'][0];
                const $itSystemField = getActualInputFieldSelector("#s2id_customfield_16904");

                $itSystemField.select2('data', {
                    id: itSystemItem.code,
                    name: itSystemItem.name
                });
            }
        });
    }
}

function fillTempoAccountFromTemplate(templatedFieldValues) {
    const account = templatedFieldValues['account'];
    if (account) {
        $.getJSON('/rest/tempo-accounts/1/account/search?tqlQuery=key%3D' + account, function (accountItems) {
            if (accountItems && accountItems['accounts'] && accountItems['accounts'].length > 0) {
                const accountItem = accountItems['accounts'][0];
                const $accountField = getActualInputFieldSelector("#s2id_customfield_13701");
                setTimeout(function () {
                    $accountField.select2('data', {
                        id: accountItem.id,
                        text: accountItem.name + " ( " + accountItem.key + ")"
                    });
                }, TIMEOUT_DELAY);
            }
        });
    }
}

function fillInformationForDutyServiceFromTemplate(templatedFieldValues) {
    const informationForDutyService = templatedFieldValues['customfield_18801'] || '';
    const $informationForDutyService = getActualInputFieldSelector("#customfield_18801");

    $informationForDutyService.val(informationForDutyService);
}

// Возвращает селектор поля ввода, расположенного на актуальном экране - если пользователь открыл модальное окно,
// то вернет селектор для поля ввода, расположенного в модальном окне, а не на основной странице.
function getActualInputFieldSelector(inputFieldSelector) {
    const modalInputSelector = $("#dialog-form " + inputFieldSelector);
    if (modalInputSelector.length > 0) {
        return modalInputSelector;
    } else {
        return $(inputFieldSelector)
    }
}
