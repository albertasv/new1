/**
 * Предоставляет возможность отображения описания типа задачи на экранах создания.
 *
 * Пример использования:
 * JIRA.Screen.IssueTypeInfoPanel.updateIssueTypeInfo("Задачи этого типа выполняются роботами.")
 */
class IssueTypeInfoPanel {

    static #mainInfoPanelId = "rb-issue-type-info";
    static #modalInfoPanelId = "rb-issue-type-info-modal";

    #mainInfoPanelController;
    #modalInfoPanelController;

    constructor() {
        this.#initInfoPanelControllers();
    }

    #initInfoPanelControllers() {
        this.#mainInfoPanelController = new ElementInfoPanel({
            forElement: '[id="issue-create-issue-type"]',
            panelElementId: IssueTypeInfoPanel.#mainInfoPanelId
        });
        this.#modalInfoPanelController = new ElementInfoPanel({
            forElement: '[data-field-id="issuetype"]',
            panelElementId: IssueTypeInfoPanel.#modalInfoPanelId
        });
    }

    updateIssueTypeInfo(newIssueTypeInfoText) {
        if (this.#isModalWindowOpened()) {
            this.#modalInfoPanelController.updatePanelText(newIssueTypeInfoText);
        } else {
            this.#mainInfoPanelController.updatePanelText(newIssueTypeInfoText);
        }
    }

    #isModalWindowOpened() {
        return document.querySelector('[data-field-id="issuetype"]') != null;
    }

}

// TODO: вероятно стоит вынести этот класс в отдельный ресурс - чтобы можно было использовать его по мере необходимости
class ElementInfoPanel {

    #forElementSelector;
    #rootElementId;
    #infoElementId;

    /**
     * @param forElement     Селектор, по которому выбирется элемент, к которому прикрепляется информация.
     *                       Панель с информацией будет помещена в parentElement указанного элемента.
     *                       Формат селектора - для функции document.querySelector()
     * @param panelElementId Префикс для идентификаторов частей создаваемой панели. Должен быть уникальным на старнице
     *                       (включая возможный динамический контент).
     */
    constructor({forElement, panelElementId}) {
        this.#forElementSelector = forElement;
        this.#rootElementId = panelElementId + "-root";
        this.#infoElementId = panelElementId + "-text";
    }

    /**
     * @param newPanelText Текст, который будет отображен в панеле под элементов, для которого она создавалась. Если
     *                     передана пустая строка (или строка, содержащая только пробельные символы), то панель информации
     *                     отображена не будет.
     */
    updatePanelText(newPanelText) {
        if (!this.#parentElementExists()) {
            return;
        }

        const rootElement = this.#rootElement();
        const infoElement = this.#infoElement();
        if (infoElement) {
            const actualIssueTypeInfo = (newPanelText || '').trim();
            infoElement.innerHTML = actualIssueTypeInfo;
            rootElement.style.display = (actualIssueTypeInfo)
                ? 'block'
                : 'none';
        }
    }

    #parentElement() {
        const issueTypeField = document.querySelector(this.#forElementSelector);
        return (issueTypeField)
            ? issueTypeField.parentElement
            : null;
    }

    #parentElementExists() {
        return this.#parentElement() != null;
    }

    #rootElement() {
        return document.getElementById(this.#rootElementId) || (() => {
            this.#createPanelElements();
            return document.getElementById(this.#rootElementId);
        })();
    }

    #infoElement() {
        return document.getElementById(this.#infoElementId) || (() => {
            this.#createPanelElements();
            return document.getElementById(this.#infoElementId);
        });
    }

    #createPanelElements() {

        const panelParentElement = this.#parentElement();

        if (!panelParentElement) {
            return;
        }

        const rootElement = document.getElementById(this.#rootElementId) || (() => {
            const createdPanelRootElement = this.#createRootElement();
            panelParentElement.append(createdPanelRootElement);
            return createdPanelRootElement;
        })();

        if (!document.getElementById(this.#infoElementId)) {
            const textElement = this.#createTextElement();
            rootElement.append(textElement);
        }

    }

    #createRootElement() {
        const issueTypeInfoRootElement = document.createElement('div');
        issueTypeInfoRootElement.id = this.#rootElementId;
        issueTypeInfoRootElement.style.display = 'none';
        issueTypeInfoRootElement.classList.add("rb-info-container");

        return issueTypeInfoRootElement;
    }

    #createTextElement() {
        const issueTypeInfoTextElement = document.createElement("div");
        issueTypeInfoTextElement.id = this.#infoElementId;
        issueTypeInfoTextElement.classList.add("aui-message");
        issueTypeInfoTextElement.classList.add("aui-message-info");

        return issueTypeInfoTextElement;
    }

}

JIRA = JIRA || {};
JIRA.Screen = JIRA.Screen || {};
JIRA.Screen.IssueTypeInfoPanel = JIRA.Screen.IssueTypeInfoPanel || new IssueTypeInfoPanel();