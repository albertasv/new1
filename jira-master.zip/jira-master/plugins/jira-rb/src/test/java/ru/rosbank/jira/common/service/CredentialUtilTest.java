package ru.rosbank.jira.common.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;

import static org.junit.Assert.*;

public class CredentialUtilTest {

    @Test
    public void testEncrypt() {
        String text = RandomStringUtils.random(10, true, true);
        String key = RandomStringUtils.random(16, true, true);
        String encryptedText = CredentialUtil.encrypt(text, key);
        String decryptedText = CredentialUtil.decrypt(encryptedText, key);
        assertEquals(text, decryptedText);
    }
}
