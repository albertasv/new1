CREATE OR REPLACE VIEW rb_worklog_v AS
WITH linked_portfolio_issue AS (
    SELECT i.id, cfv.stringvalue::numeric portfolio_issue_id
    FROM jiraissue i
             JOIN project p ON i.project = p.id
             -- Portfolio Issue field
             JOIN customfieldvalue cfv ON cfv.issue = i.id AND cfv.customfield = 16905
)
SELECT portfolio_issue_id                                                       id,
       rbp.issue,
       SUM(CASE
               WHEN EXTRACT(YEAR FROM startdate) < EXTRACT(YEAR FROM now())
                   THEN timeworked END)                                         timeworked_prev_year,
       SUM(CASE
               WHEN EXTRACT(YEAR FROM startdate) = EXTRACT(YEAR FROM now())
                   AND EXTRACT(QUARTER FROM startdate) = 1 THEN timeworked END) timeworked_q1,
       SUM(CASE
               WHEN EXTRACT(YEAR FROM startdate) = EXTRACT(YEAR FROM now())
                   AND EXTRACT(QUARTER FROM startdate) = 2 THEN timeworked END) timeworked_q2,
       SUM(CASE
               WHEN EXTRACT(YEAR FROM startdate) = EXTRACT(YEAR FROM now())
                   AND EXTRACT(QUARTER FROM startdate) = 3 THEN timeworked END) timeworked_q3,
       SUM(CASE
               WHEN EXTRACT(YEAR FROM startdate) = EXTRACT(YEAR FROM now())
                   AND EXTRACT(QUARTER FROM startdate) = 4 THEN timeworked END) timeworked_q4,
       SUM(timeworked)                                                          timeworked
FROM worklog w
         JOIN (
               -- Issues under Epic
               SELECT id worklog_issue_id, portfolio_issue_id
               FROM linked_portfolio_issue
               UNION
               -- Issues under Epic
               SELECT il.destination worklog_issue_id, lpi.portfolio_issue_id
               FROM issuelink il
                JOIN linked_portfolio_issue lpi ON lpi.id = il.source
               WHERE il.linktype = 10400) worklog_issue
              ON w.issueid = worklog_issue.worklog_issue_id
         JOIN (
         SELECT i.id,
           p.pkey || '-' || i.issuenum issue
    FROM jiraissue i
             JOIN project p ON i.project = p.id
    WHERE p.pkey IN ('CRS', 'PRJ')
         ) rbp ON rbp.id = worklog_issue.portfolio_issue_id
GROUP BY portfolio_issue_id, rbp.issue;