import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import java.sql.Timestamp

def issueManager = ComponentAccessor.issueManager
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchQuery = jqlQueryParser.parseQuery("project = CRS AND type = CR AND 'CR / Project ID' is not EMPTY")
// def searchQuery = jqlQueryParser.parseQuery("project = CRS AND type = CR AND 'Registration Date' is not EMPTY")

def currentUser = ComponentAccessor.jiraAuthenticationContext.loggedInUser
def searchService = ComponentAccessor.getComponent(SearchService)
def resultIssues = searchService.search(currentUser, searchQuery, PagerFilter.getUnlimitedFilter())

def sb = new StringBuilder("OLD_NUM;NEW_NUM;\n<br/>")
def crIdField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14000")
def regDateField = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_17203")
if (resultIssues.total > 0) {
    resultIssues.results.each() {
        documentIssue ->
            def issue = issueManager.getIssueObject(documentIssue.id)
            def oldNum = issue.getNumber()
            try {
                def newNum = Integer.parseInt(issue.getCustomFieldValue(crIdField))
                if (oldNum != newNum) {
                    // Set issue number
                    issue.setNumber(newNum)
                    // Set reg date -> created
                    def regDate = issue.getCustomFieldValue(regDateField)
                    if (regDate) {
                        issue.setCreated(regDate)
                    } else {
                        // ???
                        // issue.setCreated(new Timestamp(System.currentTimeMillis()))
                    }
                    issue.store()
                    sb.append("$oldNum;$newNum;\n<br/>")
                }
            } catch (Exception ex) {
                sb.append("$oldNum;!!ERROR!!;\n<br/>")
            }
    }
}
return sb.toString()