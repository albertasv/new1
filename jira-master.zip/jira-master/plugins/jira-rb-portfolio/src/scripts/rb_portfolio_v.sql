CREATE OR REPLACE VIEW rb_portfolio_v AS
SELECT i.id,
       p.pkey || '-' || i.issuenum issue,
       ist.pname                   status,
       i.summary                   summary,
       cc_f.stringvalue            cost_center,
       cc."DOMAIN"                 cost_center_domain_1,
       cc."CUSTOMER_DOMAIN"        cost_center_domain_2,
       manager_cu.user_name        manager,
       manager_cu.display_name     manager_name,
       team.teams_name             execution_team
FROM jiraissue i
         JOIN project p ON i.project = p.id
         JOIN issuestatus ist ON ist.id = i.issuestatus
         LEFT JOIN customfieldvalue cc_f ON cc_f.issue = i.id AND cc_f.customfield = 17212
         LEFT JOIN "AO_2E196D_COST_CENTER" cc ON cc."CODE" = cc_f.stringvalue
         LEFT JOIN customfieldvalue manager_f ON manager_f.issue = i.id AND manager_f.customfield = 17001
         LEFT JOIN app_user manager_au ON manager_au.user_key = manager_f.stringvalue
         LEFT JOIN cwd_user manager_cu ON manager_cu.lower_user_name = manager_au.lower_user_name
         LEFT JOIN (SELECT i.id issue_id, string_agg(et."NAME", ';') teams_name
                    FROM jiraissue i
                             LEFT JOIN label team_l ON team_l.issue = i.id AND team_l.fieldid = 17302
                             LEFT JOIN "AO_2E196D_EXECUTION_TEAM" et on et."CODE" = team_l.label
                    GROUP BY i.id) team ON team.issue_id = i.id
WHERE p.pkey IN ('CRS', 'PRJ');