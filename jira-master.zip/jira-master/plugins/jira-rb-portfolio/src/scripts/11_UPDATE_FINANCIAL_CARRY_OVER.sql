UPDATE "AO_2E196D_FINANCIAL"
SET "FINANCIAL_TYPE" = (CASE
                            WHEN ("SBU_PROJECT_CODE" LIKE ''С%'' OR "SBU_PROJECT_CODE" LIKE ''Р%'' OR
                                  "SBU_PROJECT_CODE" LIKE ''РРЗРАГ'')
                                THEN ''CARRY_OVER_CONTRACTED''
                            ELSE ''CARRY_OVER_NOT_CONTRACTED'' END)
WHERE "FINANCIAL_TYPE" = ''CARRY_OVER'';