-- Show info
SELECT p.id, p.pkey, p.pcounter, MAX(i.issuenum)
FROM jiraissue i
         INNER JOIN project p ON p.id = i.project
WHERE p.pkey IN ('CRS')
GROUP BY p.id, p.pkey, p.pcounter;

-- Update Issue Num counter
UPDATE project
SET pcounter = 32000
WHERE pkey IN ('CRS');

-- Financial

UPDATE "AO_2E196D_FINANCIAL"
SET "ISSUE" = issues.ikey
FROM (
         SELECT p.pkey || '-' || i.issuenum ikey, cv.stringvalue, c.cfname
         FROM jiraissue i
            INNER JOIN project p ON p.id = i.project AND p.pkey IN ('CRS', 'PRJ')
            INNER JOIN customfieldvalue cv ON cv.issue = i.id AND cv.stringvalue IS NOT NULL
            INNER JOIN customfield c ON c.id = cv.customfield AND c.cfname = 'CR / Project ID'
     ) issues
WHERE "PPM_PROJECT_CODE" = issues.stringvalue;


