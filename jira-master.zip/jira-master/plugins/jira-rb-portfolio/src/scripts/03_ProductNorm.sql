-- Replace name
UPDATE "AO_2E196D_PRODUCT"
SET "NAME" = prod.name1
FROM (
         SELECT "ID" id1, replace("NAME", "CODE" || ' ', '') name1
         FROM "AO_2E196D_PRODUCT"
     ) prod
WHERE "ID" = prod.id1;

alter table "AO_2E196D_PRODUCT" add "BUDGET_PRODUCT" boolean;

UPDATE "AO_2E196D_PRODUCT"
SET "BUDGET_PRODUCT" = false;

UPDATE "AO_2E196D_PRODUCT"
SET "BUDGET_PRODUCT" = true
-- SELECT * FROM "AO_2E196D_PRODUCT"
WHERE "CODE" in
      (
       '150180',
       '176710',
       '011000',
       '990000',
       '033000',
       '010501',
       '011702',
       '060501',
       '084000',
       '012141',
       '010543',
       '012142',
       '032142',
       '177770',
       '062144',
       '076700',
       '012101',
       '032101',
       '062108'
);