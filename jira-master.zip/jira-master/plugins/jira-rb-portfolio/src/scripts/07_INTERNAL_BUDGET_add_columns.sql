alter table "AO_2E196D_INTERNAL_BUDGET"
	add "COST_CENTER" varchar(255);

alter table "AO_2E196D_INTERNAL_BUDGET"
	add "MD_BUDGET_VALUE" double precision default 0.0;