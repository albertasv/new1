-- PPM DB External Budget export
SELECT 'CRS' || '-' || PPM_CODE                                                    ISSUE,
       CASE
           WHEN te.PARAMETER7 = '000000' AND te.PARAMETER9 = 'CapEx' THEN '076700'
           WHEN te.PARAMETER7 = '000000' AND te.PARAMETER9 = 'OpEx' THEN '990000'
           ELSE cat.LOOKUP_CODE END                                                PRODUCT,
--        te.PARAMETER9                                                              EXP_TYPE,
       period.START_DATE                                                           BUDGET_DATE,
       TO_NUMBER(te.PARAMETER1, REPLACE(TRANSLATE(te.PARAMETER1, '.012345678,-+', 'D999999999'), ',', '.'),
                 'NLS_NUMERIC_CHARACTERS=.,')                                      BUDGET_VALUE,
       te.PARAMETER2                                                               "COMMENT",
       (SELECT USERNAME FROM KNTA_USERS WHERE USER_ID = NVL(te.PARAMETER4, 1))     LAST_UPDATED_BY,
       NVL(te.PARAMETER5, TO_CHAR(period.START_DATE, 'YYYY-MM-DD') || ' 00:00:00') LAST_UPDATE_DATE,
       ROW_NUMBER() OVER (ORDER BY 1, 2, 3)                                        ID
FROM KCRT_TABLE_ENTRIES te
         INNER JOIN KNTA_PARAMETER_SET_FIELDS f
                    ON f.PARAMETER_SET_FIELD_ID = te.PARAMETER_SET_FIELD_ID AND f.PROMPT = 'External Budget (rub)'
         LEFT JOIN KNTA_LOOKUPS_NLS cat
                   ON cat.LOOKUP_TYPE = 'BUDGET_NON_LABOR_CATEGORY' AND cat.LOOKUP_CODE = te.PARAMETER7
         LEFT JOIN PPM_FISCAL_PERIODS period
                   on TO_CHAR(period.FISCAL_PERIOD_ID) = te.PARAMETER3 AND te.PARAMETER3 IS NOT NULL
         LEFT JOIN RB_PORTFOLIOS_VIEW pp ON pp.REQUEST_ID = te.REQUEST_ID AND
                                            ((pp.REQUEST_STATUS not like 'CLOSED_%' AND
                                              pp.REQUEST_STATUS <> 'CANCELLED') AND pp.TYPE = 'CR')
WHERE ((pp.REQUEST_STATUS not like 'CLOSED_%' AND
        pp.REQUEST_STATUS <> 'CANCELLED') AND pp.TYPE = 'CR')
ORDER BY 1, 2, 3;

-- Jira DB External Budget export sample
DELETE FROM "AO_2E196D_EXTERNAL_BUDGET";
INSERT INTO "AO_2E196D_EXTERNAL_BUDGET" ("ISSUE", "PRODUCT", "BUDGET_DATE", "BUDGET_VALUE", "COMMENT", "LAST_UPDATED_BY", "LAST_UPDATE_DATE", "ID") VALUES ('CRS-20925', '012111', TO_DATE('2021-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 2135400, 'в соответствии с дополнительным соглашением', 'admin', '2021-01-01 00:00:00', 1);
SELECT MAX("ID") FROM  "AO_2E196D_EXTERNAL_BUDGET";
ALTER SEQUENCE "AO_2E196D_EXTERNAL_BUDGET_ID_seq" RESTART  WITH 576;