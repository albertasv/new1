import React, {Component} from 'react';
import Select from 'react-select';
import './QBROnePage.css';

const periodOptions = [
    {value: '2022Q1', label: '2022 Q1'},
    {value: '2022Q2', label: '2022 Q2'},
    {value: '2022Q3', label: '2022 Q3'},
    {value: '2022Q4', label: '2022 Q4'},
];


const teamOptions = [
    {value: 'A000001', label: 'PPM Team'},
    {value: 'A000002', label: 'Team 2'},
];

export default class QBROnePage extends Component {

    state = {
        periodSelected: null,
        teamSelected: null
    };

    changePeriod = (periodSelected) => {
        this.setState({periodSelected}, () =>
            console.log(`Period selected:`, this.state.periodSelected)
        );
    };

    changeTeam = (teamSelected) => {
        this.setState({teamSelected}, () =>
            console.log(`Team selected:`, this.state.teamSelected)
        );
    };

    render() {
        const {periodSelected, teamSelected} = this.state;

        return (<div>
            <h1>
                QBR Information
            </h1>
            <Select
                value={periodSelected}
                onChange={this.changePeriod}
                options={periodOptions}
            />
            <Select
                value={teamSelected}
                onChange={this.changeTeam}
                options={teamOptions}
            />
            <div>
                Success Score Overall: 70% | Success Score Output: 90% | Success Score Outcome: 60% | Spent: 2 000 000
                RUB | Cap: 1 000 000 RUB
            </div>
            <table id="qbrTable" className="table100">
                <tbody>
                <tr>
                    <td colSpan="7">Expand and improve Pension solutions</td>
                </tr>
                <tr>
                    <td>Last Q</td>
                    <td>Next Q</td>
                    <td>Key Results</td>
                    <td>Success Score</td>
                    <td>Today / Long Goal</td>
                    <td>Last Q / Last Q Promised</td>
                    <td>Next Q</td>
                </tr>
                </tbody>
            </table>
        </div>);
    }
};