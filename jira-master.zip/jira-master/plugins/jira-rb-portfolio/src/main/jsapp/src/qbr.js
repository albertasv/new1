import React from 'react';
import ReactDOM from "react-dom";
import QBROnePage from "./components/QBROnePage";

AJS.$(document).ready(function () {
    AJS.$("title").text("QBR Dashboard");
    ReactDOM.render(
        <QBROnePage/>,
        document.getElementById("qbr-root")
    )
});
