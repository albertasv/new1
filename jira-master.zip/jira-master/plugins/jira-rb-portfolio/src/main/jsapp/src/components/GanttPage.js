import React, {Component} from 'react';
import ReactDOM from "react-dom";
import { Gantt, Task, EventOption, StylingOption, ViewMode, DisplayOption } from 'gantt-task-react';
import "gantt-task-react/dist/index.css";

let tasks = [
    {
        start: new Date(2020, 1, 1),
        end: new Date(2020, 1, 2),
        name: 'Idea',
        id: 'Task 0',
        type:'task',
        progress: 45,
        isDisabled: true,
        styles: { progressColor: '#ffbb54', progressSelectedColor: '#ff9e0d' },
    }
];


export default class QBROnePage extends Component {
    render() {
        return (<div>
            <h2>
                <Gantt tasks={this.tasks} />
            </h2>
        </div>);
    }
};