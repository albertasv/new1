import React, {Component} from 'react';
import ReactDOM from "react-dom";
import QBROnePage from "./components/QBROnePage";

ReactDOM.render(
    <QBROnePage/>,
    document.getElementById("root")
);