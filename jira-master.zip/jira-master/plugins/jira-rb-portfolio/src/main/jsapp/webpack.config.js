const WrmPlugin = require('atlassian-webresource-webpack-plugin');
var path = require('path');

module.exports = {
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader"
                }
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },
    watch: false,
    entry: {
        'qbr': './src/qbr.js'
    },
    plugins: [
        new WrmPlugin({
            pluginKey: 'ru.rosbank.jira.portfolio',
            locationPrefix: 'frontend/',
            watch: true,
            xmlDescriptors: path.resolve('../resources', 'META-INF', 'plugin-descriptors', 'wr-defs.xml')
        }),
    ],
    output: {
        filename: 'bundled.[name].js',
        path: path.resolve("../resources/frontend")
    }
};