AJS.$(document).ready(function () {
    AJS.$("title").text("Agile Teams");
});