AJS.$(document).ready(function () {

    var canEdit = AJS.$("#fin-details").data("edit");
    var issueKey = AJS.$("#fin-details").data("issue");

    {
        // Budget tab
        var initExtBudgetTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#external-budget"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/budget/" + issueKey + "/external?initial=false&cy=false",
                    self: "/rest/portfolio/1.0/budget/" + issueKey + "/external/current/false"
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "product",
                        header: "Product Category",
                        createView: productCreateView,
                        readView: productReadView
                    },
                    {
                        id: "quarter",
                        header: "Quarter",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return quarterInput("quarter", 0, 4)
                            }
                        })
                    },
                    {
                        id: "budgetYear",
                        header: "Year",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return yearInput('budgetYear', -2, 5);
                            }
                        })
                    },
                    {
                        id: "budgetValue",
                        header: "Budget (rub)",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='budgetValue' class='text' required type='number' min='1' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var extBudgetTable = initExtBudgetTable();

        var initIntBudgetTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#internal-budget"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/budget/" + issueKey + "/internal?initial=false&cy=false",
                    self: "/rest/portfolio/1.0/budget/" + issueKey + "/internal/current/false"
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "costCenter",
                        header: "Cost Center",
                        createView: costCenterCreateView,
                        readView: costCenterReadView
                    },
                    {
                        id: "quarter",
                        header: "Quarter",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return quarterInput("quarter", 0, 4)
                            }
                        })
                    },
                    {
                        id: "budgetYear",
                        header: "Year",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return yearInput('budgetYear', -2, 5);
                            }
                        })
                    },
                    {
                        id: "mdBudgetValue",
                        header: "M/D",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='mdBudgetValue' class='text' required type='number' min='1' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "budgetValue",
                        header: "Budget (rub)",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='budgetValue' class='text' type='number' min='1' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var intBudgetTable = initIntBudgetTable();

        // Update totals on Budget tab
        updateTotal(false, false);
        var extBudgetCreateRow = extBudgetTable.getCreateRow();
        extBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
            updateTotal(false, false);
        });

        var intBudgetCreateRow = intBudgetTable.getCreateRow();
        intBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
            updateTotal(false, false);
        });
    }


    {
        // CY budget tab
        if (AJS.$("#cy-external-budget").size() > 0) {
            var initExtBudgetTable = function () {
                return new AJS.RestfulTable({
                    el: AJS.$("#cy-external-budget"),
                    autoFocus: true,
                    allowCreate: canEdit,
                    allowEdit: false,
                    allowDelete: canEdit,
                    noEntriesMsg: 'No data',
                    resources: {
                        all: "/rest/portfolio/1.0/budget/" + issueKey + "/external?initial=false&cy=true",
                        self: "/rest/portfolio/1.0/budget/" + issueKey + "/external/current/true"
                    },
                    deleteConfirmationCallback: deleteBudgetCallback,
                    columns: [
                        {
                            id: "product",
                            header: "Product Category",
                            createView: productCreateView,
                            readView: productReadView
                        },
                        {
                            id: "quarter",
                            header: "Quarter",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return quarterInput("quarter", 0, 4)
                                }
                            })
                        },
                        {
                            id: "budgetYear",
                            header: "Year",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return yearInput('budgetYear', -2, 5);
                                }
                            })
                        },
                        {
                            id: "budgetValue",
                            header: "Budget (rub)",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='budgetValue' class='text' required type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "comment",
                            header: "Comment"
                        },
                        {
                            id: "lastUpdatedBy",
                            header: "Last Updated By",
                            createView: dummyCreateView
                        },
                        {
                            id: "lastUpdateDate",
                            header: "Last Updated",
                            readView: dateReadView,
                            createView: dummyCreateView
                        }
                    ]
                });
            }
            var extBudgetTable = initExtBudgetTable();

            var initIntBudgetTable = function () {
                return new AJS.RestfulTable({
                    el: AJS.$("#cy-internal-budget"),
                    autoFocus: true,
                    allowCreate: canEdit,
                    allowEdit: false,
                    allowDelete: canEdit,
                    noEntriesMsg: 'No data',
                    resources: {
                        all: "/rest/portfolio/1.0/budget/" + issueKey + "/internal?initial=false&cy=true",
                        self: "/rest/portfolio/1.0/budget/" + issueKey + "/internal/current/true"
                    },
                    deleteConfirmationCallback: deleteBudgetCallback,
                    columns: [
                        {
                            id: "costCenter",
                            header: "Cost Center",
                            createView: costCenterCreateView,
                            readView: costCenterReadView
                        },
                        {
                            id: "quarter",
                            header: "Quarter",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return quarterInput("quarter", 0, 4)
                                }
                            })
                        },
                        {
                            id: "budgetYear",
                            header: "Year",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return yearInput('budgetYear', -2, 5);
                                }
                            })
                        },
                        {
                            id: "mdBudgetValue",
                            header: "M/D",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='mdBudgetValue' class='text' required type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "budgetValue",
                            header: "Budget (rub)",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='budgetValue' class='text' type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "comment",
                            header: "Comment"
                        },
                        {
                            id: "lastUpdatedBy",
                            header: "Last Updated By",
                            createView: dummyCreateView
                        },
                        {
                            id: "lastUpdateDate",
                            header: "Last Updated",
                            readView: dateReadView,
                            createView: dummyCreateView
                        }
                    ]
                });
            }
            var intBudgetTable = initIntBudgetTable();

            // Update totals on CY Initial Budget tab
            updateTotal(false, true);
            var extBudgetCreateRow = extBudgetTable.getCreateRow();
            extBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
                updateTotal(false, true);
            });

            var intBudgetCreateRow = intBudgetTable.getCreateRow();
            intBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
                updateTotal(false, true);
            });

        }
    }

    {
        // Initial budget tab
        if (AJS.$("#init-external-budget").size() > 0) {
            var initExtBudgetTable = function () {
                return new AJS.RestfulTable({
                    el: AJS.$("#init-external-budget"),
                    autoFocus: true,
                    allowCreate: canEdit,
                    allowEdit: false,
                    allowDelete: canEdit,
                    noEntriesMsg: 'No data',
                    resources: {
                        all: "/rest/portfolio/1.0/budget/" + issueKey + "/external?initial=true&cy=false",
                        self: "/rest/portfolio/1.0/budget/" + issueKey + "/external/initial/false"
                    },
                    deleteConfirmationCallback: deleteBudgetCallback,
                    columns: [
                        {
                            id: "product",
                            header: "Product Category",
                            createView: productCreateView,
                            readView: productReadView
                        },
                        {
                            id: "quarter",
                            header: "Quarter",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return quarterInput("quarter", 0, 4)
                                }
                            })
                        },
                        {
                            id: "budgetYear",
                            header: "Year",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return yearInput('budgetYear', -2, 5);
                                }
                            })
                        },
                        {
                            id: "budgetValue",
                            header: "Budget (rub)",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='budgetValue' class='text' required type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "comment",
                            header: "Comment"
                        },
                        {
                            id: "lastUpdatedBy",
                            header: "Last Updated By",
                            createView: dummyCreateView
                        },
                        {
                            id: "lastUpdateDate",
                            header: "Last Updated",
                            readView: dateReadView,
                            createView: dummyCreateView
                        }
                    ]
                });
            }
            var extBudgetTable = initExtBudgetTable();

            var initIntBudgetTable = function () {
                return new AJS.RestfulTable({
                    el: AJS.$("#init-internal-budget"),
                    autoFocus: true,
                    allowCreate: canEdit,
                    allowEdit: false,
                    allowDelete: canEdit,
                    noEntriesMsg: 'No data',
                    resources: {
                        all: "/rest/portfolio/1.0/budget/" + issueKey + "/internal?initial=true&cy=false",
                        self: "/rest/portfolio/1.0/budget/" + issueKey + "/internal/initial/false"
                    },
                    deleteConfirmationCallback: deleteBudgetCallback,
                    columns: [
                        {
                            id: "costCenter",
                            header: "Cost Center",
                            createView: costCenterCreateView,
                            readView: costCenterReadView
                        },
                        {
                            id: "quarter",
                            header: "Quarter",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return quarterInput("quarter", 0, 4)
                                }
                            })
                        },
                        {
                            id: "budgetYear",
                            header: "Year",
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function (self) {
                                    return yearInput('budgetYear', -2, 5);
                                }
                            })
                        },
                        {
                            id: "mdBudgetValue",
                            header: "M/D",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='mdBudgetValue' class='text' required type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "budgetValue",
                            header: "Budget (rub)",
                            readView: moneyReadView,
                            createView: AJS.RestfulTable.CustomCreateView.extend({
                                render: function () {
                                    return $("<input name='budgetValue' class='text' type='number' min='1' step='any'/>");
                                }
                            })
                        },
                        {
                            id: "comment",
                            header: "Comment"
                        },
                        {
                            id: "lastUpdatedBy",
                            header: "Last Updated By",
                            createView: dummyCreateView
                        },
                        {
                            id: "lastUpdateDate",
                            header: "Last Updated",
                            readView: dateReadView,
                            createView: dummyCreateView
                        }
                    ]
                });
            }
            var intBudgetTable = initIntBudgetTable();

            // Update totals on Initial Budget tab
            updateTotal(true, false);
            var extBudgetCreateRow = extBudgetTable.getCreateRow();
            extBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
                updateTotal(true, false);
            });

            var intBudgetCreateRow = intBudgetTable.getCreateRow();
            intBudgetCreateRow.bind(AJS.RestfulTable.Events.CREATED, function () {
                updateTotal(true, false);
            });
        }
    }



    if (AJS.$("#benefit").size() > 0) {
        // Benefit tab
        var initBenefitTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#benefit"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/benefit/" + issueKey + "?initial=false",
                    self: "/rest/portfolio/1.0/benefit/" + issueKey + "/current"
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "category",
                        header: "Category",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return selectRender('category',
                                    ['NBI New', 'NBI Protection', 'COST Optimization', 'COST Avoidance', 'RISK Reduction', 'ROI'], self);

                            }
                        })
                    },
                    {
                        id: "benefitYear",
                        header: "Year",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return yearInput('benefitYear', -2, 5);
                            }
                        })
                    },
                    {
                        id: "benefitValue",
                        header: "Benefit",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='benefitValue' class='text' required type='number' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var benefitTable = initBenefitTable();
    }

    if (AJS.$("#init-benefit").size() > 0) {
        // Initial benefit tab
        var initBenefitTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#init-benefit"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/benefit/" + issueKey + "?initial=true",
                    self: "/rest/portfolio/1.0/benefit/" + issueKey + "/initial"
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "category",
                        header: "Category",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return selectRender('category',
                                    ['NBI New', 'NBI Protection', 'COST Optimization', 'COST Avoidance', 'RISK Reduction', 'ROI'], self);

                            }
                        })
                    },
                    {
                        id: "benefitYear",
                        header: "Year",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return yearInput('benefitYear', -2, 5);
                            }
                        })
                    },
                    {
                        id: "benefitValue",
                        header: "Benefit",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='benefitValue' class='text' required type='number' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var benefitTable = initBenefitTable();
    }

    if (AJS.$("#allocation").size() > 0) {
        // Allocation tab
        var initAllocationTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#allocation"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/allocation/" + issueKey + "?initial=false",
                    self: "/rest/portfolio/1.0/allocation/" + issueKey + "/current"
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "domainModel",
                        header: "Domain",
                        createView: domainCreateView,
                        readView: domainReadView
                    },
                    {
                        id: "allocationType",
                        header: "Type",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return selectRender('allocationType',
                                    ['EXTERNAL', 'INTERNAL'], self);
                            }
                        })
                    },
                    {
                        id: "allocationValue",
                        header: "Allocation",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='allocationValue' class='text' required type='number' min='1' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var allocationTable = initAllocationTable();
    }

    if (AJS.$("#init-allocation").size() > 0) {
        // Initial allocation tab
        var initAllocationTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#init-allocation"),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/allocation/" + issueKey + '?initial=true',
                    self: "/rest/portfolio/1.0/allocation/" + issueKey + '/initial'
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "domainModel",
                        header: "Domain",
                        createView: domainCreateView,
                        readView: domainReadView
                    },
                    {
                        id: "allocationType",
                        header: "Type",
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function (self) {
                                return selectRender('allocationType',
                                    ['EXTERNAL', 'INTERNAL'], self);
                            }
                        })
                    },
                    {
                        id: "allocationValue",
                        header: "Allocation",
                        readView: moneyReadView,
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return $("<input name='allocationValue' class='text' required type='number' min='1' step='any'/>");
                            }
                        })
                    },
                    {
                        id: "comment",
                        header: "Comment"
                    },
                    {
                        id: "lastUpdatedBy",
                        header: "Last Updated By",
                        createView: dummyCreateView
                    },
                    {
                        id: "lastUpdateDate",
                        header: "Last Updated",
                        readView: dateReadView,
                        createView: dummyCreateView
                    }
                ]
            });
        }
        var allocationTable = initAllocationTable();
    }

    {
        // SBU tab
        var initFinTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#sbu-details"),
                autoFocus: true,
                allowCreate: false,
                allowEdit: false,
                allowDelete: false,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/financial/" + issueKey + "/details",
                    self: "/rest/portfolio/1.0/financial/" + issueKey + "/details"
                },
                columns: [
                    {
                        id: "productCode",
                        header: "Product"
                    },
                    {
                        id: "financialType",
                        header: "Type"
                    },
                    {
                        id: "financialValue",
                        header: "Value",
                        readView: moneyReadView
                    },
                    {
                        id: "financialDate",
                        header: "Date",
                        readView: dateReadView
                    }
                ]
            });
        }
        initFinTable();
    }

    AJS.$("title").text("Financial Details: " + issueKey);

});

var dummyCreateView = AJS.RestfulTable.CustomCreateView.extend({
    render: function (self) {
        return $("<div>");
    }
});

var dateReadView = AJS.RestfulTable.CustomReadView.extend({
    render: function (self) {
        var res = '0'
        try {
            res = new Intl.DateTimeFormat().format(new Date(self.value));
        } catch (e) {
        }
        return $("<div class='budget-date'/>").text(res);
    }
});

var moneyReadView = AJS.RestfulTable.CustomReadView.extend({
    render: function (self) {
        var res = '0'
        try {
            res = new Intl.NumberFormat().format(self.value);
        } catch (e) {
        }
        return $("<div class='budget-number'/>").text(res);
    }
});

var productReadView = AJS.RestfulTable.CustomReadView.extend({
    render: function (self) {
        var catInfo = productCategoryFormat(self.value);
        return `<div class="product-container">
                                <span class="product-category">${catInfo}</span>
                                </div>`;
    }
});

var productCreateView = AJS.RestfulTable.CustomCreateView.extend({
    render: function () {
        var el = AJS.$("<input class='select cf-select-ci' name='productCode' required/>");

        var formatValue = function (val) {
            var catInfo = productCategoryFormat(val);
            return `<div class="dict-container">
                <span class="product-category">${catInfo}</span>
                </div>`;
        }

        el.on('DOMNodeInserted', function () {
            el.select2({
                placeholder: 'Product Category is not specified',
                allowClear: true,
                dropdownAutoWidth: true,
                dropdownCssClass: "dropdown-product",
                ajax: {
                    url: '/rest/portfolio/1.0/dictionary/BUDGET_PRODUCT.json',
                    dataType: 'json',
                    quietMillis: 250,
                    data: function (term, page) {
                        return {
                            q: term,
                            all: true,
                            page: page
                        };
                    },
                    results: function (data, page) {
                        var more = page * 10 < data.total;
                        data = AJS.$.map(data.items, function (val, i) {
                            return {
                                id: val.code,
                                name: val.name,
                                category: val.category || 'Not specified',
                                group: (val.group || 'Not specified'),
                                expenseType: (val.expenseType || 'Not specified')
                            }
                        });
                        return {results: data, more: more};
                    },
                    allowClear: true,
                    cache: true
                },
                formatResult: formatValue,
                formatSelection: formatValue,
                escapeMarkup: function (m) {
                    return m;
                }
            });
        });

        // setTimeout(function () , 500);
        return el;
    }
});

var productCategoryFormat = function (product) {
    var catInfo = '';
    var category = product.category;
    var group = product.group;
    if (category == group) {
        catInfo = category
    } else {
        catInfo = category + ' > ' + group;
    }
    var expenseType = product.expenseType;
    catInfo += ' | <span class="product-expenseType">' + expenseType + '</span>';
    return catInfo;
}

var costCenterReadView = AJS.RestfulTable.CustomReadView.extend({
    render: function (self) {
        var val = self.value;
        return `<div class="dict-container">
                <span class="cc-code">[${val.code}]</span> ${val.name}
                </div>`;
    }
});

var costCenterCreateView = AJS.RestfulTable.CustomCreateView.extend({
    render: function () {
        var el = AJS.$("<input class='select cf-select-ci' name='costCenterCode' required/>");

        var formatValue = function (val) {
            return `<div class="dict-container">
                <span class="cc-code">[${val.id}]</span> ${val.name}<br/>
                <span class="сс-b1"><label>B1:</label> ${val.b1}</span><br/>
                <span class="cc-domain"><label>Domain:</label> ${val.domain}</span>
                </div>`;
        }

        el.on('DOMNodeInserted', function () {
            el.select2({
                placeholder: 'Cost Center is not specified',
                allowClear: true,
                dropdownAutoWidth: true,
                dropdownCssClass: "dropdown-product",
                ajax: {
                    url: '/rest/portfolio/1.0/dictionary/COST_CENTER.json',
                    dataType: 'json',
                    quietMillis: 250,
                    data: function (term, page) {
                        return {
                            q: term,
                            all: true,
                            page: page
                        };
                    },
                    results: function (data, page) {
                        var more = page * 10 < data.total;
                        data = AJS.$.map(data.items, function (val, i) {
                            var domain = (val.domain || 'Not specified');
                            domain += ' > ' + (val.customerDomain || 'Not specified');
                            return {
                                id: val.code,
                                name: val.name,
                                b1: val.b1Name || 'Not specified',
                                domain: domain
                            }
                        });
                        return {results: data, more: more};
                    },
                    allowClear: true,
                    cache: true
                },
                formatResult: formatValue,
                formatSelection: formatValue,
                escapeMarkup: function (m) {
                    return m;
                }
            });
        });

        // setTimeout(function () , 500);
        return el;
    }
});

var domainReadView = AJS.RestfulTable.CustomReadView.extend({
    render: function (self) {
        var val = self.value;
        return `<div class="dict-container">
                ${val.parentDomain} > ${val.name} 
                </div>`;
    }
});

var domainCreateView = AJS.RestfulTable.CustomCreateView.extend({
    render: function () {
        var el = AJS.$("<input class='select cf-select-ci' name='domain' required/>");

        var formatValue = function (val) {
            return `<div class="dict-container">
                ${val.parentDomain} > ${val.name}
                </div>`;
        }

        el.on('DOMNodeInserted', function () {
            el.select2({
                placeholder: 'Domain is not specified',
                allowClear: true,
                dropdownAutoWidth: true,
                dropdownCssClass: "dropdown-product",
                ajax: {
                    url: '/rest/portfolio/1.0/dictionary/DOMAIN.json',
                    dataType: 'json',
                    quietMillis: 250,
                    data: function (term, page) {
                        return {
                            q: term,
                            all: true,
                            page: page
                        };
                    },
                    results: function (data, page) {
                        var more = page * 10 < data.total;
                        data = AJS.$.map(data.items, function (val, i) {
                            return {
                                id: val.name,
                                name: val.name,
                                parentDomain: val.parentDomain
                            }
                        });
                        return {results: data, more: more};
                    },
                    allowClear: true,
                    cache: true
                },
                formatResult: formatValue,
                formatSelection: formatValue,
                escapeMarkup: function (m) {
                    return m;
                }
            });
        });

        // setTimeout(function () , 500);
        return el;
    }
});

var yearInput = function (inputName, from, to) {
    var currYear = new Date().getFullYear();
    var $select = $("<select class='select'>").attr('name', inputName);
    for (var i = from; i < to; i++) {
        // $select.append($("<option selected>").attr('value', currYear).text(currYear));
        var $option = $("<option>").attr('value', currYear + i).text(currYear + i)
        $select.append($option);
        if (i == 0) {
            $option.attr('selected', 'selected');
        }
    }
    return $select;
}

var quarterInput = function (inputName, from, to) {
    var quarters = ["Q1", "Q2", "Q3", "Q4"];
    var $select = $("<select class='select'>").attr('name', inputName);
    for (var i = from; i < to; i++) {
        var $option = $("<option>").attr('value', quarters[i]).text(quarters[i]);
        $select.append($option);
        if (i == 0) {
            $option.attr('selected', 'selected');
        }
    }
    return $select;
}

var selectRender = function (inputName, values, self) {
    var $select = $("<select class='select'>").attr('name', inputName);
    for (var value of values) {
        $select.append($("<option>").attr('value', value).text(value));
    }

    if (self && self.value) {
        $select.val(self.value);
    }
    return $select;
};

var deleteBudgetCallback = function (model) {
    var activeTabHeaderId = document.getElementsByClassName('menu-item active-tab').item(0).id;
    AJS.dialog2("#delete-confirmation-dialog").show();
    var promise = new Promise(function (resolve, reject) {
        AJS.$("#dialog-submit-button").on('click', function (e) {
            resolve();
            e.preventDefault();
            AJS.dialog2("#delete-confirmation-dialog").hide();
            switch (activeTabHeaderId) {
                case "budget-tab-header":
                   setTimeout(function () {
                       updateTotal(false, false);
                   }, 500); break;
                case "cy-budget-tab-header":
                    setTimeout(function () {
                        updateTotal(false, true);
                    }, 500); break;
                case "init-budget-tab-header":
                    setTimeout(function () {
                        updateTotal(true, false);
                    }, 500); break;
            }
        });

        AJS.$(".aui-close-button, #warning-dialog-cancel").on('click', function (e) {
            reject();
            e.preventDefault();
            AJS.dialog2("#delete-confirmation-dialog").hide();
        });
    });
    return promise;
};

var updateTotal = function (initial, cy) {
    var issueKey = AJS.$("#fin-details").data("issue");
    if (initial === false && cy === false) {
        AJS.$.get("/rest/portfolio/1.0/budget/" + issueKey + "/total?initial=" + initial + "&" + "cy=" + cy)
            .success(function (data) {
                AJS.$("#external-budget-total").text(new Intl.NumberFormat().format(data.externalTotal));
                AJS.$("#external-budget-capex").text(new Intl.NumberFormat().format(data.externalCapex));
                AJS.$("#external-budget-opex").text(new Intl.NumberFormat().format(data.externalOpex));
                AJS.$("#internal-budget-md").text(new Intl.NumberFormat().format(data.internalMd));
                AJS.$("#internal-budget-total").text(new Intl.NumberFormat().format(data.internalTotal));
        });
    } else if (initial === false && cy === true) {
        AJS.$.get("/rest/portfolio/1.0/budget/" + issueKey + "/total?initial=" + initial + "&" + "cy=" + cy)
            .success(function (data) {
                AJS.$("#cy-external-budget-total").text(new Intl.NumberFormat().format(data.externalTotal));
                AJS.$("#cy-external-budget-capex").text(new Intl.NumberFormat().format(data.externalCapex));
                AJS.$("#cy-external-budget-opex").text(new Intl.NumberFormat().format(data.externalOpex));
                AJS.$("#cy-internal-budget-md").text(new Intl.NumberFormat().format(data.internalMd));
                AJS.$("#cy-internal-budget-total").text(new Intl.NumberFormat().format(data.internalTotal));
            });
    } else {
        AJS.$.get("/rest/portfolio/1.0/budget/" + issueKey + "/total?initial=" + initial + "&" + "cy=" + cy)
            .success(function (data) {
                AJS.$("#init-external-budget-total").text(new Intl.NumberFormat().format(data.externalTotal));
                AJS.$("#init-external-budget-capex").text(new Intl.NumberFormat().format(data.externalCapex));
                AJS.$("#init-external-budget-opex").text(new Intl.NumberFormat().format(data.externalOpex));
                AJS.$("#init-internal-budget-md").text(new Intl.NumberFormat().format(data.internalMd));
                AJS.$("#init-internal-budget-total").text(new Intl.NumberFormat().format(data.internalTotal));
            });
    }
}