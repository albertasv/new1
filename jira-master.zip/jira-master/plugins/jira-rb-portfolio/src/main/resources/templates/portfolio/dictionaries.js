AJS.$(document).ready(function () {

    var canEdit = AJS.$("#rb-dictionaries").data("edit");
    var groups = ['pmo', 'is', 'arch'];

    for (var group of groups) {
        var initGroupTable = function () {
            return new AJS.RestfulTable({
                el: AJS.$("#table-" + group),
                autoFocus: true,
                allowCreate: canEdit,
                allowEdit: false,
                allowDelete: canEdit,
                noEntriesMsg: 'No data',
                resources: {
                    all: "/rest/portfolio/1.0/group/" + group,
                    self: "/rest/portfolio/1.0/group/" + group
                },
                deleteConfirmationCallback: deleteBudgetCallback,
                columns: [
                    {
                        id: "username",
                        header: "Username",
                        readView: AJS.RestfulTable.CustomReadView.extend({
                            render: function (self) {
                                return userRender('username', true, true, self);
                            }
                        }),
                        createView: AJS.RestfulTable.CustomCreateView.extend({
                            render: function () {
                                return userRender('username', false, false);
                            }
                        }),
                        editView: AJS.RestfulTable.CustomEditView.extend({
                            render: function (self) {
                                return userRender('username', false, false, self);
                            }
                        })
                    },
                    {
                        id: "name",
                        header: "Name",
                        allowEdit: false
                    },
                    {
                        id: "email",
                        header: "Email",
                        allowEdit: false,
                        readView: AJS.RestfulTable.CustomReadView.extend({
                            render: function (self) {
                                var $a = $("<a/>");
                                $a.attr("href", "mailto:" + self.value);
                                return $a.text(self.value);
                            }
                        })
                    }
                ]
            });
        }
        initGroupTable();
    }


    var initFinGroupTable = function () {
        var finTable = AJS.$("#table-fin");
        var finTableFilter = finTable.data("filter");

        return new AJS.RestfulTable({
            el: finTable,
            autoFocus: true,
            allowCreate: canEdit,
            allowEdit: false,
            allowDelete: canEdit,
            noEntriesMsg: 'No data',
            resources: {
                all: "/rest/portfolio/1.0/group/fin" + (finTableFilter ? ('?q=' + finTableFilter) : ''),
                self: "/rest/portfolio/1.0/group/fin"
            },
            deleteConfirmationCallback: deleteBudgetCallback,
            columns: [
                {
                    id: "username",
                    header: "Username",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('username', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('username', false, false);
                        }
                    })
                },
                {
                    id: "name",
                    header: "Name",
                    allowEdit: false
                },
                {
                    id: "email",
                    header: "Email",
                    allowEdit: false,
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            var $a = $("<a/>");
                            $a.attr("href", "mailto:" + self.value);
                            return $a.text(self.value);
                        }
                    })
                },
                {
                    id: "domain",
                    header: "Business Domain",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('domain', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function (self) {
                            return domainRender('domain');
                        }
                    })
                }
            ]
        });
    }
    initFinGroupTable();

    var initDomainTable = function () {
        return new AJS.RestfulTable({
            el: AJS.$("#table-domain"),
            autoFocus: true,
            allowCreate: false,
            allowEdit: false,
            allowDelete: false,
            noEntriesMsg: 'No data',
            resources: {
                all: "/rest/portfolio/1.0/dictionary/crud/DOMAIN",
                self: "/rest/portfolio/1.0/dictionary/crud/DOMAIN"
            },
            deleteConfirmationCallback: deleteBudgetCallback,
            columns: [
                {
                    id: "code",
                    header: "Business Domain",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('name', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('name', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('name', false, false, self);
                        }
                    })
                },
                {
                    id: "parentDomain",
                    header: "Domain",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('code', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('code', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('code', false, true, self);
                        }
                    })
                }
            ]
        });
    }
    initDomainTable();

    var initCostCenterTable = function () {
        return new AJS.RestfulTable({
            el: AJS.$("#table-cc"),
            autoFocus: true,
            allowCreate: canEdit,
            allowEdit: canEdit,
            allowDelete: canEdit,
            noEntriesMsg: 'No data',
            resources: {
                all: "/rest/portfolio/1.0/dictionary/crud/COST_CENTER",
                self: "/rest/portfolio/1.0/dictionary/crud/COST_CENTER"
            },
            deleteConfirmationCallback: deleteBudgetCallback,
            columns: [
                {
                    id: "code",
                    header: "Code",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('code', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('code', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('code', false, true, self);
                        }
                    })
                },
                {
                    id: "name",
                    header: "Name",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('name', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('name', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('name', false, false, self);
                        }
                    })
                },
                {
                    id: "domain",
                    header: "Domain",
                    allowEdit: false,
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('domain', true, true, self);
                        }
                    })
                },
                {
                    id: "customerDomain",
                    header: "Business Domain",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('customerDomain', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return domainRender('customerDomain');
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return domainRender('customerDomain', self);
                        }
                    })
                },
                {
                    id: "sponsorName",
                    header: "Sponsor",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('sponsor', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('sponsor', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('sponsor', false, false, self);
                        }
                    })
                },
                {
                    id: "b1Name",
                    header: "B1",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('b1', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('b1', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('b1', false, false, self);
                        }
                    })
                },
                {
                    id: "sbpName",
                    header: "SBP",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('sbp', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('sbp', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('sbp', false, false, self);
                        }
                    })
                },
                {
                    id: "fbpName",
                    header: "FBP",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('fbp', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('fbp', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('fbp', false, false, self);
                        }
                    })
                },
                {
                    id: "isOfficerName",
                    header: "IS Officer",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('isOfficer', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('isOfficer', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('isOfficer', false, false, self);
                        }
                    })
                },
                {
                    id: "architectName",
                    header: "IT Architect",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return userRender('architect', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return userRender('architect', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return userRender('architect', false, false, self);
                        }
                    })
                },
                {
                    id: "agile",
                    header: "Agile",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return checkboxRender('agileOn', true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return checkboxRender('agileOn', false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return checkboxRender('agileOn', false, self);
                        }
                    })
                }
            ]
        });
    }
    initCostCenterTable();

    var initProductTable = function () {
        return new AJS.RestfulTable({
            el: AJS.$("#table-product"),
            autoFocus: true,
            allowCreate: canEdit,
            allowEdit: canEdit,
            allowDelete: canEdit,
            noEntriesMsg: 'No data',
            resources: {
                all: "/rest/portfolio/1.0/dictionary/crud/PRODUCT",
                self: "/rest/portfolio/1.0/dictionary/crud/PRODUCT"
            },
            deleteConfirmationCallback: deleteBudgetCallback,
            columns: [
                {
                    id: "code",
                    header: "Code",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('code', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('code', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('code', false, true, self);
                        }
                    })
                },
                {
                    id: "name",
                    header: "Name",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('name', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('name', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('name', false, false, self);
                        }
                    })
                },
                {
                    id: "category",
                    header: "Category",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('category', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('category', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('category', false, false, self);
                        }
                    })
                },
                {
                    id: "group",
                    header: "Group",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return textRender('group', true, true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return textRender('group', false, false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return textRender('group', false, false, self);
                        }
                    })
                },
                {
                    id: "expenseType",
                    header: "Expense Type",
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return selectRender('expenseType', ['CAPEX', 'OPEX']);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return selectRender('expenseType', ['CAPEX', 'OPEX'], self);
                        }
                    })
                },
                {
                    id: "budgetProduct",
                    header: "Budget",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return checkboxRender('budgetProductOn', true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return checkboxRender('budgetProductOn', false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return checkboxRender('budgetProductOn', false, self);
                        }
                    })
                },
                {
                    id: "hidden",
                    header: "Hidden",
                    readView: AJS.RestfulTable.CustomReadView.extend({
                        render: function (self) {
                            return checkboxRender('hiddenOn', true, self);
                        }
                    }),
                    createView: AJS.RestfulTable.CustomCreateView.extend({
                        render: function () {
                            return checkboxRender('hiddenOn', false);
                        }
                    }),
                    editView: AJS.RestfulTable.CustomEditView.extend({
                        render: function (self) {
                            return checkboxRender('hiddenOn', false, self);
                        }
                    })
                }
            ]
        });
    }
    initProductTable();
});

var textRender = function (inputName, readonly, disabled, self) {
    if (readonly) {
        var $div = $("<div/>");
        if (self && self.value) {
            $div.text(self.value);
        }
        return $div;
    }

    var $input = $("<input class='text' type='text' />").attr('name', inputName);
    if (self && self.value) {
        $input.val(self.value);
        $input.attr('value', self.value);
    }
    if (disabled) {
        $input.attr('disabled', 'disabled');
    }
    return $input;
};

var userRender = function (inputName, readonly, disabled, self) {
    if (readonly) {
        var $div = $("<div/>");
        if (self && self.value) {
            $div.text(self.value);
        }
        return $div;
    }

    var $input = $("<input class='text' type='text' placeholder='Введите логин пользователя, чтобы изменить'/>")
        .attr('name', inputName);

    if (disabled) {
        $input.attr('disabled', 'disabled');
        if (self && self.value) {
            $input.val(self.value);
            $input.attr('value', self.value);
        }
    }
    return $input;
};

var selectRender = function (inputName, values, self) {
    var $select = $("<select class='select'>").attr('name', inputName);
    for (var value of values) {
        $select.append($("<option>").attr('value', value).text(value));
    }

    if (self && self.value) {
        $select.val(self.value);
    }
    return $select;
};

var checkboxRender = function (inputName, disabled, self) {
    var $checkbox = $("<input class='checkbox' type='checkbox'/>").attr('name', inputName);
    $checkbox.val('false');
    if (disabled) {
        $checkbox.attr('disabled', 'disabled');
    }
    if (self && self.value) {
        $checkbox.attr('checked', 'checked');
        $checkbox.val('true');
    }

    $checkbox.on('click', function () {
        $checkbox.val(this.checked ? 'true' : 'false');
    });

    return $checkbox;
};

var domainRender = function (inputName, self) {
    var el = AJS.$("<input class='select cf-select-ci select-domain'/>")
        .attr('name', inputName);

    if (self && self.value) {
        el.val(self.value);
    }

    var formatValue = function (val) {
        return `<div class="dict-container">
                <span>${val.name}</span>
                </div>`;
    }

    el.on('DOMNodeInserted', function () {
        el.select2({
            allowClear: true,
            dropdownAutoWidth: true,
            ajax: {
                url: '/rest/portfolio/1.0/dictionary/DOMAIN.json',
                dataType: 'json',
                quietMillis: 250,
                data: function (term, page) {
                    return {
                        q: term,
                        all: true,
                        page: page
                    };
                },
                results: function (data, page) {
                    var more = page * 10 < data.total;
                    data = AJS.$.map(data.items, function (val, i) {
                        return {
                            id: val.code,
                            name: val.name
                        }
                    });
                    return {results: data, more: more};
                },
                initSelection: function (element, callback) {
                    var data = {
                        id: self.value,
                        name: self.value
                    };
                    callback(data);
                },
                allowClear: true,
                cache: true
            },
            formatResult: formatValue,
            formatSelection: formatValue,
            escapeMarkup: function (m) {
                return m;
            }
        });
    });
    return el;
};

var deleteBudgetCallback = function (model) {
    AJS.dialog2("#delete-confirmation-dialog").show();

    var promise = new Promise(function (resolve, reject) {
        AJS.$("#dialog-submit-button").on('click', function (e) {
            resolve();
            e.preventDefault();
            AJS.dialog2("#delete-confirmation-dialog").hide();
        });

        AJS.$(".aui-close-button, #warning-dialog-cancel").on('click', function (e) {
            reject();
            e.preventDefault();
            AJS.dialog2("#delete-confirmation-dialog").hide();
        });
    });
    return promise;
};