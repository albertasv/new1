package ru.rosbank.jira.portfolio.model.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static ru.rosbank.jira.portfolio.utils.NumberUtil.*;

public class FinancialCategoryBean extends FinancialReportBean {

    private List<FinancialReportBean> reportLines;
    private Date lastUpdateDate;

    public FinancialCategoryBean(String entityCode, String category, Integer currentYear) {
        super(entityCode, category, category, null, currentYear);
        this.reportLines = new ArrayList<>();
    }

    public List<FinancialReportBean> getReportLines() {
        Collections.sort(reportLines);
        return reportLines;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public void summarize() {
        this.summarize(this.reportLines);
    }

    public void total(FinancialCategoryBean categoryValue) {
        summarize(categoryValue.getReportLines());
    }

    private void summarize(List<FinancialReportBean> reportLines) {
        for (FinancialReportBean reportLine : reportLines) {
            this.factPrev = sum(this.factPrev, reportLine.factPrev);
            for (int i = 0; i < 4; i++) {
                this.fact[i] = sum(this.fact[i], reportLine.fact[i]);
                this.contracted[i] = sum(this.contracted[i], reportLine.contracted[i]);
                this.notContracted[i] = sum(this.notContracted[i], reportLine.notContracted[i]);
                this.forecast[i] = sum(this.forecast[i], reportLine.forecast[i]);
            }
            this.accrual = sum(this.accrual, reportLine.accrual);
            this.extBudget = sum(this.extBudget, reportLine.extBudget);
            this.extBudgetNext = sum(this.extBudgetNext, reportLine.extBudgetNext);
            this.carryOverContracted = sum(this.carryOverContracted, reportLine.carryOverContracted);
            this.carryOverNotContracted = sum(this.carryOverNotContracted, reportLine.carryOverNotContracted);
        }
    }

    @Override
    protected int getOrder() {
        switch (getCategory().toUpperCase()) {
            case "TOTAL":
                return 0;
            case "HARDWARE":
                return 10;
            case "SOFTWARE":
                return 20;
        }
        return 1000;
    }

    @Override
    public int compareTo(FinancialReportBean o) {
        return this.getOrder() - o.getOrder();
    }
}
