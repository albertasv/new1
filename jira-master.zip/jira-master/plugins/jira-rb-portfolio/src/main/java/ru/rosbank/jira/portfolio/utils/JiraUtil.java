package ru.rosbank.jira.portfolio.utils;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueInputParameters;
import com.atlassian.jira.issue.context.IssueContextImpl;
import com.atlassian.jira.issue.customfields.option.Option;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.config.FieldConfig;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.parser.JqlParseException;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.ErrorCollection;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class JiraUtil {

    private static final Logger LOG = LoggerFactory.getLogger(JiraUtil.class);

    public static String errors(ErrorCollection errorCollection) {
        if (errorCollection.hasAnyErrors()) {
            return errorCollection.getErrors()
                    .entrySet()
                    .stream()
                    .map(e -> e.getKey() + " -> " + e.getValue())
                    .collect(Collectors.joining(" | "));
        }
        return null;
    }

    public static boolean setSingleSelect(Issue portfolioIssue, IssueInputParameters inputParameters,
                                          IssueContextImpl issueContext, CustomField field, String value) {
        FieldConfig fieldConfig = field.getRelevantConfig(issueContext);

        Optional<Option> optionAny = ComponentAccessor.getOptionsManager().getOptions(fieldConfig).stream()
                .filter(option -> value.equalsIgnoreCase(option.getValue()))
                .findAny();
        if (optionAny.isPresent()) {
            if (portfolioIssue == null) {
                inputParameters.addCustomFieldValue(field.getId(), String.valueOf(optionAny.get().getOptionId()));
                return true;
            } else {
                Option optionValue = (Option) portfolioIssue.getCustomFieldValue(field);
                if (optionValue == null || !value.equalsIgnoreCase(optionValue.getValue())) {
                    inputParameters.addCustomFieldValue(field.getId(), String.valueOf(optionAny.get().getOptionId()));
                    return true;
                }
            }
        }
        return false;
    }

    public static List<Issue> getIssuesWithJqlTemplates(ApplicationUser user, String jqlTemplate, String issueKey) {
        String jql = String.format(jqlTemplate, issueKey);
        try {
            Query query = ComponentAccessor.getComponent(JqlQueryParser.class).parseQuery(jql);
            SearchResults<Issue> searchResult = ComponentAccessor.getComponent(SearchService.class)
                    .search(user, query, PagerFilter.getUnlimitedFilter());
            return searchResult.getResults();
        } catch (JqlParseException | SearchException ex) {
            LOG.error("Get issues exception for jql {} - {}", jqlTemplate, issueKey, ex);
        }
        return Collections.emptyList();
    }
}
