package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;

@Preload
public interface CostCenter extends Dictionary {
    String getDomain();

    void setDomain(String domain);

    String getCustomerDomain();

    void setCustomerDomain(String customerDomain);

    String getB1();

    void setB1(String b1);

    String getB1Name();

    void setB1Name(String b1);

    String getSponsor();

    void setSponsor(String sponsor);

    String getSponsorName();

    void setSponsorName(String sponsor);

    String getSbp();

    void setSbp(String sbp);

    String getSbpName();

    void setSbpName(String sbp);

    String getFbp();

    void setFbp(String fbp);

    String getFbpName();

    void setFbpName(String fbp);

    String getIsOfficer();

    void setIsOfficer(String isOfficer);

    String getIsOfficerName();

    void setIsOfficerName(String isOfficer);

    String getArchitect();

    void setArchitect(String architect);

    String getArchitectName();

    void setArchitectName(String architectName);

    Boolean getAgile();

    void setAgile(Boolean agile);
}
