package ru.rosbank.jira.portfolio.jql;

import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;

public class OutOfOfficeJqlFunc extends AbstractJqlFunction {


    private final UserInfoService userInfoService;


    @Inject
    public OutOfOfficeJqlFunc(@ComponentImport UserInfoService userInfoService) {
        this.userInfoService = userInfoService;
    }

    @Nonnull
    @Override
    public MessageSet validate(ApplicationUser applicationUser, @Nonnull FunctionOperand operand, @Nonnull TerminalClause terminalClause) {
        return this.validateNumberOfArgs(operand, 0);
    }

    @Nonnull
    @Override
    public List<QueryLiteral> getValues(@Nonnull QueryCreationContext queryCreationContext, @Nonnull FunctionOperand operand, @Nonnull TerminalClause terminalClause) {
        final List<QueryLiteral> literals = new LinkedList<>();
        List<UserInfoModel> oofUsers = userInfoService.getUserInfoByOofStatus();
        for(UserInfoModel user : oofUsers) {
            literals.add(new QueryLiteral(operand, user.getUsername()));
        }
        return literals;
    }

    @Override
    public int getMinimumNumberOfExpectedArguments() {
        return 0;
    }

    @Nonnull
    @Override
    public JiraDataType getDataType() {
        return JiraDataTypes.USER;
    }
}