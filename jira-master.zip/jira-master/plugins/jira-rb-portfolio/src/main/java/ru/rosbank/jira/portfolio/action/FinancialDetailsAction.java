package ru.rosbank.jira.portfolio.action;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.api.BudgetService;

import javax.inject.Inject;

import static com.google.common.base.Preconditions.checkNotNull;

public class FinancialDetailsAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(FinancialDetailsAction.class);

    private Issue issue;
    private Object finResolution;

    private final JiraAuthenticationContext authenticationContext;
    private final ConfigLoader config;
    private final BudgetService budgetService;

    @Inject
    public FinancialDetailsAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport ConfigLoader config,
            BudgetService budgetService) {
        this.authenticationContext = checkNotNull(authenticationContext);
        this.config = checkNotNull(config);
        this.budgetService = budgetService;
    }

    @Override
    protected void doValidation() {
        String issueKey = getHttpRequest().getParameter("issue");
        if (budgetService.canViewBudget(issueKey)) {
            issue = ComponentAccessor.getIssueManager().getIssueObject(issueKey);
            if (issue != null) {
                this.finResolution = issue.getCustomFieldValue(ComponentAccessor.getCustomFieldManager().getCustomFieldObject(config.getFinancialResolutionId()));
                return;
            }
        } else {
            addErrorMessage("You don't have permission to view this issue.");
        }
        addErrorMessage("You don't have permission to view this issue or it wasn't found.");
    }

    @Override
    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public Issue getIssue() {
        return issue;
    }

    public boolean getCanEdit() {
        return budgetService.canEditBudget(issue.getKey());
    }

    public Object getFinResolution() {
        return finResolution;
    }
}