package ru.rosbank.jira.portfolio.model;

public enum Multiplier {

    RUR("RUR", 1),
    KRUR("kRUR", 1000),
    MRUR("mRUR", 1000000);


    private String name;
    private long multiplier;

    Multiplier(String name, long multiplier) {
        this.name = name;
        this.multiplier = multiplier;
    }

    public String getName() {
        return name;
    }

    public long getMultiplier() {
        return multiplier;
    }

    public static Multiplier getMultiplier(long multiplier) {
        if (multiplier == KRUR.getMultiplier()) {
            return KRUR;
        } else if (multiplier == MRUR.getMultiplier()) {
            return MRUR;
        }
        return RUR;
    }
}
