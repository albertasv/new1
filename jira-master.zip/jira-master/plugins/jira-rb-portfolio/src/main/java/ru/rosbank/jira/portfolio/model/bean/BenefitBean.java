package ru.rosbank.jira.portfolio.model.bean;

import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.Benefit;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class BenefitBean {

    private int currentYear;
    private int[] years;
    private Map<String, double[]> benefitsMap = new HashMap<>();

    public BenefitBean() {
        currentYear = DateUtil.getYear(DateUtil.getCurrentYear());
        years = new int[]{currentYear - 1, currentYear, currentYear + 1, currentYear + 2, currentYear + 3};
    }

    public void addValue(Benefit benefit) {
        String category = benefit.getCategory();
        int benefitYear = DateUtil.getYear(benefit.getBenefitDate());
        double benefitValue = benefit.getBenefitValue();
        double[] benefits = benefitsMap.getOrDefault(category, new double[]{0, 0, 0, 0, 0});
        if (benefitYear < currentYear) {
            benefits[0] += benefitValue;
        } else if (benefitYear == currentYear) {
            benefits[1] += benefitValue;
        } else if (benefitYear == currentYear + 1) {
            benefits[2] += benefitValue;
        } else if (benefitYear == currentYear + 2) {
            benefits[3] += benefitValue;
        } else if (benefitYear > currentYear + 2) {
            benefits[4] += benefitValue;
        }
        benefitsMap.put(category, benefits);
    }

    public int getYears(int index) {
        return years[index];
    }

    public String getBenefit(String defaultValue, int index, String... categories) {
        double res = 0;
        for (String category : categories) {
            res += benefitsMap.getOrDefault(category, new double[]{0, 0, 0, 0, 0})[index];
        }
        return format(defaultValue, res / 1_000_000);
    }

    public String getBenefit(String defaultValue, String... categories) {
        double res = 0;
        for (String category : categories) {
            res += Arrays.stream(benefitsMap.getOrDefault(category, new double[]{0})).sum();
        }
        return format(defaultValue, res / 1_000_000);
    }

    public String getRoi() {
        return Arrays.stream(benefitsMap.getOrDefault("ROI", new double[]{0})).sum() + "%";
    }

    private String format(String defaultValue, double value) {
        NumberFormat formatter = new DecimalFormat("#0.00");
        return value == 0 ? defaultValue : formatter.format(value);
    }

    private String formatPercent(String defaultValue, double value) {
        NumberFormat formatter = new DecimalFormat("#0.0%");
        return value == 0 ? defaultValue : formatter.format(value);
    }
}
