package ru.rosbank.jira.portfolio.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.*;
import ru.rosbank.jira.common.exceptions.LoadRbStaffTeamsException;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.ao.Domain;
import ru.rosbank.jira.portfolio.ao.ExecutionTeam;
import ru.rosbank.jira.portfolio.ao.Product;
import ru.rosbank.jira.portfolio.api.*;
import ru.rosbank.jira.portfolio.model.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@Path("/dictionary")
public class DictionaryRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(DictionaryRestResource.class);

    private static final int PAGE_MAX = 10;

    private final JiraAuthenticationContext jiraAuthenticationContext;

    private DomainService domainService;
    private CostCenterService costCenterService;
    private ProductService productService;
    private ExecutionTeamService executionTeamService;
    private final BudgetService budgetService;

    private ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final ServiceNames serviceName = ServiceNames.RBSTAFF_EXECUTION_TEAMS_UPDATER;

    private final UserInfoService userInfoService;

    public DictionaryRestResource(@ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            @ComponentImport UserInfoService userInfoService,
            DomainService domainService,
            CostCenterService costCenterService,
            ProductService productService,
            ExecutionTeamService executionTeamService,
            BudgetService budgetService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.domainService = domainService;
        this.costCenterService = costCenterService;
        this.productService = productService;
        this.executionTeamService = executionTeamService;
        this.budgetService = budgetService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
        this.userInfoService = userInfoService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/{type}")
    public Response searchDictionary(
            @PathParam("type") String type,
            @QueryParam("q") String query,
            @QueryParam("page") int page) {
        List<DictionaryModel> res = new ArrayList<>();
        DictionaryType dictionaryType = DictionaryType.getType(type);
        int total = 100;
        if (dictionaryType != null) {
            switch (dictionaryType) {
                case DOMAIN:
                    for (Domain domain : domainService.search(query, PAGE_MAX, (page - 1) * PAGE_MAX)) {
                        res.add(DomainModel.convert(domain));
                    }
                    break;
                case COST_CENTER:
                    for (CostCenter item : costCenterService.search(query, PAGE_MAX, (page - 1) * PAGE_MAX)) {
                        res.add(CostCenterModel.convert(item));
                    }
                    total = costCenterService.total(query);
                    break;
                case PRODUCT:
                    for (Product item : productService.search(query, PAGE_MAX, (page - 1) * PAGE_MAX)) {
                        res.add(ProductModel.convert(item));
                    }
                    total = productService.total(query);
                    break;
                case BUDGET_PRODUCT:
                    for (Product item : productService.search(true, query, PAGE_MAX, (page - 1) * PAGE_MAX)) {
                        res.add(ProductModel.convert(item));
                    }
                    total = 20;
                    break;
                case EXECUTION_TEAM:
                    for (ExecutionTeam item : executionTeamService.search(query, PAGE_MAX, (page - 1) * PAGE_MAX)) {
                        res.add(ExecutionTeamModel.convert(item));
                    }
                    total = executionTeamService.total(query);
                    break;
            }
            return Response.ok(new DictionaryResultModel(res, total)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/{type}")
    public Response readDictionary(
            @PathParam("type") String type,
            @QueryParam("q") String query,
            @QueryParam("page") int page) {
        List<DictionaryModel> res = new ArrayList<>();
        DictionaryType dictionaryType = DictionaryType.getType(type);
        int allPageLimit = 1000;
        if (dictionaryType != null) {
            switch (dictionaryType) {
                case DOMAIN:
                    for (Domain domain : domainService.search(query, allPageLimit, 0)) {
                        res.add(DomainModel.convert(domain));
                    }
                    break;
                case COST_CENTER:
                    for (CostCenter item : costCenterService.search(query, allPageLimit, 0)) {
                        res.add(CostCenterModel.convert(item));
                    }
                    break;
                case PRODUCT:
                    for (Product item : productService.search(query, allPageLimit, 0)) {
                        res.add(ProductModel.convert(item));
                    }
                    break;
            }
            return Response.ok(res).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/{type}/{id}")
    public Response delete(@PathParam("type") String type, @PathParam("id") int id) {
        if (canEdit()) {
            DictionaryType dictionaryType = DictionaryType.getType(type);
            if (dictionaryType != null) {
                switch (dictionaryType) {
                    case COST_CENTER:
                        costCenterService.delete(id);
                        return Response.ok(new DictionaryModel(id)).build();
                    case PRODUCT:
                        productService.delete(id);
                        return Response.ok(new DictionaryModel(id)).build();
                    default:
                        return Response.status(Response.Status.NOT_FOUND).build();
                }
            }
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/PRODUCT/{id}")
    public Response deleteProduct(@PathParam("id") int id) {
        return delete(DictionaryType.PRODUCT.name(), id);
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/COST_CENTER/{id}")
    public Response deleteCostCenter(@PathParam("id") int id) {
        return delete(DictionaryType.COST_CENTER.name(), id);
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/PRODUCT")
    public Response readProduct(@QueryParam("q") String query, @QueryParam("page") int page) {
        return readDictionary(DictionaryType.PRODUCT.name(), query, page);
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/PRODUCT")
    public Response addProduct(ProductModel data) {
        if (canEdit()) {
            return Response.ok(ProductModel.convert(productService.add(data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/PRODUCT/{id}")
    public Response updateProduct(@PathParam("id") int id, ProductModel data) {
        if (canEdit()) {
            return Response.ok(ProductModel.convert(productService.update(id, data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/COST_CENTER")
    public Response readCostCenter(@QueryParam("q") String query, @QueryParam("page") int page) {
        return readDictionary(DictionaryType.COST_CENTER.name(), query, page);
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/COST_CENTER")
    public Response addCostCenter(CostCenterModel data) {
        if (canEdit()) {
            return Response.ok(CostCenterModel.convert(costCenterService.add(data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/COST_CENTER/{id}")
    public Response updateCostCenter(@PathParam("id") int id, CostCenterModel data) {
        if (canEdit()) {
            return Response.ok(CostCenterModel.convert(costCenterService.update(id, data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/crud/DOMAIN")
    public Response readDomain(@QueryParam("q") String query, @QueryParam("page") int page) {
        return readDictionary(DictionaryType.DOMAIN.name(), query, page);
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/DOMAIN")
    public Response addDomain(DomainModel data) {
        if (canEdit()) {
            return Response.ok(DomainModel.convert(domainService.add(data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @PUT
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/crud/DOMAIN/{id}")
    public Response updateDomain(@PathParam("id") int id, DomainModel data) {
        if (canEdit()) {
            return Response.ok(DomainModel.convert(domainService.update(id, data))).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Path("/loadTeams")
    @Produces({MediaType.APPLICATION_JSON})
    public Response loadTeams() {
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
                    new Date());
        try {
            if (canEdit()) {
                executionTeamService.loadRbStaffTeams();
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                    new Date());
                return Response.status(Response.Status.OK).entity(new MessageModel("OK")).build();
            }
        } catch (LoadRbStaffTeamsException loax) {
            LOG.debug("LoadRbStaffTeamsException in loadTeams() method", loax);
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(loax),
                new Date());
        } catch (Exception ex) {
            LOG.debug("Exception in loadTeams() method", ex);
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(ex),
                new Date());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(new MessageModel(ex.getMessage())).build();
        }

        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();

    }

    @PUT
    @Path("/updateTeamMember/{rb}/{newRole: .*}")
    public Response updateTeamMemberTest(@PathParam("rb") String rb, @PathParam("newRole") String newRole) {
        if (newRole.isEmpty()) {
            newRole = "";
        }
        userInfoService.updateTeamMember(0, rb, newRole);
        return Response.ok().build();
    }

    private boolean canEdit() {
        return budgetService.isPMO();
    }
}