package ru.rosbank.jira.portfolio.model.bean;

import ru.rosbank.jira.portfolio.model.Multiplier;

import java.util.Date;

public class FinancialMetaBean {

    private String code;
    private String name;
    private Date updated;
    private int year;
    private Multiplier multiplier;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Multiplier getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(Multiplier multiplier) {
        this.multiplier = multiplier;
    }
}
