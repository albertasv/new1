package ru.rosbank.jira.portfolio.model.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.ExpenseType;
import ru.rosbank.jira.portfolio.ao.ExternalBudget;
import ru.rosbank.jira.portfolio.ao.Financial;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import static ru.rosbank.jira.portfolio.utils.NumberUtil.*;

public class FinancialReportBean implements Serializable, Comparable<FinancialReportBean> {

    private static final Logger LOG = LoggerFactory.getLogger(FinancialReportBean.class);

    protected String entityCode;
    protected String category;
    protected String group;
    protected ExpenseType expenseType;
    protected Integer currentYear;

    protected BigDecimal factPrev = BigDecimal.ZERO;
    protected BigDecimal[] fact = new BigDecimal[4];
    protected BigDecimal[] contracted = new BigDecimal[4];
    protected BigDecimal[] notContracted = new BigDecimal[4];
    protected BigDecimal[] forecast = new BigDecimal[4];
    protected BigDecimal accrual = BigDecimal.ZERO;

    protected BigDecimal plan = BigDecimal.ZERO;
    protected BigDecimal planNext = BigDecimal.ZERO;

    protected BigDecimal extBudget = BigDecimal.ZERO;
    protected BigDecimal extBudgetNext = BigDecimal.ZERO;

    protected BigDecimal carryOverContracted = BigDecimal.ZERO;
    protected BigDecimal carryOverNotContracted = BigDecimal.ZERO;

    public FinancialReportBean(String entityCode, String category, String group, ExpenseType expenseType, int currentYear) {
        this.entityCode = entityCode;
        this.category = category;
        this.group = group;
        this.expenseType = expenseType;
        this.currentYear = currentYear;
    }

    public void addValue(Financial fin, long multiplier) {
        int year = DateUtil.getYear(fin.getFinancialDate());
        int quarter = DateUtil.getQuarter(fin.getFinancialDate());
        BigDecimal value = BigDecimal.valueOf(fin.getFinancialValue()).divide(BigDecimal.valueOf(multiplier));
        switch (fin.getFinancialType()) {
            case FACT:
                if (year < currentYear) {
                    factPrev = factPrev.add(value);
                } else if (year == currentYear) {
                    this.fact[quarter - 1] = sum(this.fact[quarter - 1], value);
                }
                return;
            case CONTRACTED:
                if (year == currentYear) {
                    this.contracted[quarter - 1] = sum(this.contracted[quarter - 1], value);
                }
                return;
            case NOT_CONTRACTED:
                if (year == currentYear) {
                    this.notContracted[quarter - 1] = sum(this.notContracted[quarter - 1], value);
                }
                return;
            case FORECAST:
                if (year == currentYear) {
                    this.forecast[quarter - 1] = sum(this.forecast[quarter - 1], value);
                }
                return;
            case ACCRUAL:
                if (year == currentYear) {
                    this.accrual = sum(this.accrual, value);
                }
                return;
            case ACCRUAL_FACT:
                int accrualYear = year - 1;
                if (accrualYear < currentYear) {
                    factPrev = factPrev.add(value);
                } else if (accrualYear == currentYear) {
                    this.fact[quarter - 1] = sum(this.fact[quarter - 1], value);

                    this.contracted[quarter - 1] = sum(this.contracted[quarter - 1], value);
                }

                if (year == currentYear) {
                    this.accrual = subtract(this.accrual, value);
                }
                return;
            case EXT_BUDGET:
                if (year > currentYear) {
                    this.extBudgetNext = extBudgetNext.add(value);
                }
                this.extBudget = sum(this.extBudget, value);
                return;
            case CARRY_OVER_CONTRACTED:
                if (year == currentYear) {
                    this.carryOverContracted = sum(this.carryOverContracted, value);
                }
                return;
            case CARRY_OVER_NOT_CONTRACTED:
                if (year == currentYear) {
                    this.carryOverNotContracted = sum(this.carryOverNotContracted, value);
                }
                return;
        }
    }

    public void addValue(ExternalBudget externalBudget, long multiplier) {
        int year = DateUtil.getYear(externalBudget.getBudgetDate());
        BigDecimal value = BigDecimal.valueOf(externalBudget.getBudgetValue()).divide(BigDecimal.valueOf(multiplier));
        if (year > currentYear) {
            this.extBudgetNext = extBudgetNext.add(value);
        }
        this.extBudget = sum(this.extBudget, value);
    }

    public String getEntityCode() {
        return entityCode;
    }

    public String getCategory() {
        if (category == null) {
            return "";
        }
        return category;
    }

    public String getGroup() {
        if (group == null) {
            return "";
        }
        return group;
    }

    public ExpenseType getExpenseType() {
        return expenseType;
    }

    public Integer getCurrentYear() {
        return currentYear;
    }

    public BigDecimal getFactPrev() {
        return factPrev;
    }

    public BigDecimal getFactQ1() {
        return checkNull(fact[0]);
    }

    public BigDecimal getFactQ2() {
        return checkNull(fact[1]);
    }

    public BigDecimal getFactQ3() {
        return checkNull(fact[2]);
    }

    public BigDecimal getFactQ4() {
        return checkNull(fact[3]);
    }

    public BigDecimal getFact() {
        return sum(fact);
    }

    public BigDecimal getCommittedQ1() {
        return subtract(contracted[0], fact[0]);
    }

    public BigDecimal getCommittedQ2() {
        return subtract(contracted[1], fact[1]);
    }

    public BigDecimal getCommittedQ3() {
        return subtract(contracted[2], fact[2]);
    }

    public BigDecimal getCommittedQ4() {
        return subtract(contracted[3], fact[3]);
    }

    public BigDecimal getCommitted() {
        return sum(getCommittedQ1(), getCommittedQ2(), getCommittedQ3(), getCommittedQ4());
    }

    public BigDecimal getBudget() {
        return sum(sum(contracted), sum(notContracted));
    }

    public BigDecimal getRemain() {
        return sum(notContracted);
    }

    public BigDecimal getAccrual() {
        return accrual;
    }

    public BigDecimal getPlanNext() {
        return sum(planNext, extBudgetNext);
    }

    public BigDecimal getPlan() {
        return sum(plan, extBudget);
    }

    public BigDecimal getPlanUtilized() {
        return sum(getFact(), getFactPrev(), getCommitted(), getAccrual());
    }

    public BigDecimal getPlanRemain() {
        return subtract(getPlan(), getPlanUtilized());
    }

    public BigDecimal getCheck() {
        return subtract(getPlanRemain(), getRemain());
    }

    public BigDecimal getCarryOver() {
        return sum(carryOverContracted, carryOverNotContracted);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FinancialReportBean that = (FinancialReportBean) o;
        return Objects.equals(category, that.category) &&
                Objects.equals(group, that.group) &&
                expenseType == that.expenseType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, group, expenseType);
    }

    @Override
    public int compareTo(FinancialReportBean o) {
        int c = this.getCategory().compareTo(o.getCategory());
        if (c == 0) {
            c = this.getGroup().compareTo(o.getGroup());
        }
        if (c == 0) {
            if (this.getExpenseType() == null && o.getExpenseType() == null) {
                return 0;
            }
            if (this.getExpenseType() == null) {
                return -1;
            }
            c = this.getExpenseType().compareTo(o.getExpenseType());
        }
        return c;
    }

    protected int getOrder() {
        return 0;
    }
}
