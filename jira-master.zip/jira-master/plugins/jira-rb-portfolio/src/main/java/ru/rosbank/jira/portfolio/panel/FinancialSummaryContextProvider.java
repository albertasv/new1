package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.apache.velocity.tools.generic.MathTool;
import org.apache.velocity.tools.generic.NumberTool;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.InternalBudget;
import ru.rosbank.jira.portfolio.api.*;
import ru.rosbank.jira.portfolio.model.WorklogModel;
import ru.rosbank.jira.portfolio.model.bean.FinancialCategoryBean;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FinancialSummaryContextProvider extends AbstractJiraContextProvider {

    private final ConfigLoader config;
    private final PortfolioService portfolioService;
    private final FinancialService financialService;
    private final BudgetService budgetService;
    private final WorklogService worklogService;
    private final BenefitService benefitService;
    private final AllocationService allocationService;

    private final CustomFieldManager customFieldManager;

    @Inject
    public FinancialSummaryContextProvider(@ComponentImport ConfigLoader config,
                                           PortfolioService portfolioService,
                                           FinancialService financialService,
                                           BudgetService budgetService,
                                           BenefitService benefitService,
                                           AllocationService allocationService,
                                           WorklogService worklogService) {
        this.config = config;
        this.portfolioService = portfolioService;
        this.financialService = financialService;
        this.budgetService = budgetService;
        this.worklogService = worklogService;
        this.benefitService = benefitService;
        this.allocationService = allocationService;
        this.customFieldManager = ComponentAccessor.getCustomFieldManager();
    }

    @Override
    public Map getContextMap(ApplicationUser applicationUser, JiraHelper jiraHelper) {
        HashMap<String, Object> context = new HashMap<>();
        if (jiraHelper != null) {
            Issue issue = (Issue) jiraHelper.getContextParams().get("issue");
            if (issue != null) {
                context.put("issue", issue);
                context.put("numberTool", new NumberTool());
                context.put("mathTool", new MathTool());

                boolean viewPermission = budgetService.canViewBudget(issue.getKey());
                boolean editPermission = budgetService.canEditBudget(issue.getKey());

                context.put("view", viewPermission);
                context.put("edit", editPermission);
                if (viewPermission) {
                    String projectKey = issue.getProjectObject().getKey();

                    // Year - current or parameter
                    Integer year = DateUtil.getYear(new Date());
                    String finYearParameter = jiraHelper.getRequest().getParameter("finYear");
                    if (!Strings.isNullOrEmpty(finYearParameter)) {
                        try {
                            year = Integer.parseInt(finYearParameter);
                        } catch (Exception ex) {
                        }
                    }

                    List<FinancialCategoryBean> financialReport;
                    if (projectKey.equals(config.getJiraPREProject())) {
                        // Get Portfolio Project for epic and calculate epic number
                        Issue portfolioProjectIssue = (Issue) issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getPortfolioProjectFieldId()));
                        List<Issue> portfolioProjectEpics =
                                portfolioService.getPortfolioProjectEpics(portfolioProjectIssue.getKey());
                        int epicNumber = 0;
                        CustomField ordinalPriorityField = customFieldManager.getCustomFieldObject(config.getJiraOrdinalPriorityFieldId());
                        if (ordinalPriorityField != null) {
                            Double ordinalPriority = (Double) issue.getCustomFieldValue(ordinalPriorityField);
                            if (ordinalPriority != null) {
                                epicNumber = ordinalPriority.intValue();
                            }
                        }
                        financialReport = financialService.getFinancialReport(portfolioProjectIssue.getKey(), issue.getKey(), epicNumber, year);
                    } else {
                        financialReport = financialService.getFinancialReport(issue.getKey(), year);
                    }

                    context.put("financialReport", financialReport);

                    if (!financialReport.isEmpty()) {
                        Date lastUpdateDate = financialReport.get(0).getLastUpdateDate();
                        if (lastUpdateDate != null) {
                            context.put("lastUpdateDate", new SimpleDateFormat("dd.MM.yyyy HH:mm").format(lastUpdateDate));
                        }
                    }

                    double internalMd = 0;
                    for (InternalBudget b : budgetService.searchInternal(issue.getKey(), false, false)) {
                        internalMd += b.getMdBudgetValue();
                    }
                    WorklogModel worklog = worklogService.searchWorklog(issue.getId());
                    worklog.setPlan(internalMd);
                    context.put("worklog", worklog);
                    context.put("currentYear", DateUtil.getYear(new Date()));

                    // Benefits & Allocations
                    if (projectKey.equals(config.getJiraPRJProject()) || projectKey.equals(config.getJiraPREProject())) {
                        context.put("benefits", benefitService.getBenefits(issue.getKey()));
                        context.put("allocation", allocationService.getAllocation(issue.getKey()));
                    }


                }
            }
        }
        return context;
    }
}