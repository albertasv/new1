package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Entity;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.Unique;

public interface Dictionary extends Entity {

    @NotNull
    @Unique
    String getCode();

    @NotNull
    void setCode(String code);

    String getName();

    void setName(String name);
}
