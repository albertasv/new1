package ru.rosbank.jira.portfolio.action;

import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.bc.project.ProjectService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.ConstantsManager;
import com.atlassian.jira.exception.CreateException;
import com.atlassian.jira.issue.*;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.link.IssueLinkTypeManager;
import com.atlassian.jira.issue.priority.Priority;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.xsrf.RequiresXsrfCheck;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.ErrorCollection;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.utils.JiraUtil;

import javax.inject.Inject;

public class CreateQBRAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(CreateQBRAction.class);

    private final JiraAuthenticationContext authenticationContext;
    private final IssueService issueService;
    private final ProjectService projectService;
    private final ConstantsManager constantsManager;
    private final ConfigLoader config;
    private final IssueManager issueManager;
    private final CustomFieldManager cfManager;

    private String project;
    private String issue;
    private String summary;

    @Inject
    public CreateQBRAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport IssueService issueService,
            @ComponentImport ProjectService projectService,
            @ComponentImport ConstantsManager constantsManager,
            @ComponentImport ConfigLoader config) {
        this.authenticationContext = authenticationContext;
        this.issueService = issueService;
        this.projectService = projectService;
        this.constantsManager = constantsManager;
        this.config = config;
        this.issueManager = ComponentAccessor.getIssueManager();
        this.cfManager = ComponentAccessor.getCustomFieldManager();
    }

    @Override
    protected void doValidation() {
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        if (loggedInUser == null) {
            addErrorMessage("You don't have permission to view this team or it wasn't found.");
        }
    }

    @Override
    public String execute() throws Exception {
        return super.execute();
    }

    @RequiresXsrfCheck
    public String doObjective() throws Exception {
        if (!Strings.isNullOrEmpty(project)) {
            getRedirect("/secure/CreateIssueDetails!init.jspa?pid=" + project + "&issuetype=13001", false);
        }
        return SUCCESS;
    }

    @RequiresXsrfCheck
    public String doLtkr() throws Exception {
        //String redirect = getHttpRequest().getParameter("redirect");
        ApplicationUser user = authenticationContext.getLoggedInUser();

        Issue objective = issueManager.getIssueObject(issue);
        if (objective != null) {
            IssueInputParameters issueInputParameters = issueService.newIssueInputParameters();
            issueInputParameters.setSkipScreenCheck(true);


            // TODO
            issueInputParameters.setIssueTypeId("13002");
            issueInputParameters.setProjectId(objective.getProjectId());

            // Priority
            Priority priority = objective.getPriority();
            if (priority != null) {
                issueInputParameters.setPriorityId(priority.getId());
            }

            // Assignee && reporter TODO check
            issueInputParameters.setAssigneeId(user.getUsername());
            issueInputParameters.setReporterId(user.getUsername());
            issueInputParameters.setSummary(summary);

            IssueService.CreateValidationResult validationResult = issueService.validateCreate(user, issueInputParameters);
            ErrorCollection errorCollection = validationResult.getErrorCollection();
            IssueService.IssueResult issueResult;
            if (errorCollection.hasAnyErrors()) {
                LOG.error("LTKR create error: {}", JiraUtil.errors(errorCollection));
                for (String errorMessage : errorCollection.getErrorMessages()) {
                    addErrorMessage(errorMessage);
                }
                return ERROR;
            } else {
                issueResult = issueService.create(user, validationResult);
                MutableIssue ltkr = issueResult.getIssue();
                IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
                Long splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(config.getSplitIssueLinkType()).getId();
                try {
                    issueLinkManager.createIssueLink(
                            objective.getId(),
                            ltkr.getId(),
                            splitLinkType,
                            0l,
                            user
                    );
                } catch (CreateException cex) {
                    LOG.error("Issue link error - {}", cex);
                }
                getRedirect("/browse/" + ltkr.getKey(), false);
            }
        } else {
            addErrorMessage("You have to choose the Objective issue first.");
            return ERROR;
        }
        return SUCCESS;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }
}