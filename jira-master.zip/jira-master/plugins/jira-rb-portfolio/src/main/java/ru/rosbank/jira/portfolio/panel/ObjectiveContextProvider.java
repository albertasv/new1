package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.security.xsrf.XsrfTokenGenerator;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.apache.velocity.tools.generic.NumberTool;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.utils.JiraUtil;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.atlassian.jira.permission.ProjectPermissions.*;
import static com.google.common.base.Preconditions.checkNotNull;

public class ObjectiveContextProvider extends AbstractJiraContextProvider {

    private final ConfigLoader config;

    @Inject
    public ObjectiveContextProvider(@ComponentImport ConfigLoader config) {
        this.config = checkNotNull(config);
    }

    @Override
    public Map getContextMap(ApplicationUser appUser, JiraHelper jiraHelper) {
        HashMap<String, Object> context = new HashMap<>();
        context.put("esc", new EscapeTool());
        if (jiraHelper != null) {
            Issue issue = (Issue) jiraHelper.getContextParams().get("issue");
            if (issue != null) {
                context.put("config", config);
                context.put("numberTool", new NumberTool());

                List<Issue> ltkrs = JiraUtil.getIssuesWithJqlTemplates(appUser,
                        "type='Long-term Key result' AND issueFunction in linkedIssuesOf('key=%s', 'split to') ORDER BY key",
                        issue.getKey());
                context.put("ltkrs", ltkrs);
                context.put("objective", issue);
                context.put("atl_token", ComponentAccessor.getComponentOfType(XsrfTokenGenerator.class).generateToken());
                context.put("edit",
                        ComponentAccessor.getPermissionManager().hasPermission(ASSIGNABLE_USER, issue.getProjectObject(), appUser)
                                && ComponentAccessor.getPermissionManager().hasPermission(CREATE_ISSUES, issue.getProjectObject(), appUser));
            }
        }
        return context;
    }
}
