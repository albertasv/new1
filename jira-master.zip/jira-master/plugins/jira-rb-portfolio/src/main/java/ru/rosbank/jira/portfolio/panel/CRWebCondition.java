package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.plugin.webfragment.conditions.AbstractWebCondition;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.web.Condition;
import com.atlassian.plugin.web.baseconditions.BaseCondition;
import org.springframework.stereotype.Component;

@Component
public class CRWebCondition extends AbstractWebCondition implements Condition, BaseCondition {

    @Override
    public boolean shouldDisplay(ApplicationUser applicationUser, JiraHelper jiraHelper) {
        Project project = jiraHelper.getProject();
        if (project != null && "CRS".equals(project.getKey())) {
            return true;
        }
        return false;
    }
}
