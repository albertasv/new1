package ru.rosbank.jira.portfolio.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.portfolio.ao.Product;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductModel extends DictionaryModel {

    private String category;
    private String group;
    private String expenseType;
    private String budgetProductOn;
    private boolean budgetProduct;
    private String hiddenOn;
    private boolean hidden;

    public ProductModel() {
    }

    public ProductModel(
            int id,
            String code,
            String name,
            String category,
            String group,
            String expenseType,
            Boolean budgetProduct,
            Boolean hidden) {
        super(id, code, name);
        this.category = category;
        this.group = group;
        this.expenseType = expenseType;
        this.budgetProduct = Boolean.TRUE.equals(budgetProduct);
        this.hidden = Boolean.TRUE.equals(hidden);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(String expenseType) {
        this.expenseType = expenseType;
    }

    public String getBudgetProductOn() {
        return budgetProductOn;
    }

    public void setBudgetProductOn(String budgetProductOn) {
        this.budgetProductOn = budgetProductOn;
    }

    public boolean isBudgetProduct() {
        return budgetProduct;
    }

    public void setBudgetProduct(boolean budgetProduct) {
        this.budgetProduct = budgetProduct;
    }

    public String getHiddenOn() {
        return hiddenOn;
    }

    public void setHiddenOn(String hiddenOn) {
        this.hiddenOn = hiddenOn;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public static ProductModel convert(Product item) {
        return new ProductModel(
                item.getID(),
                item.getCode(),
                item.getName(),
                item.getCategory(),
                item.getGroup(),
                item.getExpenseType() == null ? null : item.getExpenseType().name(),
                item.getBudgetProduct(),
                item.getHidden());
    }
}
