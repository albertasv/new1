package ru.rosbank.jira.portfolio.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class FinancialUtil {

    private static final Logger LOG = LoggerFactory.getLogger(FinancialUtil.class);

    public static String trimContractName(String contractName) {
        return contractName.replaceAll("(\\r|\\n)", " ").trim();
    }

    private static BigDecimal scaleValue(BigDecimal value) {
        if (value == null || value.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    public static boolean isBigDecimalScaleEquals(BigDecimal bd1, BigDecimal bd2) {
        return isBigDecimalEquals(scaleValue(bd1), scaleValue(bd2));
    }

    public static boolean isBigDecimalEquals(BigDecimal bd1, BigDecimal bd2) {
        if (bd1 == null && bd2 == null) {
            return true;
        } else if (bd1 == null || bd2 == null) {
            return false;
        }
        return bd1.compareTo(bd2) == 0;
    }

    public static boolean isBigDecimalZero(BigDecimal bd) {
        return isBigDecimalEquals(bd, BigDecimal.ZERO);
    }


    public static boolean isCR(String code) {
        return (code != null && code.length() >= 6) &&
                (isCRContracted(code)
                        || isCRAccruals(code)
                        || isCRNotContracted(code));
    }

    public static boolean isCRContracted(String code) {
        return code.matches("С[0-9]{5}$");
    }

    public static boolean isCRNotContracted(String code) {
        return code.matches("Ч[0-9]{5}$");
    }

    public static boolean isCRAccruals(String code) {
        return code.matches("К[0-9]{5}$");
    }

    /**
     * Example, Р21194
     *
     * @param code
     * @return true if code of project or project's epic
     */
    public static boolean isProject(String code) {
        return (isProjectContracted(code)
                || isProjectAccruals(code)
                || isProjectNotContracted(code)
                || isProjectForecast(code));
    }

    public static boolean isProjectContracted(String code) {
        return code.matches("Р[0-9]{5}$");
    }

    public static boolean isProjectNotContracted(String code) {
        return code.matches("Б[0-9]{5}$");
    }

    public static boolean isProjectAccruals(String code) {
        return code.matches("О[0-9]{5}$");
    }

    public static boolean isProjectForecast(String code) {
        return code.matches("П[0-9]{5}$");
    }

    public static boolean isAgileTeam(String code) {
        return isAgileTeamContracted(code)
                || isAgileTeamNotContracted(code)
                || isAgileTeamAccruals(code);
    }

    /**
     * Example, Р21194-01
     *
     * @param code
     * @return true if code of project's epic
     */
    public static boolean isProjectEpic(String code) {
        return (isProjectEpicContracted(code)
                || isProjectEpicAccruals(code)
                || isProjectEpicNotContracted(code)
                || isProjectEpicForecast(code));
    }

    public static boolean isProjectEpicContracted(String code) {
        return code.matches("Р[0-9]{5}-[0-9]{2}$");
    }

    public static boolean isProjectEpicNotContracted(String code) {
        return code.matches("Б[0-9]{5}-[0-9]{2}$");
    }

    public static boolean isProjectEpicAccruals(String code) {
        return code.matches("О[0-9]{5}-[0-9]{2}$");
    }

    public static boolean isProjectEpicForecast(String code) {
        return code.matches("П[0-9]{5}-[0-9]{2}$");
    }

    public static boolean isAgileTeamNotContracted(String code) {
        return code.equalsIgnoreCase("ПРЗРАГ");
    }

    public static boolean isAgileTeamContracted(String code) {
        return code.equalsIgnoreCase("РРЗРАГ");
    }

    public static boolean isAgileTeamAccruals(String code) {
        return code.startsWith("АКРЛАГ");
    }

    /**
     * CR start with cyrillic С, PPM format - CRS-12345
     * Project start with cyrillic Р, PPM format - PRJ-21194
     *
     * @param code
     */
    public static String formatAsPortfolioIssue(String code) {

        String strIssue = calculateCodeIssue(code);

        if (strIssue == null) {
            int indUL = code.indexOf("-ЮЛ");
            if (indUL>-1){
                return cutAndCalculateCodeIssue(code, indUL);
            }
            indUL = code.indexOf("-ИН");
            if (indUL>-1){
                return cutAndCalculateCodeIssue(code, indUL);
            }
        }
        return strIssue;
    }
    public static String cutAndCalculateCodeIssue(String code, int indUL ) {
        String code_new = code.substring(0,indUL);
        if (code.length() > indUL + 3 ){
            code_new = code_new + code.substring(indUL + 3);
        }
        return calculateCodeIssue(code_new);
    }

    public static String calculateCodeIssue(String code) {
        if (isCR(code)) {
            // CR
            return "CRS-" + code.substring(1);
        } else if (isProject(code) || isProjectEpic(code)) {
            // Project
            return "PRJ-" + code.substring(1, 6);
        }
        return null;
    }

    public static Integer getProjectEpicNumber(String code) {
        if (isProjectEpic(code)) {
            try {
                return Integer.parseInt(code.substring(7, 9));
            } catch (Exception ex) {
                LOG.debug("Project epic code parse exception", ex);
            }
        }
        return null;
    }

    public static String safeSubstring(String string, int substringLength) {
        if (string.length() <= substringLength) {
            return string;
        }
        return string.substring(0, substringLength);
    }
}
