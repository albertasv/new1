package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.user.UserManager;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.ao.ExpenseType;
import ru.rosbank.jira.portfolio.ao.Product;
import ru.rosbank.jira.portfolio.model.ProductModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("productService")
public class ProductServiceImpl implements ProductService {

    private final ActiveObjects ao;
    private final UserManager userManager;

    @Inject
    public ProductServiceImpl(@ComponentImport ActiveObjects ao,
                              @ComponentImport UserManager userManager) {
        this.ao = checkNotNull(ao);
        this.userManager = checkNotNull(userManager);
    }

    @Override
    public List<Product> all() {
        return newArrayList(ao.find(Product.class, Query.select()));
    }

    @Override
    public int total() {
        return ao.count(Product.class, Query.select());
    }

    @Override
    public Product getByCode(String code) {
        Product[] dict = ao.find(Product.class, Query.select().where("\"CODE\" = ?", code));
        if (dict.length == 1) {
            return dict[0];
        }
        return null;
    }

    private static String SEARCH_QUERY = "(LOWER(\"CODE\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"CATEGORY\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"GROUP\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"EXPENSE_TYPE\" COLLATE \"en_US\") LIKE ?" +
            ")";
    private static String SEARCH_ORDER = "\"NAME\"";

    @Override
    public List<Product> search(String query, int limit, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(Product.class,
                    Query.select()
                            .order(SEARCH_ORDER)
                            .limit(limit)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(Product.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery)
                .order(SEARCH_ORDER)
                .limit(limit)
                .offset(offset)
        ));
    }

    private static String SEARCH_BUDGET_PRODUCT_QUERY = "\"BUDGET_PRODUCT\" = ?";
    private static String SEARCH_BUDGET_ORDER = "\"CATEGORY\", \"GROUP\", \"EXPENSE_TYPE\"";

    @Override
    public List<Product> search(boolean budgetProduct, String query, int limit, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(Product.class,
                    Query.select()
                            .where(SEARCH_BUDGET_PRODUCT_QUERY, budgetProduct)
                            .order(SEARCH_BUDGET_ORDER)
                            .limit(limit)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(Product.class, Query.select()
                .where(SEARCH_QUERY + " AND " + SEARCH_BUDGET_PRODUCT_QUERY, likeQuery, likeQuery,
                        likeQuery, likeQuery, likeQuery, budgetProduct)
                .order(SEARCH_BUDGET_ORDER)
                .limit(limit)
                .offset(offset)
        ));
    }

    @Override
    public int total(String query) {
        if (Strings.isNullOrEmpty(query)) {
            return total();
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(Product.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery));
    }

    @Override
    public Product add(ProductModel data) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("CODE", data.getCode())
                .put("NAME", data.getName())
                .put("CATEGORY", data.getCategory())
                .put("GROUP", data.getGroup())
                .put("EXPENSE_TYPE", ExpenseType.getValue(data.getExpenseType()))
                .put("BUDGET_PRODUCT", "on".equalsIgnoreCase(data.getBudgetProductOn()) || "true".equalsIgnoreCase(data.getBudgetProductOn()))
                .put("HIDDEN", "on".equalsIgnoreCase(data.getHiddenOn()) || "true".equalsIgnoreCase(data.getHiddenOn()));
        return ao.create(Product.class, mapBuilder.build());
    }

    @Override
    public Product update(int id, ProductModel data) {
        Product[] dict = ao.find(Product.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            Product product = dict[0];
            String name = data.getName();
            if (name != null) {
                product.setName(name);
            }
            String category = data.getCategory();
            if (category != null) {
                product.setCategory(category);
            }
            String group = data.getGroup();
            if (group != null) {
                product.setGroup(group);
            }
            String expenseType = data.getExpenseType();
            if (expenseType != null) {
                product.setExpenseType(ExpenseType.getValue(expenseType));
            }
            product.setBudgetProduct("on".equalsIgnoreCase(data.getBudgetProductOn()) || "true".equalsIgnoreCase(data.getBudgetProductOn()));
            product.setHidden("on".equalsIgnoreCase(data.getHiddenOn()) || "true".equalsIgnoreCase(data.getHiddenOn()));
            product.save();
            return product;
        }
        return null;
    }

    @Override
    public void delete(int id) {
        Product[] dict = ao.find(Product.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            ao.delete(dict[0]);
        }
    }
}
