package ru.rosbank.jira.portfolio.model;

import java.util.Date;

public enum ExecutionTeamStatus {
    ASSESSMENT("Assessment"),
    ACTIVE("Active"),
    REGISTRATION("Registration"),
    ARCHIVE("Archive");

    ExecutionTeamStatus(String name) {
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public static ExecutionTeamStatus getStatus(String name) {
        for (ExecutionTeamStatus value : ExecutionTeamStatus.values()) {
            if (value.getName().equalsIgnoreCase(name)) {
                return value;
            }
        }
        return ARCHIVE;
    }

    public static ExecutionTeamStatus getStatus(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
            if (startDate.after(new Date())) {
                return ASSESSMENT;
            }
            if (endDate.before(new Date())) {
                return ARCHIVE;
            }
        }
        return ACTIVE;
    }
}
