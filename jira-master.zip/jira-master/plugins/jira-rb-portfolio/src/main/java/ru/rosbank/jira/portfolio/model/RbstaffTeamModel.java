package ru.rosbank.jira.portfolio.model;

import java.util.Date;

public class RbstaffTeamModel {

    private int digitTeamId;
    private String name;
    private String teamType;
    private Date startDate;
    private Date endDate;
    private String costDigit;

    public int getDigitTeamId() {
        return digitTeamId;
    }

    public void setDigitTeamId(int digitTeamId) {
        this.digitTeamId = digitTeamId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeamType() {
        return teamType;
    }

    public void setTeamType(String teamType) {
        this.teamType = teamType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCostDigit() {
        return costDigit;
    }

    public void setCostDigit(String costDigit) {
        this.costDigit = costDigit;
    }

    @Override
    public String toString() {
        return "RbstaffTeamModel{" +
                "digitTeamId=" + digitTeamId +
                ", name='" + name + '\'' +
                ", teamType='" + teamType + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", costDigit='" + costDigit + '\'' +
                '}';
    }
}
