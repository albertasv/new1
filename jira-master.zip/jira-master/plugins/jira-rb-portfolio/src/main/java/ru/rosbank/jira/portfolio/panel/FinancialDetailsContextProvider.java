package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleActors;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.PluginParseException;
import com.atlassian.plugin.spring.scanner.annotation.imports.JiraImport;
import com.atlassian.plugin.web.ContextProvider;
import com.google.common.collect.Maps;

import javax.inject.Inject;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FinancialDetailsContextProvider implements ContextProvider {

    @JiraImport
    private final PermissionManager permissionManager;

    @Inject
    public FinancialDetailsContextProvider(PermissionManager permissionManager) {
        this.permissionManager = permissionManager;
    }

    public void init(Map params) throws PluginParseException {
    }

    public Map getContextMap(Map context) {
        ApplicationUser user = (ApplicationUser) context.get("user");
        if (user == null) {
            String username = (String) context.get("username");
            user = this.getUserManager().getUserByName(username);
        }

        Map<String, Object> ctx = Maps.newHashMap();
        ctx.put("user", user);
        return ctx;
    }

    private UserManager getUserManager() {
        return ComponentAccessor.getUserManager();
    }

    private List<ApplicationUser> getMembers(Project project, String role) {
        ProjectRole admRole = ComponentAccessor.getComponent(ProjectRoleManager.class).getProjectRole(role);
        ProjectRoleActors actors = ComponentAccessor.getComponent(ProjectRoleManager.class).getProjectRoleActors(admRole, project);
        return actors.getUsers().stream().sorted(Comparator.comparing(ApplicationUser::getDisplayName)).collect(Collectors.toList());
    }
}

