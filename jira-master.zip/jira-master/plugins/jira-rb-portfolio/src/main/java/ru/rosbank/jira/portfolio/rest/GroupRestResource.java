package ru.rosbank.jira.portfolio.rest;

import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.exception.AddException;
import com.atlassian.jira.exception.PermissionException;
import com.atlassian.jira.exception.RemoveException;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.portfolio.ao.DomainUserRole;
import ru.rosbank.jira.portfolio.ao.UserRoleType;
import ru.rosbank.jira.portfolio.api.BudgetService;
import ru.rosbank.jira.portfolio.api.DomainService;
import ru.rosbank.jira.portfolio.api.DomainUserRoleService;
import ru.rosbank.jira.portfolio.model.MessageModel;
import ru.rosbank.jira.portfolio.model.UserModel;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.*;
import java.util.stream.Collectors;

import static ru.rosbank.jira.portfolio.ao.UserRoleType.PORTFOLIO_GROUPS;

@Component
@Path("/group")
public class GroupRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(GroupRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final UserUtil userUtil;
    private final UserManager userManager;
    private final GroupManager groupManager;
    private final BudgetService budgetService;
    private final DomainService domainService;
    private final DomainUserRoleService domainUserRoleService;

    public GroupRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            BudgetService budgetService,
            DomainService domainService,
            DomainUserRoleService domainUserRoleService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.userUtil = ComponentAccessor.getUserUtil();
        this.userManager = ComponentAccessor.getUserManager();
        this.groupManager = ComponentAccessor.getGroupManager();
        this.budgetService = budgetService;
        this.domainService = domainService;
        this.domainUserRoleService = domainUserRoleService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/{groupAlias}")
    public Response getGroupMembers(@PathParam("groupAlias") String groupAlias, @QueryParam("q") String query) {
        UserRoleType userRoleType = UserRoleType.getByAlias(groupAlias);
        if (userRoleType != null) {
            Map<String, List<String>> domainUserRoleMap = new HashMap<>();
            List<DomainUserRole> domainUserRoles = domainUserRoleService.search(userRoleType);
            for (DomainUserRole domainUserRole : domainUserRoles) {
                String username = domainUserRole.getUsername();
                String domain = domainUserRole.getDomain();
                List<String> domains = domainUserRoleMap.get(username);
                if (domains == null) {
                    domains = new ArrayList<>();
                    domainUserRoleMap.put(username, domains);
                }
                domains.add(domain);
            }
            return Response.ok(groupManager.getUsersInGroup(PORTFOLIO_GROUPS.get(groupAlias))
                    .stream().sorted(Comparator.comparing(ApplicationUser::getDisplayName))
                    .map(appUser -> {
                        List<String> domains = domainUserRoleMap.get(appUser.getUsername());
                        return new UserModel(appUser, domains == null ? null :
                                domains.stream().collect(Collectors.joining(";")));
                    })
                    .filter(u -> (Strings.isNullOrEmpty(query)
                            || (u.getDomain() != null && u.getDomain().contains(query))))
                    .collect(Collectors.toList())).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/{groupAlias}")
    public Response addGroupMember(@PathParam("groupAlias") String groupAlias, UserModel userModel) {
        UserRoleType userRoleType = UserRoleType.getByAlias(groupAlias);
        if (userRoleType != null) {
            String groupName = userRoleType.getGroup();
            if (canEdit() && groupName != null) {
                ApplicationUser user = userManager.getUserByName(userModel.getUsername());
                if (user == null) {
                    return Response.status(Response.Status.NOT_FOUND).build();
                }
                Group group = groupManager.getGroup(groupName);
                try {
                    userUtil.addUserToGroup(group, user);
                    String domain = userModel.getDomain();
                    if (domain != null) {
                        domainUserRoleService.add(user.getUsername(), domain, userRoleType);
                    }

                    return Response.ok(new UserModel(user, domain)).build();
                } catch (PermissionException | AddException ex) {
                    LOG.error("Add group member error {}: {}", groupAlias, ex);
                    return Response.status(Response.Status.UNAUTHORIZED).build();
                }
            }
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("/{groupAlias}/{id}")
    public Response removeGroupMember(@PathParam("groupAlias") String groupAlias, @PathParam("id") long id) {
        if (groupAlias != null) {
            String groupName = PORTFOLIO_GROUPS.get(groupAlias);
            if (canEdit() && groupName != null) {
                ApplicationUser user = userManager.getUserById(id).get();
                Group group = groupManager.getGroup(groupName);
                try {
                    userUtil.removeUserFromGroup(group, user);
                    domainUserRoleService.delete(user.getUsername(), UserRoleType.getByAlias(groupAlias));
                    return Response.ok(new UserModel(id)).build();
                } catch (PermissionException | RemoveException ex) {
                    LOG.error("Remove group member error {}: {}", groupAlias, ex);
                    return Response.status(Response.Status.UNAUTHORIZED).build();
                }
            }
            return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    private boolean canEdit() {
        return budgetService.isPMO();
    }
}