package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.Financial;
import ru.rosbank.jira.portfolio.model.CostCenterModel;
import ru.rosbank.jira.portfolio.model.ProductModel;
import ru.rosbank.jira.portfolio.model.bean.FinancialCategoryBean;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

@Transactional
public interface FinancialService {
    Financial[] searchForDetails(String issueKey);

    List<FinancialCategoryBean> getFinancialReport(String issueKey);

    List<FinancialCategoryBean> getFinancialReport(String issueKey, Integer year);

    List<FinancialCategoryBean> getFinancialReport(String issueKey, String projectEpicIssueKey, Integer projectEpicNumber, Integer year);

    void loadData(int year) throws RemoteException;

    ProductModel getCashedProduct(Map<String, ProductModel> products, String productCode);

    CostCenterModel getCashedCostCenter(Map<String, CostCenterModel> costCenters, String costCenterCode);
}
