package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.ao.Allocation;
import ru.rosbank.jira.portfolio.model.AllocationModel;
import ru.rosbank.jira.portfolio.model.bean.AllocationBean;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService
@Named("allocationService")
public class AllocationServiceImpl implements AllocationService {

    private final ActiveObjects ao;

    @Inject
    public AllocationServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public Allocation[] search(String issueKey, boolean initial) {
        return ao.find(Allocation.class,
                Query.select()
                        .where("ISSUE = ? AND INITIAL = ?", issueKey, initial)
                        .order("DOMAIN, ALLOCATION_TYPE"));
    }

    @Override
    public Allocation add(String username, String issueKey, AllocationModel dataModel, boolean initial) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("ISSUE", issueKey)
                .put("DOMAIN", dataModel.getDomain())
                .put("ALLOCATION_TYPE", dataModel.getAllocationType())
                .put("ALLOCATION_VALUE", dataModel.getAllocationValue())
                .put("INITIAL", initial)
                .put("LAST_UPDATED_BY", username)
                .put("LAST_UPDATE_DATE", new Date());

        if (dataModel.getComment() != null) {
            mapBuilder.put("COMMENT", dataModel.getComment());
        }

        if (dataModel.getInitial() != null) {
            mapBuilder.put("INITIAL", dataModel.getInitial());
        }

        return ao.create(Allocation.class, mapBuilder.build());
    }

    @Override
    public void delete(int id) {
        Allocation[] allocation = ao.find(Allocation.class, Query.select().where("ID = ?", id));
        for (Allocation b : allocation) {
            ao.delete(b);
        }
    }

    @Override
    public AllocationBean getAllocation(String issueKey) {
        AllocationBean res = new AllocationBean();
        for (Allocation allocation : search(issueKey, false)) {
            res.addAllocation(allocation);
        }
        return res;
    }
}
