package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.parser.JqlParseException;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import org.apache.axis2.AxisFault;
import org.apache.axis2.client.Options;
import org.apache.axis2.transport.http.HTTPAuthenticator;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.impl.httpclient3.HttpTransportPropertiesImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.utils.FinancialUtil;
import ru.rosbank.jira.portfolio.ao.*;
import ru.rosbank.jira.portfolio.model.CostCenterModel;
import ru.rosbank.jira.portfolio.model.FinancialType;
import ru.rosbank.jira.portfolio.model.Multiplier;
import ru.rosbank.jira.portfolio.model.ProductModel;
import ru.rosbank.jira.portfolio.model.bean.FinancialCategoryBean;
import ru.rosbank.jira.portfolio.model.bean.FinancialReportBean;
import sbu.SBU_HPPPMStub;

import javax.inject.Inject;
import javax.inject.Named;
import java.rmi.RemoteException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;
import static ru.rosbank.jira.portfolio.utils.FinancialUtil.*;

@ExportAsService
@Named("financialService")
public class FinancialServiceImpl implements FinancialService {

    private static final Logger LOG = LoggerFactory.getLogger(FinancialServiceImpl.class);

    private static final String DEFAULT_PRODUCT_EXPENSE_TYPE = ExpenseType.OPEX.name();
    private static final String DEFAULT_PRODUCT_NAME = "Not Specified";
    private static final String DEFAULT_PRODUCT_CATEGORY = "OTHER";
    private static final String DEFAULT_PRODUCT_GROUP = "OTHER";

    private static final String DEFAULT_COST_CENTER_NAME = "UNKNOWN";

    private final ActiveObjects ao;
    private final ConfigLoader config;
    private final UserManager userManager;
    private final ProductService productService;
    private final CostCenterService costCenterService;

    @Inject
    public FinancialServiceImpl(
            @ComponentImport ActiveObjects ao,
            @ComponentImport ConfigLoader config,
            ProductService productService,
            CostCenterService costCenterService) {
        this.ao = checkNotNull(ao);
        this.config = checkNotNull(config);
        this.userManager = ComponentAccessor.getUserManager();
        this.productService = productService;
        this.costCenterService = costCenterService;
    }

    @Override
    public Financial[] searchForDetails(String issueKey) {
        return ao.find(Financial.class, Query.select()
                .where("\"FINANCIAL_VALUE\" > 0 AND \"ISSUE\" = ?", issueKey)
                .order("\"FINANCIAL_DATE\" DESC, \"PRODUCT_CODE\", \"FINANCIAL_TYPE\""));
    }


    @Override
    public List<FinancialCategoryBean> getFinancialReport(String issueKey) {
        Integer year = DateUtil.getYear(new Date());
        return getFinancialReport(issueKey, year);
    }

    @Override
    public List<FinancialCategoryBean> getFinancialReport(String issueKey, Integer year) {
        return getFinancialReport(issueKey, null, null, year);
    }

    @Override
    public List<FinancialCategoryBean> getFinancialReport(String issueKey, String projectEpicIssueKey, Integer projectEpicNumber, Integer year) {
        LOG.debug("Financial report for issue: {}, epic: {}, year: {}", issueKey, projectEpicNumber, year);
        Long entityKey = null;
        long multiplier = Multiplier.MRUR.getMultiplier();

        Financial[] financialReport = projectEpicNumber == null ?
                ao.find(Financial.class, Query.select().where("ISSUE = ?", issueKey)) :
                ao.find(Financial.class, Query.select().where("ISSUE = ? AND \"PROJECT_EPIC\" = ?", issueKey, projectEpicNumber));

        ExternalBudget[] externalBudgets = ao.find(ExternalBudget.class, Query.select()
                .where("ISSUE = ? AND INITIAL = false AND CURRENT_YEAR = false", projectEpicIssueKey == null ? issueKey : projectEpicIssueKey));

        LOG.debug("Entity {} -> finReport: {}, budget: {}", entityKey, financialReport.length, externalBudgets.length);

        // Group by Report Lines
        String portfolioIssueKey = "";
        Map<FinancialReportBean, FinancialReportBean> reportMap = new HashMap<>();
        Map<String, ProductModel> productMap = new HashMap<>();
        // Fin report processing
        Date lastUpdateDate = null;
        for (Financial financial : financialReport) {
            Date finLastUpdateDate = financial.getLastUpdateDate();
            if (lastUpdateDate == null || (finLastUpdateDate != null && lastUpdateDate.before(finLastUpdateDate))) {
                lastUpdateDate = finLastUpdateDate;
            }

            ProductModel product = getCashedProduct(productMap, financial.getProductCode());
            //log.debug("@@@ product.getCode:"+product.getCode());
            //log.debug("@@@ product.getCategory:"+product.getCategory());
            //log.debug("@@@ product.getGroup:"+product.getGroup());
            //log.debug("@@@ product.getExpenseType:"+product.getExpenseType());


            //JIRA-1629 Исключить из финансовой сводки категорию HR
            // Скрываем Hidden продукты, остальные в OOHER | OPEX
            if (product.isHidden()) {
                //log.debug("@@@ product.isHidden() = true");
                continue;
            }

            portfolioIssueKey = financial.getIssue();
            //log.debug("@@@ portfolioIssueKey:"+portfolioIssueKey);

            FinancialReportBean mapKey = new FinancialReportBean(portfolioIssueKey,
                    product.getCategory(),
                    product.getGroup(),
                    ExpenseType.getValue(product.getExpenseType()),
                    year);

            FinancialReportBean mapValue;
            if (reportMap.containsKey(mapKey)) {
                mapValue = reportMap.get(mapKey);
            } else {
                mapValue = mapKey;
                reportMap.put(mapKey, mapValue);
            }
            //log.debug("@@@ addValue mapValue:"+mapValue);
            mapValue.addValue(financial, multiplier);
        }

        // External budget processing
        for (ExternalBudget externalBudget : externalBudgets) {
            ProductModel product = getCashedProduct(productMap, externalBudget.getProduct());

            FinancialReportBean mapKey = new FinancialReportBean(portfolioIssueKey,
                    product.getCategory(),
                    product.getGroup(),
                    ExpenseType.getValue(product.getExpenseType()),
                    year);
            FinancialReportBean mapValue;
            if (reportMap.containsKey(mapKey)) {
                mapValue = reportMap.get(mapKey);
            } else {
                mapValue = mapKey;
                reportMap.put(mapKey, mapValue);
            }
            //log.debug("@@@ addValue mapValue:"+mapValue);
            mapValue.addValue(externalBudget, multiplier);

        }

        // Group by category
        Map<FinancialCategoryBean, FinancialCategoryBean> categoryMap = new HashMap<>();
        // Add Total category
        FinancialCategoryBean totalCategory = new FinancialCategoryBean(portfolioIssueKey, "TOTAL", year);
        categoryMap.put(totalCategory, totalCategory);

        // Grouping
        for (FinancialReportBean finReportBean : reportMap.values()) {
            FinancialCategoryBean mapKey = new FinancialCategoryBean(portfolioIssueKey, finReportBean.getCategory(), year);
            FinancialCategoryBean mapValue;
            if (categoryMap.containsKey(mapKey)) {
                mapValue = categoryMap.get(mapKey);
            } else {
                mapValue = mapKey;
                categoryMap.put(mapKey, mapValue);
            }
            mapValue.getReportLines().add(finReportBean);
        }

        for (FinancialCategoryBean categoryValue : categoryMap.values()) {
            categoryValue.summarize();
            totalCategory.total(categoryValue);
        }

        List<FinancialCategoryBean> res = new ArrayList<>();
        res.addAll(categoryMap.values());
        Collections.sort(res);

        // set lastUpdateDate info for first line
        if (!res.isEmpty()) {
            res.get(0).setLastUpdateDate(lastUpdateDate);
        }

        return res;
    }

    @Override
    public void loadData(int year) throws RemoteException {
        LOG.info("------------ Start loading financial data for {}", year);

        String wsLocation = config.getSbuWsLocation();
        String username = config.getSbuLogin();
        String password = config.getSbuPassword();

        String financialSeviceName = year == Calendar.getInstance().get(Calendar.YEAR)
                ? ServiceNames.CURRENT_YEAR_SBU_COST_CENTERS_UPDATER.toString()
                : ServiceNames.PREVIOUS_YEAR_SBU_COST_CENTERS_UPDATER.toString();
        SBU_HPPPMStub stub;
        try {
            stub = new SBU_HPPPMStub(wsLocation);
        } catch (AxisFault axisFault) {
            LOG.error("Init stub exception", axisFault);
            throw axisFault;
        }

        LOG.info("Start SBU web service data fetching");
        HTTPAuthenticator auth = new HttpTransportPropertiesImpl.Authenticator();
        auth.setUsername(username);
        auth.setPassword(password);
        auth.setPreemptiveAuthentication(true);
        Options options = stub._getServiceClient().getOptions();
        options.setTimeOutInMilliSeconds(1000);
        options.setProperty(HTTPConstants.AUTHENTICATE, auth);

        SBU_HPPPMStub.GetBudgetReport getBudgetReport = new SBU_HPPPMStub.GetBudgetReport();
        getBudgetReport.setDateYear(DateUtil.getDate(year));

        try {
            SBU_HPPPMStub.GetBudgetReportResponse resp = stub.getBudgetReport(getBudgetReport);
            SBU_HPPPMStub.ReportBudgetItems result = resp.get_return();

            SBU_HPPPMStub.ReportBudgetItem[] reportBudgetItem = result.getReportBudgetItem();
            LOG.info("Finish SBU web service data fetching");

            LOG.info("Start SBU data processing");
            int index = 0;
            int total = reportBudgetItem.length;
            if (total > 0) {
                // Set synced = false for previous data for loadDate year
                updateSyncedFinancial(year, false);
                LOG.debug("Synced = false sbu data for year {}", year);
            } else {
                LOG.error("There is no WS sbu data for year {}", year);
                return;
            }

            int progress = 1;
            for (SBU_HPPPMStub.ReportBudgetItem budgetItem : reportBudgetItem) {
                if (index / total == progress) {
                    LOG.info("Loading progress {}%", progress);
                    progress++;
                }

                // SBU project code
                String sbuProject = budgetItem.getProject().trim();
                String sbuProject_new = sbuProject;
                if (sbuProject.indexOf("-ЮЛ")>-1){
                    sbuProject_new = sbuProject.substring(0,sbuProject.indexOf("-ЮЛ"));
                }
                if (sbuProject.indexOf("-ИН")>-1){
                    sbuProject_new = sbuProject.substring(0,sbuProject.indexOf("-ИН"));
                }


                // Cost Center Code
                String costCenter = budgetItem.getCostCentre();

                // Search Portfolio issue
                String portfolioIssueKey = null;
                Integer projectEpicNumber = null;

                if (isAgileTeam(sbuProject)) {
                    // TODO Load Agile team data, if it's necessary
                } else {
                    Issue portfolioIssue = getPortfolioIssue(sbuProject);

                    if (portfolioIssue != null) {
                        portfolioIssueKey = portfolioIssue.getKey();
                        if (FinancialUtil.isProjectEpic(sbuProject_new)) {
                            projectEpicNumber = FinancialUtil.getProjectEpicNumber(sbuProject_new);
                        }
                    }
                }

                String product = safeSubstring(budgetItem.getProduct(), 6);
                // Expense type
                ExpenseType expType = ExpenseType.getValue(budgetItem.getCostCategory());
                // Contract - code and type
                String contract = budgetItem.getContract();
                // Payer
                String payer = budgetItem.getPayer();
                Date period = budgetItem.getPeriod();

                FinancialType planType = null;

                if ((isCRNotContracted(sbuProject_new)
                        || isProjectNotContracted(sbuProject_new))
                        || isProjectEpicNotContracted(sbuProject_new)
                        || isAgileTeamNotContracted(sbuProject_new)) {
                    planType = FinancialType.NOT_CONTRACTED;
                } else if (isProjectForecast(sbuProject_new)
                        || isProjectEpicForecast(sbuProject_new)) {
                    planType = FinancialType.FORECAST;
                } else if (isCRContracted(sbuProject_new)
                        || isProjectContracted(sbuProject_new)
                        || isProjectEpicContracted(sbuProject_new)
                        || isAgileTeamContracted(sbuProject_new)) {
                    planType = FinancialType.CONTRACTED;
                } else if (isCRAccruals(sbuProject_new)
                        || isProjectAccruals(sbuProject_new)
                        || isProjectEpicAccruals(sbuProject_new)
                        || isAgileTeamAccruals(sbuProject_new)) {
                    planType = FinancialType.ACCRUAL;
                } else {
                    planType = FinancialType.UNKNOWN;
                }

                if (planType != null) {
                    float fact = budgetItem.getSpent();
                    updateFinancial(portfolioIssueKey, projectEpicNumber,
                            sbuProject, costCenter, product, expType,
                            contract, payer,
                            (planType == FinancialType.ACCRUAL) ? FinancialType.ACCRUAL_FACT : FinancialType.FACT, period, fact);
                    float plan = budgetItem.getИтогоПланСУчетомОжидаемыхКорректировокБюджета();
                    updateFinancial(portfolioIssueKey, projectEpicNumber,
                            sbuProject, costCenter, product, expType,
                            contract, payer,
                            planType, period, plan);

                    LOG.debug("BudgetItem;{};{};{};{};{};{};",
                            sbuProject,
                            portfolioIssueKey,
                            product,
                            new SimpleDateFormat().format(period),
                            new DecimalFormat("#.##").format(fact),
                            new DecimalFormat("#.##").format(plan)
                    );
                }

                float carryOver = budgetItem.getCarryOver();
                if (carryOver > 0) {
                    if (isCRContracted(sbuProject_new) ||
                            isProjectContracted(sbuProject_new) ||
                            isAgileTeamContracted(sbuProject_new)
                    ) {
                        updateFinancial(portfolioIssueKey, projectEpicNumber,
                                sbuProject, costCenter, product, expType,
                                contract, payer, FinancialType.CARRY_OVER_CONTRACTED, period, carryOver);
                    } else if (isCRNotContracted(sbuProject_new) ||
                            isProjectNotContracted(sbuProject_new) ||
                            isAgileTeamNotContracted(sbuProject_new)) {
                        updateFinancial(portfolioIssueKey, projectEpicNumber,
                                sbuProject, costCenter, product, expType,
                                contract, payer, FinancialType.CARRY_OVER_NOT_CONTRACTED, period, carryOver);
                    }

                }
                index++;
            }


            LOG.debug("Removing sbu data synced = false for year {}", year);
            removeFinancial(year);
            LOG.info("Finish SBU data processing");
        } catch (RemoteException rex) {
            LOG.error("Get budgetItem exception", rex);
            throw rex;
        }
        LOG.info("------------ Finish loading");
    }

    @Override
    public ProductModel getCashedProduct(Map<String, ProductModel> products, String productCode) {
        ProductModel productModel = products.get(productCode);
        if (productModel == null) {
            Product p = productService.getByCode(productCode);
            String category = ((p == null || Strings.isNullOrEmpty(p.getCategory())) ? DEFAULT_PRODUCT_CATEGORY : p.getCategory()).trim();
            String group = ((p == null || Strings.isNullOrEmpty(p.getGroup())) ? DEFAULT_PRODUCT_GROUP : p.getGroup()).trim();

            if (p != null) {
                productModel = ProductModel.convert(p);

            } else {
                productModel = new ProductModel(
                        -1,
                        productCode,
                        DEFAULT_PRODUCT_NAME,
                        category, group,
                        DEFAULT_PRODUCT_EXPENSE_TYPE,
                        false,
                        false);
            }
            products.put(productCode, productModel);
        }
        return productModel;
    }

    @Override
    public CostCenterModel getCashedCostCenter(Map<String, CostCenterModel> costCenters, String costCenterCode) {
        CostCenterModel ccModel = costCenters.get(costCenterCode);
        if (ccModel == null) {
            CostCenter cc = costCenterService.getByCode(costCenterCode);

            if (cc != null) {
                ccModel = new CostCenterModel(cc.getID(), cc.getCode(), cc.getName());
                ccModel.setB1(cc.getB1());
                ccModel.setB1Name(cc.getB1Name());
                ccModel.setDomain(cc.getDomain());
                ccModel.setCustomerDomain(cc.getCustomerDomain());

            } else {
                ccModel = new CostCenterModel(-1, costCenterCode, DEFAULT_COST_CENTER_NAME);
            }
            costCenters.put(costCenterCode, ccModel);
        }
        return ccModel;
    }

    private Issue getPortfolioIssue(String code) {
        String syncUserLogin = config.getJiraPpmSyncUser();
        ApplicationUser syncUser = userManager.getUserByName(syncUserLogin);
        String jqlTemplate = "key = '%s'";

        String portfolioIssueKey = formatAsPortfolioIssue(code);
        if (config.getPpmCodeFieldId() != null && !Strings.isNullOrEmpty(portfolioIssueKey)) {
            String jql = String.format(jqlTemplate, portfolioIssueKey);
            try {
                com.atlassian.query.Query query = ComponentAccessor.getComponent(JqlQueryParser.class).parseQuery(jql);
                SearchResults<Issue> searchResult = ComponentAccessor.getComponent(SearchService.class)
                        .search(syncUser, query, PagerFilter.newPageAlignedFilter(0, 2));
                int total = searchResult.getTotal();
                if (total == 1) {
                    return searchResult.getResults().get(0);
                }
            } catch (JqlParseException | SearchException e) {
                LOG.error("Get portfolio issue exception {}", code);
            }
        }
        return null;
    }

    private void updateSyncedFinancial(int year, boolean synced) {
        ao.executeInTransaction(() -> {
            Financial[] fs = ao.find(Financial.class, "extract(YEAR FROM \"FINANCIAL_DATE\") = ?", year);
            for (Financial f : fs) {
                f.setSynced(synced);
                f.save();
            }
            return fs;
        });
    }

    private void removeFinancial(int year) {
        ao.deleteWithSQL(Financial.class, "\"SYNCED\" = false AND extract(YEAR FROM \"FINANCIAL_DATE\") = ?", year);
    }

    private void updateFinancial(String issueKey, Integer projectEpicNumber,
                                 String sbuCode, String costCenterCode, String productCode, ExpenseType expType,
                                 String contractCode, String payerCode,
                                 FinancialType finType, Date finDate, float finValue) {


        Financial[] financials = ao.find(Financial.class, Query.select()
                .where("\"SBU_PROJECT_CODE\" = ? AND \"COST_CENTER_CODE\" = ? AND \"CONTRACT_CODE\" = ?" +
                                " AND \"PAYER_CODE\" = ? AND \"FINANCIAL_TYPE\" = ? AND \"FINANCIAL_DATE\" = ?" +
                                " AND \"PRODUCT_CODE\" = ?"
                        , sbuCode, costCenterCode, contractCode, payerCode, finType, finDate, productCode));

        if (financials == null || financials.length == 0) {
            ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                    .put("CREATION_DATE", new Date())
                    .put("LAST_UPDATE_DATE", new Date())
                    .put("SBU_PROJECT_CODE", sbuCode)
                    .put("COST_CENTER_CODE", costCenterCode)
                    .put("PRODUCT_CODE", productCode)
                    .put("PAYER_CODE", payerCode)
                    .put("CONTRACT_CODE", contractCode)
                    .put("FINANCIAL_TYPE", finType)
                    .put("FINANCIAL_DATE", finDate)
                    .put("FINANCIAL_VALUE", Double.valueOf(finValue))
                    .put("SYNCED", true);
            if (issueKey != null) {
                mapBuilder.put("ISSUE", issueKey);
            }
            if (expType != null) {
                mapBuilder.put("EXPENSE_TYPE", expType);
            }
            if (projectEpicNumber != null) {
                mapBuilder.put("PROJECT_EPIC", projectEpicNumber);
            }

            ao.create(Financial.class, mapBuilder.build());
        } else {
            Financial financial = financials[0];
            financial.setIssue(issueKey);
            financial.setLastUpdateDate(new Date());
            financial.setFinancialValue(Double.valueOf(finValue));
            financial.setFinancialType(finType.name());
            financial.setSynced(true);
            financial.save();
        }
    }

}
