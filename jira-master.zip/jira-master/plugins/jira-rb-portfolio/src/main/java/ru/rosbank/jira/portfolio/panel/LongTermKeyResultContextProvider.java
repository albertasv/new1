package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.apache.velocity.tools.generic.NumberTool;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.utils.JiraUtil;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.atlassian.jira.permission.ProjectPermissions.EDIT_ISSUES;
import static com.google.common.base.Preconditions.checkNotNull;

public class LongTermKeyResultContextProvider extends AbstractJiraContextProvider {

    private final ConfigLoader config;

    @Inject
    public LongTermKeyResultContextProvider(@ComponentImport ConfigLoader config) {
        this.config = checkNotNull(config);
    }

    @Override
    public Map getContextMap(ApplicationUser appUser, JiraHelper jiraHelper) {
        HashMap<String, Object> context = new HashMap<>();
        context.put("esc", new EscapeTool());
        if (jiraHelper != null) {
            Issue issue = (Issue) jiraHelper.getContextParams().get("issue");
            if (issue != null) {
                context.put("config", config);
                context.put("numberTool", new NumberTool());

                List<Issue> objectives = JiraUtil.getIssuesWithJqlTemplates(appUser,
                        "type=Objective AND issueFunction in linkedIssuesOf('key=%s', 'split from') ORDER BY key",
                        issue.getKey());
                if (objectives.isEmpty()) {

                } else if (objectives.size() == 1) {
                    context.put("objective", objectives.get(0));
                }
                context.put("edit", ComponentAccessor.getPermissionManager().hasPermission(EDIT_ISSUES, issue.getProjectObject(), appUser));
            }
        }
        return context;
    }
}
