package ru.rosbank.jira.portfolio.api.scheduling;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.portfolio.api.FinancialService;
import ru.rosbank.jira.portfolio.utils.DateUtil;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import java.rmi.RemoteException;
import java.util.Date;

@Named("financialPreviousYearJobRunner")
public class ScheduledFinancialPreviousYearJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledFinancialPreviousYearJobRunner.class);

    private final FinancialService financialService;

    private final ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final ServiceNames serviceName = ServiceNames.PREVIOUS_YEAR_SBU_COST_CENTERS_UPDATER;

    @Inject
    public ScheduledFinancialPreviousYearJobRunner(@ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                                   FinancialService financialService) {
        this.financialService = financialService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(JobRunnerRequest jobRunnerRequest) {
        LOG.info("Executing a financial scheduled job for previous year");
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
            new Date());
        try {
            if (financialService != null) {
                // JIRA-1742 Temporary comment
                financialService.loadData(DateUtil.getYear(DateUtil.getPrevYear()));
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                    new Date());
            }
        } catch (RemoteException rex) {
            LOG.error("Exception in ScheduledFinancialPreviousYearJobRunner.runJob method {}", ErrorStackTracer.getStackTrace(rex));
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(rex),
                new Date());
        }
        return JobRunnerResponse.success();
    }
}