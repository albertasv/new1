package ru.rosbank.jira.portfolio.model;

public class WorklogModel {

    private final static double SECONDS_TO_WORK_DAYS = 60 * 60 * 8;

    private long id;
    private String issue;
    private double timeworked;
    private double timeworkedQ1;
    private double timeworkedQ2;
    private double timeworkedQ3;
    private double timeworkedQ4;
    private double timeworkedPrevYear;
    private double plan;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public double getTimeworked() {
        return timeworked / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworked(double timeworked) {
        this.timeworked = timeworked;
    }

    public double getTimeworkedQ1() {
        return timeworkedQ1 / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworkedQ1(double timeworkedQ1) {
        this.timeworkedQ1 = timeworkedQ1;
    }

    public double getTimeworkedQ2() {
        return timeworkedQ2 / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworkedQ2(double timeworkedQ2) {
        this.timeworkedQ2 = timeworkedQ2;
    }

    public double getTimeworkedQ3() {
        return timeworkedQ3 / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworkedQ3(double timeworkedQ3) {
        this.timeworkedQ3 = timeworkedQ3;
    }

    public double getTimeworkedQ4() {
        return timeworkedQ4 / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworkedQ4(double timeworkedQ4) {
        this.timeworkedQ4 = timeworkedQ4;
    }

    public double getTimeworkedPrevYear() {
        return timeworkedPrevYear / SECONDS_TO_WORK_DAYS;
    }

    public void setTimeworkedPrevYear(double timeworkedPrevYear) {
        this.timeworkedPrevYear = timeworkedPrevYear;
    }

    public double getTimeworkedCurrYear() {
        return (timeworkedQ1 + timeworkedQ2 + timeworkedQ3 + timeworkedQ4) / SECONDS_TO_WORK_DAYS;
    }

    public double getPlan() {
        return plan;
    }

    public void setPlan(double plan) {
        this.plan = plan;
    }

    public double getRemain() {
        return getPlan() - getTimeworked();
    }
}
