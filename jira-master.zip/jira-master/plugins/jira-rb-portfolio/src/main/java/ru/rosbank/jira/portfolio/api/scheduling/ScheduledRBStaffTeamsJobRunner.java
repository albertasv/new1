package ru.rosbank.jira.portfolio.api.scheduling;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.scheduler.JobRunner;
import com.atlassian.scheduler.JobRunnerRequest;
import com.atlassian.scheduler.JobRunnerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.common.exceptions.LoadRbStaffTeamsException;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

@Named("rbStaffTeamsJobRunner")
public class ScheduledRBStaffTeamsJobRunner implements JobRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ScheduledRBStaffTeamsJobRunner.class);

    private final ExecutionTeamService executionTeamService;

    private ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;

    private final ServiceNames serviceName = ServiceNames.RBSTAFF_EXECUTION_TEAMS_UPDATER;

    @Inject
    public ScheduledRBStaffTeamsJobRunner(@ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
                                          ExecutionTeamService executionTeamService) {
        this.executionTeamService = executionTeamService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }

    @Nullable
    @Override
    public JobRunnerResponse runJob(@Nonnull JobRunnerRequest jobRunnerRequest) {
        LOG.info("Executing a rbstaff teams sync scheduled job");
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(), new Date());
        try {
            if (executionTeamService != null) {
                executionTeamService.loadRbStaffTeams();
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                    new Date());
            }
        } catch (LoadRbStaffTeamsException lrx) {
            LOG.error("Exception in ScheduledRBStaffTeamsJobRunner.runJob method {}", ErrorStackTracer.getStackTrace(lrx));
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(lrx),
                    new Date());
        }
        return JobRunnerResponse.success();
    }
}