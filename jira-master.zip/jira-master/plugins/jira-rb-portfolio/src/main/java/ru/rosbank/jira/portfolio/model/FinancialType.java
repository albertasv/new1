package ru.rosbank.jira.portfolio.model;

public enum FinancialType {
    CONTRACTED,
    NOT_CONTRACTED,
    FORECAST,
    FACT,
    ACCRUAL,
    ACCRUAL_FACT,
    EXT_BUDGET,
    CARRY_OVER_CONTRACTED,
    CARRY_OVER_NOT_CONTRACTED,
    UNKNOWN;

    public static FinancialType getValue(String name) {
        try {
            return FinancialType.valueOf(name);
        } catch (Exception ex) {
            return null;
        }
    }
}