package ru.rosbank.jira.portfolio.model.bean;

import com.google.common.base.Strings;
import ru.rosbank.jira.portfolio.ao.Allocation;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

public class AllocationBean {

    private Map<String, double[]> allocationMap = new HashMap<>();
    private double[] total = new double[2];
    private String comment = "";

    public void addAllocation(Allocation allocation) {
        String domain = allocation.getDomain();
        int type = Allocation.EXTERNAL_TYPE.equals(allocation.getAllocationType()) ? 0 : 1;
        double value = allocation.getAllocationValue();

        double[] values = allocationMap.getOrDefault(domain, new double[2]);
        values[type] += (value / 1_000_000);
        total[type] += (value / 1_000_000);
        allocationMap.put(domain, values);
        if (!Strings.isNullOrEmpty(allocation.getComment())) {
            comment = allocation.getComment();
        }
    }

    public String getAllocationFormat(String defaultValue, String domain) {
        return format(defaultValue, getAllocation(domain));
    }

    public String getAllocationFormatPercent(String defaultValue, String domain) {
        return getTotal() == 0 ? defaultValue : formatPercent(defaultValue, getAllocation(domain) / getTotal());
    }

    public double getAllocation(String domain) {
        return getAllocation(0, domain) + getAllocation(1, domain);
    }

    public String getAllocationFormat(String defaultValue, int type, String domain) {
        return format(defaultValue, getAllocation(type, domain));
    }

    public double getAllocation(int type, String domain) {
        return allocationMap.get(domain) == null ? 0 : allocationMap.get(domain)[type];
    }

    public String getAllocationFormat(String defaultValue, String... domains) {
        return format(defaultValue, getAllocation(domains));
    }

    public double getAllocation(String... domains) {
        return getAllocation(0, domains) + getAllocation(1, domains);
    }

    public String getAllocationFormat(String defaultValue, int type, String... domains) {
        return format(defaultValue, getAllocation(type, domains));
    }

    public String getAllocationFormatPercent(String defaultValue, String... domains) {
        return getTotal() == 0 ? defaultValue : formatPercent(defaultValue, getAllocation(domains) / getTotal());
    }

    public double getAllocation(int type, String... domains) {
        double res = 0;
        for (String domain : domains) {
            res += allocationMap.get(domain) == null ? 0 : allocationMap.get(domain)[type];
        }
        return res;
    }

    public String getTotalFormat(String defaultValue) {
        return format(defaultValue, getTotal());
    }

    public double getTotal() {
        return total[0] + total[1];
    }

    public String getTotalFormat(String defaultValue, int type) {
        return format(defaultValue, getTotal(type));
    }

    public double getTotal(int type) {
        return total[type];
    }

    public String getComment() {
        return comment;
    }

    private String format(String defaultValue, double value) {
        NumberFormat formatter = new DecimalFormat("#0.00");
        return value == 0 ? defaultValue : formatter.format(value);
    }

    private String formatPercent(String defaultValue, double value) {
        NumberFormat formatter = new DecimalFormat("#0.0%");
        return value == 0 ? defaultValue : formatter.format(value);
    }
}
