package ru.rosbank.jira.portfolio.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BenefitModel {

    private Integer id;
    private String category;
    double benefitValue;
    private Integer benefitYear;
    private String issue;
    private Date lastUpdateDate;
    private String lastUpdatedBy;
    private Boolean initial;
    private String comment;

    public BenefitModel() {
    }

    public BenefitModel(Integer id) {
        this.id = id;
    }

    public BenefitModel(Integer id,
                        String category,
                        double benefitValue,
                        Integer benefitYear,
                        Date lastUpdateDate,
                        String lastUpdatedBy,
                        String comment) {
        this.id = id;
        this.category = category;
        this.benefitValue = benefitValue;
        this.benefitYear = benefitYear;
        this.lastUpdateDate = lastUpdateDate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.comment = comment;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getBenefitValue() {
        return benefitValue;
    }

    public void setBenefitValue(double benefitValue) {
        this.benefitValue = benefitValue;
    }

    public Integer getBenefitYear() {
        return benefitYear;
    }

    public void setBenefitYear(Integer benefitYear) {
        this.benefitYear = benefitYear;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Boolean getInitial() {
        return initial;
    }

    public void setInitial(Boolean initial) {
        this.initial = initial;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
