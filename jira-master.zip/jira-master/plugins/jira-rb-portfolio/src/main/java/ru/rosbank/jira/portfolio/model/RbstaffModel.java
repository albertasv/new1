package ru.rosbank.jira.portfolio.model;

public class RbstaffModel {

    private String staffId;
    private String login;

    private String digitRoleName;
    private String digitTeamName;

    private String name;
    private String surname;
    private String email;

    private String phone;
    private String internalPhone;
    private String position;
    private String depart;
    private String employeeId;
    private String pregLeaveTo;

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getDigitRoleName() {
        return digitRoleName;
    }

    public void setDigitRoleName(String digitRoleName) {
        this.digitRoleName = digitRoleName;
    }

    public String getDigitTeamName() {
        return digitTeamName;
    }

    public void setDigitTeamName(String digitTeamName) {
        this.digitTeamName = digitTeamName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getInternalPhone() {
        return internalPhone;
    }

    public void setInternalPhone(String internalPhone) {
        this.internalPhone = internalPhone;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getPregLeaveTo() {
        return pregLeaveTo;
    }

    public void setPregLeaveTo(String pregLeaveTo) {
        this.pregLeaveTo = pregLeaveTo;
    }

    @Override
    public String toString() {
        return "RbstaffModel{" +
                "staffId='" + staffId + '\'' +
                ", login='" + login + '\'' +
                ", digitRoleName='" + digitRoleName + '\'' +
                ", digitTeamName='" + digitTeamName + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
