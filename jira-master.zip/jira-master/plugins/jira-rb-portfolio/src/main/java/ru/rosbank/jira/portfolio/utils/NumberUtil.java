package ru.rosbank.jira.portfolio.utils;

import java.math.BigDecimal;

public class NumberUtil {

    public static BigDecimal checkNull(BigDecimal value) {
        if (value == null) {
            return BigDecimal.ZERO;
        }
        return value;
    }

    public static BigDecimal sum(BigDecimal... values) {
        BigDecimal res = BigDecimal.ZERO;
        for (BigDecimal val : values) {
            if (val != null) {
                res = res.add(val);
            }
        }
        return res;
    }

    public static BigDecimal subtract(BigDecimal val1, BigDecimal val2) {
        return checkNull(val1).subtract(checkNull(val2));
    }


}
