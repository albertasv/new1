package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Entity;
import net.java.ao.schema.NotNull;

import java.util.Date;

public interface Benefit extends Entity {

    String getCategory();

    void setCategory(String category);

    double getBenefitValue();

    void setBenefitValue(double value);

    Date getBenefitDate();

    void setBenefitDate(Date date);

    @NotNull
    String getIssue();

    @NotNull
    void setIssue(String issueKey);

    @NotNull
    Date getLastUpdateDate();

    @NotNull
    void setLastUpdateDate(Date lastUpdateDate);

    @NotNull
    String getLastUpdatedBy();

    @NotNull
    void setLastUpdatedBy(String lastUpdateBy);

    Boolean getInitial();

    void setInitial(Boolean initial);

    String getComment();

    String setComment(String comment);
}
