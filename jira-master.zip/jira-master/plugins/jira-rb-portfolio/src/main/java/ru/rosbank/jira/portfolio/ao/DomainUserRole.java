package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;

@Preload
public interface DomainUserRole extends Entity {

    String getDomain();

    void setDomain(String domain);

    String getUsername();

    void setUsername(String username);

    String getRole();

    void setRole(String role);
}
