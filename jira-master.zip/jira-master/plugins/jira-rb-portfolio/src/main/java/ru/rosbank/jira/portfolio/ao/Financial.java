package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Entity;
import net.java.ao.Preload;
import ru.rosbank.jira.portfolio.model.FinancialType;

import java.util.Date;

@Preload
public interface Financial extends Entity {

    Date getCreationDate();

    void setCreationDate(Date creationDate);

    Date getLastUpdateDate();

    void setLastUpdateDate(Date lastUpdateDate);

    String getSbuProjectCode();

    void setSbuProjectCode(String sbuProjectCode);

    String getCostCenterCode();

    void setCostCenterCode(String costCenterCode);

    String getProductCode();

    void setProductCode(String productCode);

    ExpenseType getExpenseType();

    void setExpenseType(ExpenseType expenseType);

    FinancialType getFinancialType();

    void setFinancialType(String financialType);

    Date getFinancialDate();

    void setFinancialDate(Date financialDate);

    Double getFinancialValue();

    void setFinancialValue(Double value);

    String getPayerCode();

    void setPayerCode(String payerCode);

    String getContractCode();

    void setContractCode(String contractCode);

    String getIssue();

    void setIssue(String issue);

    Boolean getSynced();

    void setSynced(boolean synced);

    Integer getProjectEpic();

    void setProjectEpic(Integer projectEpic);
}
