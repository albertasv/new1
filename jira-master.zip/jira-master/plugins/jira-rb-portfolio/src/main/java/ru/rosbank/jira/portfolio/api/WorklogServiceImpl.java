package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.portfolio.model.WorklogModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService
@Named("worklogService")
public class WorklogServiceImpl implements WorklogService {

    private static final Logger LOG = LoggerFactory.getLogger(WorklogServiceImpl.class);
    @ComponentImport
    private final ActiveObjects ao;

    @Inject
    public WorklogServiceImpl(ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public WorklogModel searchWorklog(long issueId) {
        WorklogModel worklog = new WorklogModel();
        SQLProcessor sqlProcessor = null;
        try {
            sqlProcessor = new SQLProcessor("defaultDS");
            ResultSet rs = sqlProcessor.executeQuery("SELECT id, issue, timeworked, timeworked_prev_year," +
                    " timeworked_q1, timeworked_q2, timeworked_q3, timeworked_q4" +
                    " FROM rb_worklog_v WHERE id = " + issueId);
            if (rs.next()) {
                worklog.setTimeworked(rs.getDouble("timeworked"));
                worklog.setTimeworkedQ1(rs.getDouble("timeworked_q1"));
                worklog.setTimeworkedQ2(rs.getDouble("timeworked_q2"));
                worklog.setTimeworkedQ3(rs.getDouble("timeworked_q3"));
                worklog.setTimeworkedQ4(rs.getDouble("timeworked_q4"));
                worklog.setTimeworkedPrevYear(rs.getDouble("timeworked_prev_year"));
            }
        } catch (GenericEntityException | SQLException ex) {
            LOG.error("Get worklog data error: {}", ex);
        } finally {
            if (sqlProcessor != null) {
                try {
                    sqlProcessor.close();
                } catch (GenericEntityException e) {
                }
            }
        }
        return worklog;
    }
}
