package ru.rosbank.jira.portfolio.action;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;
import ru.rosbank.jira.portfolio.model.ExecutionTeamModel;

import javax.inject.Inject;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

public class QBRAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(QBRAction.class);

    private final JiraAuthenticationContext authenticationContext;
    private final ExecutionTeamService executionTeamService;

    @Inject
    public QBRAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            ExecutionTeamService executionTeamService) {
        this.authenticationContext = checkNotNull(authenticationContext);
        this.executionTeamService = executionTeamService;
    }

    @Override
    protected void doValidation() {
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        if (loggedInUser == null) {
            addErrorMessage("You don't have permission to view this team or it wasn't found.");
        }
    }

    @Override
    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public List<ExecutionTeamModel> getTeams() {
        return this.executionTeamService.getAgileTeams();
    }
}