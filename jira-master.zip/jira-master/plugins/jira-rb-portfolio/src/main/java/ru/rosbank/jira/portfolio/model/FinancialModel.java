package ru.rosbank.jira.portfolio.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
public class FinancialModel {

    private String productCode;
    private String financialType;
    private Double financialValue;
    private Date financialDate;

    public FinancialModel(String productCode, String financialType, Double financialValue, Date financialDate) {
        this.productCode = productCode;
        this.financialType = financialType;
        this.financialValue = financialValue;
        this.financialDate = financialDate;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getFinancialType() {
        return financialType;
    }

    public void setFinancialType(String financialType) {
        this.financialType = financialType;
    }

    public Double getFinancialValue() {
        return financialValue;
    }

    public void setFinancialValue(Double financialValue) {
        this.financialValue = financialValue;
    }

    public Date getFinancialDate() {
        return financialDate;
    }

    public void setFinancialDate(Date financialDate) {
        this.financialDate = financialDate;
    }
}
