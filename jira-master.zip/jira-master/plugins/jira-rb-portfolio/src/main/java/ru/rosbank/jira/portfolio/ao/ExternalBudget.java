package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;

@Preload
public interface ExternalBudget extends Budget {

    String getProduct();

    void setProduct(String product);

    boolean getCurrentYear();

    void setCurrentYear(boolean value);

}
