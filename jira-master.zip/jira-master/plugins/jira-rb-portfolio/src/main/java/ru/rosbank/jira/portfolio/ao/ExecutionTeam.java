package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;
import net.java.ao.schema.NotNull;

import java.util.Date;

@Preload
public interface ExecutionTeam extends Dictionary {

    @NotNull
    String getStatus();

    @NotNull
    void setStatus(String status);

    @NotNull
    String getType();

    @NotNull
    void setType(String type);

    String getOwnerUserName();

    void setOwnerUserName(String userName);

    String getOwnerFullName();

    void setOwnerFullName(String fullName);

    boolean isAgile();

    void setAgile(Boolean agile);

    int getExternalId();

    int setExternalId(int id);

    Date getStartDate();

    void setStartDate(Date startDate);

    Date getEndDate();

    void setEndDate(Date endDate);

    String getCostCenter();

    void setCostCenter(String costCenter);

    Date getLastUpdateDate();

    void setLastUpdateDate(Date lastUpdateDate);
}
