package ru.rosbank.jira.portfolio.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@XmlRootElement(name = "portfolioModel")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PortfolioModel {

    private Integer epicNumber;
    private List<String> labels;
    private String portfolioType;
    private String ppmCode;
    private String status;
    private String statusCategory;
    private String key;
    private String summary;
    private String description;
    private String domain;
    private String category;
    private String costCenter;

    private String manager;
    private String isOfficer;
    private String itArchitect;

    private Date startDate;
    private Date regDate;
    private Date endInitialDate;
    private Date endValidatedDate;
    private Date endActualDate;
    private Date steerCoDate;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public Integer getEpicNumber() {
        return epicNumber;
    }

    public void setEpicNumber(Integer epicNumber) {
        this.epicNumber = epicNumber;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public String getPortfolioType() {
        return portfolioType;
    }

    public void setPortfolioType(String portfolioType) {
        this.portfolioType = portfolioType;
    }

    public String getPpmCode() {
        return ppmCode;
    }

    public void setPpmCode(String ppmCode) {
        this.ppmCode = ppmCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCategory() {
        return statusCategory;
    }

    public void setStatusCategory(String statusCategory) {
        this.statusCategory = statusCategory;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getIsOfficer() {
        return isOfficer;
    }

    public void setIsOfficer(String isOfficer) {
        this.isOfficer = isOfficer;
    }

    public String getItArchitect() {
        return itArchitect;
    }

    public void setItArchitect(String itArchitect) {
        this.itArchitect = itArchitect;
    }

    public Date getStartDate() {
        return startDate;
    }

    public String getStartDateFormatted() {
        return startDate == null ? null : dateFormat.format(startDate);
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public Date getEndInitialDate() {
        return endInitialDate;
    }

    public String getEndInitialDateFormatted() {
        return endInitialDate == null ? null : dateFormat.format(endInitialDate);
    }

    public void setEndInitialDate(Date endInitialDate) {
        this.endInitialDate = endInitialDate;
    }

    public Date getEndValidatedDate() {
        return endValidatedDate;
    }

    public String getEndValidatedDateFormatted() {
        return endValidatedDate == null ? null : dateFormat.format(endValidatedDate);
    }

    public void setEndValidatedDate(Date endValidatedDate) {
        this.endValidatedDate = endValidatedDate;
    }

    public Date getEndActualDate() {
        return endActualDate;
    }

    public String getEndActualDateFormatted() {
        return endActualDate == null ? null : dateFormat.format(endActualDate);
    }

    public void setEndActualDate(Date endActualDate) {
        this.endActualDate = endActualDate;
    }

    public Date getSteerCoDate() {
        return steerCoDate;
    }

    public void setSteerCoDate(Date steerCoDate) {
        this.steerCoDate = steerCoDate;
    }
}
