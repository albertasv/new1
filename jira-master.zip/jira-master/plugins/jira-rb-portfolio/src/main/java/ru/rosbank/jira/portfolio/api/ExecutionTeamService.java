package ru.rosbank.jira.portfolio.api;

import ru.rosbank.jira.common.exceptions.LoadRbStaffAllInfoException;
import ru.rosbank.jira.common.exceptions.LoadRbStaffTeamsException;
import ru.rosbank.jira.portfolio.ao.ExecutionTeam;
import ru.rosbank.jira.portfolio.model.ExecutionTeamModel;

import java.io.IOException;
import java.util.List;

public interface ExecutionTeamService extends DictionaryService<ExecutionTeam> {

    ExecutionTeamModel getAgileTeam(String codeOrName);

    ExecutionTeam getByName(String name);

    List<ExecutionTeamModel> getAgileTeams();

    void loadRbStaffTeams() throws LoadRbStaffTeamsException;
}
