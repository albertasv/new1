package ru.rosbank.jira.portfolio.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.Benefit;
import ru.rosbank.jira.portfolio.api.BenefitService;
import ru.rosbank.jira.portfolio.api.BudgetService;
import ru.rosbank.jira.portfolio.model.BenefitModel;
import ru.rosbank.jira.portfolio.model.MessageModel;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Component
@Path("/benefit")
public class BenefitRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(BenefitRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final BenefitService benefitService;
    private final BudgetService budgetService;

    @Inject
    public BenefitRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            BenefitService benefitService,
            BudgetService budgetService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.benefitService = benefitService;
        this.budgetService = budgetService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}")
    public Response search(
            @PathParam("issueKey") String issueKey,
            @QueryParam("initial") Boolean initial) {
        if (canView(issueKey)) {
            List<BenefitModel> res = new ArrayList<>();
            for (Benefit a : benefitService.search(issueKey, Boolean.TRUE.equals(initial))) {
                res.add(new BenefitModel(
                        a.getID(),
                        a.getCategory(),
                        a.getBenefitValue(),
                        DateUtil.getYear(a.getBenefitDate()),
                        a.getLastUpdateDate(),
                        a.getLastUpdatedBy(),
                        a.getComment()));
            }
            return Response.ok(res).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{initial}")
    public Response add(@PathParam("issueKey") String issueKey,
                        @PathParam("initial") String initial,
                        BenefitModel dataModel) {
        if (canEdit(issueKey)) {
            String username = jiraAuthenticationContext.getLoggedInUser().getUsername();
            Benefit a = benefitService.add(username, issueKey, dataModel, "initial".equalsIgnoreCase(initial));
            return Response.ok(new BenefitModel(
                    a.getID(),
                    a.getCategory(),
                    a.getBenefitValue(),
                    DateUtil.getYear(a.getBenefitDate()),
                    a.getLastUpdateDate(),
                    a.getLastUpdatedBy(),
                    a.getComment())).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{initial}/{id}")
    public Response delete(@PathParam("issueKey") String issueKey,
                           @PathParam("initial") String initial,
                           @PathParam("id") int id) {
        if (canEdit(issueKey)) {
            benefitService.delete(id);
            return Response.ok(new BenefitModel(id)).build();

        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    private boolean canView(String issueKey) {
        return budgetService.canViewBudget(issueKey);
    }

    private boolean canEdit(String issueKey) {
        return budgetService.canEditBudget(issueKey);
    }
}