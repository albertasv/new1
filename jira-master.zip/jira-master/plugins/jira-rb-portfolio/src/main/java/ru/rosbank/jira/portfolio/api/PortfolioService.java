package ru.rosbank.jira.portfolio.api;

import com.atlassian.jira.issue.Issue;

import java.util.List;

public interface PortfolioService {

    List<Issue> getPortfolioProjectEpics(String portfolioProject);
}
