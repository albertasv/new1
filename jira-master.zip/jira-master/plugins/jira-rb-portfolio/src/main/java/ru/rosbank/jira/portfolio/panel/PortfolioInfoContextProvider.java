package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.component.pico.ComponentManager;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.RendererManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.renderer.JiraRendererPlugin;
import com.atlassian.jira.issue.fields.renderer.wiki.AtlassianWikiRenderer;
import com.atlassian.jira.issue.label.Label;
import com.atlassian.jira.issue.label.LabelManager;
import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.user.UserManager;
import org.apache.velocity.tools.generic.EscapeTool;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.ao.ExecutionTeam;
import ru.rosbank.jira.portfolio.api.CostCenterService;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;

import javax.inject.Inject;
import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

public class PortfolioInfoContextProvider extends AbstractJiraContextProvider {

    private final UserManager userManager;
    private final ConfigLoader config;
    private final CustomFieldManager customFieldManager;
    private final LabelManager labelManager;
    private final CostCenterService costCenterService;
    private final ExecutionTeamService executionTeamService;

    private final JiraRendererPlugin renderer;

    @Inject
    public PortfolioInfoContextProvider(@ComponentImport UserManager userManager,
                                        @ComponentImport ConfigLoader config,
                                        CostCenterService costCenterService,
                                        ExecutionTeamService executionTeamService) {
        this.userManager = checkNotNull(userManager);
        this.config = checkNotNull(config);
        this.customFieldManager = ComponentAccessor.getCustomFieldManager();
        this.labelManager = ComponentAccessor.getComponent(LabelManager.class);
        this.costCenterService = costCenterService;
        this.executionTeamService = executionTeamService;

        RendererManager rendererManager = ComponentManager.getInstance().getComponent(RendererManager.class);
        renderer = rendererManager.getRendererForType(AtlassianWikiRenderer.RENDERER_TYPE);
    }

    @Override
    public Map getContextMap(ApplicationUser applicationUser, JiraHelper jiraHelper) {
        HashMap<String, Object> context = new HashMap<>();
        context.put("esc", new EscapeTool());
        if (jiraHelper != null) {
            Issue issue = (Issue) jiraHelper.getContextParams().get("issue");
            if (issue != null) {
                context.put("config", config);
                context.put("description", renderer.render(issue.getDescription(), null));
                context.put("project", issue.getProjectObject().getName());
                context.put("portfolioId", issue.getNumber());
                context.put("status", issue.getStatus().getName());
                // Labels
                context.put("labels", issue.getLabels().stream().map(label -> label.getLabel()).collect(Collectors.toList()));
                context.put("category", issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getCategoryFieldId())));
                context.put("isOfficerResolution", issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getIsOfficerResolutionId())));
                context.put("isOfficerClosing", issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getIsOfficerClosingId())));
                context.put("financialResolution", issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getFinancialResolutionId())));
                context.put("itArchitectResolution", issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getItArchitectResolutionId())));

                CustomField costCenterField = customFieldManager.getCustomFieldObject(config.getCostCenterFieldId());
                String costCenterCode = (String) issue.getCustomFieldValue(costCenterField);
                if (costCenterCode != null) {
                    CostCenter costCenter = costCenterService.getByCode(costCenterCode);
                    if (costCenter != null) {
                        context.put("costCenter", costCenter);
                        context.put("b1", userManager.getUserProfile(costCenter.getB1()));
                        context.put("sponsor", userManager.getUserProfile(costCenter.getSponsor()));
                        context.put("sbp", userManager.getUserProfile(costCenter.getSbp()));
                        context.put("fbp", userManager.getUserProfile(costCenter.getFbp()));
                        context.put("iSOfficer", userManager.getUserProfile(costCenter.getIsOfficer()));
                    }
                }

                // Teams
                CustomField teamsField = customFieldManager.getCustomFieldObject(config.getExecutionTeamsFieldId());
                Set<Label> teamLabels = (Set<Label>) issue.getCustomFieldValue(teamsField);
                if (teamLabels != null) {
                    List<ExecutionTeam> teams = new ArrayList<>();
                    for (Label teamLabel : teamLabels) {
                        teams.add(executionTeamService.getByCode(teamLabel.getLabel()));
                    }
                    context.put("teams", teams);
                }
            }
        }
        return context;
    }
}
