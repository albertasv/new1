package ru.rosbank.jira.portfolio.action;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.action.JiraWebActionSupport;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.NumberTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ClickLogService;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;
import ru.rosbank.jira.portfolio.model.ExecutionTeamModel;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

public class TeamInfoAction extends JiraWebActionSupport {

    private static final Logger LOG = LoggerFactory.getLogger(TeamInfoAction.class);

    private final JiraAuthenticationContext authenticationContext;
    private final UserInfoService userInfoService;
    private final ClickLogService clickLogService;
    private final ExecutionTeamService executionTeamService;

    private ExecutionTeamModel team;
    private List<UserInfoModel> teamMembers = new ArrayList<>();
    private final NumberTool numberTool = new NumberTool();

    @Inject
    public TeamInfoAction(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport UserInfoService userInfoService,
            @ComponentImport ClickLogService clickLogService,
            ExecutionTeamService executionTeamService) {
        this.authenticationContext = checkNotNull(authenticationContext);
        this.userInfoService = checkNotNull(userInfoService);
        this.clickLogService = checkNotNull(clickLogService);
        this.executionTeamService = executionTeamService;
    }

    @Override
    protected void doValidation() {
        ApplicationUser loggedInUser = authenticationContext.getLoggedInUser();
        String teamCode = getHttpRequest().getParameter("code");
        this.team = executionTeamService.getAgileTeam(teamCode);

        // Enable logging agile team visit
        if (LOG.isInfoEnabled()) {
            clickLogService.addClickLog("TEAM_INFO_" + teamCode);
        }

        if (team == null || loggedInUser == null) {
            addErrorMessage("You don't have permission to view this team or it wasn't found.");
        } else {
            this.teamMembers = userInfoService.getUserInfoByTeam(team.getId()).stream()
                    .filter(uim -> getUserManager().getUserByName(uim.getUsername()).isActive())
                    .map(uim -> {
                        ApplicationUser appUser = getUserManager().getUserByName(uim.getUsername());
                        uim.setDisplayName(appUser.getDisplayName());
                        return uim;
                    })
                    .sorted((uim1, uim2) -> {
                        if (uim1.getTeamRole() != null && uim1.getTeamRole().toLowerCase().contains("owner") &&
                                uim2.getTeamRole() != null && !uim2.getTeamRole().toLowerCase().contains("owner")) {
                            return -1;
                        } else if (uim1.getTeamRole() != null && !uim1.getTeamRole().toLowerCase().contains("owner") &&
                                uim2.getTeamRole() != null && uim2.getTeamRole().toLowerCase().contains("owner")) {
                            return 1;
                        }
                        return uim1.getDisplayName().compareTo(uim2.getDisplayName());
                    })
                    .collect(Collectors.toList());
            // this.financialReport = financialService.getFinancialReport(teamCode);
        }
    }

    @Override
    public String execute() throws Exception {
        return super.execute(); //returns SUCCESS
    }

    public ExecutionTeamModel getTeam() {
        return team;
    }

    public List<UserInfoModel> getTeamMembers() {
        return teamMembers;
    }

    public NumberTool getNumberTool() {
        return numberTool;
    }
}