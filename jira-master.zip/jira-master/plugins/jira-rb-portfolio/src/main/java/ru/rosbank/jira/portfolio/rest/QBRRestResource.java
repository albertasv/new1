package ru.rosbank.jira.portfolio.rest;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.fields.config.manager.IssueTypeSchemeManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.portfolio.model.DictionaryResultModel;
import ru.rosbank.jira.portfolio.model.ProjectModel;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static com.atlassian.jira.permission.ProjectPermissions.ASSIGNABLE_USER;
import static com.atlassian.jira.permission.ProjectPermissions.CREATE_ISSUES;


@Component
@Path("/qbr")
public class QBRRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(QBRRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final PermissionManager permissionManager;
    private final IssueTypeSchemeManager issueTypeSchemeManager;

    public QBRRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.permissionManager = ComponentAccessor.getPermissionManager();
        this.issueTypeSchemeManager = ComponentAccessor.getIssueTypeSchemeManager();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("projects")
    public Response getProjects(@QueryParam("q") String query) {
        ApplicationUser appUser = jiraAuthenticationContext.getLoggedInUser();
        Collection<Project> projects = this.permissionManager.getProjects(CREATE_ISSUES, appUser);
        List<ProjectModel> res = projects.stream()
                .filter(project ->
                        !project.isArchived()
                                && (Strings.isNullOrEmpty(query)
                                || project.getKey().toLowerCase().contains(query.toLowerCase())
                                || project.getName().toLowerCase().contains(query.toLowerCase()))
                                && ComponentAccessor.getPermissionManager().hasPermission(CREATE_ISSUES, project, appUser)
                                && ComponentAccessor.getPermissionManager().hasPermission(ASSIGNABLE_USER, project, appUser)
                                && this.issueTypeSchemeManager.getIssueTypesForProject(project).stream()
                                .anyMatch(it -> "Objective".equalsIgnoreCase(it.getName())))
                .map(ProjectModel::convert)
                .sorted(Comparator.comparing(ProjectModel::getName))
                .collect(Collectors.toList());
        return Response.ok(new DictionaryResultModel(res, res.size())).build();
    }
}
