package ru.rosbank.jira.portfolio.api;

import ru.rosbank.jira.portfolio.ao.Dictionary;

import java.util.List;

public interface DictionaryService<E extends Dictionary> {

    List<E> all();

    int total();

    E getByCode(String code);

    List<E> search(String query, int limit, int offset);

    int total(String query);
}
