package ru.rosbank.jira.portfolio.utils;

import java.text.DateFormatSymbols;
import java.util.*;

public class DateUtil {

    public static Date getDate(Integer year, Integer quarter, Integer month, Integer day) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (year != null) {
            cal.set(Calendar.YEAR, year);
        }

        if (quarter != null) {
            if (quarter == 1) {
                cal.set(Calendar.MONTH, 0);
            } else if (quarter == 2) {
                cal.set(Calendar.MONTH, 3);
            } else if (quarter == 3) {
                cal.set(Calendar.MONTH, 6);
            } else if (quarter == 4) {
                cal.set(Calendar.MONTH, 9);
            }
        }

        if (month != null) {
            cal.set(Calendar.MONTH, month + 1);
        }
        if (day != null) {
            cal.set(Calendar.DATE, day);
        }
        return cal.getTime();
    }

    public static Date getDate(int year, int quarter) {
        return getDate(year, quarter, null, 1);
    }

    public static Date getDate(int year) {
        return getDate(year, 1);
    }

    public static Date getCurrentYear(int quarter) {
        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        return getDate(currentYear, quarter);
    }

    public static Date getCurrentYear() {
        return getCurrentYear(1);
    }

    public static Date getPrevYear() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -1);
        cal.set(Calendar.MONTH, Calendar.DECEMBER);
        cal.set(Calendar.DAY_OF_MONTH, 31);
        return cal.getTime();
    }

    public static Integer getYear(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.get(Calendar.YEAR);
    }

    public static Integer getQuarter(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return (cal.get(Calendar.MONTH) / 3) + 1;
    }

    public static String monthName(int month) {
        String[] shortMonths = new DateFormatSymbols().getShortMonths();
        if (month < 0 || month > 11) {
            return null;
        }
        return shortMonths[month - 1];
    }
}
