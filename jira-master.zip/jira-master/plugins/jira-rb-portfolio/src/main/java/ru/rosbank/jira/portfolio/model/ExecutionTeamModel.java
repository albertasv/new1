package ru.rosbank.jira.portfolio.model;

import com.atlassian.jira.project.Project;
import ru.rosbank.jira.portfolio.ao.Dictionary;
import ru.rosbank.jira.portfolio.ao.ExecutionTeam;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExecutionTeamModel extends DictionaryModel {

    private ExecutionTeamStatus status;
    private ExecutionTeamType type;
    private String ownerUserName;
    private String ownerFullName;
    private Date startDate;
    private Date endDate;
    private String costCenter;

    private List<Project> projects = new ArrayList<>();

    public ExecutionTeamModel(int id, String code, String name) {
        super(id, code, name);
    }

    public ExecutionTeamStatus getStatus() {
        return status;
    }

    public void setStatus(ExecutionTeamStatus status) {
        this.status = status;
    }

    public ExecutionTeamType getType() {
        return type;
    }

    public void setType(ExecutionTeamType type) {
        this.type = type;
    }

    public String getOwnerUserName() {
        return ownerUserName;
    }

    public void setOwnerUserName(String ownerUserName) {
        this.ownerUserName = ownerUserName;
    }

    public String getOwnerFullName() {
        return ownerFullName;
    }

    public void setOwnerFullName(String ownerFullName) {
        this.ownerFullName = ownerFullName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public String getStartDateFormatted() {
        return startDate != null ? new SimpleDateFormat("yyyy-MM-dd").format(startDate) : "";
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public String getEndDateFormatted() {
        return endDate != null ? new SimpleDateFormat("yyyy-MM-dd").format(endDate) : "";
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public static ExecutionTeamModel convert(ExecutionTeam item) {
        if (item == null) {
            return null;
        }
        ExecutionTeamModel teamModel = new ExecutionTeamModel(item.getID(), item.getCode(), item.getName());
        teamModel.setStatus(ExecutionTeamStatus.getStatus(item.getStatus()));
        teamModel.setType(ExecutionTeamType.getType(item.getType()));
        teamModel.setOwnerUserName(item.getOwnerUserName());
        teamModel.setOwnerFullName(item.getOwnerFullName());
        teamModel.setStartDate(item.getStartDate());
        teamModel.setEndDate(item.getEndDate());
        teamModel.setCostCenter(item.getCostCenter());
        return teamModel;
    }
}
