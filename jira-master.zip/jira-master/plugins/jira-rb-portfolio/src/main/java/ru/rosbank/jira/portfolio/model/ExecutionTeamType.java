package ru.rosbank.jira.portfolio.model;

public enum ExecutionTeamType {
    SERVICE("Service"),
    CHANNEL("Channel"),
    PRODUCT("Product"),
    COC("CoC"),
    PLATFORM("Platform"),
    DEV_SERVICE("Development Service"),
    UNKNOWN("Unknown");

    ExecutionTeamType(String name) {
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public static ExecutionTeamType getType(String name) {
        for (ExecutionTeamType value : ExecutionTeamType.values()) {
            if (value.getName().equalsIgnoreCase(name) ||
                    value.name().equalsIgnoreCase(name)) {
                return value;
            }
        }
        return UNKNOWN;
    }

}
