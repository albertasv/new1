package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;


@Preload
public interface InternalBudget extends Budget {
    double getMdBudgetValue();

    void setMdBudgetValue(double value);

    String getCostCenter();

    String setCostCenter(String costCenter);

    boolean getCurrentYear();

    void setCurrentYear(boolean value);
}
