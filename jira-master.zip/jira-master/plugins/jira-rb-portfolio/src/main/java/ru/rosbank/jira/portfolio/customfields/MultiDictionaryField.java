package ru.rosbank.jira.portfolio.customfields;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.customfields.ProjectImportLabelFieldParser;
import com.atlassian.jira.issue.customfields.impl.LabelsCFType;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutItem;
import com.atlassian.jira.issue.fields.rest.json.beans.JiraBaseUrls;
import com.atlassian.jira.issue.label.Label;
import com.atlassian.jira.issue.label.LabelManager;
import com.atlassian.jira.issue.label.LabelUtil;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;
import ru.rosbank.jira.portfolio.model.DictionaryModel;
import ru.rosbank.jira.portfolio.model.DictionaryType;
import ru.rosbank.jira.portfolio.model.ExecutionTeamModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class MultiDictionaryField extends LabelsCFType {
    private static final Logger LOG = LoggerFactory.getLogger(MultiDictionaryField.class);

    private final ExecutionTeamService executionTeamService;

    public static final String CODE_MULTI_SEPARATOR = " ";
    public static final String NAME_MULTI_SEPARATOR = "#@#";

    public MultiDictionaryField(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            @ComponentImport IssueManager issueManager,
            @ComponentImport GenericConfigManager genericConfigManager,
            @ComponentImport LabelUtil labelUtil,
            @ComponentImport LabelManager labelManager,
            @ComponentImport ProjectImportLabelFieldParser projectImportableCustomFieldParser,
            @ComponentImport JiraBaseUrls jiraBaseUrls,
            ExecutionTeamService executionTeamService) {
        super(authenticationContext, issueManager, genericConfigManager, labelUtil, labelManager, projectImportableCustomFieldParser, jiraBaseUrls);
        this.executionTeamService = executionTeamService;
    }

    @Override
    public Map<String, Object> getVelocityParameters(final Issue issue,
                                                     final CustomField field,
                                                     final FieldLayoutItem fieldLayoutItem) {
        final Map<String, Object> map = super.getVelocityParameters(issue, field, fieldLayoutItem);
        map.put("esc", new EscapeTool());
        map.put("type", getDictionaryType());

        Object itemCodes;
        if (issue != null) {
            if (issue.isCreated()) {
                itemCodes = this.getValueFromIssue(field, issue);
            } else {
                itemCodes = this.getDefaultValue(field.getRelevantConfig(issue));
            }
        } else {
            // NULL
            itemCodes = map.get("value");
        }

        if (itemCodes != null) {
            List<DictionaryModel> res = new ArrayList<>();
            for (Label itemCode : (Set<Label>) itemCodes) {
                switch (getDictionaryType()) {
                    case EXECUTION_TEAM:
                        ExecutionTeamModel teamModel = ExecutionTeamModel.convert(executionTeamService.getByCode(itemCode.getLabel()));
                        if (teamModel != null) {
                            res.add(teamModel);
                        }
                        break;
                }
            }
            map.put("value", res);
            map.put("valueCodes", res.stream().map(DictionaryModel::getCode).collect(Collectors.joining(CODE_MULTI_SEPARATOR)));
            map.put("valueNames", res.stream().map(DictionaryModel::getName).collect(Collectors.joining(NAME_MULTI_SEPARATOR)));
        } else {
            map.remove("value");
        }
        return map;
    }

    private DictionaryType type;

    private DictionaryType getDictionaryType() {
        if (type == null) {
            type = DictionaryType.getType(this.getDescriptor().getParams().get("type"));
        }
        return type;
    }
}