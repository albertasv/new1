package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.DomainUserRole;
import ru.rosbank.jira.portfolio.ao.UserRoleType;

import java.util.List;

@Transactional
public interface DomainUserRoleService {

    List<DomainUserRole> search(UserRoleType userRoleType);

    DomainUserRole add(String username, String domain, UserRoleType userRoleType);

    void delete(String username, UserRoleType userRoleType);
}
