package ru.rosbank.jira.portfolio.customfields;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.customfields.impl.FieldValidationException;
import com.atlassian.jira.issue.customfields.impl.GenericTextCFType;
import com.atlassian.jira.issue.customfields.manager.GenericConfigManager;
import com.atlassian.jira.issue.customfields.persistence.CustomFieldValuePersister;
import com.atlassian.jira.issue.customfields.persistence.PersistenceFieldType;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.fields.TextFieldCharacterLengthValidator;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutItem;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.ao.Dictionary;
import ru.rosbank.jira.portfolio.api.CostCenterService;
import ru.rosbank.jira.portfolio.model.DictionaryModel;
import ru.rosbank.jira.portfolio.model.DictionaryType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;

public class DictionaryField extends GenericTextCFType {
    private static final Logger LOG = LoggerFactory.getLogger(DictionaryField.class);

    private final CostCenterService costCenterService;

    public DictionaryField(
            @ComponentImport CustomFieldValuePersister customFieldValuePersister,
            @ComponentImport GenericConfigManager genericConfigManager,
            @ComponentImport TextFieldCharacterLengthValidator textFieldCharacterLengthValidator,
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            CostCenterService costCenterService) {
        super(customFieldValuePersister, genericConfigManager, textFieldCharacterLengthValidator, jiraAuthenticationContext);
        this.costCenterService = costCenterService;
    }

    @Override
    public String getStringFromSingularObject(String itemCode) {
        if (itemCode != null) {
            Dictionary item = null;
            switch (getDictionaryType()) {
                case COST_CENTER:
                    item = costCenterService.getByCode(itemCode);
                    break;
            }
            if (item != null) {
                return item.getCode();
            }
        }
        return null;
    }

    @Override
    public String getSingularObjectFromString(String itemCode) throws FieldValidationException {
        Dictionary item = null;
        switch (getDictionaryType()) {
            case COST_CENTER:
                item = costCenterService.getByCode(itemCode);
                break;
        }
        return item == null ? null : item.getCode();
    }

    @Override
    public Map<String, Object> getVelocityParameters(final Issue issue,
                                                     final CustomField field,
                                                     final FieldLayoutItem fieldLayoutItem) {
        final Map<String, Object> map = super.getVelocityParameters(issue, field, fieldLayoutItem);
        map.put("esc", new EscapeTool());
        map.put("type", getDictionaryType());

        Object itemCode;
        if (issue != null) {
            if (issue.isCreated()) {
                itemCode = this.getValueFromIssue(field, issue);
            } else {
                itemCode = this.getDefaultValue(field.getRelevantConfig(issue));
            }
        } else {
            // NULL
            itemCode = map.get("value");
        }

        if (itemCode != null) {
            CostCenter item = costCenterService.getByCode((String) itemCode);
            if (item != null) {
                map.put("value", DictionaryModel.convert(getDictionaryType(), item));
            }
        } else {
            map.remove("value");
        }
        return map;
    }

    @Nonnull
    @Override
    protected PersistenceFieldType getDatabaseType() {
        return PersistenceFieldType.TYPE_LIMITED_TEXT;
    }

    @Nullable
    @Override
    protected String getObjectFromDbValue(@Nonnull Object o) throws FieldValidationException {
        Dictionary item = null;
        switch (getDictionaryType()) {
            case COST_CENTER:
                item = costCenterService.getByCode((String) o);
                break;
        }
        return item == null ? null : item.getCode();
    }

    private DictionaryType type;

    private DictionaryType getDictionaryType() {
        if (type == null) {
            type = DictionaryType.getType(this.getDescriptor().getParams().get("type"));
        }
        return type;
    }
}