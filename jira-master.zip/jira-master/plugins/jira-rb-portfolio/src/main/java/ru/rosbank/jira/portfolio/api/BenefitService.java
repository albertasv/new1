package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.Benefit;
import ru.rosbank.jira.portfolio.model.BenefitModel;
import ru.rosbank.jira.portfolio.model.bean.BenefitBean;

import java.util.List;

@Transactional
public interface BenefitService {

    Benefit[] search(String issueKey, boolean initial);

    void delete(int id);

    Benefit add(String username, String issueKey, BenefitModel dataModel, boolean initial);

    BenefitBean getBenefits(String issueKey);
}
