package ru.rosbank.jira.portfolio.rest;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ErrorStackTracer;
import ru.rosbank.jira.common.api.ExternalServiceSyncStatusProvider;
import ru.rosbank.jira.common.api.ServiceNames;
import ru.rosbank.jira.common.api.Statuses;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.Financial;
import ru.rosbank.jira.portfolio.api.BudgetService;
import ru.rosbank.jira.portfolio.api.FinancialService;
import ru.rosbank.jira.portfolio.model.FinancialModel;
import ru.rosbank.jira.portfolio.model.MessageModel;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@Path("/financial")
public class FinancialRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(FinancialRestResource.class);

    private final FinancialService financialService;
    private final BudgetService budgetService;

    private ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider;


    @Inject
    public FinancialRestResource(@ComponentImport ExternalServiceSyncStatusProvider externalServiceSyncStatusProvider,
            FinancialService financialService,
            BudgetService budgetService) {
        this.financialService = financialService;
        this.budgetService = budgetService;
        this.externalServiceSyncStatusProvider = externalServiceSyncStatusProvider;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/load")
    public Response load() {
            StringBuilder message = new StringBuilder();
            final ServiceNames serviceName = ServiceNames.CURRENT_YEAR_SBU_COST_CENTERS_UPDATER;
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
                new Date());
            try {
                if (budgetService.isPMO()) {
                    financialService.loadData(DateUtil.getYear(DateUtil.getCurrentYear()));
                    message.append("OK");
                    externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                        new Date());
                    return Response.ok(message).build();
                }
            } catch (RemoteException rex) {
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(rex),
                    new Date());
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(new MessageModel("Errors")).build();
            }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/load/{year}")
    public Response load(@PathParam("year") Integer year) {
        final ServiceNames serviceName = ServiceNames.PREVIOUS_YEAR_SBU_COST_CENTERS_UPDATER;
        StringBuilder message = new StringBuilder();
        externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATING, Statuses.UPDATING.getMessage(),
            new Date());

        try {
            if (budgetService.isPMO()) {
                financialService.loadData(year);
                message.append("OK");
                externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.UPDATED, Statuses.UPDATED.getMessage(),
                    new Date());
                return Response.ok(message).build();
            }
        } catch (RemoteException rex) {
            LOG.debug("RemoteException in FinancialRestResource.load() method", rex);
            externalServiceSyncStatusProvider.writeStatus(serviceName, Statuses.FAILED, ErrorStackTracer.getStackTrace(rex),
                new Date());
            message.append(rex.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(new MessageModel("Errors")).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/details")
    public Response searchForDetails(@PathParam("issueKey") String issueKey) {
        if (canView(issueKey)) {
            List<FinancialModel> res = new ArrayList<>();
            for (Financial f : financialService.searchForDetails(issueKey)) {
                res.add(new FinancialModel(
                        f.getProductCode(),
                        f.getFinancialType().name(),
                        f.getFinancialValue(),
                        f.getFinancialDate()));
            }
            return Response.ok(res).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    private boolean canView(String issueKey) {
        return budgetService.canViewBudget(issueKey);
    }

}