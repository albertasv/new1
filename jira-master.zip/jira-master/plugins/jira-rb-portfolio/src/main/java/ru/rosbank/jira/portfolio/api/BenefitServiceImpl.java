package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.Benefit;
import ru.rosbank.jira.portfolio.model.BenefitModel;
import ru.rosbank.jira.portfolio.model.bean.BenefitBean;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService
@Named("benefitService")
public class BenefitServiceImpl implements BenefitService {

    private final ActiveObjects ao;

    @Inject
    public BenefitServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    @Override
    public Benefit[] search(String issueKey, boolean initial) {
        return ao.find(Benefit.class,
                Query.select()
                        .where("ISSUE = ? AND INITIAL = ?", issueKey, initial)
                        .order("\"BENEFIT_DATE\" DESC, \"CATEGORY\""));
    }

    @Override
    public Benefit add(String username, String issueKey, BenefitModel dataModel, boolean initial) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("ISSUE", issueKey)
                .put("CATEGORY", dataModel.getCategory())
                .put("BENEFIT_DATE", DateUtil.getDate(dataModel.getBenefitYear()))
                .put("BENEFIT_VALUE", dataModel.getBenefitValue())
                .put("INITIAL", initial)
                .put("LAST_UPDATED_BY", username)
                .put("LAST_UPDATE_DATE", new Date());

        if (dataModel.getComment() != null) {
            mapBuilder.put("COMMENT", dataModel.getComment());
        }
        
        if (dataModel.getInitial() != null) {
            mapBuilder.put("INITIAL", dataModel.getInitial());
        }
        return ao.create(Benefit.class, mapBuilder.build());
    }

    @Override
    public void delete(int id) {
        Benefit[] benefit = ao.find(Benefit.class, Query.select().where("ID = ?", id));
        for (Benefit b : benefit) {
            ao.delete(b);
        }
    }

    @Override
    public BenefitBean getBenefits(String issueKey) {
        Benefit[] benefits = search(issueKey, false);
        BenefitBean benefitBean = new BenefitBean();
        for (Benefit benefit : benefits) {
            benefitBean.addValue(benefit);
        }
        return benefitBean;
    }
}
