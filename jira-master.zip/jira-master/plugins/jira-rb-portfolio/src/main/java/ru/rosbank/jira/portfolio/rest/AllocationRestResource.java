package ru.rosbank.jira.portfolio.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.portfolio.ao.Allocation;
import ru.rosbank.jira.portfolio.ao.Domain;
import ru.rosbank.jira.portfolio.api.*;
import ru.rosbank.jira.portfolio.model.AllocationModel;
import ru.rosbank.jira.portfolio.model.DomainModel;
import ru.rosbank.jira.portfolio.model.MessageModel;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Component
@Path("/allocation")
public class AllocationRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(AllocationRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final AllocationService allocationService;
    private final BudgetService budgetService;
    private final DomainService domainService;


    @Inject
    public AllocationRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            AllocationService allocationService,
            BudgetService budgetService,
            DomainService domainService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.allocationService = allocationService;
        this.budgetService = budgetService;
        this.domainService = domainService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}")
    public Response search(
            @PathParam("issueKey") String issueKey,
            @QueryParam("initial") Boolean initial) {
        if (canView(issueKey)) {
            List<AllocationModel> res = new ArrayList<>();

            for (Allocation a : allocationService.search(issueKey, Boolean.TRUE.equals(initial))) {
                Domain domain = domainService.getByCode(a.getDomain());
                res.add(new AllocationModel(
                        a.getID(),
                        DomainModel.convert(domain),
                        a.getAllocationType(),
                        a.getAllocationValue(),
                        a.getLastUpdateDate(),
                        a.getLastUpdatedBy(),
                        a.getComment()));
            }
            return Response.ok(res).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{initial}")
    public Response add(@PathParam("issueKey") String issueKey,
                        @PathParam("initial") String initial,
                        AllocationModel dataModel) {
        if (canEdit(issueKey)) {
            String username = jiraAuthenticationContext.getLoggedInUser().getUsername();
            Allocation a = allocationService.add(username, issueKey, dataModel, "initial".equalsIgnoreCase(initial));
            Domain domain = domainService.getByCode(a.getDomain());
            return Response.ok(new AllocationModel(
                    a.getID(),
                    DomainModel.convert(domain),
                    a.getAllocationType(),
                    a.getAllocationValue(),
                    a.getLastUpdateDate(),
                    a.getLastUpdatedBy(),
                    a.getComment())).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{initial}/{id}")
    public Response delete(@PathParam("issueKey") String issueKey,
                           @PathParam("id") int id) {
        if (canEdit(issueKey)) {
            allocationService.delete(id);
            return Response.ok(new AllocationModel(id)).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    private boolean canView(String issueKey) {
        return budgetService.canViewBudget(issueKey);
    }

    private boolean canEdit(String issueKey) {
        return budgetService.canEditBudget(issueKey);
    }
}