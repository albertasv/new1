package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.ExternalBudget;
import ru.rosbank.jira.portfolio.ao.InternalBudget;
import ru.rosbank.jira.portfolio.model.BudgetModel;

@Transactional
public interface BudgetService {

    ExternalBudget[] searchExternal(String issueKey, boolean initial, boolean currentYear);

    InternalBudget[] searchInternal(String issueKey, boolean initial, boolean currentYear);

    void deleteExternal(int id);

    void deleteInternal(int id);

    ExternalBudget addExternal(String username, String issueKey, BudgetModel dataModel, boolean initial, boolean currentYear);

    InternalBudget addInternal(String username, String issueKey, BudgetModel dataModel, boolean initial, boolean currentYear);

    boolean canViewBudget(String issueKey);

    boolean canEditBudget(String issueKey);

    boolean isPMO();
}
