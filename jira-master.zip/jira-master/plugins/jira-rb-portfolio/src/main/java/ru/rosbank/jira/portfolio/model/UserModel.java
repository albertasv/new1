package ru.rosbank.jira.portfolio.model;

import com.atlassian.jira.user.ApplicationUser;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.portfolio.ao.CostCenter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserModel {

    private Long id;
    private String username;
    private String name;
    private String email;
    private String domain;

    public UserModel() {
    }

    public UserModel(Long id) {
        this.id = id;
    }

    public UserModel(ApplicationUser appUser, String domain) {
        id = appUser.getId();
        username = appUser.getUsername();
        name = appUser.getDisplayName();
        email = appUser.getEmailAddress();
        this.domain = domain;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getDomain() {
        return domain;
    }
}
