package ru.rosbank.jira.portfolio.rest;

import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.*;
import ru.rosbank.jira.portfolio.api.BudgetService;
import ru.rosbank.jira.portfolio.api.CostCenterService;
import ru.rosbank.jira.portfolio.api.FinancialService;
import ru.rosbank.jira.portfolio.api.ProductService;
import ru.rosbank.jira.portfolio.model.*;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

@Component
@Path("/budget")
public class BudgetRestResource {

    private static final Logger LOG = LoggerFactory.getLogger(BudgetRestResource.class);

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final FinancialService financialService;
    private final BudgetService budgetService;
    private final ProductService productService;
    private final CostCenterService costCenterService;

    @Inject
    public BudgetRestResource(
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            @ComponentImport PermissionManager permissionManager,
            FinancialService financialService,
            BudgetService budgetService,
            ProductService productService,
            CostCenterService costCenterService) {
        this.jiraAuthenticationContext = jiraAuthenticationContext;
        this.financialService = financialService;
        this.budgetService = budgetService;
        this.productService = productService;
        this.costCenterService = costCenterService;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{budgetType}")
    public Response search(
            @PathParam("issueKey") String issueKey,
            @PathParam("budgetType") String budgetType,
            @QueryParam("initial") Boolean initial,
            @QueryParam("cy") Boolean currentYear) {
        if (canView(issueKey)) {
            List<BudgetModel> res = new ArrayList<>();
            Map<String, ProductModel> products = new HashMap<>();
            if (budgetType.equalsIgnoreCase(Budget.EXTERNAL_BUDGET)) {
                for (ExternalBudget b : budgetService.searchExternal(issueKey, Boolean.TRUE.equals(initial), Boolean.TRUE.equals(currentYear))) {
                    Date budgetDate = b.getBudgetDate();
                    ProductModel productModel = financialService.getCashedProduct(products, b.getProduct());

                    res.add(new BudgetModel(
                            b.getID(),
                            productModel,
                            b.getBudgetValue(),
                            "Q" + DateUtil.getQuarter(budgetDate),
                            DateUtil.getYear(budgetDate),
                            b.getComment(),
                            b.getLastUpdateDate(),
                            b.getLastUpdatedBy()));
                }
            } else if (budgetType.equalsIgnoreCase(Budget.INTERNAL_BUDGET)) {
                Map<String, CostCenterModel> costCenters = new HashMap<>();
                for (InternalBudget b : budgetService.searchInternal(issueKey, Boolean.TRUE.equals(initial), Boolean.TRUE.equals(currentYear))) {
                    Date budgetDate = b.getBudgetDate();
                    CostCenterModel cc = financialService.getCashedCostCenter(costCenters, b.getCostCenter());

                    res.add(new BudgetModel(
                            b.getID(),
                            cc,
                            b.getMdBudgetValue(),
                            b.getBudgetValue(),
                            "Q" + DateUtil.getQuarter(budgetDate),
                            DateUtil.getYear(budgetDate),
                            b.getComment(),
                            b.getLastUpdateDate(),
                            b.getLastUpdatedBy()));
                }
            } else {
                return Response.status(Response.Status.NOT_FOUND).build();
            }

            return Response.ok(res).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/total")
    public Response total(
            @PathParam("issueKey") String issueKey,
            @QueryParam("initial") Boolean initial,
            @QueryParam("cy") Boolean currentYear) {
        if (canView(issueKey)) {
            double capex = 0;
            double opex = 0;
            double internalMd = 0;
            double internalTotal = 0;

            Map<String, ProductModel> products = new HashMap<>();
            for (ExternalBudget b : budgetService.searchExternal(issueKey, Boolean.TRUE.equals(initial), Boolean.TRUE.equals(currentYear))) {
                ProductModel product = financialService.getCashedProduct(products, b.getProduct());

                if (ExpenseType.CAPEX.name().equalsIgnoreCase(product.getExpenseType())) {
                    capex += b.getBudgetValue();
                } else {
                    opex += b.getBudgetValue();
                }
            }

            for (InternalBudget b : budgetService.searchInternal(issueKey, Boolean.TRUE.equals(initial), Boolean.TRUE.equals(currentYear))) {
                internalMd += b.getMdBudgetValue();
                internalTotal += b.getBudgetValue();
            }

            return Response.ok(new BudgetTotalModel(capex, opex, internalTotal, internalMd)).build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @POST
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{budgetType}/{initial}/{cy}")
    public Response add(@PathParam("issueKey") String issueKey,
                        @PathParam("budgetType") String budgetType,
                        @PathParam("initial") String initial,
                        @PathParam("cy") String currentYear,
                        BudgetModel dataModel) {
        if (canEdit(issueKey)) {
            String username = jiraAuthenticationContext.getLoggedInUser().getUsername();
            if (budgetType.equalsIgnoreCase(Budget.EXTERNAL_BUDGET)) {
                ExternalBudget b = budgetService.addExternal(username, issueKey, dataModel,
                        "initial".equalsIgnoreCase(initial),
                        "true".equalsIgnoreCase(currentYear));
                Date budgetDate = b.getBudgetDate();

                ProductModel productModel = null;
                Product p = productService.getByCode(b.getProduct());
                if (p != null) {
                    productModel = ProductModel.convert(p);
                }
                return Response.ok(new BudgetModel(
                        b.getID(),
                        productModel,
                        b.getBudgetValue(),
                        "Q" + DateUtil.getQuarter(budgetDate),
                        DateUtil.getYear(b.getBudgetDate()),
                        b.getComment(),
                        b.getLastUpdateDate(),
                        b.getLastUpdatedBy())).build();
            } else if (budgetType.equalsIgnoreCase(Budget.INTERNAL_BUDGET)) {
                InternalBudget b = budgetService.addInternal(username, issueKey, dataModel,
                        "initial".equalsIgnoreCase(initial),
                        "true".equalsIgnoreCase(currentYear));
                Date budgetDate = b.getBudgetDate();

                CostCenterModel ccModel = null;
                CostCenter cc = costCenterService.getByCode(b.getCostCenter());
                if (cc != null) {
                    ccModel = new CostCenterModel(cc.getID(), cc.getCode(), cc.getName());
                    ccModel.setB1(cc.getB1());
                    ccModel.setB1Name(cc.getB1Name());
                    ccModel.setDomain(cc.getDomain());
                    ccModel.setCustomerDomain(cc.getCustomerDomain());
                }
                return Response.ok(new BudgetModel(
                        b.getID(),
                        ccModel,
                        b.getMdBudgetValue(),
                        b.getBudgetValue(),
                        "Q" + DateUtil.getQuarter(budgetDate),
                        DateUtil.getYear(b.getBudgetDate()),
                        b.getComment(),
                        b.getLastUpdateDate(),
                        b.getLastUpdatedBy())).build();
            }
            return Response.ok().build();
        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    @DELETE
    @Produces({MediaType.APPLICATION_JSON})
    @Path("{issueKey}/{budgetType}/{initial}/{cy}/{id}")
    public Response delete(@PathParam("issueKey") String issueKey,
                           @PathParam("budgetType") String budgetType,
                           @PathParam("initial") String initial,
                           @PathParam("cy") String currentYear,
                           @PathParam("id") int id) {
        if (canEdit(issueKey)) {
            if (budgetType.equalsIgnoreCase(Budget.EXTERNAL_BUDGET)) {
                budgetService.deleteExternal(id);
            } else if (budgetType.equalsIgnoreCase(Budget.INTERNAL_BUDGET)) {
                budgetService.deleteInternal(id);
            } else {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            return Response.ok(new BudgetModel(id)).build();

        }
        return Response.status(Response.Status.FORBIDDEN).entity(new MessageModel("No access")).build();
    }

    private boolean canView(String issueKey) {
        return budgetService.canViewBudget(issueKey);
    }

    private boolean canEdit(String issueKey) {
        return budgetService.canEditBudget(issueKey);
    }
}