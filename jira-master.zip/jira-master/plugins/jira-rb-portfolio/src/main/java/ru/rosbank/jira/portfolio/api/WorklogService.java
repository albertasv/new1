package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.model.WorklogModel;

@Transactional
public interface WorklogService {

    WorklogModel searchWorklog(long issueId);

}
