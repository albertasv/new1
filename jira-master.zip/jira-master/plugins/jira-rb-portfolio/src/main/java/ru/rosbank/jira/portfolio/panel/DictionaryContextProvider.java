package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.apache.velocity.tools.generic.EscapeTool;
import ru.rosbank.jira.portfolio.api.BudgetService;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

public class DictionaryContextProvider extends AbstractJiraContextProvider {

    private final JiraAuthenticationContext authenticationContext;
    private final BudgetService budgetService;

    @Inject
    public DictionaryContextProvider(
            @ComponentImport JiraAuthenticationContext authenticationContext,
            BudgetService budgetService) {
        this.authenticationContext = authenticationContext;
        this.budgetService = budgetService;
    }

    @Override
    public Map getContextMap(ApplicationUser applicationUser, JiraHelper jiraHelper) {
        HashMap<String, Object> context = new HashMap<>();
        context.put("esc", new EscapeTool());
        context.put("canEdit", budgetService.isPMO());
        if (jiraHelper != null) {
            context.put("tab", jiraHelper.getRequest().getParameter("tab"));
            context.put("domain", jiraHelper.getRequest().getParameter("domain"));
        }
        return context;
    }
}
