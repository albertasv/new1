package ru.rosbank.jira.portfolio.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class DictionaryResultModel <E extends DictionaryModel> {
    private List<E> items;
    private int total;

    public DictionaryResultModel() {
    }

    public DictionaryResultModel(List<E> items, int total) {
        this.items = items;
        this.total = total;
    }

    public List<E> getItems() {
        return items;
    }

    public void setItems(List<E> items) {
        this.items = items;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
