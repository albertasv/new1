package ru.rosbank.jira.portfolio.model;

public enum DictionaryType {
    DOMAIN,
    COST_CENTER,
    PRODUCT,
    BUDGET_PRODUCT,
    EXECUTION_TEAM;

    public static DictionaryType getType(String type) {
        for (DictionaryType value : DictionaryType.values()) {
            if (value.name().equalsIgnoreCase(type)) {
                return value;
            }
        }
        return null;
    }
}
