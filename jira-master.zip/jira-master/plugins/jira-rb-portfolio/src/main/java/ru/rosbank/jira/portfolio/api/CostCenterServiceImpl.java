package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.ao.Domain;
import ru.rosbank.jira.portfolio.model.CostCenterModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("costCenterService")
public class CostCenterServiceImpl implements CostCenterService {

    private final ActiveObjects ao;
    private final UserManager userManager;
    private final DomainService domainService;

    @Inject
    public CostCenterServiceImpl(
            @ComponentImport ActiveObjects ao,
            DomainService domainService) {
        this.ao = checkNotNull(ao);
        this.userManager = ComponentAccessor.getUserManager();
        this.domainService = domainService;
    }

    @Override
    public List<CostCenter> all() {
        return newArrayList(ao.find(CostCenter.class, Query.select()));
    }

    @Override
    public int total() {
        return ao.count(CostCenter.class, Query.select());
    }

    @Override
    public CostCenter getByCode(String code) {
        CostCenter[] systems = ao.find(CostCenter.class, Query.select().where("\"CODE\" = ?", code));
        if (systems.length == 1) {
            return systems[0];
        }
        return null;
    }

    private static String SEARCH_QUERY = "(LOWER(\"CODE\" COLLATE \"en_US\") LIKE ? OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ? " +
            "OR LOWER(\"DOMAIN\" COLLATE \"en_US\") LIKE ? OR LOWER(\"CUSTOMER_DOMAIN\" COLLATE \"en_US\") LIKE ? " +
            "OR LOWER(\"B1_NAME\" COLLATE \"en_US\") LIKE ?)";
    private static String SEARCH_ORDER = "\"NAME\"";

    @Override
    public List<CostCenter> search(String query, int limit, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(CostCenter.class,
                    Query.select()
                            .order(SEARCH_ORDER)
                            .limit(limit)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(CostCenter.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery, likeQuery, likeQuery, likeQuery)
                .order(SEARCH_ORDER)
                .limit(limit)
                .offset(offset)
        ));
    }

    @Override
    public int total(String query) {
        if (Strings.isNullOrEmpty(query)) {
            return total();
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(CostCenter.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery, likeQuery, likeQuery, likeQuery));
    }

    @Override
    public CostCenter add(CostCenterModel data) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("CODE", data.getCode())
                .put("NAME", data.getName())
                .put("AGILE", "on".equalsIgnoreCase(data.getAgileOn()) || "true".equalsIgnoreCase(data.getAgileOn()));

        String customerDomain = data.getCustomerDomain();
        if (customerDomain != null) {
            Domain domainObject = domainService.getByCode(customerDomain);
            if (domainObject != null) {
                mapBuilder.put("CUSTOMER_DOMAIN", customerDomain);
                mapBuilder.put("DOMAIN", domainObject.getParentDomain());
            }
        }

        String sponsor = data.getSponsor();
        if (!Strings.isNullOrEmpty(sponsor)) {
            ApplicationUser sponsorAU = userManager.getUserByName(sponsor);
            if (sponsorAU != null) {
                mapBuilder.put("SPONSOR", sponsorAU.getUsername());
                mapBuilder.put("SPONSOR_NAME", sponsorAU.getDisplayName());
            }
        }
        String b1 = data.getB1();
        if (!Strings.isNullOrEmpty(b1)) {
            ApplicationUser b1AU = userManager.getUserByName(b1);
            if (b1AU != null) {
                mapBuilder.put("B1", b1AU.getUsername());
                mapBuilder.put("B1_NAME", b1AU.getDisplayName());
            }
        }
        String sbp = data.getSbp();
        if (!Strings.isNullOrEmpty(sbp)) {
            ApplicationUser sbpAU = userManager.getUserByName(sbp);
            if (sbpAU != null) {
                mapBuilder.put("SBP", sbpAU.getUsername());
                mapBuilder.put("SBP_NAME", sbpAU.getDisplayName());
            }
        }
        String fbp = data.getFbp();
        if (!Strings.isNullOrEmpty(fbp)) {
            List<ApplicationUser> fbpAU = Arrays.stream(fbp.split(";")).map(s -> userManager.getUserByName(s))
                    .collect(Collectors.toList());

            if (fbpAU != null) {
                mapBuilder.put("FBP", fbpAU.stream().map(au -> au.getUsername())
                        .collect(Collectors.joining(";")));
                mapBuilder.put("FBP_NAME", fbpAU.stream().map(au -> au.getDisplayName())
                        .collect(Collectors.joining(";")));
            }
        }
        String isOfficer = data.getIsOfficer();
        if (!Strings.isNullOrEmpty(isOfficer)) {
            ApplicationUser isOfficerAU = userManager.getUserByName(isOfficer);
            if (isOfficerAU != null) {
                mapBuilder.put("IS_OFFICER", isOfficerAU.getUsername());
                mapBuilder.put("IS_OFFICER_NAME", isOfficerAU.getDisplayName());
            }
        }
        String architect = data.getArchitect();
        if (!Strings.isNullOrEmpty(architect)) {
            ApplicationUser architectAU = userManager.getUserByName(architect);
            if (architectAU != null) {
                mapBuilder.put("ARCHITECT", architectAU.getUsername());
                mapBuilder.put("ARCHITECT_NAME", architectAU.getDisplayName());
            }
        }
        return ao.create(CostCenter.class, mapBuilder.build());
    }

    @Override
    public CostCenter update(int id, CostCenterModel data) {
        CostCenter[] dict = ao.find(CostCenter.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            CostCenter item = dict[0];
            String name = data.getName();
            if (name != null) {
                item.setName(name);
            }

            String customerDomain = data.getCustomerDomain();
            if (customerDomain != null) {
                Domain domainObject = domainService.getByCode(customerDomain);
                if (domainObject != null) {
                    item.setCustomerDomain(customerDomain);
                    item.setDomain(domainObject.getParentDomain());
                }
            }

            String sponsor = data.getSponsor();
            if (!Strings.isNullOrEmpty(sponsor)) {
                ApplicationUser sponsorAU = userManager.getUserByName(sponsor);
                if (sponsorAU != null) {
                    item.setSponsor(sponsorAU.getUsername());
                    item.setSponsorName(sponsorAU.getDisplayName());
                }
            }
            String b1 = data.getB1();
            if (!Strings.isNullOrEmpty(b1)) {
                ApplicationUser b1AU = userManager.getUserByName(b1);
                if (b1AU != null) {
                    item.setB1(b1AU.getUsername());
                    item.setB1Name(b1AU.getDisplayName());
                }
            }
            String sbp = data.getSbp();
            if (!Strings.isNullOrEmpty(sbp)) {
                ApplicationUser sbpAU = userManager.getUserByName(sbp);
                if (sbpAU != null) {
                    item.setSbp(sbpAU.getUsername());
                    item.setSbpName(sbpAU.getDisplayName());
                }
            }
            String fbp = data.getFbp();
            if (!Strings.isNullOrEmpty(fbp)) {
                ApplicationUser fbpAU = userManager.getUserByName(fbp);
                if (fbpAU != null) {
                    item.setFbp(fbpAU.getUsername());
                    item.setFbpName(fbpAU.getDisplayName());
                }
            }
            String isOfficer = data.getIsOfficer();
            if (!Strings.isNullOrEmpty(isOfficer)) {
                ApplicationUser isOfficerAU = userManager.getUserByName(isOfficer);
                if (isOfficerAU != null) {
                    item.setIsOfficer(isOfficerAU.getUsername());
                    item.setIsOfficerName(isOfficerAU.getDisplayName());
                }
            }
            String architect = data.getArchitect();
            if (!Strings.isNullOrEmpty(architect)) {
                ApplicationUser architectAU = userManager.getUserByName(architect);
                if (architectAU != null) {
                    item.setArchitect(architectAU.getUsername());
                    item.setArchitectName(architectAU.getDisplayName());
                }
            }

            item.setAgile("on".equalsIgnoreCase(data.getAgileOn()) || "true".equalsIgnoreCase(data.getAgileOn()));
            item.save();
            return item;
        }
        return null;
    }

    @Override
    public void delete(int id) {
        CostCenter[] dict = ao.find(CostCenter.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            ao.delete(dict[0]);
        }
    }
}
