package ru.rosbank.jira.portfolio.jql;

import com.atlassian.jira.JiraDataType;
import com.atlassian.jira.JiraDataTypes;
import com.atlassian.jira.jql.operand.QueryLiteral;
import com.atlassian.jira.jql.query.QueryCreationContext;
import com.atlassian.jira.jql.validator.NumberOfArgumentsValidator;
import com.atlassian.jira.plugin.jql.function.AbstractJqlFunction;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.MessageSet;
import com.atlassian.jira.util.MessageSetImpl;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.clause.TerminalClause;
import com.atlassian.query.operand.FunctionOperand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.UserInfoModel;
import ru.rosbank.jira.common.api.UserInfoService;
import ru.rosbank.jira.portfolio.api.ExecutionTeamService;
import ru.rosbank.jira.portfolio.model.ExecutionTeamModel;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class AgileTeamJqlFunc extends AbstractJqlFunction {

    private static final Logger LOG = LoggerFactory.getLogger(AgileTeamJqlFunc.class);

    private final UserInfoService userInfoService;

    private final ExecutionTeamService executionTeamService;

    @Inject
    public AgileTeamJqlFunc(@ComponentImport UserInfoService userInfoService, ExecutionTeamService executionTeamService) {
        this.executionTeamService = executionTeamService;
        this.userInfoService = userInfoService;
    }

    @Nonnull
    public MessageSet validate(ApplicationUser applicationUser,
                               @Nonnull FunctionOperand operand,
                               @Nonnull TerminalClause terminalClause) {
        return this.validateNumberOfArgs(operand, 1);
    }

    protected MessageSet validateNumberOfArgs(FunctionOperand operand, int expected) {
        // TODO: Объединить в одно условие
        MessageSet messages = new MessageSetImpl();
        if(operand.getArgs().size() == 0) {
            messages.addErrorMessage("Function " + operand.getName() + " expected '1' argument, but received '0'.");
            return messages;
        }
        if(operand.getArgs().get(0).equals("")) {
            messages.addErrorMessage("Function " + operand.getName() + " expected '1' argument, but received '0'.");
            return messages;
        }
        return (new NumberOfArgumentsValidator(expected, getI18n())).validate(operand);
    }


    @Nonnull
    public List<QueryLiteral> getValues(@Nonnull QueryCreationContext queryCreationContext, FunctionOperand operand,
                                        @Nonnull TerminalClause terminalClause) {
        final List<QueryLiteral> literals = new LinkedList<>();
        String teamCodeOrName = operand.getArgs().get(0);
        ExecutionTeamModel team = executionTeamService.getAgileTeam(teamCodeOrName);
        List<UserInfoModel> teamMembers = new ArrayList<>(userInfoService.getUserInfoByTeam(team.getId()));
        for(UserInfoModel teamMember : teamMembers) {
            literals.add(new QueryLiteral(operand, teamMember.getUsername()));
        }
        return literals;
    }

    public int getMinimumNumberOfExpectedArguments() {
        return 1;
    }

    @Nonnull
    public JiraDataType getDataType() {
        return JiraDataTypes.USER;
    }
}