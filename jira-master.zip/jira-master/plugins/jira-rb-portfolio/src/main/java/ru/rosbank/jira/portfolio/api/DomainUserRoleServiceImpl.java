package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.ao.DomainUserRole;
import ru.rosbank.jira.portfolio.ao.UserRoleType;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@Named("domainUserRoleService")
public class DomainUserRoleServiceImpl implements DomainUserRoleService {

    private final ActiveObjects ao;

    @Inject
    public DomainUserRoleServiceImpl(@ComponentImport ActiveObjects ao) {
        this.ao = checkNotNull(ao);
    }

    private static String SEARCH_QUERY = "( \"ROLE\" = ? )";

    @Override
    public List<DomainUserRole> search(UserRoleType userRoleType) {
        return newArrayList(ao.find(DomainUserRole.class, Query.select()
                .where(SEARCH_QUERY, userRoleType.name())));
    }

    @Override
    public DomainUserRole add(String username, String domain, UserRoleType userRoleType) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("USERNAME", username)
                .put("ROLE", userRoleType.name())
                .put("DOMAIN", domain);
        return ao.create(DomainUserRole.class, mapBuilder.build());
    }

    private static String DELETE_QUERY = "( \"USERNAME\" = ? AND \"ROLE\" = ? )";

    @Override
    public void delete(String username, UserRoleType userRoleType) {
        ao.deleteWithSQL(DomainUserRole.class, DELETE_QUERY, username, userRoleType.name());
    }
}
