package ru.rosbank.jira.portfolio.panel;

import com.atlassian.jira.plugin.webfragment.conditions.AbstractWebCondition;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.web.Condition;
import com.atlassian.plugin.web.baseconditions.BaseCondition;
import com.google.common.collect.ImmutableList;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PortfolioWebCondition extends AbstractWebCondition implements Condition, BaseCondition {

    private static List<String> PORTFOLIO_PROJECTS = ImmutableList.of("CRS", "PRJ", "PRE");

    @Override
    public boolean shouldDisplay(ApplicationUser applicationUser, JiraHelper jiraHelper) {
        Project project = jiraHelper.getProject();
        if (project != null && (PORTFOLIO_PROJECTS.contains(project.getKey()))) {
            return true;
        }
        return false;
    }
}
