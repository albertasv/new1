package ru.rosbank.jira.portfolio.model;

import ru.rosbank.jira.portfolio.ao.Dictionary;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class DictionaryModel {
    protected int id;
    protected String code;
    protected String name;

    public DictionaryModel() {
    }

    public DictionaryModel(int id) {
        this.id = id;
    }

    public DictionaryModel(int id, String code, String name) {
        this.id = id;
        this.code = code;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static DictionaryModel convert(DictionaryType type, Dictionary item) {
        return new DictionaryModel(item.getID(), item.getCode(), item.getName());
    }
}
