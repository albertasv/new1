package ru.rosbank.jira.portfolio.ao;

import com.google.common.collect.ImmutableMap;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum UserRoleType {
    FINANCIAL_CONTROL("fin", "Financial Control"),
    PMO("pmo", "Portfolio Administrators"),
    IS_OFFICER("is", "IS Officers"),
    IT_ARCHITECT("arch", "IT Architects");

    private String alias;
    private String group;

    UserRoleType(String alias, String group) {
        this.alias = alias;
        this.group = group;
    }

    public String getAlias() {
        return alias;
    }

    public String getGroup() {
        return group;
    }

    public static UserRoleType getByAlias(String groupAlias) {
        for (UserRoleType urt : UserRoleType.values()) {
            if (urt.getAlias().equalsIgnoreCase(groupAlias)) {
                return urt;
            }
        }
        return null;
    }

    public static Map<String, String> PORTFOLIO_GROUPS =
            Arrays.asList(UserRoleType.values()).stream().collect(Collectors.toMap(u -> u.getAlias(), o -> o.getGroup()));
}
