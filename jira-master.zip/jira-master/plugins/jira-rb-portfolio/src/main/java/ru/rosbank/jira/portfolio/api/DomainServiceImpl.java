package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.user.UserManager;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.portfolio.ao.Domain;
import ru.rosbank.jira.portfolio.model.DomainModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("domainService")
public class DomainServiceImpl implements DomainService {

    private final ActiveObjects ao;
    private final UserManager userManager;

    @Inject
    public DomainServiceImpl(@ComponentImport ActiveObjects ao,
                             @ComponentImport UserManager userManager) {
        this.ao = checkNotNull(ao);
        this.userManager = checkNotNull(userManager);
    }

    @Override
    public List<Domain> all() {
        return newArrayList(ao.find(Domain.class, Query.select()));
    }

    @Override
    public int total() {
        return ao.count(Domain.class, Query.select());
    }

    @Override
    public Domain getByCode(String code) {
        Domain[] dict = ao.find(Domain.class, Query.select().where("\"CODE\" = ?", code));
        if (dict.length == 1) {
            return dict[0];
        }
        return null;
    }

    private static String SEARCH_QUERY = "(" +
            "LOWER(\"CODE\" COLLATE \"en_US\") LIKE ?" +
            " OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ?" +
            ")";
    private static String SEARCH_ORDER = "\"PARENT_DOMAIN\", \"NAME\"";

    @Override
    public List<Domain> search(String query, int limit, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(Domain.class,
                    Query.select()
                            .order(SEARCH_ORDER)
                            .limit(limit)
                            .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(Domain.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery)
                .order(SEARCH_ORDER)
                .limit(limit)
                .offset(offset)
        ));
    }

    @Override
    public int total(String query) {
        if (Strings.isNullOrEmpty(query)) {
            return total();
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(Domain.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery));
    }

    @Override
    public Domain add(DomainModel data) {
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("CODE", data.getCode())
                .put("NAME", data.getName())
                .put("PARENT_DOMAIN", data.getParentDomain());
        return ao.create(Domain.class, mapBuilder.build());
    }

    @Override
    public Domain update(int id, DomainModel data) {
        Domain[] dict = ao.find(Domain.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            Domain domain = dict[0];
            String name = data.getName();
            if (name != null) {
                domain.setName(name);
            }
            domain.save();
            return domain;
        }
        return null;
    }

    @Override
    public void delete(int id) {
        Domain[] dict = ao.find(Domain.class, Query.select().where("\"ID\" = ?", id));
        if (dict.length == 1) {
            ao.delete(dict[0]);
        }
    }
}
