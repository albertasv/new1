package ru.rosbank.jira.portfolio.model;

import ru.rosbank.jira.portfolio.ao.CostCenter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class CostCenterModel extends DictionaryModel {

    private String domain;
    private String customerDomain;
    private String b1;
    private String b1Name;
    private String sponsor;
    private String sponsorName;
    private String sbp;
    private String sbpName;
    private String fbp;
    private String fbpName;
    private String isOfficer;
    private String isOfficerName;
    private String architect;
    private String architectName;
    private boolean agile;
    private String agileOn;

    public CostCenterModel() {
    }

    public CostCenterModel(int id) {
        this.id = id;
    }

    public CostCenterModel(int id, String code, String name) {
        super(id, code, name);
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getCustomerDomain() {
        return customerDomain;
    }

    public void setCustomerDomain(String customerDomain) {
        this.customerDomain = customerDomain;
    }

    public String getB1() {
        return b1;
    }

    public void setB1(String b1) {
        this.b1 = b1;
    }

    public String getB1Name() {
        return b1Name;
    }

    public void setB1Name(String b1Name) {
        this.b1Name = b1Name;
    }

    public String getSponsor() {
        return sponsor;
    }

    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getSbp() {
        return sbp;
    }

    public void setSbp(String sbp) {
        this.sbp = sbp;
    }

    public String getSbpName() {
        return sbpName;
    }

    public void setSbpName(String sbpName) {
        this.sbpName = sbpName;
    }

    public String getFbp() {
        return fbp;
    }

    public void setFbp(String fbp) {
        this.fbp = fbp;
    }

    public String getFbpName() {
        return fbpName;
    }

    public void setFbpName(String fbpName) {
        this.fbpName = fbpName;
    }

    public String getIsOfficer() {
        return isOfficer;
    }

    public void setIsOfficer(String isOfficer) {
        this.isOfficer = isOfficer;
    }

    public String getIsOfficerName() {
        return isOfficerName;
    }

    public void setIsOfficerName(String isOfficerName) {
        this.isOfficerName = isOfficerName;
    }

    public String getArchitect() {
        return architect;
    }

    public void setArchitect(String architect) {
        this.architect = architect;
    }

    public String getArchitectName() {
        return architectName;
    }

    public void setArchitectName(String architectName) {
        this.architectName = architectName;
    }

    public boolean isAgile() {
        return agile;
    }

    public void setAgile(boolean agile) {
        this.agile = agile;
    }

    public String getAgileOn() {
        return agileOn;
    }

    public void setAgileOn(String agileOn) {
        this.agileOn = agileOn;
    }

    public static CostCenterModel convert(CostCenter item) {
        CostCenterModel cc = new CostCenterModel(item.getID(), item.getCode(), item.getName());
        cc.setDomain(item.getDomain());
        cc.setCustomerDomain(item.getCustomerDomain());
        cc.setB1(item.getB1());
        cc.setB1Name(item.getB1Name());
        cc.setSponsor(item.getSponsor());
        cc.setSponsorName(item.getSponsorName());
        cc.setSbp(item.getSbp());
        cc.setSbpName(item.getSbpName());
        cc.setFbp(item.getFbp());
        cc.setFbpName(item.getFbpName());
        cc.setIsOfficer(item.getIsOfficer());
        cc.setIsOfficerName(item.getIsOfficerName());
        cc.setArchitect(item.getArchitect());
        cc.setArchitectName(item.getArchitectName());
        cc.setAgile(Boolean.TRUE.equals(item.getAgile()));
        return cc;
    }
}
