package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;

@Preload
public interface Product extends Dictionary {

    Boolean getBudgetProduct();

    void setBudgetProduct(boolean Boolean);

    String getCategory();

    void setCategory(String category);

    String getGroup();

    void setGroup(String group);

    ExpenseType getExpenseType();

    void setExpenseType(ExpenseType expenseType);

    Boolean getHidden();

    void setHidden(boolean hidden);
}
