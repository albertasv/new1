package ru.rosbank.jira.portfolio.model;

import com.atlassian.jira.project.Project;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectModel extends DictionaryModel {

    public ProjectModel(int id, String code, String name) {
        super(id, code, name);
    }

    public static ProjectModel convert(Project item) {
        return new ProjectModel(
                item.getId().intValue(),
                item.getKey(),
                item.getName());
    }
}
