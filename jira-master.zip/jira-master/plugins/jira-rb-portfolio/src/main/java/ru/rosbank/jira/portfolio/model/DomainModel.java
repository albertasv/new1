package ru.rosbank.jira.portfolio.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import ru.rosbank.jira.portfolio.ao.Domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DomainModel extends DictionaryModel {

    private String parentDomain;

    public DomainModel() {
    }

    public DomainModel(int id, String code, String name, String parentDomain) {
        super(id, code, name);
        this.parentDomain = parentDomain;
    }

    public static DomainModel convert(Domain item) {
        return new DomainModel(
                item.getID(),
                item.getCode(),
                item.getName(),
                item.getParentDomain());
    }

    public String getParentDomain() {
        return parentDomain;
    }

    public void setParentDomain(String parentDomain) {
        this.parentDomain = parentDomain;
    }
}
