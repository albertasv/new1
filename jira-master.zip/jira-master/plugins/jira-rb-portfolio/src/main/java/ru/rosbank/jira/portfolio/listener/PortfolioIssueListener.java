package ru.rosbank.jira.portfolio.listener;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.IssueTypeManager;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.exception.CreateException;
import com.atlassian.jira.issue.*;
import com.atlassian.jira.issue.context.IssueContextImpl;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.issue.link.IssueLink;
import com.atlassian.jira.issue.link.IssueLinkManager;
import com.atlassian.jira.issue.link.IssueLinkTypeManager;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.issue.status.Status;
import com.atlassian.jira.jql.parser.JqlParseException;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.model.ChangeItem;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.jira.workflow.JiraWorkflow;
import com.atlassian.jira.workflow.TransitionOptions;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.Query;
import com.google.common.base.Strings;
import com.opensymphony.workflow.loader.ActionDescriptor;
import com.opensymphony.workflow.loader.StepDescriptor;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.api.CostCenterService;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkNotNull;
import static ru.rosbank.jira.portfolio.utils.JiraUtil.*;


@Component
public class PortfolioIssueListener implements InitializingBean, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(PortfolioIssueListener.class);

    private final EventPublisher eventPublisher;
    private final JiraAuthenticationContext authenticationContext;
    private final IssueService issueService;
    private final CostCenterService costCenterService;
    private final ConfigLoader config;

    private final UserManager userManager;
    private final ProjectManager projectManager;
    private final IssueManager issueManager;
    private final IssueTypeManager issueTypeManager;
    private final CustomFieldManager customFieldManager;

    @Inject
    public PortfolioIssueListener(@ComponentImport EventPublisher eventPublisher,
                                  @ComponentImport JiraAuthenticationContext authenticationContext,
                                  @ComponentImport IssueService issueService,
                                  @ComponentImport ConfigLoader config,
                                  CostCenterService costCenterService) {
        this.eventPublisher = checkNotNull(eventPublisher);
        this.authenticationContext = checkNotNull(authenticationContext);
        this.issueService = checkNotNull(issueService);
        this.config = checkNotNull(config);
        this.costCenterService = costCenterService;

        this.userManager = ComponentAccessor.getUserManager();
        this.projectManager = ComponentAccessor.getProjectManager();
        this.issueManager = ComponentAccessor.getIssueManager();
        this.issueTypeManager = ComponentAccessor.getComponent(IssueTypeManager.class);
        this.customFieldManager = ComponentAccessor.getCustomFieldManager();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOG.info("Enabling portfolio listener");
        eventPublisher.register(this);
    }

    @Override
    public void destroy() throws Exception {
        LOG.info("Disabling portfolio listener");
        eventPublisher.unregister(this);
    }

    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {
        Long eventTypeId = issueEvent.getEventTypeId();
        MutableIssue issue = (MutableIssue) issueEvent.getIssue();
        ApplicationUser currentUser = authenticationContext.getLoggedInUser();

        if (eventTypeId.equals(EventType.ISSUE_CREATED_ID)) {
            // Create Portfolio links for new Issues
            CustomField portfolioIssueField = ComponentAccessor.getCustomFieldManager().getCustomFieldObject(config.getPortfolioIssueFieldId());
            Issue portfolioIssue = (Issue) issue.getCustomFieldValue(portfolioIssueField);
            if (portfolioIssue != null) {
                try {
                    IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
                    Long splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(config.getSplitIssueLinkType()).getId();
                    issueLinkManager.createIssueLink(
                            portfolioIssue.getId(),
                            issue.getId(),
                            splitLinkType,
                            0l,
                            currentUser
                    );
                } catch (Exception ex) {
                    LOG.error("Create Link Exception {}", ex);
                }
            }

            // Create Issues for Architects and IS Officers
            Project project = issue.getProjectObject();
            if (project != null && config.getJiraCRSProject().equals(project.getKey())) {
                ApplicationUser syncUser = userManager.getUserByName(config.getJiraPpmSyncUser());
                //JIRA-4071
                //createArchTask(syncUser, issue);

                //JIRA-3169
                //createISTask(syncUser, issue);
            }
        } else if (eventTypeId.equals(EventType.ISSUE_UPDATED_ID)) {
            try {
                issueEvent.getChangeLog()
                        .getRelated("ChildChangeItem").stream().forEach(
                        cit -> {
                            // Create Portfolio links for updated Issues
                            // "Portfolio Issue" Field updated
                            Object ciField = cit.get(ChangeItem.FIELD);
                            if (config.getPortfolioIssueFieldName().equals(ciField)) {
                                String oldValue = (String) cit.get(ChangeItem.OLDSTRING);
                                String newValue = (String) cit.get(ChangeItem.NEWSTRING);
                                if (ObjectUtils.notEqual(oldValue, newValue)) {
                                    IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
                                    Long splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(config.getSplitIssueLinkType()).getId();
                                    if (!Strings.isNullOrEmpty(oldValue)) {
                                        // remove old link
                                        MutableIssue portfolioIssue = issueManager.getIssueByCurrentKey(oldValue);
                                        IssueLink issueLink = issueLinkManager.getIssueLink(
                                                portfolioIssue.getId(),
                                                issue.getId(),
                                                splitLinkType);
                                        issueLinkManager.removeIssueLink(issueLink, currentUser);
                                    }

                                    if (!Strings.isNullOrEmpty(newValue)) {
                                        // create link for new value
                                        MutableIssue portfolioIssue = issueManager.getIssueByCurrentKey(newValue);
                                        try {
                                            issueLinkManager.createIssueLink(
                                                    portfolioIssue.getId(),
                                                    issue.getId(),
                                                    splitLinkType,
                                                    0l,
                                                    currentUser
                                            );
                                        } catch (Exception ex) {
                                            LOG.error("Create Link Exception {}", ex);
                                        }
                                    }
                                }
                            } else if (config.getITArchitectFieldName().equals(ciField)) {
                                String newArchitect = (String) cit.get(ChangeItem.NEWVALUE);
                                updateArchTask(currentUser, issue, newArchitect, null);
                            } else if (config.getItArchitectResolutionName().equals(ciField)) {
                                String newStatus = cit.get(ChangeItem.NEWVALUE) == null ? "To Do" : "Done";
                                updateArchTask(currentUser, issue, null, newStatus);
                            }
                        });

            } catch (Exception e) {
                LOG.error("Search ChangeItems for Portfolio Issues exception {}", e);
            }
        }
    }

    /**
     * Create IS issue
     *
     * @param syncUser
     * @param issue
     */
    private void createISTask(ApplicationUser syncUser, Issue issue) {
        LOG.debug("Start creation of issue for IS Architects.");
        IssueInputParameters inputParameters = issueService.newIssueInputParameters();
        inputParameters.setSkipScreenCheck(true);

        // Project
        Project project = projectManager.getProjectByCurrentKey(config.getJiraISOfficeProject());
        inputParameters.setProjectId(project.getId());

        // Summary
        inputParameters.setSummary("IS analysis " + issue.getKey() + ": " + issue.getSummary());

        // Assignee IS Officer or ARC leader
        ApplicationUser isOfficer = (ApplicationUser) issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getISOfficerFieldId()));
        if (isOfficer == null) {
            isOfficer = project.getProjectLead();
        }
        inputParameters.setAssigneeId(isOfficer.getUsername());

        // Due date
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar dueDate = Calendar.getInstance();
        dueDate.setTime(new Date());
        dueDate.add(Calendar.DAY_OF_YEAR, 7);
        inputParameters.setDueDate(sdf.format(dueDate.getTime()));

        Issue isIssue = createIssue(syncUser, inputParameters, issue);
        if (isIssue == null) {
            addComment(issue, syncUser, "При создании задачи на группу офицеров ИБ произошла ошибка. Создайте вручную или обратитесь администраторам.");
        }
        LOG.debug("Finish creation of issue for IS Officer.");
    }

    /**
     * Create Arch issue
     *
     * @param syncUser
     * @param issue
     */
    private void createArchTask(ApplicationUser syncUser, Issue issue) {
        LOG.debug("Start creation of issue for IT Architects.");
        IssueInputParameters inputParameters = issueService.newIssueInputParameters();
        inputParameters.setSkipScreenCheck(true);

        // Project
        Project project = projectManager.getProjectByCurrentKey(config.getJiraArchitectProject());
        inputParameters.setProjectId(project.getId());

        inputParameters.setSummary("Arch analysis " + issue.getKey() + ": " + issue.getSummary());

        // Assignee IT Architect
        ApplicationUser architect = (ApplicationUser) issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getITArchitectFieldId()));
        inputParameters.setAssigneeId(architect == null ? "backlog" : architect.getUsername());

        Issue archIssue = createIssue(syncUser, inputParameters, issue);
        if (archIssue == null) {
            addComment(issue, syncUser, "При создании задачи на группу архитекторов произошла ошибка. Создайте вручную или обратитесь администраторам.");
        }
        LOG.debug("Finish creation of issue for IT Architects.");
    }

    private Issue createIssue(ApplicationUser syncUser, IssueInputParameters inputParameters, Issue sourceIssue) {
        // Set context syncUser
        ComponentAccessor.getJiraAuthenticationContext().setLoggedInUser(syncUser);

        // Issue type
        IssueType type = issueTypeManager.getIssueTypes().stream()
                .filter(issueType -> "Task".equals(issueType.getName())).findAny().orElse(null);
        inputParameters.setIssueTypeId(type.getId());

        // Medium priority
        inputParameters.setPriorityId("10002");

        // CR manager
        ApplicationUser manager = (ApplicationUser) sourceIssue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getManagerFieldId()));
        inputParameters.setReporterId(manager.getUsername());

        // Domain
        String costCenterCode = (String) sourceIssue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getCostCenterFieldId()));
        if (!Strings.isNullOrEmpty(costCenterCode)) {
            CostCenter costCenter = costCenterService.getByCode(costCenterCode);
            if (costCenter != null) {
                if (costCenter.getCustomerDomain() != null) {
                    CustomField domainField = customFieldManager.getCustomFieldObject(config.getDomainFieldId());
                    IssueContextImpl issueContext = new IssueContextImpl(inputParameters.getProjectId(), inputParameters.getIssueTypeId());
                    boolean isDomainSet = setSingleSelect(null, inputParameters, issueContext, domainField, costCenter.getCustomerDomain());
                    if (!isDomainSet && costCenter.getDomain() != null) {
                        setSingleSelect(null, inputParameters, issueContext, domainField, costCenter.getDomain());
                    }
                }
            }
        }

        // Issue Source - Portfolio
        inputParameters.addCustomFieldValue(config.getJiraIssueSourceFieldId(), "Portfolio");

        inputParameters.addCustomFieldValue(config.getPortfolioIssueFieldId(), sourceIssue.getKey());

        LOG.debug("Application user for creation {}", syncUser);
        IssueService.CreateValidationResult validationResult =
                issueService.validateCreate(syncUser, inputParameters);
        String validationErrors = errors(validationResult.getErrorCollection());
        if (validationErrors == null) {
            IssueService.IssueResult issueResult = issueService.create(syncUser, validationResult);
            String createErrors = errors(issueResult.getErrorCollection());
            if (createErrors == null) {
                MutableIssue resultIssue = issueResult.getIssue();
                LOG.debug("Issue Created - {}", resultIssue.getKey());

                // Set Link issues
                IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
                Long splitLinkType = ComponentAccessor.getComponent(IssueLinkTypeManager.class).getIssueLinkType(config.getSplitIssueLinkType()).getId();
                try {
                    issueLinkManager.createIssueLink(
                            sourceIssue.getId(),
                            resultIssue.getId(),
                            splitLinkType,
                            0l,
                            syncUser
                    );
                } catch (CreateException cex) {
                    LOG.error("Issue link error - {}", cex);
                }
                return resultIssue;
            } else {
                LOG.error("Issue create result error - {}", createErrors);
            }
        } else {
            LOG.debug("Issue create validation error - {}", validationErrors);
        }
        return null;
    }

    private void updateArchTask(ApplicationUser syncUser, Issue issue, String newArchitect, String newStatus) {
        Project project = issue.getProjectObject();
        if (project != null && config.getJiraCRSProject().equals(project.getKey())) {
            try {
                String jqlTemplate = "project = '%s' AND issueFunction in linkedIssuesOf('key = %s', 'split to')";
                String jql = String.format(jqlTemplate, config.getJiraArchitectProject(), issue.getKey());
                // String jqlTemplate = "project = '%s' AND '%s' = %s";
                // String jql = String.format(jqlTemplate, config.getJiraArchitectProject(), config.getPortfolioIssueFieldName(), issue.getKey());
                Query query = ComponentAccessor.getComponent(JqlQueryParser.class)
                        .parseQuery(jql);
                SearchResults<Issue> searchResult = ComponentAccessor.getComponent(SearchService.class)
                        .search(syncUser, query, PagerFilter.newPageAlignedFilter(0, 2));
                int total = searchResult.getTotal();
                if (total == 1) {
                    Issue architectIssue = searchResult.getResults().get(0);

                    // Set newArchitect as assignee
                    IssueInputParameters issueInputParameters = issueService.newIssueInputParameters();
                    if (!Strings.isNullOrEmpty(newArchitect)) {
                        issueInputParameters.setSkipScreenCheck(true);

                        ApplicationUser newArchitectByKey = userManager.getUserByKey(newArchitect);
                        if (newArchitectByKey == null) {
                            newArchitectByKey = userManager.getUserByName(newArchitect);
                        }

                        if (newArchitectByKey != null) {
                            issueInputParameters.setAssigneeId(newArchitectByKey.getUsername());
                            issueInputParameters.setComment("Поле IT Architect изменено в CR");

                            IssueService.UpdateValidationResult updateValidationResult =
                                    issueService.validateUpdate(syncUser, architectIssue.getId(), issueInputParameters);

                            String validationErrors = errors(updateValidationResult.getErrorCollection());
                            if (validationErrors == null) {
                                IssueService.IssueResult issueResult = issueService.update(syncUser, updateValidationResult);
                                String updateErrors = errors(issueResult.getErrorCollection());
                                if (updateErrors == null) {
                                    architectIssue = issueResult.getIssue();
                                    LOG.debug("Architect Issue Updated - {}", architectIssue.getKey());
                                } else {
                                    LOG.error("Architect Issue update error - {}", updateErrors);
                                }
                            }
                        } else {
                            LOG.error("Architect not found - {}", newArchitect);
                        }
                    }

                    if (!Strings.isNullOrEmpty(newStatus)) {
                        // Transition
                        Status portfolioIssueStatus = architectIssue.getStatus();
                        if (!portfolioIssueStatus.getName().equalsIgnoreCase(newStatus)) {
                            JiraWorkflow jiraWorkflow = ComponentAccessor.getWorkflowManager().getWorkflow(architectIssue);
                            // Looking for common transition
                            StepDescriptor oStep = jiraWorkflow.getLinkedStep(portfolioIssueStatus);
                            List<ActionDescriptor> oActions = (List<ActionDescriptor>) oStep.getActions();
                            Optional<ActionDescriptor> anyAction = oActions.stream()
                                    .filter(oAction -> oAction.getName().equalsIgnoreCase(newStatus))
                                    .findAny();
                            Integer actionId = null;
                            if (anyAction.isPresent()) {
                                ActionDescriptor oAction = anyAction.get();
                                actionId = oAction.getId();
                            } else {
                                // If there is no common action, looking for global
                                Optional<ActionDescriptor> anyGlobalAction = jiraWorkflow.getAllActions().stream().filter(oAction ->
                                        jiraWorkflow.isGlobalAction(oAction) && (oAction.getName().equalsIgnoreCase(newStatus)))
                                        .findAny();
                                if (anyGlobalAction.isPresent()) {
                                    actionId = anyGlobalAction.get().getId();
                                }
                            }

                            if (actionId != null) {
                                issueInputParameters.setComment("Поле IT Architect Resolution изменено в CR");
                                TransitionOptions transitionOptions = new TransitionOptions.Builder().skipConditions().build();
                                IssueService.TransitionValidationResult transitionValidationResult
                                        = issueService.validateTransition(syncUser,
                                        architectIssue.getId(),
                                        actionId,
                                        issueInputParameters, transitionOptions);
                                String transitionValidationErrors = errors(transitionValidationResult.getErrorCollection());
                                if (transitionValidationErrors == null) {
                                    IssueService.IssueResult transitionResult = issueService.transition(syncUser, transitionValidationResult);
                                    String transitionErrors = errors(transitionResult.getErrorCollection());

                                    if (transitionErrors == null) {
                                        // TO transition result HERE
                                    }
                                }
                            }
                        }
                    }
                }

            } catch (JqlParseException | SearchException e) {
                LOG.error("Update architect issue error", e);
            }
        }
    }

    private void addComment(Issue issue, ApplicationUser user, String comment) {
        ComponentAccessor.getCommentManager().create(issue, user, comment, false);
    }
}