package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.Product;
import ru.rosbank.jira.portfolio.model.ProductModel;

import java.util.List;

@Transactional
public interface ProductService extends DictionaryService<Product> {

    List<Product> search(boolean isBudgetProduct, String query, int limit, int offset);

    Product add(ProductModel data);

    Product update(int id, ProductModel data);

    void delete(int id);
}
