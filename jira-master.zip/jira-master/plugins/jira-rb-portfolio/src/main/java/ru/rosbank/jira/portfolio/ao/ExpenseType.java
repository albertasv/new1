package ru.rosbank.jira.portfolio.ao;

public enum ExpenseType {
    CAPEX, OPEX;

    public static ExpenseType getValue(String name) {
        try {
            return ExpenseType.valueOf(name);
        } catch (Exception ex) {
            return null;
        }
    }
}
