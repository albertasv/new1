package ru.rosbank.jira.portfolio.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BudgetModel {

    private Integer id;
    private ProductModel product;
    private String productCode;

    private String quarter;
    private Double budgetValue;

    private CostCenterModel costCenter;
    private String costCenterCode;
    private Double mdBudgetValue;

    private Integer budgetYear;
    private String comment;
    private Date lastUpdateDate;
    private String lastUpdatedBy;

    public BudgetModel() {
    }

    public BudgetModel(Integer id) {
        this.id = id;
    }

    public BudgetModel(
            Integer id,
            ProductModel product,
            Double budgetValue,
            String quarter,
            Integer budgetYear,
            String comment,
            Date lastUpdateDate,
            String lastUpdatedBy) {
        this.id = id;
        this.product = product;
        this.comment = comment;
        this.budgetValue = budgetValue;
        this.quarter = quarter;
        this.budgetYear = budgetYear;
        this.lastUpdateDate = lastUpdateDate;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public BudgetModel(
            Integer id,
            CostCenterModel costCenter,
            Double mdBudgetValue,
            Double budgetValue,
            String quarter,
            Integer budgetYear,
            String comment,
            Date lastUpdateDate,
            String lastUpdatedBy) {
        this.id = id;
        this.costCenter = costCenter;
        this.mdBudgetValue = mdBudgetValue;
        this.budgetValue = budgetValue;
        this.quarter = quarter;
        this.budgetYear = budgetYear;
        this.comment = comment;
        this.lastUpdateDate = lastUpdateDate;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ProductModel getProduct() {
        return product;
    }

    public void setProduct(ProductModel product) {
        this.product = product;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Double getBudgetValue() {
        return budgetValue;
    }

    public void setBudgetValue(Double budgetValue) {
        this.budgetValue = budgetValue;
    }

    public CostCenterModel getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(CostCenterModel costCenter) {
        this.costCenter = costCenter;
    }

    public String getCostCenterCode() {
        return costCenterCode;
    }

    public void setCostCenterCode(String costCenterCode) {
        this.costCenterCode = costCenterCode;
    }

    public Double getMdBudgetValue() {
        return mdBudgetValue;
    }

    public void setMdBudgetValue(Double mdBudgetValue) {
        this.mdBudgetValue = mdBudgetValue;
    }

    public Integer getBudgetYear() {
        return budgetYear;
    }

    public void setBudgetYear(Integer budgetYear) {
        this.budgetYear = budgetYear;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getQuarter() {
        return quarter;
    }

    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }
}
