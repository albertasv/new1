package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.Allocation;
import ru.rosbank.jira.portfolio.model.AllocationModel;
import ru.rosbank.jira.portfolio.model.bean.AllocationBean;

@Transactional
public interface AllocationService {

    Allocation[] search(String issueKey, boolean initial);

    void delete(int id);

    Allocation add(String username, String issueKey, AllocationModel dataModel, boolean initial);
    
    AllocationBean getAllocation(String issueKey);
}
