package ru.rosbank.jira.portfolio.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class BudgetTotalModel {
    private double externalTotal = 0;
    private double externalCapex = 0;
    private double externalOpex = 0;
    private double internalTotal = 0;
    private double internalMd = 0;

    public BudgetTotalModel(double externalCapex, double externalOpex, double internalTotal, double internalMd) {
        this.externalTotal = externalCapex + externalOpex;
        this.externalCapex = externalCapex;
        this.externalOpex = externalOpex;
        this.internalTotal = internalTotal;
        this.internalMd = internalMd;
    }

    public double getExternalTotal() {
        return externalTotal;
    }

    public double getExternalCapex() {
        return externalCapex;
    }

    public double getExternalOpex() {
        return externalOpex;
    }

    public double getInternalTotal() {
        return internalTotal;
    }

    public double getInternalMd() {
        return internalMd;
    }
}
