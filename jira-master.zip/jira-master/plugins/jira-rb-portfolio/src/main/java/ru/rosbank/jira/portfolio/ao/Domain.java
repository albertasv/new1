package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Preload;

@Preload
public interface Domain extends Dictionary {

    String getParentDomain();

    void setParentDomain(String name);
}
