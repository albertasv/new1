package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.Domain;
import ru.rosbank.jira.portfolio.model.DomainModel;

@Transactional
public interface DomainService extends DictionaryService<Domain> {

    Domain add(DomainModel data);

    Domain update(int id, DomainModel data);

    void delete(int id);
}
