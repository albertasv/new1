package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import net.java.ao.Query;
import ru.rosbank.jira.common.api.ConfigLoader;
import ru.rosbank.jira.portfolio.utils.DateUtil;
import ru.rosbank.jira.portfolio.ao.Budget;
import ru.rosbank.jira.portfolio.ao.ExternalBudget;
import ru.rosbank.jira.portfolio.ao.InternalBudget;
import ru.rosbank.jira.portfolio.model.BudgetModel;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

@ExportAsService
@Named("budgetService")
public class BudgetServiceImpl implements BudgetService {

    private final JiraAuthenticationContext jiraAuthenticationContext;
    private final ActiveObjects ao;
    private final ConfigLoader config;


    private final IssueManager issueManager;
    private final CustomFieldManager customFieldManager;
    private final GroupManager groupManager;

    @Inject
    public BudgetServiceImpl(
            @ComponentImport ActiveObjects ao,
            @ComponentImport JiraAuthenticationContext jiraAuthenticationContext,
            @ComponentImport ConfigLoader config) {
        this.ao = checkNotNull(ao);
        this.jiraAuthenticationContext = checkNotNull(jiraAuthenticationContext);
        this.config = checkNotNull(config);

        this.issueManager = ComponentAccessor.getIssueManager();
        this.customFieldManager = ComponentAccessor.getCustomFieldManager();
        this.groupManager = ComponentAccessor.getGroupManager();
    }

    @Override
    public ExternalBudget[] searchExternal(String issueKey, boolean initial, boolean currentYear) {
        return ao.find(ExternalBudget.class,
                Query.select()
                        .where("ISSUE = ? AND INITIAL = ? AND CURRENT_YEAR = ?", issueKey, initial, currentYear)
                        .order("BUDGET_DATE DESC, LAST_UPDATE_DATE DESC"));
    }

    @Override
    public InternalBudget[] searchInternal(String issueKey, boolean initial, boolean currentYear) {
        return ao.find(InternalBudget.class,
                Query.select()
                        .where("ISSUE = ? AND INITIAL = ? AND CURRENT_YEAR = ?", issueKey, initial, currentYear));
    }

    @Override
    public ExternalBudget addExternal(String username, String issueKey, BudgetModel dataModel, boolean initial, boolean currentYear) {
        int quarter = Integer.parseInt(dataModel.getQuarter().substring(1));
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("ISSUE", issueKey)
                .put("PRODUCT", dataModel.getProductCode())
                .put("BUDGET_DATE", DateUtil.getDate(dataModel.getBudgetYear(), quarter))
                .put("BUDGET_VALUE", dataModel.getBudgetValue())
                .put("INITIAL", initial)
                .put("LAST_UPDATED_BY", username)
                .put("LAST_UPDATE_DATE", new Date())
                .put("CURRENT_YEAR", currentYear);

        if (!Strings.isNullOrEmpty(dataModel.getComment())) {
            mapBuilder.put("COMMENT", dataModel.getComment());
        }

        return ao.create(ExternalBudget.class, mapBuilder.build());
    }

    @Override
    public InternalBudget addInternal(String username, String issueKey, BudgetModel dataModel, boolean initial, boolean currentYear) {
        // TODO calc budgetValue RUR
        int quarter = Integer.parseInt(dataModel.getQuarter().substring(1));
        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                .put("ISSUE", issueKey)
                .put("BUDGET_DATE", DateUtil.getDate(dataModel.getBudgetYear(), quarter))
                .put("COST_CENTER", dataModel.getCostCenterCode())
                .put("MD_BUDGET_VALUE", dataModel.getMdBudgetValue())
                .put("INITIAL", initial)
                .put("LAST_UPDATED_BY", username)
                .put("LAST_UPDATE_DATE", new Date())
                .put("CURRENT_YEAR", currentYear);


        if (dataModel.getBudgetValue() != null) {
            mapBuilder.put("BUDGET_VALUE", dataModel.getBudgetValue());
        } else {
            mapBuilder.put("BUDGET_VALUE", 0.0);
        }

        if (!Strings.isNullOrEmpty(dataModel.getComment())) {
            mapBuilder.put("COMMENT", dataModel.getComment());
        }
        return ao.create(InternalBudget.class, mapBuilder.build());
    }

    @Override
    public void deleteExternal(int id) {
        ExternalBudget[] budgets = ao.find(ExternalBudget.class, Query.select().where("ID = ?", id));
        for (ExternalBudget b : budgets) {
            ao.delete(b);
        }
    }

    @Override
    public void deleteInternal(int id) {
        Budget[] budgets = ao.find(InternalBudget.class, Query.select().where("ID = ?", id));
        for (Budget b : budgets) {
            ao.delete(b);
        }
    }

    @Override
    public boolean canViewBudget(String issueKey) {
        ApplicationUser user = jiraAuthenticationContext.getLoggedInUser();
        // CR / Project Manager
        Object manager = issueManager.getIssueObject(issueKey).getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getManagerFieldId()));
        if (user != null && user.equals(manager)) {
            return true;
        }
        // Groups
        if (userInGroup(user,
                ImmutableList.of("IS Officers", "IT Architects", "Portfolio Administrators", "Financial Control"))) {
            return true;
        }
        return false;
    }

    @Override
    public boolean canEditBudget(String issueKey) {
        ApplicationUser user = jiraAuthenticationContext.getLoggedInUser();
        MutableIssue issue = issueManager.getIssueObject(issueKey);

        // Groups
        if (userInGroup(user, ImmutableList.of("Portfolio Administrators"))) {
            return true;
        }

        // Financial Resolution
        Object finResolution = issue.getCustomFieldValue(ComponentAccessor.getCustomFieldManager().getCustomFieldObject(config.getFinancialResolutionId()));
        if (finResolution != null) {
            return false;
        }
        // CR / Project Manager
        Object manager = issue.getCustomFieldValue(customFieldManager.getCustomFieldObject(config.getManagerFieldId()));
        if (user != null && user.equals(manager)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isPMO() {
        // Groups
        if (userInGroup(jiraAuthenticationContext.getLoggedInUser(), ImmutableList.of("Portfolio Administrators"))) {
            return true;
        }
        return false;
    }

    private boolean userInGroup(ApplicationUser user, List<String> groups) {
        for (String groupName : groupManager.getGroupNamesForUser(user)) {
            for (String inGroup : groups) {
                if (inGroup.equals(groupName)) {
                    return true;
                }
            }
        }
        return false;
    }
}
