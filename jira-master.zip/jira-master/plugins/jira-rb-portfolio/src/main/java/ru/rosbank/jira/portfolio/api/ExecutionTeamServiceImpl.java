package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.UserUtils;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.java.ao.Query;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.ofbiz.core.entity.jdbc.SQLProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.*;
import ru.rosbank.jira.common.exceptions.LoadRbStaffAllInfoException;
import ru.rosbank.jira.common.exceptions.LoadRbStaffDetailsException;
import ru.rosbank.jira.common.exceptions.LoadRbStaffInfoException;
import ru.rosbank.jira.common.exceptions.LoadRbStaffTeamsException;
import ru.rosbank.jira.portfolio.ao.ExecutionTeam;
import ru.rosbank.jira.portfolio.model.*;

import javax.inject.Inject;
import javax.inject.Named;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.collect.Lists.newArrayList;

@ExportAsService
@Named("executionTeamService")
public class ExecutionTeamServiceImpl implements ExecutionTeamService {

    private static final Logger LOG = LoggerFactory.getLogger(ExecutionTeamServiceImpl.class);
    private static String SEARCH_QUERY = "(LOWER(\"CODE\" COLLATE \"en_US\") LIKE ? OR LOWER(\"NAME\" COLLATE \"en_US\") LIKE ?) " +
            "AND UPPER(\"STATUS\") = 'ACTIVE'";
    private static String SEARCH_ALL_AGILE_QUERY = "\"AGILE\" = true " +
            "AND UPPER(\"STATUS\") = 'ACTIVE' " +
            "AND (\"START_DATE\" <=  now() OR \"START_DATE\" IS NULL) " +
            "AND (\"END_DATE\" >=  now() OR \"END_DATE\" IS NULL)";

    private static String SEARCH_AGILE_QUERY = "\"AGILE\" = true " +
            "AND UPPER(\"STATUS\") = 'ACTIVE' " +
            "AND (\"START_DATE\" <=  now() OR \"START_DATE\" IS NULL) " +
            "AND (\"END_DATE\" >=  now() OR \"END_DATE\" IS NULL) AND (" + SEARCH_QUERY + ")";

    private final ActiveObjects ao;
    private final ProjectPropertyService projectPropertyService;
    private final UserInfoService userInfoService;
    private final ConfigLoader config;
    private final ProjectManager projectManager;
    private final UserManager userManager;

    @Inject
    public ExecutionTeamServiceImpl(@ComponentImport ActiveObjects ao,
                                    @ComponentImport ProjectPropertyService projectPropertyService,
                                    @ComponentImport UserInfoService userInfoService,
                                    @ComponentImport ConfigLoader config) {
        this.ao = checkNotNull(ao);
        this.projectPropertyService = checkNotNull(projectPropertyService);
        this.userInfoService = checkNotNull(userInfoService);
        this.config = checkNotNull(config);

        this.projectManager = ComponentAccessor.getProjectManager();
        this.userManager = ComponentAccessor.getUserManager();
    }

    @Override
    public List<ExecutionTeam> all() {
        return newArrayList(ao.find(ExecutionTeam.class, Query.select()));
    }

    @Override
    public int total() {
        return ao.count(ExecutionTeam.class, Query.select());
    }

    @Override
    public ExecutionTeam getByCode(String code) {
        ExecutionTeam[] systems;
        systems = ao.find(ExecutionTeam.class, Query.select().where("\"CODE\" = ?", code));
        if (systems.length == 1) {
            return systems[0];
        }
        return null;
    }

    @Override
    public ExecutionTeam getByName(String name) {
        ExecutionTeam[] systems;
        systems = ao.find(ExecutionTeam.class, Query.select().where("\"NAME\" = ?", name));
        if (systems.length == 1) {
            return systems[0];
        }
        return null;
    }

    @Override
    public List<ExecutionTeam> search(String query, int limit, int offset) {
        if (Strings.isNullOrEmpty(query)) {
            return newArrayList(ao.find(ExecutionTeam.class,
                    Query.select()
                            .where("UPPER(\"STATUS\") = 'ACTIVE'")
                            .order("\"NAME\"")
                            .limit(limit)
                            .offset(offset)
            ));
        } else if (query.startsWith("agile_team#")) {
            String likeQuery = "%" + query.substring(11).toLowerCase() + "%";
            return newArrayList(ao.find(ExecutionTeam.class, Query.select()
                    .where(SEARCH_AGILE_QUERY, likeQuery, likeQuery)
                    .order("\"NAME\"")
                    .limit(limit)
                    .offset(offset)
            ));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return newArrayList(ao.find(ExecutionTeam.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery)
                .order("\"NAME\"")
                .limit(limit)
                .offset(offset)
        ));
    }

    @Override
    public int total(String query) {
        if (Strings.isNullOrEmpty(query)) {
            return total();
        } else if (query.startsWith("agile_team#")) {
            String likeQuery = "%" + query.substring(11).toLowerCase() + "%";
            return ao.count(ExecutionTeam.class, Query.select()
                    .where(SEARCH_QUERY, likeQuery, likeQuery));
        }
        String likeQuery = "%" + query.toLowerCase() + "%";
        return ao.count(ExecutionTeam.class, Query.select()
                .where(SEARCH_QUERY, likeQuery, likeQuery));
    }

    @Override
    public ExecutionTeamModel getAgileTeam(String codeOrName) {
        ExecutionTeam team;
        if (codeOrName.matches("A\\d{5}") || codeOrName.matches("F\\d{5}")) {
            team = getByCode(codeOrName);
        } else {
            team = getByName(codeOrName);
        }
        if (team != null) {
            Map<String, List<Project>> projectMap = getProjectMap();
            ExecutionTeamModel res = ExecutionTeamModel.convert(team);
            res.setProjects(projectMap.get(codeOrName));
            return res;
        }
        return null;
    }

    @Override
    public List<ExecutionTeamModel> getAgileTeams() {
        ExecutionTeam[] agileTeams = ao.find(ExecutionTeam.class, Query.select()
                .where(SEARCH_ALL_AGILE_QUERY)
                .order("\"NAME\"")
        );

        Map<String, List<Project>> projectMap = getProjectMap();
        return newArrayList(agileTeams).stream().map(
                team -> {
                    ExecutionTeamModel model = ExecutionTeamModel.convert(team);
                    List<Project> projects = projectMap.get(team.getCode());
                    model.setProjects(projects);
                    return model;
                }).collect(Collectors.toList());
    }

    @Override
    public void loadRbStaffTeams() throws LoadRbStaffTeamsException {

        // First load all digit rbStaff users
        try {
            loadRbStaffAllInfo();
        } catch (LoadRbStaffAllInfoException loax) {
            LOG.debug("Exception in loadRbStaffTeams() method", loax);
            throw new LoadRbStaffTeamsException(loax.getMessage(), loax.getStackTrace());
        }

        // Load teams and members
        String rbStaffUrl = config.getRbStaffUrl();
        int timeout = 10000;

        // Get Teams
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(getCredentialsProvider()).build()) {

            HttpGet httpMethod = new HttpGet(rbStaffUrl + "/api/Search/GetDigitTeamsByNameAsync");
            httpMethod.addHeader("Content-Type", "application/json");
            httpMethod.addHeader("charset", "UTF-8");
            httpMethod.setConfig(RequestConfig.custom().setAuthenticationEnabled(true)
                    .setConnectionRequestTimeout(timeout)
                    .setConnectTimeout(timeout)
                    .setRedirectsEnabled(true)
                    .setSocketTimeout(timeout)
                    .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .build());

            LOG.debug("Trying to get rbstaff teams info");
            try (CloseableHttpResponse response = httpClient.execute(httpMethod)) {
                String teamJson = EntityUtils.toString(response.getEntity());
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                Gson gson = gsonBuilder.create();
                Type jsonTypeOf = new TypeToken<ArrayList<RbstaffTeamModel>>() {
                }.getType();
                List<RbstaffTeamModel> teamModels = gson.fromJson(teamJson, jsonTypeOf);
                for (RbstaffTeamModel teamModel : teamModels) {
                    if (teamModel.getName().startsWith("Команды")) {
                        // Skip "teamType":null (Parent teams)
                        continue;
                    }
                    String teamType = ExecutionTeamType.getType(teamModel.getTeamType() == null ? null :
                            teamModel.getTeamType().replaceAll("Команды", "").trim()).name();

                    int teamId = teamModel.getDigitTeamId();
                    ExecutionTeam[] executionTeams = ao.find(ExecutionTeam.class, Query.select().where("\"EXTERNAL_ID\" = ?", teamId));
                    ExecutionTeam executionTeam;

                    String teamName = teamModel.getName();
                    Date startDate = teamModel.getStartDate();
                    Date endDate = teamModel.getEndDate();
                    String status = ExecutionTeamStatus.getStatus(startDate, endDate).name();
                    String costCenterCode = teamModel.getCostDigit();

                    if (executionTeams.length > 0) {
                        executionTeam = executionTeams[0];
                        executionTeam.setName(teamName);
                        executionTeam.setStatus(status);
                        executionTeam.setType(teamType);
                        executionTeam.setAgile(true);
                        executionTeam.setCostCenter(costCenterCode);
                        executionTeam.setStartDate(startDate);
                        executionTeam.setEndDate(endDate);
                        executionTeam.setLastUpdateDate(new Date());
                        executionTeam.save();
                    } else {
                        ImmutableMap.Builder<String, Object> mapBuilder = ImmutableMap.<String, Object>builder()
                                .put("NAME", teamName)
                                .put("CODE", "A00000")
                                .put("STATUS", status)
                                .put("TYPE", teamType)
                                .put("AGILE", true)
                                .put("COST_CENTER", costCenterCode != null ? costCenterCode : "")
                                .put("START_DATE", startDate)
                                .put("END_DATE", endDate)
                                .put("EXTERNAL_ID", teamModel.getDigitTeamId())
                                .put("LAST_UPDATE_DATE", new Date());
                        executionTeam = ao.create(ExecutionTeam.class, mapBuilder.build());

                        executionTeam.setCode("A" + Strings.padStart(String.valueOf(executionTeam.getID()), 5, '0'));
                        executionTeam.save();
                    }
                    if (executionTeam != null) {
                        UserInfoModel owner = loadRbStaffInfo(executionTeam).stream()
                                .filter(uim -> uim != null &&
                                        uim.getTeamRole() != null &&
                                        uim.getTeamRole().toLowerCase().contains("owner"))
                                .findAny().orElse(null);
                        if (owner != null) {
                            ApplicationUser ownerAppUser = userManager.getUserByName(owner.getUsername());
                            if (ownerAppUser != null && ownerAppUser.isActive()) {
                                executionTeam.setOwnerUserName(ownerAppUser.getUsername());
                                executionTeam.setOwnerFullName(ownerAppUser.getDisplayName());
                            } else {
                                executionTeam.setOwnerUserName(null);
                                executionTeam.setOwnerFullName(null);
                            }
                        } else {
                            executionTeam.setOwnerUserName(null);
                            executionTeam.setOwnerFullName(null);
                        }
                        executionTeam.save();
                    }
                }
            }
        } catch (Exception ex) {
            LOG.debug("Exception in loadRbStaffTeams() method", ex);
            throw new LoadRbStaffTeamsException(ex.getMessage(), ex.getStackTrace());
        }
    }

    private void loadRbStaffAllInfo() throws LoadRbStaffAllInfoException {
        String rbStaffUrl = config.getRbStaffUrl();
        int timeout = 3600000;

        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(getCredentialsProvider()).build()) {
            HttpPost httpMethod = new HttpPost(rbStaffUrl + "/api/Search");
            httpMethod.addHeader("Content-Type", "application/json");
            httpMethod.addHeader("charset", "UTF-8");
            httpMethod.setConfig(RequestConfig.custom().setAuthenticationEnabled(true)
                    .setConnectionRequestTimeout(timeout)
                    .setConnectTimeout(timeout)
                    .setRedirectsEnabled(true)
                    .setSocketTimeout(timeout)
                    .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .build());

            // (required) IBFS = eb898a3d-3f14-4a13-bd63-a3718e247f73
            StringEntity entity = new StringEntity("{\"textPattern\": \"%%%\", \"searchType\": \"1\", \"departId\": \"eb898a3d-3f14-4a13-bd63-a3718e247f73\"}", "UTF8");
            httpMethod.setEntity(entity);

            LOG.debug("Trying to get all rbstaff members");
            try (CloseableHttpResponse response = httpClient.execute(httpMethod)) {
                String json = EntityUtils.toString(response.getEntity());
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                Gson gson = gsonBuilder.create();
                Type rbstaffType = new TypeToken<ArrayList<RbstaffModel>>() {
                }.getType();
                List<RbstaffModel> rbstaff = gson.fromJson(json, rbstaffType);
                LOG.debug("@@@ rbstaff.size():"+rbstaff.size());
                int i = 1;
                for (RbstaffModel member : rbstaff) {
                    LOG.debug("@@@ i="+i);
                    i ++;
                    LOG.debug("RBStaff members: {}", member.toString());
                    String emailOrUsername = member.getEmail();
                    String role = member.getDigitRoleName();
                    if (emailOrUsername == null) {
                        LOG.error("There is no email for {} {}", member.getName(), member.getSurname());
                        RbstaffModel rbstaffModel = loadRbStaffDetails(member.getEmployeeId(), member.getStaffId());
                        if (rbstaffModel != null) {
                            emailOrUsername = rbstaffModel.getLogin();
                        }
                    }

                    if (emailOrUsername != null) {
                        ApplicationUser au = UserUtils.getUsersByEmail(emailOrUsername).stream().filter(
                                        user ->
                                                user.isActive() &&
                                                        user.getUsername().toLowerCase().matches("^(rb[0-9]|rbxmos[0-9]).*$"))
                                .findAny().orElse(null);
                        if (au == null) {
                            au = UserUtils.getUsersByEmail(emailOrUsername).stream().findAny().orElse(null);
                        }

                        if (au == null) {
                            au = userManager.getUserByName(emailOrUsername);
                        }

                        String depart = member.getDepart();
                        if ((au != null ) && (depart != null)) {
                            updateUserDepart(au.getUsername(), depart);
                        }
                        else LOG.debug("@@@ emailOrUsername is not au:" +emailOrUsername);

                        UserInfoModel uim = userInfoService.updateTeamMember(-1, emailOrUsername, role);
                    }
                }
                userInfoService.resetTeamMembers(-1);
            }
        } catch (LoadRbStaffDetailsException lridex) {
            LOG.error("LoadRbStaffDetailsException in LoadRbStaffAllInfo() method", lridex);
            throw new LoadRbStaffAllInfoException(lridex.getMessage(), lridex.getStackTrace());
        } catch (Exception ex) {
            LOG.error("Exception in LoadRbStaffAllInfo() method", ex);
            throw new LoadRbStaffAllInfoException(ex.getMessage(), ex.getStackTrace());
        }
    }

    public void updateUserDepart(String userName, String depart){
        SQLProcessor sqlProcessor = null;
        try {
            String strSQL = "UPDATE \"AO_D46467_USER_INFO\" SET ";
            String[] departs = depart.split("/");
            String departs7[] = {"", "", "", "", "", "", ""};
            for (int i = 0; i < departs.length; i ++){
                if (i > 6)  {
                    LOG.debug("@@@ userName:" +userName+ "depart > 7 will be ignored!!! :"+depart);
                    continue;
                }
                departs7[i] = departs[i];
            }

            strSQL +=   "\"DEPART1\" = '" + departs7[0].trim() + "'";
            strSQL += ", \"DEPART2\" = '" + departs7[1].trim() + "'";
            strSQL += ", \"DEPART3\" = '" + departs7[2].trim() + "'";
            strSQL += ", \"DEPART4\" = '" + departs7[3].trim() + "'";
            strSQL += ", \"DEPART5\" = '" + departs7[4].trim() + "'";
            strSQL += ", \"DEPART6\" = '" + departs7[5].trim() + "'";
            strSQL += ", \"DEPART7\" = '" + departs7[6].trim() + "'";
            strSQL += " WHERE \"USERNAME\" = '" + userName + "' ;";

            sqlProcessor = new SQLProcessor("defaultDS");
            sqlProcessor.prepareStatement(strSQL);

            int update = sqlProcessor.executeUpdate();
            LOG.debug("@@@ OK @@@ userName:" +userName+ "depart:"+depart);

            sqlProcessor.close();

        } catch (Exception ex) {
            LOG.error("Update: data error: {}" + ex);
        } finally {
            if (sqlProcessor != null) {
                try {
                    sqlProcessor.close();
                } catch (Exception e) {
                    LOG.error("Close: error: {}" + e);
                }
            }
        }
    }

    private List<UserInfoModel> loadRbStaffInfo(ExecutionTeam team) throws LoadRbStaffInfoException {
        String rbStaffUrl = config.getRbStaffUrl();
        int timeout = 10000;

        List<UserInfoModel> members = new ArrayList<>();
        // Get Teams
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(getCredentialsProvider()).build()) {
            HttpPost httpMethod = new HttpPost(rbStaffUrl + "/api/Search");
            httpMethod.addHeader("Content-Type", "application/json");
            httpMethod.addHeader("charset", "UTF-8");
            httpMethod.setConfig(RequestConfig.custom().setAuthenticationEnabled(true)
                    .setConnectionRequestTimeout(timeout)
                    .setConnectTimeout(timeout)
                    .setRedirectsEnabled(true)
                    .setSocketTimeout(timeout)
                    .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .build());

            StringEntity entity = new StringEntity("{\"textPattern\": \"" + team.getName() + "\",\"searchType\": \"21\"}", "UTF8");
            httpMethod.setEntity(entity);

            LOG.debug("Trying to get rbstaff team members {}", team.getName());
            try (CloseableHttpResponse response = httpClient.execute(httpMethod)) {
                String json = EntityUtils.toString(response.getEntity());
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                Gson gson = gsonBuilder.create();
                Type rbstaffType = new TypeToken<ArrayList<RbstaffModel>>() {
                }.getType();
                List<RbstaffModel> rbstaff = gson.fromJson(json, rbstaffType);

                LOG.info(" Found rbstaff for team {}: {}", team.getName(), rbstaff.size());
                int teamId = team.getID();
                userInfoService.resetTeamMembers(teamId);
                for (RbstaffModel member : rbstaff) {
                    String emailOrUsername = member.getEmail();
                    String role = member.getDigitRoleName();
                    if (emailOrUsername == null) {
                        LOG.error("There is no email for {} {}", member.getName(), member.getSurname());
                        RbstaffModel rbstaffModel = loadRbStaffDetails(member.getEmployeeId(), member.getStaffId());
                        if (rbstaffModel != null) {
                            emailOrUsername = rbstaffModel.getLogin();
                        }
                    }

                    UserInfoModel uim = null;
                    if (emailOrUsername != null) {
                        uim = userInfoService.updateTeamMember(teamId, emailOrUsername, role);
                    }

                    if (uim != null) {
                        members.add(uim);
                    } else {
                        RbstaffModel rbstaffModel = loadRbStaffDetails(member.getEmployeeId(), member.getStaffId());
                        if (rbstaffModel != null) {
                            emailOrUsername = rbstaffModel.getLogin();
                            if (emailOrUsername != null) {
                                uim = userInfoService.updateTeamMember(teamId, emailOrUsername, role);
                            }
                            if (uim != null) {
                                members.add(uim);
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            LOG.error("Exception in loadRbStaffInfo() method", ex);
            throw new LoadRbStaffInfoException(ex.getMessage(), ex.getStackTrace());
        }
        return members;
    }

    private RbstaffModel loadRbStaffDetails(String employeeId, String staffId) throws LoadRbStaffDetailsException {
        String rbStaffUrl = config.getRbStaffUrl();
        int timeout = 10000;

        try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(getCredentialsProvider()).build()) {
            HttpGet httpMethod = new HttpGet(rbStaffUrl + "/api/Employee/Details/" + employeeId + "/" + staffId);
            httpMethod.addHeader("Content-Type", "application/json");
            httpMethod.addHeader("charset", "UTF-8");
            httpMethod.setConfig(RequestConfig.custom().setAuthenticationEnabled(true)
                    .setConnectionRequestTimeout(timeout)
                    .setConnectTimeout(timeout)
                    .setRedirectsEnabled(true)
                    .setSocketTimeout(timeout)
                    .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.BASIC))
                    .build());


            LOG.debug("Trying to get rbstaff employee details {} {}", employeeId, staffId);
            try (CloseableHttpResponse response = httpClient.execute(httpMethod)) {
                String json = EntityUtils.toString(response.getEntity());
                GsonBuilder gsonBuilder = new GsonBuilder();
                gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                Gson gson = gsonBuilder.create();

                return gson.fromJson(json, new TypeToken<RbstaffModel>() {
                }.getType());
            }
        } catch (Exception ex) {
            LOG.error("Exception in LoadRbStaffDetails() method", ex);
            throw new LoadRbStaffDetailsException(ex.getMessage(), ex.getStackTrace());
        }
        //return null;
    }

    private CredentialsProvider getCredentialsProvider() {
        String rbStaffLogin = config.getRbStaffLogin();
        String rbStaffDomain = config.getRbStaffLoginDomain();
        String rbStaffPassword = config.getRbStaffPassword();

        NTCredentials webServiceCredentials = new NTCredentials(rbStaffLogin, rbStaffPassword, "", rbStaffDomain);
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(new AuthScope(AuthScope.ANY), webServiceCredentials);

        return credentialsProvider;
    }

    private Map<String, List<Project>> getProjectMap() {
        Map<String, List<Project>> projectMap = new HashMap<>();
        List<ProjectPropertyModel> pps = projectPropertyService.search("agile.team");
        if (pps != null) {
            for (ProjectPropertyModel pp : pps) {
                String teamCodes = pp.getValue();
                for (String teamCode : teamCodes.split(",")) {
                    List<Project> projects = projectMap.get(teamCode);
                    if (projects == null) {
                        projects = new ArrayList<>();
                    }
                    projects.add(projectManager.getProjectObj(pp.getProject()));
                    projectMap.put(teamCode, projects);
                }

            }
        }
        return projectMap;
    }
}
