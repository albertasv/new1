package ru.rosbank.jira.portfolio.api;

import com.atlassian.activeobjects.tx.Transactional;
import ru.rosbank.jira.portfolio.ao.CostCenter;
import ru.rosbank.jira.portfolio.model.CostCenterModel;

@Transactional
public interface CostCenterService extends DictionaryService<CostCenter> {
    
    CostCenter add(CostCenterModel data);

    CostCenter update(int id, CostCenterModel data);

    void delete(int id);
}
