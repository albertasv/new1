package ru.rosbank.jira.portfolio.ao;

import net.java.ao.Entity;
import net.java.ao.schema.NotNull;

import java.util.Date;

public interface Budget extends Entity {

    String EXTERNAL_BUDGET = "external";
    String INTERNAL_BUDGET = "internal";

    @NotNull
    String getIssue();

    @NotNull
    void setIssue(String issueKey);

    @NotNull
    Date getLastUpdateDate();

    @NotNull
    void setLastUpdateDate(Date lastUpdateDate);

    @NotNull
    String getLastUpdatedBy();

    @NotNull
    void setLastUpdatedBy(String lastUpdateBy);

    double getBudgetValue();

    void setBudgetValue(double value);

    Date getBudgetDate();

    void setBudgetDate(Date date);

    String getComment();

    String setComment(String comment);

    Boolean getInitial();

    void setInitial(Boolean initial);
}
