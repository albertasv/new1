package ru.rosbank.jira.portfolio.api;


import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.parser.JqlParseException;
import com.atlassian.jira.jql.parser.JqlQueryParser;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.query.Query;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.jira.common.api.ConfigLoader;

import javax.inject.Named;
import java.util.Collections;
import java.util.List;

@ExportAsService
@Named("portfolioService")
public class PortfolioServiceImpl implements PortfolioService {
    private static final Logger LOG = LoggerFactory.getLogger(PortfolioServiceImpl.class);

    private final ConfigLoader config;
    private final UserManager userManager;

    public PortfolioServiceImpl(@ComponentImport ConfigLoader config) {
        this.config = config;
        this.userManager = ComponentAccessor.getUserManager();
    }

    @Override
    public List<Issue> getPortfolioProjectEpics(String portfolioProject) {
        String syncUserLogin = config.getJiraPpmSyncUser();
        ApplicationUser syncUser = userManager.getUserByName(syncUserLogin);
        if (!Strings.isNullOrEmpty(portfolioProject)) {
            String jql = String.format("'Portfolio Project' = %s ORDER BY key", portfolioProject);
            try {
                Query query = ComponentAccessor.getComponent(JqlQueryParser.class).parseQuery(jql);
                SearchResults<Issue> searchResult = ComponentAccessor.getComponent(SearchService.class)
                        .search(syncUser, query, PagerFilter.getUnlimitedFilter());
                return searchResult.getResults();
            } catch (JqlParseException | SearchException ex) {
                LOG.error("Project Epic search exception", ex);
            }
        }
        return Collections.emptyList();
    }
}
