package ru.rosbank.jira.templates;

public class AddTaskProjectHook extends AddProjectHook {

    public AddTaskProjectHook() {
        super("TEMPLATE01");
    }
}
