package ru.rosbank.jira.templates;

public class AddAgileCommonProjectHook extends AddProjectHook {

    public AddAgileCommonProjectHook() {
        super("TEMPLATE02");
    }
}
