package ru.rosbank.jira.templates;

public class AddAgileSoftwareProjectHook extends AddProjectHook {

    public AddAgileSoftwareProjectHook() {
        super("TEMPLATE03");
    }
}
