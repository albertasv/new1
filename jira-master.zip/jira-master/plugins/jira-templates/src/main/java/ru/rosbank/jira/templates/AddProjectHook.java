package ru.rosbank.jira.templates;

import com.atlassian.jira.bc.projectroles.ProjectRoleService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.customfields.CustomFieldUtils;
import com.atlassian.jira.issue.fields.IssueTypeField;
import com.atlassian.jira.issue.fields.config.FieldConfigScheme;
import com.atlassian.jira.issue.fields.config.manager.FieldConfigSchemeManager;
import com.atlassian.jira.issue.fields.config.manager.PrioritySchemeManager;
import com.atlassian.jira.issue.fields.layout.field.FieldConfigurationScheme;
import com.atlassian.jira.issue.fields.layout.field.FieldLayoutManager;
import com.atlassian.jira.issue.fields.screen.issuetype.IssueTypeScreenScheme;
import com.atlassian.jira.issue.fields.screen.issuetype.IssueTypeScreenSchemeManager;
import com.atlassian.jira.permission.PermissionSchemeManager;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.project.template.hook.ConfigureData;
import com.atlassian.jira.project.template.hook.ConfigureResponse;
import com.atlassian.jira.project.template.hook.ValidateData;
import com.atlassian.jira.project.template.hook.ValidateResponse;
import com.atlassian.jira.scheme.Scheme;
import com.atlassian.jira.security.roles.ProjectRole;
import com.atlassian.jira.security.roles.ProjectRoleManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.SimpleErrorCollection;
import com.atlassian.jira.workflow.AssignableWorkflowScheme;
import com.atlassian.jira.workflow.migration.AssignableWorkflowSchemeMigrationHelper;
import com.atlassian.jira.workflow.migration.DefaultMigrationHelperFactory;
import com.atlassian.jira.workflow.migration.MigrationHelperFactory;
import org.ofbiz.core.entity.GenericEntityException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;


public class AddProjectHook implements com.atlassian.jira.project.template.hook.AddProjectHook {
    private static final Logger log = Logger.getLogger("ru.rosbank.jira.templates.AddProjectHook");

    private final String templateProjectKey;

    public AddProjectHook(String templateProjectKey) {
        this.templateProjectKey = templateProjectKey;
    }

    @Override
    public ValidateResponse validate(final ValidateData validateData) {
        ValidateResponse validateResponse = ValidateResponse.create();
        return validateResponse;
    }

    @Override
    public ConfigureResponse configure(final ConfigureData configureData) {
        ConfigureResponse configureResponse = ConfigureResponse.create();

        ProjectManager projectManager = ComponentAccessor.getProjectManager();
        Project templateProject = projectManager.getProjectByCurrentKey(templateProjectKey);
        Project newProject = configureData.project();

        // Update Issue Type Scheme
        IssueTypeField configurableField = ComponentAccessor.getFieldManager().getIssueTypeField();

        FieldConfigSchemeManager fieldConfigSchemeManager = ComponentAccessor.getFieldConfigSchemeManager();
        FieldConfigScheme fieldConfigScheme = fieldConfigSchemeManager.getFieldConfigScheme(
                ComponentAccessor.getIssueTypeSchemeManager().getConfigScheme(templateProject).getId());

        List<Long> projectIds = new ArrayList<>();
        projectIds.addAll(fieldConfigScheme.getAssociatedProjectIds());
        projectIds.add(newProject.getId());

        List contexts = CustomFieldUtils.buildJiraIssueContexts(false,
                projectIds.toArray(new Long[]{}), projectManager);
        fieldConfigSchemeManager.removeSchemeAssociation(contexts, configurableField);
        fieldConfigSchemeManager.updateFieldConfigScheme(fieldConfigScheme, contexts, configurableField);

        // Update Permission Scheme
        PermissionSchemeManager permissionSchemeManager = ComponentAccessor.getPermissionSchemeManager();
        Scheme defaultPermissionScheme = permissionSchemeManager.getSchemeFor(templateProject);
        permissionSchemeManager.removeSchemesFromProject(newProject);
        permissionSchemeManager.addSchemeToProject(newProject, defaultPermissionScheme);

        // Update Screens Scheme
        IssueTypeScreenSchemeManager issueTypeScreenSchemeManager = ComponentAccessor.getIssueTypeScreenSchemeManager();
        IssueTypeScreenScheme issueTypeScreenScheme = issueTypeScreenSchemeManager.getIssueTypeScreenScheme(templateProject);
        issueTypeScreenSchemeManager.addSchemeAssociation(newProject, issueTypeScreenScheme);

        // Update Fields Scheme
        FieldLayoutManager fieldLayoutManager = ComponentAccessor.getComponent(FieldLayoutManager.class);
        FieldConfigurationScheme fieldConfigurationScheme = fieldLayoutManager.getFieldConfigurationScheme(templateProject);
        if (fieldConfigurationScheme != null) {
            fieldLayoutManager.addSchemeAssociation(newProject, fieldConfigurationScheme.getId());
        }

        // Update Priority Scheme
        PrioritySchemeManager prioritySchemeManager = ComponentAccessor.getComponent(PrioritySchemeManager.class);
        FieldConfigScheme priorityScheme = prioritySchemeManager.getScheme(templateProject);
        if (priorityScheme != null) {
            prioritySchemeManager.assignProject(fieldConfigSchemeManager.getFieldConfigScheme(priorityScheme.getId()), newProject);
        }

        // Update workflow
        AssignableWorkflowScheme workflowScheme = ComponentAccessor.getWorkflowSchemeManager().getWorkflowSchemeObj(templateProject);
        MigrationHelperFactory migrationHelperFactory = ComponentAccessor.getComponent(DefaultMigrationHelperFactory.class);
        try {
            AssignableWorkflowSchemeMigrationHelper workflowSchemeMigrationHelper = migrationHelperFactory.createMigrationHelper(newProject, workflowScheme);
            workflowSchemeMigrationHelper.doQuickMigrate();
        } catch (GenericEntityException ex) {
//            log.error("New project creation failed", ex);
        }

        // Set Project Lead as Default Assignee
        projectManager.updateProject(newProject, newProject.getName(), newProject.getDescription(), newProject.getLeadUserKey(), newProject.getUrl(), 2l);

        // Set Project Lead as Administrators / Project Members /  Tempo Project Managers
        ApplicationUser projectLead = newProject.getProjectLead();
        ProjectRoleService prs = ComponentAccessor.getComponent(ProjectRoleService.class);
        ProjectRole adminRole = ComponentAccessor.getComponent(ProjectRoleManager.class).getProjectRole("Administrators");
        SimpleErrorCollection simpleErrorCollection = new SimpleErrorCollection();

        prs.addActorsToProjectRole(Arrays.asList(projectLead.getUsername()), adminRole, newProject, "atlassian-user-role-actor", simpleErrorCollection);
        if (simpleErrorCollection.hasAnyErrors()) {
            for (String msg : simpleErrorCollection.getErrorMessages()) {
                log.info("add user to project error msg: " + msg);
            }
        }

        return configureResponse;
    }
}
