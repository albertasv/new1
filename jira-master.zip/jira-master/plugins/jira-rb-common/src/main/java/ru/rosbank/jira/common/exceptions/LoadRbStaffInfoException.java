package ru.rosbank.jira.common.exceptions;

public class LoadRbStaffInfoException extends CustomException{

    public LoadRbStaffInfoException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }
}
