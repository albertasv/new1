package ru.rosbank.jira.common.exceptions;

public abstract class CustomException extends Exception {

    protected String message;

    public String getMessage() {
        return message;
    }
}
