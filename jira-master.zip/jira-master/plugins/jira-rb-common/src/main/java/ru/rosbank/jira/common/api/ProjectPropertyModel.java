package ru.rosbank.jira.common.api;


public interface ProjectPropertyModel {

    int getId();

    void setId(int id);

    Long getProject();

    void setProject(Long project);

    String getKey();

    void setKey(String key);

    String getValue();

    void setValue(String value);

}
