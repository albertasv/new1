package ru.rosbank.jira.common.api;

import java.util.Date;

public interface ClickLogModel {

    String getUsername();

    void setUsername(String username);

    String getTopic();

    void setTopic(String topic);

    int getClick();

    void setClick(int click);

    Date getLastUpdateDate();

    void setLastUpdateDate(Date lastUpdateDate);
}
