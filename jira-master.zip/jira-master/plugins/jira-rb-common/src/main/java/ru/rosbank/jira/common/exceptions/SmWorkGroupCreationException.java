package ru.rosbank.jira.common.exceptions;

public class SmWorkGroupCreationException extends CustomException {
    public SmWorkGroupCreationException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }
}
