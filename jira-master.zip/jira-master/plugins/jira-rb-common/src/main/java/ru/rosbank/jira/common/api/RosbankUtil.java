package ru.rosbank.jira.common.api;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RosbankUtil {


    public static String getJiraKey(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        return getJiraKey(text, text.length());
    }

    public static String getJiraKey(String text, int maxLength) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        int length = text.length();
        String regex = "([A-Z][A-Z0-9]+)-[0-9]+";
        text = length < maxLength ? text : text.substring(0, maxLength);
        Matcher m = Pattern.compile(regex).matcher(text);
        while (m.find()) {
            return m.group();
        }
        return null;
    }
}