package ru.rosbank.jira.common.exceptions;

public class LoadRbStaffAllInfoException extends CustomException{

    public LoadRbStaffAllInfoException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }
}
