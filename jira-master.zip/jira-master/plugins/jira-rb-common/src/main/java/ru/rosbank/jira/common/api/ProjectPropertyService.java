package ru.rosbank.jira.common.api;

import java.util.List;

public interface ProjectPropertyService {

    ProjectPropertyModel search(int propId);

    List<ProjectPropertyModel> search(Long project);

    List<ProjectPropertyModel> search(String key);

    ProjectPropertyModel search(Long project, String key);

    ProjectPropertyModel add(Long project, String key, String value);

    ProjectPropertyModel update(Long project, String key, String value);

    void delete(int propId);
}
