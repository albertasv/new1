package ru.rosbank.jira.common.api;

public interface UserInfoModel {

    String getUsername();

    void setUsername(String username);

    String getDisplayName();

    void setDisplayName(String displayName);

    String getEmail();

    void setEmail(String email);

    String getPhone();

    void setPhone(String phone);

    String getInternalPhone();

    void setInternalPhone(String phone);

    Boolean getExchangeIntegration();

    void setExchangeIntegration(Boolean exchange);

    Boolean getOof();

    void setOof(Boolean oof);

    String getOofMessage();

    void setOofMessage(String message);

    Integer getTeamId();

    void setTeamId(Integer teamId);

    String getTeam();

    void setTeam(String team);

    String getTeamRole();

    void setTeamRole(String role);

    String getEmployeeId();

    void setEmployeeId(String employeeId);

    String getStaffId();

    void setStaffId(String staffId);

    Boolean getCalendarSync();

    void setCalendarSync(Boolean calendarSync);

    String getPlanningIssue();

    void setPlanningIssue(String planningIssue);

    int getPriorityPlanningIssue();

    void setPriorityPlanningIssue(int priorityPlanningIssue);

    String getExcludedCategory();

    void setExcludedCategory(String excludedCategory);

    String getNews();

    void setNews(String news);
}
