package ru.rosbank.jira.common.api;

import java.util.List;

public interface UserInfoService {

    UserInfoModel add(UserInfoModel user);

    UserInfoModel update(UserInfoModel user);

    UserInfoModel getUserInfo(String username);

    UserInfoModel getUserInfo(String username, boolean withCache);

    List<UserInfoModel> getUserInfo(List<String> username);

    List<UserInfoModel> getUserInfoByTeam(int teamId);

    List<UserInfoModel> getUserInfoByOofStatus();

    List<UserInfoModel> getUserInfoByCalendarSync(boolean calendarSync);

    void resetTeamMembers(int teamId);

    UserInfoModel updateTeamMember(int teamId, String email, String role);
}
