package ru.rosbank.jira.common.exceptions;

public class LoadRbStaffTeamsException extends CustomException{

    public LoadRbStaffTeamsException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }
}
