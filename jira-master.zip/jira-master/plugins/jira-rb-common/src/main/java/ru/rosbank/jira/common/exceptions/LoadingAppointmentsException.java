package ru.rosbank.jira.common.exceptions;

public class LoadingAppointmentsException extends CustomException {

    public LoadingAppointmentsException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }

}
