package ru.rosbank.jira.common.api;

public interface ClickLogService {

    void addClickLog(String topic);
    
    void addClickLog(String username, String topic);
}
