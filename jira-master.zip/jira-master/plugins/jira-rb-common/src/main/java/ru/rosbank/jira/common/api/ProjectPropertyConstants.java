package ru.rosbank.jira.common.api;

public class ProjectPropertyConstants {

    /**
     * execute (default) or reassign - SM integration "Done" resolution behaviour
     */
    public static final String SM_RESOLUTION_DONE_ACTION = "sm.resolution.done.action";

    public static final String SM_RESOLUTION_DONE_ACTION_EXECUTE = "execute";
    public static final String SM_RESOLUTION_DONE_ACTION_REASSIGN = "reassign";


    public static final String SM_INTEGRATION_STATUS = "sm.integration.status";

    /**
     * Agile team linked to Jira project space
     */
    public static final String AGILE_TEAM = "agile.team";

    public static final String SYSTEMS_CONTEXT = "itSystems";

    /**
     * SM Workgroup to forward linked incident
     */

    public static final String FAVORITE_SM_WORKGROUPS = "favorite.sm.workgroups";
}
