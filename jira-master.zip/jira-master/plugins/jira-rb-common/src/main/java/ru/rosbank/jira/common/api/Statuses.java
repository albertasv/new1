package ru.rosbank.jira.common.api;

public enum Statuses {
    UPDATING("Database is being updating"),
    UPDATED("Database updating success"),
    UPDATED_WITH_ERRORS("During update process errors appeared"),
    FAILED("Unable to update database");

    private String message;

    Statuses(String s) {
        this.message = s;
    }

    public String getMessage(){
        return message;
    }
}
