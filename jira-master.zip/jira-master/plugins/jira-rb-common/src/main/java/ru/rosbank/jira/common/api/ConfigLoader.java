package ru.rosbank.jira.common.api;

public interface ConfigLoader {

    Long getPortfolioIssueFieldId();

    Long getPortfolioProjectFieldId();

    Long getPpmCodeFieldId();

    Long getDescriptionEnFieldId();

    Long getDomainFieldId();

    Long getCategoryFieldId();

    Long getCostCenterFieldId();

    Long getManagerFieldId();

    Long getISOfficerFieldId();

    Long getITArchitectFieldId();

    Long getExecutionTeamsFieldId();

    Long getItArchitectResolutionId();

    Long getIsOfficerResolutionId();

    Long getFinancialResolutionId();

    Long getIsOfficerClosingId();

    Long getStartDateFieldId();

    Long getRegDateFieldId();

    Long getEndInitialDateFieldId();

    Long getEndValidatedDateFieldId();

    Long getEndActualDateFieldId();

    Long getSteerCoFieldId();

    Long getSplitIssueLinkType();

    Long getRelatesIssueLinkType();

    Long getJiraIssueSourceFieldId();

    Long getJiraItSystemFieldId();

    Long getJiraImpactFieldId();

    Long getJiraSmNumberFieldId();

    Long getJiraServiceFieldId();

    Long getJiraStartDateFieldId();

    Long getJiraGroupFieldId();

    Long getJiraSmCauseReasonFieldId();

    Long getJiraSmAmountLinkedSdFieldId();

    Long getEnvironmentFoundFieldId();

    Long getJiraProblemSourceFieldId();

    Long getJiraProblemSourceFieldDefaultOptionId();

    Long getJiraChecklistsFieldId();

    Long getJiraSolutionFieldId();

    Long getJiraSmDeadlineFieldId();

    Long getJiraOrdinalPriorityFieldId();

    Long getJiraThemesFieldId();

    Long getJiraVendorFieldId();

    Long getJiraProjectAimsFieldId();

    Long getJiraProjectPerimeterFieldId();

    Long getJiraReadinessCriteriaFieldId();

    Long getSmWorkGroupFieldId();

    Long getSptTypeFieldId();

    Long getSyncedWithSmStatusFieldId();

    Long getActivityTypeFieldId();

    Long getTestEnvironmentFieldId();

    String getEnvironmentFoundProdOptionId();

    String getItArchitectResolutionName();

    String getITArchitectFieldName();

    String getJiraCRSProject();

    String getPortfolioIssueFieldName();

    String getJiraPRJProject();

    String getJiraPREProject();

    String getJiraArchitectProject();

    String getJiraISOfficeProject();

    String getJiraProblemProject();

    String getJiraEnvironment();

    String getPortfolioModelVersion();

    String getJiraPpmSyncUser();

    String getSptTypeProdOptionId();

    String getSbuWsLocation();

    String getSbuLogin();

    String getSbuPassword();

    String getSmUrl();

    String getSmActionUrl();

    String getSmAuth();

    String getSmLogin();

    String getSmPassword();

    String getJiraSmUser();

    String getEwsLogin();

    String getEwsPassword();

    String getRbStaffUrl();

    String getRbStaffLogin();

    String getRbStaffLoginDomain();

    String getRbStaffPassword();

    String getSyncedWithSmStatusFieldValue();

    String getSmReturnCode3Message();

    String getSmReturnCode51Message();

    String getSmReturnCode71Message();

    String getCalendarScheduling();

    String getWorklogScheduling();

    String getDauScheduling();

    String getCurrentFinancialYearScheduling();

    String getPreviousFinancialYearScheduling();

    String getRbStaffTeamsLoadingScheduling();

    String getSmReasonsUpdaterScheduling();

    String getSmMessagesQueueCleanerScheduling();

    String getServicesSyncStatusesCheckerScheduling();
}