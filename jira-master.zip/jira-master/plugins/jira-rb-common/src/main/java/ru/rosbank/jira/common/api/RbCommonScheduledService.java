package ru.rosbank.jira.common.api;

public interface RbCommonScheduledService {
    void reschedule();
}
