package ru.rosbank.jira.common.exceptions;

public class LoadRbStaffDetailsException extends CustomException {

    public LoadRbStaffDetailsException(String message, StackTraceElement[] stackTraceElements) {
        this.message = message;
        super.setStackTrace(stackTraceElements);
    }
}
