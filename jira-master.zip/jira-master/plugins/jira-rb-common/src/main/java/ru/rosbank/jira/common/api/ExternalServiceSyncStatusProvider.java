package ru.rosbank.jira.common.api;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.Date;

@Transactional
public interface ExternalServiceSyncStatusProvider {
    void writeStatus(ServiceNames system, Statuses status, String message, Date dateTime);
}
