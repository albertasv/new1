function toClipboard(e) {
    e = e || window.event;
    var target = e.target || e.srcElement || e;
    if (target.nodeType == 3) target = target.parentNode;
    var url = target.dataset.url;
    textToClipboard(window.location.origin + url);
    return false;
}

function textToClipboard(text) {
    var dummy = document.createElement("textarea");
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    document.body.appendChild(dummy);
    dummy.value = text;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}

function toDelete(e) {
    e = e || window.event;
    var target = e.target || e.srcElement || e;
    if (target.nodeType == 3) target = target.parentNode;

    var filename = target.dataset.filename;
    if (filename) {
        var res = window.confirm("Confirm deleting file: " + filename);
        if (res == true) {
            window.location.href = "/media/delete?filename=" + filename;
        }
    }
    return false;
}