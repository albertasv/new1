package ru.rosbank.ppmteam.media;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "media")
public class AppProperties {

    private String adminContact;
    private String mediaDoc;

    private String rootUrl;
    private String storage;
    private String tmpStorage;
    private Integer sizeTreshold;

    private String ldapUrl;
    private String ldapDomain;
    private String searchFilter;

    public String getAdminContact() {
        return adminContact;
    }

    public void setAdminContact(String adminContact) {
        this.adminContact = adminContact;
    }

    public String getMediaDoc() {
        return mediaDoc;
    }

    public void setMediaDoc(String mediaDoc) {
        this.mediaDoc = mediaDoc;
    }

    public String getRootUrl() {
        return rootUrl;
    }

    public void setRootUrl(String rootUrl) {
        this.rootUrl = rootUrl;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getTmpStorage() {
        return tmpStorage;
    }

    public void setTmpStorage(String tmpStorage) {
        this.tmpStorage = tmpStorage;
    }

    public Integer getSizeTreshold() {
        return sizeTreshold;
    }

    public void setSizeTreshold(Integer sizeTreshold) {
        this.sizeTreshold = sizeTreshold;
    }

    public String getLdapUrl() {
        return ldapUrl;
    }

    public void setLdapUrl(String ldapUrl) {
        this.ldapUrl = ldapUrl;
    }

    public String getLdapDomain() {
        return ldapDomain;
    }

    public void setLdapDomain(String ldapDomain) {
        this.ldapDomain = ldapDomain;
    }

    public String getSearchFilter() {
        return searchFilter;
    }

    public void setSearchFilter(String searchFilter) {
        this.searchFilter = searchFilter;
    }
}