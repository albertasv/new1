package ru.rosbank.ppmteam.media.web;

public class MediaData {

    private String filename;
    private String url;

    public MediaData(String root, String username, String filename) {
        this.filename = filename;
        this.url = root + "/" + username + "/" + filename;
    }

    public String getFilename() {
        return filename;
    }

    public String getUrl() {
        return url;
    }
}
