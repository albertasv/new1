package ru.rosbank.ppmteam.media;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;

@Configuration
@EnableWebSecurity
public class AppSecurityConfig extends WebSecurityConfigurerAdapter {
    private static final Logger log = LoggerFactory.getLogger(AppSecurityConfig.class);

    private final AppProperties appProps;

    public AppSecurityConfig(AppProperties appProps) {
        this.appProps = appProps;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/", "/css/*", "/webfonts/*", "/js/*", "/errors/*")
                .permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login")
                .permitAll()
                .and()
                .logout()
                .deleteCookies("JSESSIONID")
                .permitAll();
    }

    @Bean
    public ActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        ActiveDirectoryLdapAuthenticationProvider adProvider =
                new ActiveDirectoryLdapAuthenticationProvider("rosbank.rus.socgen", "ldaps://rsb-dc1mos000.rosbank.rus.socgen:636/");
        adProvider.setSearchFilter("(&(objectCategory=user)(sAMAccountName={1}))");
        // TODO Doesn't work with code below
        // new ActiveDirectoryLdapAuthenticationProvider(appProps.getLdapDomain(), appProps.getLdapUrl());
        // adProvider.setSearchFilter(appProps.getSearchFilter());
        return adProvider;
    }
}