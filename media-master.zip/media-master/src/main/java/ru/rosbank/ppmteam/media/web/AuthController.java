package ru.rosbank.ppmteam.media.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import ru.rosbank.ppmteam.media.AppProperties;

import java.security.Principal;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String login(Principal principal) {
        if (principal != null) {
            return "redirect:media";
        }
        return "login";
    }
}