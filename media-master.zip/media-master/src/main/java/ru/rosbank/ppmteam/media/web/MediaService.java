package ru.rosbank.ppmteam.media.web;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.rosbank.ppmteam.media.AppProperties;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@Component
public class MediaService {

    private static final Logger log = LoggerFactory.getLogger(MediaService.class);
    private final AppProperties appProps;

    public MediaService(AppProperties appProps) {
        this.appProps = appProps;
    }

    List<MediaData> list(String username) throws IOException {
        List<MediaData> res = new ArrayList<>();
        File userStorage = new File(appProps.getStorage(), username);
        if (userStorage.exists()) {
            if (userStorage.exists() && userStorage.isDirectory()) {
                Files.list(userStorage.toPath())
                        .sorted()
                        .forEach(path -> {
                            MediaData item = new MediaData(appProps.getRootUrl(), username, path.getFileName().toString());
                            res.add(item);
                        });
            }
        }
        return res;
    }

    public boolean upload(String username, FileItem fileItem) throws IOException {

        String uploadedFileName = fileItem.getName();

        File userStorage = new File(appProps.getStorage(), username);
        if (!userStorage.exists()) {
            userStorage.mkdir();
        }
        File uploadedFile = new File(userStorage, uploadedFileName);
        try (InputStream uploadedStream = fileItem.getInputStream();
             OutputStream out = new FileOutputStream(uploadedFile)) {
            IOUtils.copy(uploadedStream, out);
            log.debug("Saved file {}", uploadedFile);
        }
        return true;
    }

    public boolean delete(String username, String filename) {
        log.debug("Deleting for user: {}, file: {}", username, filename);

        File userStorage = new File(appProps.getStorage(), username);
        if (userStorage.exists() && userStorage.isDirectory()) {
            File file = new File(userStorage, filename);
            if (file.exists()) {
                try {
                    return file.delete();
                } catch (Exception ex) {
                    log.error("Delete file exception", ex);
                }
            }
        }
        return false;
    }
}
