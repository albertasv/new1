package ru.rosbank.ppmteam.media.web;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.rosbank.ppmteam.media.AppProperties;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.List;

@Controller
public class MediaController {

    private static final Logger log = LoggerFactory.getLogger(MediaController.class);

    private final AppProperties appProps;
    private final MediaService mediaService;

    public MediaController(AppProperties appProps, MediaService mediaService) {
        this.appProps = appProps;
        this.mediaService = mediaService;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/media")
    public String media(Principal principal, Model model) throws IOException {
        if (principal == null) {
            return "redirect:/login";
        }
        String username = getCurrentUser(principal);
        List<MediaData> mediaData = mediaService.list(username);
        model.addAttribute("username", username);
        model.addAttribute("mediaData", mediaData);

        return "media";
    }

    @PostMapping("/media/upload")
    public String handleUpload(Principal principal,
                               HttpServletRequest request,
                               RedirectAttributes redirectAttributes) throws Exception {

        if (principal == null) {
            return "redirect:/login";
        }
        String username = getCurrentUser(principal);
        DiskFileItemFactory factory = new DiskFileItemFactory();
        String tmpDir = appProps.getTmpStorage();
        if (tmpDir == null) {
            tmpDir = System.getProperty("java.io.tmpdir");
        }
        factory.setRepository(new File(tmpDir));
        int sizeThreshold = appProps.getSizeTreshold() != null ? appProps.getSizeTreshold()
                : DiskFileItemFactory.DEFAULT_SIZE_THRESHOLD;
        factory.setSizeThreshold(sizeThreshold);
        factory.setFileCleaningTracker(null);
        log.debug("Start uploading. Size treshold: {}.", sizeThreshold);

        ServletFileUpload upload = new ServletFileUpload(factory);

        List<FileItem> items = upload.parseRequest(request);
        String message = null;
        for (FileItem item : items) {
            if (!item.isFormField()) {
                if ("file".equals(item.getFieldName())) {
                    if (item.getName() == null || item.getName().isEmpty()) {
                        message = "No file was been selected";
                    } else if (item.getSize() == 0) {
                        message = "No file was been selected, or it was an empty file";
                    } else {
                        if (mediaService.upload(username, item)) {
                            message = String.format("File \"%s\" was successfully uploaded!", item.getName());
                        }
                    }
                }
            }
        }

        if (message != null) {
            redirectAttributes.addFlashAttribute("message", message);
        }
        log.debug("Finish uploading");
        return "redirect:/media";
    }

    @GetMapping("/media/delete")
    public String handleDelete(Principal principal,
                               @RequestParam String filename,
                               RedirectAttributes redirectAttributes) {
        String message;

        if (mediaService.delete(getCurrentUser(principal), filename)) {
            message = String.format("File \"%s\" was deleted.", filename);
        } else {
            message = String.format("File \"%s\" was deleted. Please contact administrators: ", filename, appProps.getAdminContact());
        }
        if (message != null) {
            redirectAttributes.addFlashAttribute("message", message);
        }
        return "redirect:/media";
    }

    private String getCurrentUser(Principal principal) {
        return principal.getName();
    }
}