package ru.rosbank.ppmteam.shortener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import ru.rosbank.ppmteam.shortener.database.Link;
import ru.rosbank.ppmteam.shortener.database.LinkRepo;

import java.util.List;


@Component
public class ShortenerService {

    private static final Logger log = LoggerFactory.getLogger(ShortenerService.class);
    private final AppProperties appProps;
    private final LinkRepo linkRepo;

    public ShortenerService(AppProperties appProps,
                            LinkRepo linkRepo) {
        this.appProps = appProps;
        this.linkRepo = linkRepo;
    }


    public String getLinkWithStat(String shortener) {
        Link link = linkRepo.findOneByShortener(shortener);
        if (link != null) {
            // Update stat
            link.setStat(link.getStat() + 1);
            linkRepo.save(link);

            return link.getLink();
        }
        return null;
    }

    public Link getLink(String shortener) {
        Link link = linkRepo.findOneByShortener(shortener);
        if (link != null) {
            return link;
        }
        return null;
    }

    public void addLink(String createdBy, String shortener, String link) {
        Link addLink = new Link();
        addLink.setStat(0);
        addLink.setShortener(shortener);
        addLink.setLink(link);
        addLink.setCreatedBy(createdBy);
        linkRepo.save(addLink);
    }

    public void updateLink(String shortener, String link) {
        Link addLink = linkRepo.findOneByShortener(shortener);
        addLink.setStat(0);
        addLink.setShortener(shortener);
        addLink.setShortener(link);
        linkRepo.save(addLink);
    }

    public List<Link> getLinks() {
        Pageable page = PageRequest.of(0, 100, Sort.by("id").descending());
        return linkRepo.findAll(page).toList();
    }

    public void remove(Long remove) {
        linkRepo.deleteById(remove);
    }
}
