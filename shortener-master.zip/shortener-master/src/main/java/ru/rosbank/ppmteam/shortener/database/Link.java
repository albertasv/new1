package ru.rosbank.ppmteam.shortener.database;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
public class Link implements Serializable {

    @Id
    @GeneratedValue
    @Column(nullable = false)
    private Long id;

    @Column(unique = true, nullable = false)
    private String shortener;
    @Column(nullable = false)
    private String link;
    private long stat;

    @Column(name = "created_by")
    private String createdBy;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getShortener() {
        return shortener;
    }

    public void setShortener(String shortener) {
        this.shortener = shortener;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public long getStat() {
        return stat;
    }

    public void setStat(long stat) {
        this.stat = stat;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
}
