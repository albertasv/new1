package ru.rosbank.ppmteam.shortener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.rosbank.ppmteam.shortener.database.Link;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.List;

@Controller
public class ShortenerController {

    private static final Logger log = LoggerFactory.getLogger(ShortenerController.class);

    private final AppProperties appProps;
    private final ShortenerService shortenerService;

    public ShortenerController(AppProperties appProps, ShortenerService shortenerService) {
        this.appProps = appProps;
        this.shortenerService = shortenerService;
    }


    @GetMapping("/")
    public String index() {
        return "index";
    }

    /**
     * @param principal
     * @param model
     * @return
     */
    @GetMapping("/admin")
    public String admin(
            HttpServletRequest request,
            Principal principal, Model model) {
        if (principal == null) {
            return "redirect:/login";
        }

        String username = getCurrentUser(principal);
        model.addAttribute("ctxPath", request.getContextPath());
        model.addAttribute("username", username);

        List<Link> links = shortenerService.getLinks();
        model.addAttribute("links", links);

        return "admin";
    }

    @PostMapping("/admin")
    public String admin(
            HttpServletRequest request,
            Principal principal,
            Model model,
            @RequestParam(required = false) String shortener,
            @RequestParam(required = false) String link) {
        if (principal == null) {
            return "redirect:/login";
        }

        String username = getCurrentUser(principal);
        if (shortener != null && link != null) {
            Link addLink = shortenerService.getLink(shortener);
            if (addLink != null) {
                model.addAttribute("message", "There is the link with key " + shortener);
            } else {
                shortenerService.addLink(username, shortener, link);
            }
        }

        return admin(request, principal, model);
    }

    @GetMapping("/link")
    public String link(@RequestParam String shortener) {
        return redirect(shortener);
    }

    @GetMapping("/{shortener}")
    public String redirect(@PathVariable String shortener) {
        String link = shortenerService.getLinkWithStat(shortener);
        if (link == null) {
            return "index";
        }
        return "redirect:" + link;
    }

    /**
     * @param principal
     * @param model
     * @return
     */
    @GetMapping("/remove")
    public String remove(Principal principal, Model model,
                         @RequestParam Long id) {
        if (principal == null) {
            return "redirect:/login";
        }

        String username = getCurrentUser(principal);
        model.addAttribute("username", username);

        if (id != null) {
            shortenerService.remove(id);
        }
        return "redirect:admin";
    }

    private String getCurrentUser(Principal principal) {
        return principal.getName();
    }

}